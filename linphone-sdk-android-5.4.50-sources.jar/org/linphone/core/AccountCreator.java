/*
AccountCreator.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* The object used to configure an account on a server via XML-RPC, see<br/>
* https://wiki.linphone.org/xwiki/wiki/public/view/Lib/Features/Override%20account%20creator%20request/.<br/>
* <br/>
*/
public interface AccountCreator {
    public enum TransportStatus {
        /**
        * Transport ok. <br/>
        * <br/>
        */
        Ok(0),

        /**
        * Transport invalid. <br/>
        * <br/>
        */
        Unsupported(1);

        protected final int mValue;

        private TransportStatus (int value) {
            mValue = value;
        }

        static public TransportStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            case 1: return Unsupported;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for TransportStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum DomainStatus {
        /**
        * Domain ok. <br/>
        * <br/>
        */
        Ok(0),

        /**
        * Domain invalid. <br/>
        * <br/>
        */
        Invalid(1);

        protected final int mValue;

        private DomainStatus (int value) {
            mValue = value;
        }

        static public DomainStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            case 1: return Invalid;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for DomainStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum ActivationCodeStatus {
        /**
        * Activation code ok. <br/>
        * <br/>
        */
        Ok(0),

        /**
        * Activation code too short. <br/>
        * <br/>
        */
        TooShort(1),

        /**
        * Activation code too long. <br/>
        * <br/>
        */
        TooLong(2),

        /**
        * Contain invalid characters. <br/>
        * <br/>
        */
        InvalidCharacters(3);

        protected final int mValue;

        private ActivationCodeStatus (int value) {
            mValue = value;
        }

        static public ActivationCodeStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            case 1: return TooShort;
            case 2: return TooLong;
            case 3: return InvalidCharacters;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for ActivationCodeStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum AlgoStatus {
        /**
        * Algorithm ok. <br/>
        * <br/>
        */
        Ok(0),

        /**
        * Algorithm not supported. <br/>
        * <br/>
        */
        NotSupported(1);

        protected final int mValue;

        private AlgoStatus (int value) {
            mValue = value;
        }

        static public AlgoStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            case 1: return NotSupported;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for AlgoStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum LanguageStatus {
        /**
        * Language ok. <br/>
        * <br/>
        */
        Ok(0);

        protected final int mValue;

        private LanguageStatus (int value) {
            mValue = value;
        }

        static public LanguageStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for LanguageStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum PasswordStatus {
        /**
        * Password ok. <br/>
        * <br/>
        */
        Ok(0),

        /**
        * Password too short. <br/>
        * <br/>
        */
        TooShort(1),

        /**
        * Password too long. <br/>
        * <br/>
        */
        TooLong(2),

        /**
        * Contain invalid characters. <br/>
        * <br/>
        */
        InvalidCharacters(3),

        /**
        * Missing specific characters. <br/>
        * <br/>
        */
        MissingCharacters(4);

        protected final int mValue;

        private PasswordStatus (int value) {
            mValue = value;
        }

        static public PasswordStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            case 1: return TooShort;
            case 2: return TooLong;
            case 3: return InvalidCharacters;
            case 4: return MissingCharacters;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for PasswordStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum EmailStatus {
        /**
        * Email ok. <br/>
        * <br/>
        */
        Ok(0),

        /**
        * Email malformed. <br/>
        * <br/>
        */
        Malformed(1),

        /**
        * Contain invalid characters. <br/>
        * <br/>
        */
        InvalidCharacters(2);

        protected final int mValue;

        private EmailStatus (int value) {
            mValue = value;
        }

        static public EmailStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            case 1: return Malformed;
            case 2: return InvalidCharacters;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for EmailStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum UsernameStatus {
        /**
        * Username ok. <br/>
        * <br/>
        */
        Ok(0),

        /**
        * Username too short. <br/>
        * <br/>
        */
        TooShort(1),

        /**
        * Username too long. <br/>
        * <br/>
        */
        TooLong(2),

        /**
        * Contain invalid characters. <br/>
        * <br/>
        */
        InvalidCharacters(3),

        /**
        * Invalid username. <br/>
        * <br/>
        */
        Invalid(4);

        protected final int mValue;

        private UsernameStatus (int value) {
            mValue = value;
        }

        static public UsernameStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            case 1: return TooShort;
            case 2: return TooLong;
            case 3: return InvalidCharacters;
            case 4: return Invalid;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for UsernameStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Backend {
        /**
        * XMLRPC Backend. <br/>
        * <br/>
        */
        XMLRPC(0),

        /**
        * FlexiAPI Backend. <br/>
        * <br/>
        */
        FlexiAPI(1);

        protected final int mValue;

        private Backend (int value) {
            mValue = value;
        }

        static public Backend fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return XMLRPC;
            case 1: return FlexiAPI;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Backend");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum PhoneNumberStatus {
        /**
        * Phone number ok. <br/>
        * <br/>
        */
        Ok(1),

        /**
        * Phone number too short. <br/>
        * <br/>
        */
        TooShort(2),

        /**
        * Phone number too long. <br/>
        * <br/>
        */
        TooLong(4),

        /**
        * Country code invalid. <br/>
        * <br/>
        */
        InvalidCountryCode(8),

        /**
        * Phone number invalid. <br/>
        * <br/>
        */
        Invalid(16);

        protected final int mValue;

        private PhoneNumberStatus (int value) {
            mValue = value;
        }

        static public PhoneNumberStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 1: return Ok;
            case 2: return TooShort;
            case 4: return TooLong;
            case 8: return InvalidCountryCode;
            case 16: return Invalid;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for PhoneNumberStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Status {
        /**
        * Request status. <br/>
        * <br/>
        * Request passed <br/>
        */
        RequestOk(0),

        /**
        * Request failed. <br/>
        * <br/>
        */
        RequestFailed(1),

        /**
        * Request failed due to missing argument(s) <br/>
        * <br/>
        */
        MissingArguments(2),

        /**
        * Request failed due to missing callback(s) <br/>
        * <br/>
        */
        MissingCallbacks(3),

        /**
        * Account status. <br/>
        * <br/>
        * Account created <br/>
        */
        AccountCreated(4),

        /**
        * Account not created. <br/>
        * <br/>
        */
        AccountNotCreated(5),

        /**
        * Account exist. <br/>
        * <br/>
        */
        AccountExist(6),

        /**
        * Account exist with alias. <br/>
        * <br/>
        */
        AccountExistWithAlias(7),

        /**
        * Account not exist. <br/>
        * <br/>
        */
        AccountNotExist(8),

        /**
        * Account was created with Alias. <br/>
        * <br/>
        */
        AliasIsAccount(9),

        /**
        * Alias exist. <br/>
        * <br/>
        */
        AliasExist(10),

        /**
        * Alias not exist. <br/>
        * <br/>
        */
        AliasNotExist(11),

        /**
        * Account activated. <br/>
        * <br/>
        */
        AccountActivated(12),

        /**
        * Account already activated. <br/>
        * <br/>
        */
        AccountAlreadyActivated(13),

        /**
        * Account not activated. <br/>
        * <br/>
        */
        AccountNotActivated(14),

        /**
        * Account linked. <br/>
        * <br/>
        */
        AccountLinked(15),

        /**
        * Account not linked. <br/>
        * <br/>
        */
        AccountNotLinked(16),

        /**
        * Server. <br/>
        * <br/>
        * Error server <br/>
        */
        ServerError(17),

        /**
        * Error cannot send SMS. <br/>
        * <br/>
        */
        PhoneNumberInvalid(18),

        /**
        * Error key doesn't match. <br/>
        * <br/>
        */
        WrongActivationCode(19),

        /**
        * Error too many SMS sent. <br/>
        * <br/>
        */
        PhoneNumberOverused(20),

        /**
        * Error algo isn't MD5 or SHA-256. <br/>
        * <br/>
        */
        AlgoNotSupported(21),

        /**
        * Generic error. <br/>
        * <br/>
        */
        UnexpectedError(22),

        /**
        * This API isn't implemented in the current backend. <br/>
        * <br/>
        */
        NotImplementedError(23),

        /**
        * Request has been denied, probably due to invalid auth token. <br/>
        * <br/>
        */
        RequestNotAuthorized(24),

        /**
        * Request has been denied, due to too many requests sent in given period. <br/>
        * <br/>
        */
        RequestTooManyRequests(25);

        protected final int mValue;

        private Status (int value) {
            mValue = value;
        }

        static public Status fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return RequestOk;
            case 1: return RequestFailed;
            case 2: return MissingArguments;
            case 3: return MissingCallbacks;
            case 4: return AccountCreated;
            case 5: return AccountNotCreated;
            case 6: return AccountExist;
            case 7: return AccountExistWithAlias;
            case 8: return AccountNotExist;
            case 9: return AliasIsAccount;
            case 10: return AliasExist;
            case 11: return AliasNotExist;
            case 12: return AccountActivated;
            case 13: return AccountAlreadyActivated;
            case 14: return AccountNotActivated;
            case 15: return AccountLinked;
            case 16: return AccountNotLinked;
            case 17: return ServerError;
            case 18: return PhoneNumberInvalid;
            case 19: return WrongActivationCode;
            case 20: return PhoneNumberOverused;
            case 21: return AlgoNotSupported;
            case 22: return UnexpectedError;
            case 23: return NotImplementedError;
            case 24: return RequestNotAuthorized;
            case 25: return RequestTooManyRequests;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Status");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Assign a proxy config pointer to the LinphoneAccountCreator. <br/>
    * <br/>
    * @param account The LinphoneAccount to associate with the<br/>
    * LinphoneAccountCreator.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void setAccount(@Nullable Account account);

    /**
    * Get the account creation request token received to be used to check user<br/>
    * validation. <br/>
    * <br/>
    * @return The token set, if any   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getAccountCreationRequestToken();

    /**
    * Set the account creation request token received to be used to check user<br/>
    * validation. <br/>
    * <br/>
    * @param token The token to set   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void setAccountCreationRequestToken(@Nullable String token);

    /**
    * Get the activation code. <br/>
    * <br/>
    * @return The activation code of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getActivationCode();

    /**
    * Set the activation code. <br/>
    * <br/>
    * @param activationCode The activation code to set   <br/>
    * @return {@link ActivationCodeStatus#Ok} if everything is OK, or a specific<br/>
    * error otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.ActivationCodeStatus setActivationCode(@Nullable String activationCode);

    /**
    * Get the algorithm configured in the account creator. <br/>
    * <br/>
    * @return The algorithm of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getAlgorithm();

    /**
    * Set the supported algorithm. <br/>
    * <br/>
    * @param algorithm The algorithm to use   <br/>
    * @return LinphoneAccountCreatorAlgoStatusOk if everything is OK, or a specific<br/>
    * error otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.AlgoStatus setAlgorithm(@Nullable String algorithm);

    /**
    * Set the set_as_default property. <br/>
    * <br/>
    * @param setAsDefault true for the created proxy config to be set as default in<br/>
    * {@link Core}, false otherwise <br/>
    * @return {@link Status#RequestOk} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status setAsDefault(boolean setAsDefault);

    /**
    * Get the display name. <br/>
    * <br/>
    * @return The display name of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getDisplayName();

    /**
    * Set the display name. <br/>
    * <br/>
    * @param displayName The display name to set   <br/>
    * @return {@link UsernameStatus#Ok} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.UsernameStatus setDisplayName(@Nullable String displayName);

    /**
    * Get the domain. <br/>
    * <br/>
    * @return The domain of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getDomain();

    /**
    * Set the domain. <br/>
    * <br/>
    * @param domain The domain to set   <br/>
    * @return {@link DomainStatus#Ok} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.DomainStatus setDomain(@Nullable String domain);

    /**
    * Get the email. <br/>
    * <br/>
    * @return The email of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getEmail();

    /**
    * Set the email. <br/>
    * <br/>
    * @param email The email to set   <br/>
    * @return {@link EmailStatus#Ok} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.EmailStatus setEmail(@Nullable String email);

    /**
    * Get the ha1. <br/>
    * <br/>
    * @return The ha1 of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getHa1();

    /**
    * Set the ha1. <br/>
    * <br/>
    * @param ha1 The ha1 to set   <br/>
    * @return {@link PasswordStatus#Ok} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.PasswordStatus setHa1(@Nullable String ha1);

    /**
    * Get the language use in email of SMS. <br/>
    * <br/>
    * @return The language of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getLanguage();

    /**
    * Set the language to use in email or SMS if supported. <br/>
    * <br/>
    * @param lang The language to use   <br/>
    * @return {@link LanguageStatus#Ok} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.LanguageStatus setLanguage(@Nullable String lang);

    /**
    * Get the password. <br/>
    * <br/>
    * @return The password of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getPassword();

    /**
    * Set the password. <br/>
    * <br/>
    * @param password The password to set   <br/>
    * @return {@link PasswordStatus#Ok} if everything is OK, or specific(s) error(s)<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.PasswordStatus setPassword(@Nullable String password);

    /**
    * Get the international prefix. <br/>
    * <br/>
    * @return The international prefix (or phone country code) of the {@link AccountCreator}<br/>
    * .   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getPhoneCountryCode();

    /**
    * Get the RFC 3966 normalized phone number. <br/>
    * <br/>
    * @return The phone number of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getPhoneNumber();

    /**
    * Get the param to be used by the backend to send the push notification to the<br/>
    * device asking for an auth token. <br/>
    * <br/>
    * @return The pn_param set, if any   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getPnParam();

    /**
    * Set the param to be used by the backend to send the push notification to the<br/>
    * device asking for an auth token. <br/>
    * <br/>
    * @param pnParam The pn_param to set   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void setPnParam(@Nullable String pnParam);

    /**
    * Get the prid to be used by the backend to send the push notification to the<br/>
    * device asking for an auth token. <br/>
    * <br/>
    * @return The pn_prid set, if any   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getPnPrid();

    /**
    * Set the prid to be used by the backend to send the push notification to the<br/>
    * device asking for an auth token. <br/>
    * <br/>
    * @param pnPrid The pn_prid to set   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void setPnPrid(@Nullable String pnPrid);

    /**
    * Get the provider to be used by the backend to send the push notification to the<br/>
    * device asking for an auth token. <br/>
    * <br/>
    * @return The pn_provider set, if any   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getPnProvider();

    /**
    * Set the provider to be used by the backend to send the push notification to the<br/>
    * device asking for an auth token. <br/>
    * <br/>
    * @param pnProvider The pn_provider to set   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void setPnProvider(@Nullable String pnProvider);

    /**
    * Assign a proxy config pointer to the LinphoneAccountCreator. <br/>
    * <br/>
    * @param cfg The LinphoneProxyConfig to associate with the<br/>
    * LinphoneAccountCreator.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void setProxyConfig(@Nullable ProxyConfig cfg);

    /**
    * Get the route. <br/>
    * <br/>
    * @return The route of the {@link AccountCreator}.   <br/>
    */
    @Nullable
    public String getRoute();

    /**
    * Set the route. <br/>
    * <br/>
    * @param route The route to set   <br/>
    * @return {@link Status#RequestOk} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    */
    public AccountCreator.Status setRoute(@Nullable String route);

    /**
    * Get the set_as_default property. <br/>
    * <br/>
    * @return true if account will be set as default, false otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public boolean getSetAsDefault();

    /**
    * Get the authentication token set (if any) to be used to authenticate next<br/>
    * queries, if required. <br/>
    * <br/>
    * @return The token set, if any   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getToken();

    /**
    * Set the authentication token received by push notification to be used to<br/>
    * authenticate next queries, if required. <br/>
    * <br/>
    * @param token The token to set   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void setToken(@Nullable String token);

    /**
    * Get Transport. <br/>
    * <br/>
    * @return The {@link TransportType} of the creator. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public TransportType getTransport();

    /**
    * Set Transport. <br/>
    * <br/>
    * @param transport The {@link TransportType} to set <br/>
    * @return {@link TransportStatus#Ok} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.TransportStatus setTransport(TransportType transport);

    /**
    * Get the username. <br/>
    * <br/>
    * @return The username of the {@link AccountCreator}.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public String getUsername();

    /**
    * Set the username. <br/>
    * <br/>
    * @param username The username to set   <br/>
    * @return {@link UsernameStatus#Ok} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.UsernameStatus setUsername(@Nullable String username);

    /**
    * Send a request to activate an account on server. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status activateAccount();

    /**
    * Send a request to activate an alias. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status activateAlias();

    /**
    * Send a request to create an account on server. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status createAccount();

    /**
    * Create and configure a {@link Account} and a {@link AuthInfo} from informations<br/>
    * set in the {@link AccountCreator}. <br/>
    * <br/>
    * @return A {@link Account} object if successful, null otherwise.     <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @Nullable
    public Account createAccountInCore();

    /**
    * Create and configure a proxy config and a authentication info for an account<br/>
    * creator. <br/>
    * <br/>
    * @return A {@link ProxyConfig} object if successful, null otherwise.   <br/>
    * @deprecated 05/05/2023 Use {@link #createAccountInCore} instead. <br/>
    */
    @Deprecated
    @Nullable
    public ProxyConfig createProxyConfig();

    /**
    * Send a request to create a push account on server. <br/>
    * <br/>
    * Push accounts are used in account dependent situation when account cannot send<br/>
    * push notifications. A username and password are automatically generated, an<br/>
    * account is automatically activated. <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status createPushAccount();

    /**
    * Send a request to know if an account is activated on server. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status isAccountActivated();

    /**
    * Send a request to know the existence of account on server. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status isAccountExist();

    /**
    * Send a request to know if an account is linked. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status isAccountLinked();

    /**
    * Send a request to know if an alias is used. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status isAliasUsed();

    /**
    * Send a request to link an account to an alias. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status linkAccount();

    /**
    * Send a request to get the password & algorithm of an account using the<br/>
    * confirmation key. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status loginLinphoneAccount();

    /**
    * Send a request to recover an account. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status recoverAccount();

    /**
    * Request an account creation "request_token" to be used on account creations. <br/>
    * <br/>
    * The request_token is retrieved from the callback<br/>
    * linphone_account_creator_cbs_get_account_creation_request_token <br/>
    * @return {@link Status#RequestOk} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status requestAccountCreationRequestToken();

    /**
    * Send a request to get a token to be used for account creation from a<br/>
    * request_token. <br/>
    * <br/>
    * The token is retrieved from the callback<br/>
    * linphone_account_creator_cbs_get_account_creation_token_using_request_token <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status requestAccountCreationTokenUsingRequestToken();

    /**
    * Request an auth token to be send by the backend by push notification. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if everything is OK, or a specific error<br/>
    * otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status requestAuthToken();

    /**
    * Reset the account creator entries like username, password, phone number... <br/>
    * <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void reset();

    /**
    * Set the phone number normalized. <br/>
    * <br/>
    * @param phoneNumber The phone number to set   <br/>
    * @param countryCode Country code to associate phone number with   <br/>
    * @return {@link PhoneNumberStatus#Ok} if everything is OK, or specific(s)<br/>
    * error(s) otherwise. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public int setPhoneNumber(@Nullable String phoneNumber, @Nullable String countryCode);

    /**
    * Send a request to update an account. <br/>
    * <br/>
    * @return {@link Status#RequestOk} if the request has been sent, {@link Status#RequestFailed}<br/>
    * otherwise <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public AccountCreator.Status updateAccount();

    /**
    * Require the account creator to use special "test admin account". <br/>
    * <br/>
    * warning: The "test admin account" is a special feature required for automated<br/>
    * test, and requires the APP_EVERYONE_IS_ADMIN property to be enabled on the<br/>
    * remote Flexisip Account Manager (FlexiAPI). This feature must never be turned<br/>
    * on for a production-stage app. <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    public void useTestAdminAccount();

    /**
    * Create a {@link AccountCreator} and set Linphone Request callbacks. <br/>
    * <br/>
    * @param core The {@link Core} used for the XML-RPC communication   <br/>
    * @return The new {@link AccountCreator} object.   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    @Deprecated
    @NonNull
    public AccountCreator create(@NonNull Core core);

    /**
    */
    public void addListener(AccountCreatorListener listener);

    /**
    */
    public void removeListener(AccountCreatorListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AccountCreatorImpl implements AccountCreator {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AccountCreatorImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native void setAccount(long nativePtr, Account account);
    @Override
    synchronized public void setAccount(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccount(nativePtr, account);
    }

    private native String getAccountCreationRequestToken(long nativePtr);
    @Override @Nullable
    synchronized public String getAccountCreationRequestToken()  {
        
        
        return getAccountCreationRequestToken(nativePtr);
    }

    private native void setAccountCreationRequestToken(long nativePtr, String token);
    @Override
    synchronized public void setAccountCreationRequestToken(@Nullable String token)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccountCreationRequestToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccountCreationRequestToken(nativePtr, token);
    }

    private native String getActivationCode(long nativePtr);
    @Override @Nullable
    synchronized public String getActivationCode()  {
        
        
        return getActivationCode(nativePtr);
    }

    private native int setActivationCode(long nativePtr, String activationCode);
    @Override
    synchronized public AccountCreator.ActivationCodeStatus setActivationCode(@Nullable String activationCode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setActivationCode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.ActivationCodeStatus.fromInt(setActivationCode(nativePtr, activationCode));
    }

    private native String getAlgorithm(long nativePtr);
    @Override @Nullable
    synchronized public String getAlgorithm()  {
        
        
        return getAlgorithm(nativePtr);
    }

    private native int setAlgorithm(long nativePtr, String algorithm);
    @Override
    synchronized public AccountCreator.AlgoStatus setAlgorithm(@Nullable String algorithm)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAlgorithm() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.AlgoStatus.fromInt(setAlgorithm(nativePtr, algorithm));
    }

    private native int setAsDefault(long nativePtr, boolean setAsDefault);
    @Override
    synchronized public AccountCreator.Status setAsDefault(boolean setAsDefault)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAsDefault() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(setAsDefault(nativePtr, setAsDefault));
    }

    private native String getDisplayName(long nativePtr);
    @Override @Nullable
    synchronized public String getDisplayName()  {
        
        
        return getDisplayName(nativePtr);
    }

    private native int setDisplayName(long nativePtr, String displayName);
    @Override
    synchronized public AccountCreator.UsernameStatus setDisplayName(@Nullable String displayName)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDisplayName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.UsernameStatus.fromInt(setDisplayName(nativePtr, displayName));
    }

    private native String getDomain(long nativePtr);
    @Override @Nullable
    synchronized public String getDomain()  {
        
        
        return getDomain(nativePtr);
    }

    private native int setDomain(long nativePtr, String domain);
    @Override
    synchronized public AccountCreator.DomainStatus setDomain(@Nullable String domain)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDomain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.DomainStatus.fromInt(setDomain(nativePtr, domain));
    }

    private native String getEmail(long nativePtr);
    @Override @Nullable
    synchronized public String getEmail()  {
        
        
        return getEmail(nativePtr);
    }

    private native int setEmail(long nativePtr, String email);
    @Override
    synchronized public AccountCreator.EmailStatus setEmail(@Nullable String email)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEmail() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.EmailStatus.fromInt(setEmail(nativePtr, email));
    }

    private native String getHa11(long nativePtr);
    @Override @Nullable
    synchronized public String getHa1()  {
        
        
        return getHa11(nativePtr);
    }

    private native int setHa11(long nativePtr, String ha1);
    @Override
    synchronized public AccountCreator.PasswordStatus setHa1(@Nullable String ha1)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHa1() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.PasswordStatus.fromInt(setHa11(nativePtr, ha1));
    }

    private native String getLanguage(long nativePtr);
    @Override @Nullable
    synchronized public String getLanguage()  {
        
        
        return getLanguage(nativePtr);
    }

    private native int setLanguage(long nativePtr, String lang);
    @Override
    synchronized public AccountCreator.LanguageStatus setLanguage(@Nullable String lang)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLanguage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.LanguageStatus.fromInt(setLanguage(nativePtr, lang));
    }

    private native String getPassword(long nativePtr);
    @Override @Nullable
    synchronized public String getPassword()  {
        
        
        return getPassword(nativePtr);
    }

    private native int setPassword(long nativePtr, String password);
    @Override
    synchronized public AccountCreator.PasswordStatus setPassword(@Nullable String password)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPassword() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.PasswordStatus.fromInt(setPassword(nativePtr, password));
    }

    private native String getPhoneCountryCode(long nativePtr);
    @Override @Nullable
    synchronized public String getPhoneCountryCode()  {
        
        
        return getPhoneCountryCode(nativePtr);
    }

    private native String getPhoneNumber(long nativePtr);
    @Override @Nullable
    synchronized public String getPhoneNumber()  {
        
        
        return getPhoneNumber(nativePtr);
    }

    private native String getPnParam(long nativePtr);
    @Override @Nullable
    synchronized public String getPnParam()  {
        
        
        return getPnParam(nativePtr);
    }

    private native void setPnParam(long nativePtr, String pnParam);
    @Override
    synchronized public void setPnParam(@Nullable String pnParam)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPnParam() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPnParam(nativePtr, pnParam);
    }

    private native String getPnPrid(long nativePtr);
    @Override @Nullable
    synchronized public String getPnPrid()  {
        
        
        return getPnPrid(nativePtr);
    }

    private native void setPnPrid(long nativePtr, String pnPrid);
    @Override
    synchronized public void setPnPrid(@Nullable String pnPrid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPnPrid() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPnPrid(nativePtr, pnPrid);
    }

    private native String getPnProvider(long nativePtr);
    @Override @Nullable
    synchronized public String getPnProvider()  {
        
        
        return getPnProvider(nativePtr);
    }

    private native void setPnProvider(long nativePtr, String pnProvider);
    @Override
    synchronized public void setPnProvider(@Nullable String pnProvider)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPnProvider() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPnProvider(nativePtr, pnProvider);
    }

    private native void setProxyConfig(long nativePtr, ProxyConfig cfg);
    @Override
    synchronized public void setProxyConfig(@Nullable ProxyConfig cfg)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setProxyConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setProxyConfig(nativePtr, cfg);
    }

    private native String getRoute(long nativePtr);
    @Override @Nullable
    synchronized public String getRoute()  {
        
        
        return getRoute(nativePtr);
    }

    private native int setRoute(long nativePtr, String route);
    @Override
    synchronized public AccountCreator.Status setRoute(@Nullable String route)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRoute() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(setRoute(nativePtr, route));
    }

    private native boolean getSetAsDefault(long nativePtr);
    @Override
    synchronized public boolean getSetAsDefault()  {
        
        
        return getSetAsDefault(nativePtr);
    }

    private native String getToken(long nativePtr);
    @Override @Nullable
    synchronized public String getToken()  {
        
        
        return getToken(nativePtr);
    }

    private native void setToken(long nativePtr, String token);
    @Override
    synchronized public void setToken(@Nullable String token)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setToken(nativePtr, token);
    }

    private native int getTransport(long nativePtr);
    @Override
    synchronized public TransportType getTransport()  {
        
        
        return TransportType.fromInt(getTransport(nativePtr));
    }

    private native int setTransport(long nativePtr, int transport);
    @Override
    synchronized public AccountCreator.TransportStatus setTransport(TransportType transport)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTransport() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.TransportStatus.fromInt(setTransport(nativePtr, transport.toInt()));
    }

    private native String getUsername(long nativePtr);
    @Override @Nullable
    synchronized public String getUsername()  {
        
        
        return getUsername(nativePtr);
    }

    private native int setUsername(long nativePtr, String username);
    @Override
    synchronized public AccountCreator.UsernameStatus setUsername(@Nullable String username)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUsername() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.UsernameStatus.fromInt(setUsername(nativePtr, username));
    }

    private native int activateAccount(long nativePtr);
    @Override
    synchronized public AccountCreator.Status activateAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call activateAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(activateAccount(nativePtr));
    }

    private native int activateAlias(long nativePtr);
    @Override
    synchronized public AccountCreator.Status activateAlias()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call activateAlias() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(activateAlias(nativePtr));
    }

    private native int createAccount(long nativePtr);
    @Override
    synchronized public AccountCreator.Status createAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(createAccount(nativePtr));
    }

    private native Account createAccountInCore(long nativePtr);
    @Override @Nullable
    synchronized public Account createAccountInCore()  {
        
        
        return (Account)createAccountInCore(nativePtr);
    }

    private native ProxyConfig createProxyConfig(long nativePtr);
    @Override @Nullable
    synchronized public ProxyConfig createProxyConfig()  {
        
        
        return (ProxyConfig)createProxyConfig(nativePtr);
    }

    private native int createPushAccount(long nativePtr);
    @Override
    synchronized public AccountCreator.Status createPushAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPushAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(createPushAccount(nativePtr));
    }

    private native int isAccountActivated(long nativePtr);
    @Override
    synchronized public AccountCreator.Status isAccountActivated()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAccountActivated() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(isAccountActivated(nativePtr));
    }

    private native int isAccountExist(long nativePtr);
    @Override
    synchronized public AccountCreator.Status isAccountExist()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAccountExist() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(isAccountExist(nativePtr));
    }

    private native int isAccountLinked(long nativePtr);
    @Override
    synchronized public AccountCreator.Status isAccountLinked()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAccountLinked() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(isAccountLinked(nativePtr));
    }

    private native int isAliasUsed(long nativePtr);
    @Override
    synchronized public AccountCreator.Status isAliasUsed()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAliasUsed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(isAliasUsed(nativePtr));
    }

    private native int linkAccount(long nativePtr);
    @Override
    synchronized public AccountCreator.Status linkAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call linkAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(linkAccount(nativePtr));
    }

    private native int loginLinphoneAccount(long nativePtr);
    @Override
    synchronized public AccountCreator.Status loginLinphoneAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call loginLinphoneAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(loginLinphoneAccount(nativePtr));
    }

    private native int recoverAccount(long nativePtr);
    @Override
    synchronized public AccountCreator.Status recoverAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call recoverAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(recoverAccount(nativePtr));
    }

    private native int requestAccountCreationRequestToken(long nativePtr);
    @Override
    synchronized public AccountCreator.Status requestAccountCreationRequestToken()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call requestAccountCreationRequestToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(requestAccountCreationRequestToken(nativePtr));
    }

    private native int requestAccountCreationTokenUsingRequestToken(long nativePtr);
    @Override
    synchronized public AccountCreator.Status requestAccountCreationTokenUsingRequestToken()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call requestAccountCreationTokenUsingRequestToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(requestAccountCreationTokenUsingRequestToken(nativePtr));
    }

    private native int requestAuthToken(long nativePtr);
    @Override
    synchronized public AccountCreator.Status requestAuthToken()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call requestAuthToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(requestAuthToken(nativePtr));
    }

    private native void reset(long nativePtr);
    @Override
    synchronized public void reset()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call reset() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        reset(nativePtr);
    }

    private native int setPhoneNumber(long nativePtr, String phoneNumber, String countryCode);
    @Override
    synchronized public int setPhoneNumber(@Nullable String phoneNumber, @Nullable String countryCode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPhoneNumber() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setPhoneNumber(nativePtr, phoneNumber, countryCode);
    }

    private native int updateAccount(long nativePtr);
    @Override
    synchronized public AccountCreator.Status updateAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call updateAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return AccountCreator.Status.fromInt(updateAccount(nativePtr));
    }

    private native void useTestAdminAccount(long nativePtr);
    @Override
    synchronized public void useTestAdminAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call useTestAdminAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        useTestAdminAccount(nativePtr);
    }

    private native AccountCreator create(long nativePtr, Core core);
    @Override @NonNull
    synchronized public AccountCreator create(@NonNull Core core)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call create() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountCreator)create(nativePtr, core);
    }

    private native void addListener(long nativePtr, AccountCreatorListener listener);
    @Override
    synchronized public void addListener(AccountCreatorListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, AccountCreatorListener listener);
    @Override
    synchronized public void removeListener(AccountCreatorListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
