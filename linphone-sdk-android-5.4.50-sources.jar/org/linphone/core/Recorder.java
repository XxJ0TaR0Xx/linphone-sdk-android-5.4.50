/*
Recorder.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Interface used to record audio and video into files. <br/>
* <br/>
* see: {@link Core#createRecorder} <br/>
*/
public interface Recorder {
    public enum State {
        /**
        * No file is opened for recording. <br/>
        * <br/>
        */
        Closed(0),

        /**
        * The recorder is paused. <br/>
        * <br/>
        */
        Paused(1),

        /**
        * The recorder is running. <br/>
        * <br/>
        */
        Running(2);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Closed;
            case 1: return Paused;
            case 2: return Running;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Get linear volume when capturing audio. <br/>
    * <br/>
    * @return Linear volume. <br/>
    */
    public float getCaptureVolume();

    /**
    * Gets the duration of the recording. <br/>
    * <br/>
    * @return the duration of the recording, in milliseconds. <br/>
    */
    public int getDuration();

    /**
    * Gets the file used for recording. <br/>
    * <br/>
    * @return the file used for the recording if any.   <br/>
    */
    @Nullable
    public String getFile();

    /**
    * Retrieves the {@link RecorderParams} object. <br/>
    * <br/>
    * @return The {@link RecorderParams} object.   <br/>
    */
    @NonNull
    public RecorderParams getParams();

    /**
    * Sets the {@link RecorderParams} object. <br/>
    * <br/>
    * @param params The {@link RecorderParams} object to set.   <br/>
    */
    public void setParams(@NonNull RecorderParams params);

    /**
    * Gets the current state of the recorder. <br/>
    * <br/>
    * @return the current {@link State}. <br/>
    */
    public Recorder.State getState();

    /**
    * Closes the opened file. <br/>
    * <br/>
    */
    public void close();

    /**
    * Create a {@link Content} object from the recording, for example to send it<br/>
    * within a {@link ChatMessage}. <br/>
    * <br/>
    * warning: Recorder must be in Closed state! <br/>
    * @return the {@link Content} matching the recording, or null.   <br/>
    */
    @Nullable
    public Content createContent();

    /**
    * Opens a file for recording. <br/>
    * <br/>
    * If the file already exists, it will open in append mode, otherwise it is<br/>
    * created.<br/>
    * @param file The path to the file to open.   <br/>
    */
    public int open(@NonNull String file);

    /**
    * Pauses the recording. <br/>
    * <br/>
    */
    public int pause();

    /**
    * Starts the recording into the opened file. <br/>
    * <br/>
    */
    public int start();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class RecorderImpl implements Recorder {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected RecorderImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native float getCaptureVolume(long nativePtr);
    @Override
    synchronized public float getCaptureVolume()  {
        
        
        return getCaptureVolume(nativePtr);
    }

    private native int getDuration(long nativePtr);
    @Override
    synchronized public int getDuration()  {
        
        
        return getDuration(nativePtr);
    }

    private native String getFile(long nativePtr);
    @Override @Nullable
    synchronized public String getFile()  {
        
        
        return getFile(nativePtr);
    }

    private native RecorderParams getParams(long nativePtr);
    @Override @NonNull
    synchronized public RecorderParams getParams()  {
        
        
        return (RecorderParams)getParams(nativePtr);
    }

    private native void setParams(long nativePtr, RecorderParams params);
    @Override
    synchronized public void setParams(@NonNull RecorderParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParams(nativePtr, params);
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public Recorder.State getState()  {
        
        
        return Recorder.State.fromInt(getState(nativePtr));
    }

    private native void close(long nativePtr);
    @Override
    synchronized public void close()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call close() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        close(nativePtr);
    }

    private native Content createContent(long nativePtr);
    @Override @Nullable
    synchronized public Content createContent()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Content)createContent(nativePtr);
    }

    private native int open(long nativePtr, String file);
    @Override
    synchronized public int open(@NonNull String file)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call open() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return open(nativePtr, file);
    }

    private native int pause(long nativePtr);
    @Override
    synchronized public int pause()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call pause() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return pause(nativePtr);
    }

    private native int start(long nativePtr);
    @Override
    synchronized public int start()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call start() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return start(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
