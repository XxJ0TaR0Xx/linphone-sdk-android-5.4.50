/*
CodecPriorityPolicy.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Codec priority policies. <br/>
* <br/>
* This enum represents different policies for managing offered codec lists during<br/>
* calls, as well as the offer-answer logic. Currently, policies can be applied<br/>
* only for video codecs. <br/>
*/
public enum CodecPriorityPolicy {
    /**
    * In this mode, codecs have initial default ordering, that can be changed by the<br/>
    * application The answerer of a call accepts codecs with the order given in the<br/>
    * offer. <br/>
    * <br/>
    */
    Basic(0),

    /**
    * In this mode, the codec list is managed by the {@link Core} according to<br/>
    * hardware capabilities in the goal of optimizing video quality and user<br/>
    * experience. <br/>
    * <br/>
    * The answerer of call may re-order the offerer's list in its answer in order to<br/>
    * give preference to certain codecs. <br/>
    */
    Auto(1);

    protected final int mValue;

    private CodecPriorityPolicy (int value) {
        mValue = value;
    }

    static public CodecPriorityPolicy fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Basic;
        case 1: return Auto;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for CodecPriorityPolicy");
        }
    }
    
    static protected CodecPriorityPolicy[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        CodecPriorityPolicy[] enumArray = new CodecPriorityPolicy[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = CodecPriorityPolicy.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(CodecPriorityPolicy[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
