/*
AccountCreatorListenerStub.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

public class AccountCreatorListenerStub implements AccountCreatorListener {
    @Override
    public void onCreateAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onIsAccountExist(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onActivateAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onSendToken(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onAccountCreationRequestToken(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onAccountCreationTokenUsingRequestToken(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onIsAccountActivated(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onLinkAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onActivateAlias(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onIsAliasUsed(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onIsAccountLinked(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onRecoverAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onUpdateAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

    @Override
    public void onLoginLinphoneAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response) {
        // Auto-generated method stub
    }

}