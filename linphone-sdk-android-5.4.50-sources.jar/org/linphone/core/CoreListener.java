/*
CoreListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* That class holds all the callbacks which are called by {@link Core}. <br/>
* <br/>
* Once created, add your {@link CoreListener} using {@link Core#addListener}.<br/>
* Keep a reference on it as long as you need it. You can use {@link Core#removeListener}<br/>
* to remove it but that isn't mandatory.<br/>
* The same applies to all listeners in our API. <br/>
*/
public interface CoreListener {
    /**
    * Global state notification callback. <br/>
    * <br/>
    * @param core the {@link Core}.   <br/>
    * @param state the {@link GlobalState} <br/>
    * @param message informational message.   <br/>
    */
    public void onGlobalStateChanged(@NonNull Core core, GlobalState state, @NonNull String message);

    /**
    * Registration state notification callback prototype. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param proxyConfig the {@link ProxyConfig} which state has changed   <br/>
    * @param state the current {@link RegistrationState} <br/>
    * @param message a non null informational message about the state   <br/>
    * @deprecated 06/04/2020 Use LinphoneCoreCbsAccountRegistrationStateChangedCb<br/>
    * instead<br/>
    */
    public void onRegistrationStateChanged(@NonNull Core core, @NonNull ProxyConfig proxyConfig, RegistrationState state, @NonNull String message);

    /**
    * Callback prototype for notifying the application about a received conference<br/>
    * info. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param conferenceInfo the {@link ConferenceInfo} received   <br/>
    */
    public void onConferenceInfoReceived(@NonNull Core core, @NonNull ConferenceInfo conferenceInfo);

    /**
    * Callback prototype for notifying the application a push notification was<br/>
    * received. <br/>
    * <br/>
    * On iOS it only works with pushkit (VoIP) pushes. <br/>
    * @param core {@link Core} object   <br/>
    * @param payload the body of the push notification, if any   <br/>
    */
    public void onPushNotificationReceived(@NonNull Core core, @Nullable String payload);

    /**
    * Callback to notify that there are errors from the video rendering. <br/>
    * <br/>
    * Check LinphoneCallCbsVideoDisplayErrorOccurredCb for more details.<br/>
    * @param core {@link Core} object   <br/>
    * @param errorCode The error code. It depends of the display filter (available<br/>
    * for OpenGL) <br/>
    */
    public void onPreviewDisplayErrorOccurred(@NonNull Core core, int errorCode);

    /**
    * Call state notification callback. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param call the {@link Call} object whose state is changed.   <br/>
    * @param state the new {@link Call#State} of the call <br/>
    * @param message a non null informational message about the state.   <br/>
    */
    public void onCallStateChanged(@NonNull Core core, @NonNull Call call, Call.State state, @NonNull String message);

    /**
    * Report status change for a friend previously added to the {@link Core} with<br/>
    * linphone_core_add_friend(). <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneFriend Updated {@link Friend}   <br/>
    */
    public void onNotifyPresenceReceived(@NonNull Core core, @NonNull Friend linphoneFriend);

    /**
    * Reports presence model change for a specific URI or phone number of a friend. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneFriend {@link Friend} object   <br/>
    * @param uriOrTel The URI or phone number for which the presence model has<br/>
    * changed   <br/>
    * @param presenceModel The new {@link PresenceModel}   <br/>
    */
    public void onNotifyPresenceReceivedForUriOrTel(@NonNull Core core, @NonNull Friend linphoneFriend, @NonNull String uriOrTel, @NonNull PresenceModel presenceModel);

    /**
    * Reports that a new subscription request has been received and wait for a<br/>
    * decision. <br/>
    * <br/>
    * note: A subscription request is notified by this function only if the {@link SubscribePolicy}<br/>
    * for the given {@link Friend} has been set to {@link SubscribePolicy#SPWait}.<br/>
    * See {@link Friend#setIncSubscribePolicy}. <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneFriend The {@link Friend} aimed by the subscription.   <br/>
    * @param url URI of the subscriber   <br/>
    */
    public void onNewSubscriptionRequested(@NonNull Core core, @NonNull Friend linphoneFriend, @NonNull String url);

    /**
    * Callback for requesting authentication information to application or user. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param authInfo a {@link AuthInfo} pre-filled with username, realm and domain<br/>
    * values as much as possible   <br/>
    * @param method the type of authentication requested as {@link AuthMethod} enum  <br/>
    * Application shall reply to this callback using {@link Core#addAuthInfo}. <br/>
    */
    public void onAuthenticationRequested(@NonNull Core core, @NonNull AuthInfo authInfo, @NonNull AuthMethod method);

    /**
    * Callback to notify a new call-log entry has been added. <br/>
    * <br/>
    * This is done typically when a call terminates. <br/>
    * @param core the {@link Core}   <br/>
    * @param callLog the new {@link CallLog} entry added.   <br/>
    */
    public void onCallLogUpdated(@NonNull Core core, @NonNull CallLog callLog);

    /**
    * Callback to notify the callid of a call has been updated. <br/>
    * <br/>
    * This is done typically when a call retry. <br/>
    * @param core the {@link Core}   <br/>
    * @param previousCallId the previous callid.   <br/>
    * @param currentCallId the new callid.   <br/>
    */
    public void onCallIdUpdated(@NonNull Core core, @NonNull String previousCallId, @NonNull String currentCallId);

    /**
    * Called after a download is terminated or a new attachement is to be downloaded. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param downloadCount outstanding number of files to be downloaded including the<br/>
    * one that is currently downloading <br/>
    * @param uploadCount outstanding number of files to be upload including the one<br/>
    * that is currently uploading <br/>
    */
    public void onRemainingNumberOfFileTransferChanged(@NonNull Core core, int downloadCount, int uploadCount);

    /**
    * Chat message callback prototype. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} involved in this conversation. Can be created<br/>
    * by the framework in case the From-URI is not present in any chat room.   <br/>
    * @param message {@link ChatMessage} incoming message   <br/>
    */
    public void onMessageReceived(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message);

    /**
    * Chat message new reaction callback prototype. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} involved in this conversation. Can be created<br/>
    * by the framework in case the From-URI is not present in any chat room.   <br/>
    * @param message the {@link ChatMessage} to which the reaction applies to   <br/>
    * @param reaction the {@link ChatMessageReaction} that has been sent or received <br/>
    *  <br/>
    */
    public void onNewMessageReaction(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message, @NonNull ChatMessageReaction reaction);

    /**
    * Chat message removed reaction callback prototype. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} involved in this conversation. Can be created<br/>
    * by the framework in case the From-URI is not present in any chat room.   <br/>
    * @param message the {@link ChatMessage} to which a reaction has been removed<br/>
    * from   <br/>
    * @param address the {@link Address} of the person that removed it's reaction   <br/>
    */
    public void onReactionRemoved(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message, @NonNull Address address);

    /**
    * Chat messages callback prototype. <br/>
    * <br/>
    * Only called when aggregation is enabled (aka [sip] chat_messages_aggregation ==<br/>
    * 1 or using {@link Core#setChatMessagesAggregationEnabled}), it replaces the<br/>
    * single message received callback. <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} involved in this conversation. Can be created<br/>
    * by the framework in case the From-URI is not present in any chat room.   <br/>
    * @param messages The  of incoming messages   <br/>
    */
    public void onMessagesReceived(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage[] messages);

    /**
    * Called after the {@link ChatMessage#send} was called. <br/>
    * <br/>
    * The message will be in state InProgress. In case of resend this callback won't<br/>
    * be called. <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} involved in this conversation. Can be be<br/>
    * created by the framework in case the From-URI is not present in any chat room. <br/>
    *  <br/>
    * @param message {@link ChatMessage} outgoing message   <br/>
    */
    public void onMessageSent(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message);

    /**
    * Chat room session state changed callback. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} that has been marked as read.   <br/>
    * @param state the new {@link Call#State} of the call <br/>
    * @param message a non null informational message about the state.   <br/>
    */
    public void onChatRoomSessionStateChanged(@NonNull Core core, @NonNull ChatRoom chatRoom, Call.State state, @NonNull String message);

    /**
    * Chat room marked as read callback. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} that has been marked as read.   <br/>
    */
    public void onChatRoomRead(@NonNull Core core, @NonNull ChatRoom chatRoom);

    /**
    * Chat message not decrypted callback prototype. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} involved in this conversation. Can be be<br/>
    * created by the framework in case the from-URI is not present in any chat room. <br/>
    *  <br/>
    * @param message {@link ChatMessage} incoming message   <br/>
    */
    public void onMessageReceivedUnableDecrypt(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message);

    /**
    * Is composing notification callback prototype. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom {@link ChatRoom} involved in the conversation.   <br/>
    */
    public void onIsComposingReceived(@NonNull Core core, @NonNull ChatRoom chatRoom);

    /**
    * Callback for being notified of DTMFs received. <br/>
    * <br/>
    * @param core the LinphoneCore   <br/>
    * @param call the LinphoneCall that received the dtmf   <br/>
    * @param dtmf the ascii code of the dtmf <br/>
    */
    public void onDtmfReceived(@NonNull Core core, @NonNull Call call, int dtmf);

    /**
    * Callback prototype for when a refer is received. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param referToAddr the address of the refer   <br/>
    * @param customHeaders the headers of the received REFER message   <br/>
    * @param content the content of the refer   <br/>
    */
    public void onReferReceived(@NonNull Core core, @NonNull Address referToAddr, @NonNull Headers customHeaders, @Nullable Content content);

    /**
    * GoClear ACK sent on call callback. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param call the {@link Call} on which the GoClear ACK was sent.   <br/>
    */
    public void onCallGoclearAckSent(@NonNull Core core, @NonNull Call call);

    /**
    * Call encryption changed callback. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param call the {@link Call} on which encryption is changed.   <br/>
    * @param mediaEncryptionEnabled whether encryption is activated. <br/>
    * @param authenticationToken an authentication token, currently set for ZRTP kind<br/>
    * of encryption only.   <br/>
    */
    public void onCallEncryptionChanged(@NonNull Core core, @NonNull Call call, boolean mediaEncryptionEnabled, @Nullable String authenticationToken);

    /**
    * Call send master key changed callback. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param call the {@link Call} on which the GoClear ACK was sent.   <br/>
    * @param masterKey new master key.   <br/>
    */
    public void onCallSendMasterKeyChanged(@NonNull Core core, @NonNull Call call, @Nullable String masterKey);

    /**
    * Call receive master key changed callback. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param call the {@link Call} on which the GoClear ACK was sent.   <br/>
    * @param masterKey new master key.   <br/>
    */
    public void onCallReceiveMasterKeyChanged(@NonNull Core core, @NonNull Call call, @Nullable String masterKey);

    /**
    * Callback for notifying progresses of transfers. <br/>
    * <br/>
    * @param core the LinphoneCore   <br/>
    * @param transferred the LinphoneCall that was transferred   <br/>
    * @param callState the LinphoneCallState of the call to transfer target at the<br/>
    * far end. <br/>
    */
    public void onTransferStateChanged(@NonNull Core core, @NonNull Call transferred, Call.State callState);

    /**
    * Callback prototype when using the buddy plugin. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param linphoneFriend the {@link Friend} that has been updated   <br/>
    */
    public void onBuddyInfoUpdated(@NonNull Core core, @NonNull Friend linphoneFriend);

    /**
    * Callback for receiving quality statistics for calls. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param call the {@link Call}   <br/>
    * @param callStats the {@link CallStats} statistics.   <br/>
    */
    public void onCallStatsUpdated(@NonNull Core core, @NonNull Call call, @NonNull CallStats callStats);

    /**
    * Callback prototype for receiving info messages. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param call the call whose info message belongs to.   <br/>
    * @param message the info message.   <br/>
    */
    public void onInfoReceived(@NonNull Core core, @NonNull Call call, @NonNull InfoMessage message);

    /**
    * Callback prototype for notifying the application about changes of subscription<br/>
    * states, including arrival of new subscriptions. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneEvent the {@link Event}   <br/>
    * @param state the new {@link SubscriptionState} <br/>
    */
    public void onSubscriptionStateChanged(@NonNull Core core, @NonNull Event linphoneEvent, SubscriptionState state);

    /**
    * Callback prototype for notifying the application about notification that is<br/>
    * being sent. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneEvent the {@link Event} received   <br/>
    * @param body the {@link Content} of the event   <br/>
    */
    public void onNotifySent(@NonNull Core core, @NonNull Event linphoneEvent, @Nullable Content body);

    /**
    * Callback prototype for notifying the application about notification received<br/>
    * from the network. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneEvent the {@link Event} received   <br/>
    * @param notifiedEvent The event as string   <br/>
    * @param body the {@link Content} of the event   <br/>
    */
    public void onNotifyReceived(@NonNull Core core, @NonNull Event linphoneEvent, @NonNull String notifiedEvent, @Nullable Content body);

    /**
    * Callback prototype for notifying the application about subscription received<br/>
    * from the network. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneEvent the {@link Event} received   <br/>
    * @param subscribeEvent The event as string   <br/>
    * @param body the {@link Content} of the event   <br/>
    */
    public void onSubscribeReceived(@NonNull Core core, @NonNull Event linphoneEvent, @NonNull String subscribeEvent, @Nullable Content body);

    /**
    * Callback prototype for notifying the application about changes of publish<br/>
    * states. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneEvent the {@link Event}   <br/>
    * @param state the new {@link PublishState} <br/>
    */
    public void onPublishStateChanged(@NonNull Core core, @NonNull Event linphoneEvent, PublishState state);

    /**
    * Callback prototype for notifying the application about publish received from<br/>
    * the network. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param linphoneEvent the {@link Event} received   <br/>
    * @param publishEvent The event as string   <br/>
    * @param body the {@link Content} of the event   <br/>
    */
    public void onPublishReceived(@NonNull Core core, @NonNull Event linphoneEvent, @NonNull String publishEvent, @Nullable Content body);

    /**
    * Callback prototype for configuring status changes notification. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param status the current {@link ConfiguringState} <br/>
    * @param message informational message.   <br/>
    */
    public void onConfiguringStatus(@NonNull Core core, ConfiguringState status, @Nullable String message);

    /**
    * Callback prototype for reporting network change either automatically detected<br/>
    * or notified by {@link Core#setNetworkReachable}. <br/>
    * <br/>
    * @param core the {@link Core}   <br/>
    * @param reachable true if network is reachable. <br/>
    */
    public void onNetworkReachable(@NonNull Core core, boolean reachable);

    /**
    * Callback prototype for reporting log collection upload state change. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param state The state of the log collection upload <br/>
    * @param info Additional information: error message in case of error state, URL<br/>
    * of uploaded file in case of success.    <br/>
    */
    public void onLogCollectionUploadStateChanged(@NonNull Core core, Core.LogCollectionUploadState state, @NonNull String info);

    /**
    * Callback prototype for reporting log collection upload progress indication. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param offset the number of bytes sent since the start of the upload <br/>
    * @param total the total number of bytes to upload <br/>
    */
    public void onLogCollectionUploadProgressIndication(@NonNull Core core, int offset, int total);

    /**
    * Callback prototype for reporting when a friend list has been added to the core<br/>
    * friend lists. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param friendList {@link FriendList} object   <br/>
    */
    public void onFriendListCreated(@NonNull Core core, @NonNull FriendList friendList);

    /**
    * Callback prototype for reporting when a friend list has been removed from the<br/>
    * core friend lists. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param friendList {@link FriendList} object   <br/>
    */
    public void onFriendListRemoved(@NonNull Core core, @NonNull FriendList friendList);

    /**
    * Callback notifying that a new {@link Call} (either incoming or outgoing) has<br/>
    * been created. <br/>
    * <br/>
    * @param core {@link Core} object that has created the call   <br/>
    * @param call The newly created {@link Call} object   <br/>
    */
    public void onCallCreated(@NonNull Core core, @NonNull Call call);

    /**
    * Callback prototype for reporting the result of a version update check. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param result The result of the version update check   <br/>
    * @param version The version to update to   <br/>
    * @param url The url where to download the new version if the result is<br/>
    * #LinphoneVersionUpdateCheckNewVersionAvailable    <br/>
    */
    public void onVersionUpdateCheckResultReceived(@NonNull Core core, @NonNull VersionUpdateCheckResult result, @Nullable String version, @Nullable String url);

    /**
    * Callback prototype telling that a {@link Conference} state has changed. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param conference The {@link Conference} object for which the state has changed<br/>
    *   <br/>
    * @param state the current {@link ChatRoom#State} <br/>
    */
    public void onConferenceStateChanged(@NonNull Core core, @NonNull Conference conference, Conference.State state);

    /**
    * Callback prototype telling that a {@link ChatRoom} state has changed. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom The {@link ChatRoom} object for which the state has changed   <br/>
    * @param state the current {@link ChatRoom#State} <br/>
    */
    public void onChatRoomStateChanged(@NonNull Core core, @NonNull ChatRoom chatRoom, ChatRoom.State state);

    /**
    * Callback prototype telling that a {@link ChatRoom} subject has changed. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom The {@link ChatRoom} object for which the subject has changed   <br/>
    */
    public void onChatRoomSubjectChanged(@NonNull Core core, @NonNull ChatRoom chatRoom);

    /**
    * Callback prototype telling that a {@link ChatRoom} ephemeral message has<br/>
    * expired. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param chatRoom The {@link ChatRoom} object for which a message has expired.   <br/>
    */
    public void onChatRoomEphemeralMessageDeleted(@NonNull Core core, @NonNull ChatRoom chatRoom);

    /**
    * Callback prototype telling that an Instant Message Encryption Engine user<br/>
    * registered on the server with or without success. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param status the return status of the registration action. <br/>
    * @param userId the userId published on the encryption engine server   <br/>
    * @param info information about failure   <br/>
    */
    public void onImeeUserRegistration(@NonNull Core core, boolean status, @NonNull String userId, @NonNull String info);

    /**
    * Callback prototype telling the result of decoded qrcode. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param result The result of the decoded qrcode   <br/>
    */
    public void onQrcodeFound(@NonNull Core core, @Nullable String result);

    /**
    * Callback prototype telling a call has started (incoming or outgoing) while<br/>
    * there was no other call. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    */
    public void onFirstCallStarted(@NonNull Core core);

    /**
    * Callback prototype telling the last call has ended ({@link Core#getCallsNb}<br/>
    * returns 0) <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    */
    public void onLastCallEnded(@NonNull Core core);

    /**
    * Callback prototype telling that the audio device for at least one call has<br/>
    * changed. <br/>
    * <br/>
    * @param core LinphoneCore object   <br/>
    * @param audioDevice the newly used LinphoneAudioDevice object   <br/>
    */
    public void onAudioDeviceChanged(@NonNull Core core, @NonNull AudioDevice audioDevice);

    /**
    * Callback prototype telling the audio devices list has been updated. <br/>
    * <br/>
    * Either a new device is available or a previously available device isn't<br/>
    * anymore. You can call {@link Core#getAudioDevices} to get the new list. <br/>
    * @param core {@link Core} object   <br/>
    */
    public void onAudioDevicesListUpdated(@NonNull Core core);

    /**
    * Function prototype used by linphone_core_cbs_set_ec_calibration_result. <br/>
    * <br/>
    * @param core The {@link Core}.   <br/>
    * @param status The {@link EcCalibratorStatus} of the calibrator. <br/>
    * @param delayMs The measured delay if available. <br/>
    */
    public void onEcCalibrationResult(@NonNull Core core, EcCalibratorStatus status, int delayMs);

    /**
    * Function prototype used by linphone_core_cbs_set_ec_calibration_audio_init. <br/>
    * <br/>
    * @param core The {@link Core}.   <br/>
    */
    public void onEcCalibrationAudioInit(@NonNull Core core);

    /**
    * Function prototype used by linphone_core_cbs_set_ec_calibration_audio_uninit. <br/>
    * <br/>
    * @param core The {@link Core}.   <br/>
    */
    public void onEcCalibrationAudioUninit(@NonNull Core core);

    /**
    * Callback notifying that a {@link Account} has its registration state changed. <br/>
    * <br/>
    * @param core The {@link Core} object.   <br/>
    * @param account The {@link Account} object which has its registration changed.   <br/>
    * @param state The new {@link RegistrationState} for this account. <br/>
    * @param message a non null informational message about the state   <br/>
    */
    public void onAccountRegistrationStateChanged(@NonNull Core core, @NonNull Account account, RegistrationState state, @NonNull String message);

    /**
    * Default account changed callback prototype. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param account {@link Account} object that has been set as the default account,<br/>
    * probably by calling {@link Core#setDefaultAccount}, or null if the default<br/>
    * account was removed.   <br/>
    */
    public void onDefaultAccountChanged(@NonNull Core core, @Nullable Account account);

    /**
    * Account added callback prototype. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param account {@link Account} object that has been added to the Core using<br/>
    * {@link Core#addAccount} for example.    <br/>
    */
    public void onAccountAdded(@NonNull Core core, @NonNull Account account);

    /**
    * Account removed callback prototype. <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param account {@link Account} object that has been added to the Core using<br/>
    * {@link Core#removeAccount} for example.    <br/>
    */
    public void onAccountRemoved(@NonNull Core core, @NonNull Account account);

    /**
    * Callback notifying that a Message Waiting Indication state has changed. <br/>
    * <br/>
    * @param core The {@link Core} object.   <br/>
    * @param lev The {@link Event} object notifying the MWI.   <br/>
    * @param mwi The {@link MessageWaitingIndication} object that is notified.   <br/>
    */
    public void onMessageWaitingIndicationChanged(@NonNull Core core, @NonNull Event lev, @NonNull MessageWaitingIndication mwi);

    /**
    * Callback notifying a snapshot has been taken. <br/>
    * <br/>
    * @param core LinphoneCore object.   <br/>
    * @param filePath the name of the saved file.   <br/>
    */
    public void onSnapshotTaken(@NonNull Core core, @NonNull String filePath);

    /**
    * Callback for notifying about an alert (e.g on Qos) <br/>
    * <br/>
    * @param core {@link Core} object   <br/>
    * @param alert {@link Alert} to notify   <br/>
    */
    public void onNewAlertTriggered(@NonNull Core core, @NonNull Alert alert);

}