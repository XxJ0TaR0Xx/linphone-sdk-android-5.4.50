/*
SubscriptionState.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum for subscription states. <br/>
* <br/>
* {@link SubscriptionState#Terminated} and {@link SubscriptionState#Error} are<br/>
* final states. <br/>
*/
public enum SubscriptionState {
    /**
    * Initial state, should not be used. <br/>
    * <br/>
    */
    None(0),

    /**
    * An outgoing subcription was sent. <br/>
    * <br/>
    */
    OutgoingProgress(1),

    /**
    * An incoming subcription is received. <br/>
    * <br/>
    */
    IncomingReceived(2),

    /**
    * Subscription is pending, waiting for user approval. <br/>
    * <br/>
    */
    Pending(3),

    /**
    * Subscription is accepted. <br/>
    * <br/>
    */
    Active(4),

    /**
    * Subscription is terminated normally. <br/>
    * <br/>
    */
    Terminated(5),

    /**
    * Subscription was terminated by an error, indicated by {@link Event#getReason} <br/>
    * <br/>
    */
    Error(6),

    /**
    * Subscription is about to expire, only sent if [sip]->refresh_generic_subscribe<br/>
    * property is set to 0. <br/>
    * <br/>
    */
    Expiring(7);

    protected final int mValue;

    private SubscriptionState (int value) {
        mValue = value;
    }

    static public SubscriptionState fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return None;
        case 1: return OutgoingProgress;
        case 2: return IncomingReceived;
        case 3: return Pending;
        case 4: return Active;
        case 5: return Terminated;
        case 6: return Error;
        case 7: return Expiring;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for SubscriptionState");
        }
    }
    
    static protected SubscriptionState[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        SubscriptionState[] enumArray = new SubscriptionState[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = SubscriptionState.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(SubscriptionState[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
