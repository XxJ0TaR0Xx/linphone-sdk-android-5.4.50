/*
ParticipantInfo.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object defining all information related to a participant. <br/>
* <br/>
*/
public interface ParticipantInfo {
    /**
    * Get the address of the object {@link ParticipantInfo}. <br/>
    * <br/>
    * @return the {@link Address} of the {@link ParticipantInfo} object.   <br/>
    */
    @NonNull
    public Address getAddress();

    /**
    * Get the CCMP uri of the object {@link ParticipantInfo}. <br/>
    * <br/>
    * @return the CCMP uri of the {@link ParticipantInfo} or null.   <br/>
    */
    @Nullable
    public String getCcmpUri();

    /**
    * Get the role of the object {@link ParticipantInfo}. <br/>
    * <br/>
    * @return the {@link Participant#Role} of the {@link ParticipantInfo} object.   <br/>
    */
    @NonNull
    public Participant.Role getRole();

    /**
    * Set the role of the object {@link ParticipantInfo}. <br/>
    * <br/>
    * @param role the {@link Participant#Role} of the {@link ParticipantInfo} object.<br/>
    *   <br/>
    */
    public void setRole(@NonNull Participant.Role role);

    /**
    * Set the a custom parameter to object {@link ParticipantInfo}. <br/>
    * <br/>
    * @param name the name of the parameter.   <br/>
    * @param value the value of the parameter.   <br/>
    */
    public void addParameter(@NonNull String name, @NonNull String value);

    /**
    * Clone an object {@link ParticipantInfo}. <br/>
    * <br/>
    * @return the cloned {@link ParticipantInfo} object.   <br/>
    */
    @NonNull
    public ParticipantInfo clone();

    /**
    * Get the value of a custom parameter of the object {@link ParticipantInfo}. <br/>
    * <br/>
    * @param name the name of the parameter.   <br/>
    * @return value the value of the parameter.   <br/>
    */
    @NonNull
    public String getParameterValue(@NonNull String name);

    /**
    * Find whether a {@link ParticipantInfo} has a parameter. <br/>
    * <br/>
    * @param name the name of the parameter.   <br/>
    * @return true if the parameter is present, false otherwise <br/>
    */
    public boolean hasParameter(@NonNull String name);

    /**
    * Find the value of a custom parameter of the object {@link ParticipantInfo}. <br/>
    * <br/>
    * @param name the name of the parameter.   <br/>
    */
    public void removeParameter(@NonNull String name);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ParticipantInfoImpl implements ParticipantInfo {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ParticipantInfoImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Address getAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getAddress()  {
        
        
        return (Address)getAddress(nativePtr);
    }

    private native String getCcmpUri(long nativePtr);
    @Override @Nullable
    synchronized public String getCcmpUri()  {
        
        
        return getCcmpUri(nativePtr);
    }

    private native int getRole(long nativePtr);
    @Override @NonNull
    synchronized public Participant.Role getRole()  {
        
        
        return Participant.Role.fromInt(getRole(nativePtr));
    }

    private native void setRole(long nativePtr, int role);
    @Override
    synchronized public void setRole(@NonNull Participant.Role role)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRole() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRole(nativePtr, role.toInt());
    }

    private native void addParameter(long nativePtr, String name, String value);
    @Override
    synchronized public void addParameter(@NonNull String name, @NonNull String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParameter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addParameter(nativePtr, name, value);
    }

    private native ParticipantInfo clone(long nativePtr);
    @Override @NonNull
    synchronized public ParticipantInfo clone()  {
        
        
        return (ParticipantInfo)clone(nativePtr);
    }

    private native String getParameterValue(long nativePtr, String name);
    @Override @NonNull
    synchronized public String getParameterValue(@NonNull String name)  {
        
        
        return getParameterValue(nativePtr, name);
    }

    private native boolean hasParameter(long nativePtr, String name);
    @Override
    synchronized public boolean hasParameter(@NonNull String name)  {
        
        
        return hasParameter(nativePtr, name);
    }

    private native void removeParameter(long nativePtr, String name);
    @Override
    synchronized public void removeParameter(@NonNull String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeParameter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeParameter(nativePtr, name);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
