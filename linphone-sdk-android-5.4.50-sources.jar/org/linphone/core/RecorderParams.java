/*
RecorderParams.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object containing various parameters of a {@link Recorder}. <br/>
* <br/>
* see: {@link Core#createRecorder} <br/>
*/
public interface RecorderParams {
    /**
    * Retrieve the {@link AudioDevice} object. <br/>
    * <br/>
    * @return the {@link AudioDevice} object.   <br/>
    */
    @Nullable
    public AudioDevice getAudioDevice();

    /**
    * Set the {@link AudioDevice} object. <br/>
    * <br/>
    * @param device The {@link AudioDevice} object to set.   <br/>
    */
    public void setAudioDevice(@Nullable AudioDevice device);

    /**
    * Retrieves the #LinphoneRecorderFileFormat. <br/>
    * <br/>
    * @return the #LinphoneRecorderFileFormat. <br/>
    */
    public MediaFileFormat getFileFormat();

    /**
    * Set the #LinphoneRecorderFileFormat. <br/>
    * <br/>
    * see: {@link Core#getSupportedFileFormatsList} for information about supported<br/>
    * file formats. <br/>
    * @param format The #LinphoneRecorderFileFormat to set. <br/>
    */
    public void setFileFormat(MediaFileFormat format);

    /**
    * Retrieves the video codec. <br/>
    * <br/>
    * @return the video codec.   <br/>
    */
    @Nullable
    public String getVideoCodec();

    /**
    * Set the video codec. <br/>
    * <br/>
    * @param videoCodec The video codec to set.   <br/>
    */
    public void setVideoCodec(@Nullable String videoCodec);

    /**
    * Retrieves the webcam name. <br/>
    * <br/>
    * @return the webcam name.   <br/>
    */
    @Nullable
    public String getWebcamName();

    /**
    * Set the webcam name. <br/>
    * <br/>
    * @param webcamName The webcam name to set.   <br/>
    */
    public void setWebcamName(@Nullable String webcamName);

    /**
    * Retrieves the window id used to display the camera preview. <br/>
    * <br/>
    * @return the window id.   <br/>
    */
    @Nullable
    public Object getWindowId();

    /**
    * Sets the window id to use to display the camera preview. <br/>
    * <br/>
    * see: linphone_core_set_native_window_id() for a general discussion about window<br/>
    * ID types. <br/>
    * @param windowId The window id to set.   <br/>
    */
    public void setWindowId(@Nullable Object windowId);

    /**
    * Clone a {@link RecorderParams} object. <br/>
    * <br/>
    * @return the cloned {@link RecorderParams} object.   <br/>
    */
    @NonNull
    public RecorderParams clone();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class RecorderParamsImpl implements RecorderParams {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected RecorderParamsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native AudioDevice getAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getAudioDevice()  {
        
        
        return (AudioDevice)getAudioDevice(nativePtr);
    }

    private native void setAudioDevice(long nativePtr, AudioDevice device);
    @Override
    synchronized public void setAudioDevice(@Nullable AudioDevice device)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioDevice(nativePtr, device);
    }

    private native int getFileFormat(long nativePtr);
    @Override
    synchronized public MediaFileFormat getFileFormat()  {
        
        
        return MediaFileFormat.fromInt(getFileFormat(nativePtr));
    }

    private native void setFileFormat(long nativePtr, int format);
    @Override
    synchronized public void setFileFormat(MediaFileFormat format)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFileFormat() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFileFormat(nativePtr, format.toInt());
    }

    private native String getVideoCodec(long nativePtr);
    @Override @Nullable
    synchronized public String getVideoCodec()  {
        
        
        return getVideoCodec(nativePtr);
    }

    private native void setVideoCodec(long nativePtr, String videoCodec);
    @Override
    synchronized public void setVideoCodec(@Nullable String videoCodec)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoCodec() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoCodec(nativePtr, videoCodec);
    }

    private native String getWebcamName(long nativePtr);
    @Override @Nullable
    synchronized public String getWebcamName()  {
        
        
        return getWebcamName(nativePtr);
    }

    private native void setWebcamName(long nativePtr, String webcamName);
    @Override
    synchronized public void setWebcamName(@Nullable String webcamName)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setWebcamName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setWebcamName(nativePtr, webcamName);
    }

    private native Object getWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object getWindowId()  {
        
        
        return getWindowId(nativePtr);
    }

    private native void setWindowId(long nativePtr, Object windowId);
    @Override
    synchronized public void setWindowId(@Nullable Object windowId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setWindowId(nativePtr, windowId);
    }

    private native RecorderParams clone(long nativePtr);
    @Override @NonNull
    synchronized public RecorderParams clone()  {
        
        
        return (RecorderParams)clone(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
