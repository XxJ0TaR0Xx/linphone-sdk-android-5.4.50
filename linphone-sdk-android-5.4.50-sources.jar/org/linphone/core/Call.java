/*
Call.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* This object represents a call issued or received by the {@link Core}. <br/>
* <br/>
* Linphone only allows at most one active call at any given time and it will be<br/>
* in {@link State#StreamsRunning}. However, if the core is locally hosting a<br/>
* {@link Conference}, you may have some or all the calls in the conference in<br/>
* {@link State#StreamsRunning} as well as an additional active call outside of<br/>
* the conference in {@link State#StreamsRunning} if the local participant of the<br/>
* {@link Conference} is not part of it.<br/>
* You can get the {@link State} of the call using {@link #getState}, it's current<br/>
* {@link CallParams} with {@link #getCurrentParams} and the latest statistics by<br/>
* calling {@link #getAudioStats} or {@link #getVideoStats}.<br/>
* The application can receive the various kind of events occuring in a call<br/>
* through the {@link CallListener} interface, see also {@link #addListener}. <br/>
*/
public interface Call {
    public enum Status {
        /**
        * The call was sucessful. <br/>
        * <br/>
        */
        Success(0),

        /**
        * The call was aborted (caller hanged up) <br/>
        * <br/>
        */
        Aborted(1),

        /**
        * The call was missed (incoming call timed out without being answered or hanged<br/>
        * up) <br/>
        * <br/>
        */
        Missed(2),

        /**
        * The call was declined, either locally or by remote end. <br/>
        * <br/>
        */
        Declined(3),

        /**
        * The call was aborted before being advertised to the application - for protocol<br/>
        * reasons. <br/>
        * <br/>
        */
        EarlyAborted(4),

        /**
        * The call was answered on another device. <br/>
        * <br/>
        */
        AcceptedElsewhere(5),

        /**
        * The call was declined on another device. <br/>
        * <br/>
        */
        DeclinedElsewhere(6);

        protected final int mValue;

        private Status (int value) {
            mValue = value;
        }

        static public Status fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Success;
            case 1: return Aborted;
            case 2: return Missed;
            case 3: return Declined;
            case 4: return EarlyAborted;
            case 5: return AcceptedElsewhere;
            case 6: return DeclinedElsewhere;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Status");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Dir {
        /**
        * outgoing calls <br/>
        * <br/>
        */
        Outgoing(0),

        /**
        * incoming calls <br/>
        * <br/>
        */
        Incoming(1);

        protected final int mValue;

        private Dir (int value) {
            mValue = value;
        }

        static public Dir fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Outgoing;
            case 1: return Incoming;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Dir");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum State {
        /**
        * Initial state. <br/>
        * <br/>
        */
        Idle(0),

        /**
        * Incoming call received. <br/>
        * <br/>
        */
        IncomingReceived(1),

        /**
        * PushIncoming call received. <br/>
        * <br/>
        */
        PushIncomingReceived(2),

        /**
        * Outgoing call initialized. <br/>
        * <br/>
        */
        OutgoingInit(3),

        /**
        * Outgoing call in progress. <br/>
        * <br/>
        */
        OutgoingProgress(4),

        /**
        * Outgoing call ringing. <br/>
        * <br/>
        */
        OutgoingRinging(5),

        /**
        * Outgoing call early media. <br/>
        * <br/>
        */
        OutgoingEarlyMedia(6),

        /**
        * Connected. <br/>
        * <br/>
        */
        Connected(7),

        /**
        * Streams running. <br/>
        * <br/>
        */
        StreamsRunning(8),

        /**
        * Pausing. <br/>
        * <br/>
        */
        Pausing(9),

        /**
        * Paused. <br/>
        * <br/>
        */
        Paused(10),

        /**
        * Resuming. <br/>
        * <br/>
        */
        Resuming(11),

        /**
        * Referred. <br/>
        * <br/>
        */
        Referred(12),

        /**
        * Error. <br/>
        * <br/>
        */
        Error(13),

        /**
        * Call end. <br/>
        * <br/>
        */
        End(14),

        /**
        * Paused by remote. <br/>
        * <br/>
        */
        PausedByRemote(15),

        /**
        * The call's parameters are updated for example when video is asked by remote. <br/>
        * <br/>
        */
        UpdatedByRemote(16),

        /**
        * We are proposing early media to an incoming call. <br/>
        * <br/>
        */
        IncomingEarlyMedia(17),

        /**
        * We have initiated a call update. <br/>
        * <br/>
        */
        Updating(18),

        /**
        * The call object is now released. <br/>
        * <br/>
        */
        Released(19),

        /**
        * The call is updated by remote while not yet answered (SIP UPDATE in early<br/>
        * dialog received) <br/>
        * <br/>
        */
        EarlyUpdatedByRemote(20),

        /**
        * We are updating the call while not yet answered (SIP UPDATE in early dialog<br/>
        * sent) <br/>
        * <br/>
        */
        EarlyUpdating(21);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Idle;
            case 1: return IncomingReceived;
            case 2: return PushIncomingReceived;
            case 3: return OutgoingInit;
            case 4: return OutgoingProgress;
            case 5: return OutgoingRinging;
            case 6: return OutgoingEarlyMedia;
            case 7: return Connected;
            case 8: return StreamsRunning;
            case 9: return Pausing;
            case 10: return Paused;
            case 11: return Resuming;
            case 12: return Referred;
            case 13: return Error;
            case 14: return End;
            case 15: return PausedByRemote;
            case 16: return UpdatedByRemote;
            case 17: return IncomingEarlyMedia;
            case 18: return Updating;
            case 19: return Released;
            case 20: return EarlyUpdatedByRemote;
            case 21: return EarlyUpdating;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Returns a copy of the call statistics for the audio stream. <br/>
    * <br/>
    * @return a {@link CallStats} object for the audio stream or null if it isn't<br/>
    * available.     <br/>
    */
    @Nullable
    public CallStats getAudioStats();

    /**
    * Returns the ZRTP authentication token to verify. <br/>
    * <br/>
    * @return the authentication token to verify or null if ZRTP isn't enabled.   <br/>
    */
    @Nullable
    public String getAuthenticationToken();

    /**
    * Returns whether ZRTP authentication token is verified. <br/>
    * <br/>
    * If not, it must be verified by users as described in ZRTP procedure. Once done,<br/>
    * the application must inform of the results with {@link #setAuthenticationTokenVerified}<br/>
    * . <br/>
    * @return true if authentication token is verifed, false otherwise. <br/>
    */
    public boolean getAuthenticationTokenVerified();

    /**
    * Sets the result of ZRTP short code verification by user. <br/>
    * <br/>
    * If remote party also does the same, it will update the ZRTP cache so that<br/>
    * user's verification will not be required for the two users. <br/>
    * @param verified whether the ZRTP SAS is verified. <br/>
    */
    public void setAuthenticationTokenVerified(boolean verified);

    /**
    * Returns call quality averaged over all the duration of the call. <br/>
    * <br/>
    * See {@link #getCurrentQuality} for more details about quality measurement. <br/>
    * @return the call average quality since tbe beginning of the call. <br/>
    */
    public float getAverageQuality();

    /**
    * Indicates whether received Baudot tones should be detected. <br/>
    * <br/>
    * The Baudot functionality is to be enabled first by calling {@link Core#enableBaudot}<br/>
    * . <br/>
    * @param enabled wether or not to detect received Baudot tones. <br/>
    */
    public void setBaudotDetectionEnabled(boolean enabled);

    /**
    * Defines the Baudot mode for the call. <br/>
    * <br/>
    * The Baudot functionality is to be enabled first by calling {@link Core#enableBaudot}<br/>
    * . <br/>
    * @param mode The Baudot mode to use for the call. <br/>
    */
    public void setBaudotMode(BaudotMode mode);

    /**
    * Set the Baudot significant pause timeout after which a LETTERS tone is<br/>
    * retransmitted before resuming transmission (in seconds). <br/>
    * <br/>
    * Default is 5s. The Baudot functionality is to be enabled first by calling<br/>
    * {@link Core#enableBaudot}. <br/>
    * @param seconds The significant pause timeout in seconds. <br/>
    */
    public void setBaudotPauseTimeout(int seconds);

    /**
    * Defines the Baudot standard to use for sending Baudot tones in the call. <br/>
    * <br/>
    * The Baudot functionality is to be enabled first by calling {@link Core#enableBaudot}<br/>
    * . <br/>
    * @param standard The Baudot standard to use for sending Baudot tones. <br/>
    */
    public void setBaudotSendingStandard(BaudotStandard standard);

    /**
    * Gets the call log associated to this call. <br/>
    * <br/>
    * @return The {@link CallLog} associated with the specified {@link Call}.   <br/>
    */
    @NonNull
    public CallLog getCallLog();

    /**
    * Returns if camera pictures are allowed to be sent to the remote party. <br/>
    * <br/>
    * @return true if local video stream is being sent, false otherwise. <br/>
    */
    public boolean isCameraEnabled();

    /**
    * Indicates whether camera input should be sent to remote end. <br/>
    * <br/>
    * @param enabled wether or not to send local video stream. <br/>
    */
    public void setCameraEnabled(boolean enabled);

    /**
    * Obtain a chat room for real time messaging from a call if not already existing,<br/>
    * else return existing one. <br/>
    * <br/>
    * No reference is given to the caller: the chat room will be deleted when the<br/>
    * call is ended. The call must have been accepted with a real time text stream<br/>
    * (see {@link CallParams#enableRealtimeText}). <br/>
    * @return {@link ChatRoom} where real time messaging can take place or null if<br/>
    * chat room couldn't be created.    <br/>
    */
    @Nullable
    public ChatRoom getChatRoom();

    /**
    * Returns the associated conference object if any. <br/>
    * <br/>
    * @return A pointer on {@link Conference} or null if the call is not part of any<br/>
    * conference.   <br/>
    */
    @Nullable
    public Conference getConference();

    /**
    * Gets the core that has created the specified call. <br/>
    * <br/>
    * @return The {@link Core} object that has created the specified call.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Returns current parameters associated to the call. <br/>
    * <br/>
    * @return the current {@link CallParams} of this call.   <br/>
    */
    @NonNull
    public CallParams getCurrentParams();

    /**
    * Obtains real-time quality rating of the call. <br/>
    * <br/>
    * Based on local RTP statistics and RTCP feedback, a quality rating is computed<br/>
    * and updated during all the duration of the call. This function returns its<br/>
    * value at the time of the function call. It is expected that the rating is<br/>
    * updated at least every 5 seconds or so. The rating is a floating point number<br/>
    * comprised between 0 and 5.<br/>
    * 4-5 = good quality  3-4 = average quality  2-3 = poor quality  1-2 = very poor<br/>
    * quality  0-1 = can't be worse, mostly unusable <br/>
    * @return The function returns -1 if no quality measurement is available, for<br/>
    * example if no active audio stream exist. Otherwise it returns the quality<br/>
    * rating. <br/>
    */
    public float getCurrentQuality();

    /**
    * Returns direction of the call (incoming or outgoing). <br/>
    * <br/>
    * @return the {@link Dir} <br/>
    */
    public Call.Dir getDir();

    /**
    * Returns the diversion address associated to this call. <br/>
    * <br/>
    * @return the diversion address as {@link Address} or null.   <br/>
    */
    @Nullable
    public Address getDiversionAddress();

    /**
    * Returns call's duration in seconds. <br/>
    * <br/>
    * @return the call's duration in seconds. <br/>
    */
    public int getDuration();

    /**
    * Returns if echo cancellation is enabled. <br/>
    * <br/>
    * see: {@link Core#enableEchoCancellation}. <br/>
    * @return true if echo cancellation is enabled, false otherwise. <br/>
    */
    public boolean isEchoCancellationEnabled();

    /**
    * Enables or disables echo cancellation for this call. <br/>
    * <br/>
    * see: {@link Core#enableEchoCancellation}. <br/>
    * @param enable wether to enable echo cancellation or not. <br/>
    */
    public void setEchoCancellationEnabled(boolean enable);

    /**
    * Returns if echo limiter is enabled. <br/>
    * <br/>
    * see: {@link Core#enableEchoLimiter}. <br/>
    * @return true if echo limiter is enabled, false otherwise. <br/>
    */
    public boolean isEchoLimiterEnabled();

    /**
    * Enables or disables echo limiter for this call. <br/>
    * <br/>
    * see: {@link Core#enableEchoLimiter}. <br/>
    * @param enable wether to enable echo limiter or not. <br/>
    */
    public void setEchoLimiterEnabled(boolean enable);

    /**
    * Returns full details about call errors or termination reasons. <br/>
    * <br/>
    * @return {@link ErrorInfo} object holding the reason error.   <br/>
    */
    @NonNull
    public ErrorInfo getErrorInfo();

    /**
    * Gets the current input device for this call. <br/>
    * <br/>
    * @return the {@link AudioDevice} used by this call as input or null if there is<br/>
    * currently no soundcard configured (depending on the state of the call)   <br/>
    */
    @Nullable
    public AudioDevice getInputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as input for this call only. <br/>
    * <br/>
    * @param audioDevice The {@link AudioDevice}. null does nothing.   <br/>
    */
    public void setInputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Returns whether or not the call is currently being recorded. <br/>
    * <br/>
    * @return true if recording is in progress, false otherwise <br/>
    * @deprecated 15/09/2021 Use {@link CallParams#isRecording} instead. <br/>
    */
    @Deprecated
    public boolean isRecording();

    /**
    * Returns the local ZRTP authentication token to verify by the remote. <br/>
    * <br/>
    * @return the local authentication token to verify or null if ZRTP isn't enabled.<br/>
    *   <br/>
    */
    @Nullable
    public String getLocalAuthenticationToken();

    /**
    * Returns the local tag of the {@link Call}. <br/>
    * <br/>
    * @return the local tag.   <br/>
    */
    @NonNull
    public String getLocalTag();

    /**
    * Gets microphone muted state. <br/>
    * <br/>
    * Note that the microphone may be disabled globally if false was given to {@link Core#enableMic}<br/>
    * . <br/>
    * @return The microphone muted state. <br/>
    * warning: This method returns state of the mute capability of the call passed as<br/>
    * argument. If this call is part of a conference, it is strongly recommended to<br/>
    * call {@link Conference#getMicrophoneMuted} to know whether this device is muted<br/>
    * or not. <br/>
    */
    public boolean getMicrophoneMuted();

    /**
    * Sets microphone muted state. <br/>
    * <br/>
    * The boolean value given is applied logical-and with the value given to {@link Core#enableMic}<br/>
    * . <br/>
    * @param muted The microphone muted state. <br/>
    * warning: This method only mutes the call passed as argument. If this call is<br/>
    * part of a conference, it is strongly recommended to call {@link Conference#setMicrophoneMuted}<br/>
    * to ensure that the setting is correctly apply across all participants and the<br/>
    * conference callbacks are called. <br/>
    */
    public void setMicrophoneMuted(boolean muted);

    /**
    * Gets microphone volume gain. <br/>
    * <br/>
    * If the sound backend supports it, the returned gain is equal to the gain set<br/>
    * with the system mixer. <br/>
    * @return double Percentage of the max supported volume gain. Valid values are in<br/>
    * [ 0.0 : 1.0 ]. In case of failure, a negative value is returned <br/>
    */
    public float getMicrophoneVolumeGain();

    /**
    * Sets microphone volume gain. <br/>
    * <br/>
    * If the sound backend supports it, the new gain will synchronized with the<br/>
    * system mixer. <br/>
    * @param volume Percentage of the max supported gain. Valid values are in [ 0.0 :<br/>
    * 1.0 ]. <br/>
    */
    public void setMicrophoneVolumeGain(float volume);

    /**
    * Get the native window handle of the video window, casted as an unsigned long. <br/>
    * <br/>
    * see: {@link Core#setNativeVideoWindowId} for a general discussion about window<br/>
    * IDs. <br/>
    * @return the native video window id (type may vary depending on platform).   <br/>
    */
    @Nullable
    public Object getNativeVideoWindowId();

    /**
    * Set the native video window id where the video is to be displayed. <br/>
    * <br/>
    * For MacOS, Linux, Windows: if not set or 0 a window will be automatically<br/>
    * created, unless the special id -1 is given. see: {@link Core#setNativeVideoWindowId}<br/>
    * for a general discussion about window IDs. <br/>
    * @param windowId the native video window id.   <br/>
    */
    public void setNativeVideoWindowId(@Nullable Object windowId);

    /**
    * Gets the current output device for this call. <br/>
    * <br/>
    * @return the {@link AudioDevice} used by this call as output or null if there is<br/>
    * currently no soundcard configured (depending on the state of the call)   <br/>
    */
    @Nullable
    public AudioDevice getOutputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as output for this call only. <br/>
    * <br/>
    * @param audioDevice The {@link AudioDevice}. null does nothing.   <br/>
    */
    public void setOutputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Returns read-only local parameters associated with the call. <br/>
    * <br/>
    * This is typically the parameters passed at call initiation to {@link Core#inviteAddressWithParams}<br/>
    * or {@link #acceptWithParams}, or some default parameters if no {@link CallParams}<br/>
    * was explicitely passed during call initiation. <br/>
    * @return the call's local parameters.   <br/>
    */
    @NonNull
    public CallParams getParams();

    /**
    * Sets call parameters - advanced and not recommended feature - use with caution. <br/>
    * <br/>
    * Local call parameters applicable to an outgoing or incoming shall usually be<br/>
    * passed to {@link Core#inviteAddressWithParams} or {@link #acceptWithParams}.<br/>
    * However, in some cases it might be desirable from a software design standpoint<br/>
    * to modify local parameters outside of the application layer, typically in the<br/>
    * purpose of implementing a custom logic including special headers in INVITE or<br/>
    * 200Ok requests, driven by a call_state_changed listener method. This function<br/>
    * accepts to assign a new {@link CallParams} only in {@link State#OutgoingInit}<br/>
    * and {@link State#IncomingReceived} states.<br/>
    * @param params the {@link CallParams} object   <br/>
    */
    public void setParams(@NonNull CallParams params);

    /**
    * Gets the mesured playback volume level (received from remote) in dbm0. <br/>
    * <br/>
    * @return float Volume level in dbm0. <br/>
    */
    public float getPlayVolume();

    /**
    * Gets a player associated with the call to play a local file and stream it to<br/>
    * the remote peer. <br/>
    * <br/>
    * @return A {@link Player} object.   <br/>
    */
    @Nullable
    public Player getPlayer();

    /**
    * Returns the reason for a call termination (either error or normal termination) <br/>
    * <br/>
    * @return the {@link Reason} of the call termination. <br/>
    */
    public Reason getReason();

    /**
    * Gets the mesured record volume level (sent to remote) in dbm0. <br/>
    * <br/>
    * @return float Volume level in dbm0. <br/>
    */
    public float getRecordVolume();

    /**
    * Gets the refer-to uri (if the call was transferred). <br/>
    * <br/>
    * @return The refer-to uri of the call (if it was transferred).   <br/>
    */
    @Nullable
    public String getReferTo();

    /**
    * Gets the refer-to uri (if the call was transferred). <br/>
    * <br/>
    * @return The refer-to uri of the call (if it was transferred).   <br/>
    */
    @Nullable
    public Address getReferToAddress();

    /**
    * Gets the referred-by address, which is set when an incoming call is received as<br/>
    * a consequence of a call transfer operation by a third party. <br/>
    * <br/>
    * The referred-by address is the sip identity of the one who initiated the<br/>
    * transfer. <br/>
    * @return The referred-by address   <br/>
    */
    @Nullable
    public Address getReferredByAddress();

    /**
    * Returns the remote address associated to this call. <br/>
    * <br/>
    * @return The {@link Address} of the remote end of the call.   <br/>
    */
    @NonNull
    public Address getRemoteAddress();

    /**
    * Returns the remote address associated to this call as a string. <br/>
    * <br/>
    * The result string must be freed by user using ms_free(). <br/>
    * @return the remote address as a string.     <br/>
    * @deprecated 06/07/2020 use {@link #getRemoteAddress} instead. <br/>
    */
    @Deprecated
    @Nullable
    public String getRemoteAddressAsString();

    /**
    * Returns a list of 4 remote ZRTP authentication tokens. <br/>
    * <br/>
    * The user needs to select one. <br/>
    * @return the authentication tokens to verify or null if ZRTP isn't enabled.    <br/>
    */
    @NonNull
    public String[] getRemoteAuthenticationTokens();

    /**
    * Returns the far end's sip contact as a string, if available. <br/>
    * <br/>
    * @return the remote contact or null.   <br/>
    */
    @Nullable
    public String getRemoteContact();

    /**
    * Returns the far end's sip contact as an address, if available. <br/>
    * <br/>
    * @return the remote contact as a {@link Address} or null.   <br/>
    */
    @Nullable
    public Address getRemoteContactAddress();

    /**
    * Returns call parameters proposed by remote. <br/>
    * <br/>
    * This is useful when receiving an incoming call, to know whether the remote<br/>
    * party supports video, encryption or whatever.<br/>
    * @return the {@link CallParams} suggested by the remote or null.   <br/>
    */
    @Nullable
    public CallParams getRemoteParams();

    /**
    * Returns the remote tag of the {@link Call}. <br/>
    * <br/>
    * @return the remote tag.   <br/>
    */
    @NonNull
    public String getRemoteTag();

    /**
    * Returns the far end's user agent description string, if available. <br/>
    * <br/>
    * @return the remote user agent or null.   <br/>
    */
    @Nullable
    public String getRemoteUserAgent();

    /**
    * Returns the call object this call is replacing, if any. <br/>
    * <br/>
    * Call replacement can occur during call transfers. By default, the core<br/>
    * automatically terminates the replaced call and accept the new one. This<br/>
    * function allows the application to know whether a new incoming call is a one<br/>
    * that replaces another one. <br/>
    * @return the {@link Call} object this call is replacing or null.   <br/>
    */
    @Nullable
    public Call getReplacedCall();

    /**
    * The address to which the call has been sent, taken directly from the SIP<br/>
    * request-URI of the INVITE. <br/>
    * <br/>
    * Usually equal to the To field, except when e.g. using a fallback contact<br/>
    * address. You should probably use getToAddress() instead, unless you know what<br/>
    * you're doing. <br/>
    * @return the {@link Address} matching the URI of the INVITE request.   <br/>
    */
    @NonNull
    public Address getRequestAddress();

    /**
    * Gets speaker muted state. <br/>
    * <br/>
    * @return The speaker muted state. <br/>
    */
    public boolean getSpeakerMuted();

    /**
    * Sets speaker muted state. <br/>
    * <br/>
    * @param muted The speaker muted state. <br/>
    */
    public void setSpeakerMuted(boolean muted);

    /**
    * Gets speaker volume gain. <br/>
    * <br/>
    * If the sound backend supports it, the returned gain is equal to the gain set<br/>
    * with the system mixer. <br/>
    * @return Percentage of the max supported volume gain. Valid values are in [ 0.0<br/>
    * : 1.0 ]. In case of failure, a negative value is returned <br/>
    */
    public float getSpeakerVolumeGain();

    /**
    * Sets speaker volume gain. <br/>
    * <br/>
    * If the sound backend supports it, the new gain will synchronized with the<br/>
    * system mixer. <br/>
    * @param volume Percentage of the max supported gain. Valid values are in [ 0.0 :<br/>
    * 1.0 ]. <br/>
    */
    public void setSpeakerVolumeGain(float volume);

    /**
    * Retrieves the call's current state. <br/>
    * <br/>
    * @return the current {@link State} of this call. <br/>
    */
    public Call.State getState();

    /**
    * Returns the number of stream for the given call. <br/>
    * <br/>
    * @return the amount of streams for this call. <br/>
    */
    public int getStreamCount();

    /**
    * Returns a copy of the call statistics for the text stream. <br/>
    * <br/>
    * @return a {@link CallStats} object for the text stream or null if it isn't<br/>
    * available.     <br/>
    */
    @Nullable
    public CallStats getTextStats();

    /**
    * Returns the to address with its headers associated to this call. <br/>
    * <br/>
    * @return the {@link Address} matching the TO of the call.   <br/>
    */
    @NonNull
    public Address getToAddress();

    /**
    * Returns the current transfer state, if a transfer has been initiated from this<br/>
    * call. <br/>
    * <br/>
    * see: linphone_core_transfer_call , linphone_core_transfer_call_to_another <br/>
    * @return the {@link State}. <br/>
    */
    public Call.State getTransferState();

    /**
    * When this call has received a transfer request, returns the new call that was<br/>
    * automatically created as a result of the transfer. <br/>
    * <br/>
    * @return the transfer {@link Call} created.   <br/>
    */
    @Nullable
    public Call getTransferTargetCall();

    /**
    * Gets the transferer if this call was started automatically as a result of an<br/>
    * incoming transfer request. <br/>
    * <br/>
    * The call in which the transfer request was received is returned in this case. <br/>
    * @return The transferer {@link Call} if the specified call was started<br/>
    * automatically as a result of an incoming transfer request, null otherwise.   <br/>
    */
    @Nullable
    public Call getTransfererCall();

    /**
    * Gets the video source of a call. <br/>
    * <br/>
    * @return The {@link VideoSourceDescriptor} describing the video source that is<br/>
    * set   <br/>
    */
    @Nullable
    public VideoSourceDescriptor getVideoSource();

    /**
    * Sets the video source of a call. <br/>
    * <br/>
    * @param descriptor The {@link VideoSourceDescriptor} describing the video source<br/>
    * to set   <br/>
    */
    public void setVideoSource(@Nullable VideoSourceDescriptor descriptor);

    /**
    * Returns a copy of the call statistics for the video stream. <br/>
    * <br/>
    * @return a {@link CallStats} object for the video stream or null if it isn't<br/>
    * available.     <br/>
    */
    @Nullable
    public CallStats getVideoStats();

    /**
    * Returns whether ZRTP cache mismatch. <br/>
    * <br/>
    * If mismatch, the ZRTP authentication token must be verified by users as<br/>
    * described in ZRTP procedure. <br/>
    * @return true if ZRTP cache mismatch, false otherwise. <br/>
    */
    public boolean getZrtpCacheMismatchFlag();

    /**
    * Accepts an incoming call. <br/>
    * <br/>
    * Basically the application is notified of incoming calls within the<br/>
    * call_state_changed callback of the LinphoneCoreVTable structure, where it will<br/>
    * receive a #LinphoneCallStateIncoming event with the associated {@link Call}<br/>
    * object. The application can later accept the call using this method. <br/>
    * @return 0 on success, -1 on failure <br/>
    */
    public int accept();

    /**
    * Accepts an early media session for an incoming call. <br/>
    * <br/>
    * This is identical as calling {@link #acceptEarlyMediaWithParams} with null<br/>
    * parameters. <br/>
    * @return 0 if successful, -1 otherwise <br/>
    * see: {@link #acceptEarlyMediaWithParams} <br/>
    */
    public int acceptEarlyMedia();

    /**
    * When receiving an incoming, accepts to start a media session as early-media. <br/>
    * <br/>
    * This means the call is not accepted but audio & video streams can be<br/>
    * established if the remote party supports early media. However, unlike after<br/>
    * call acceptance, mic and camera input are not sent during early-media, though<br/>
    * received audio & video are played normally. The call can then later be fully<br/>
    * accepted using {@link #accept} or {@link #acceptWithParams}. <br/>
    * @param params The call parameters to use (can be null).   <br/>
    * @return 0 if successful, -1 otherwise <br/>
    */
    public int acceptEarlyMediaWithParams(@Nullable CallParams params);

    /**
    * Accepts and execute a transfer (ie an incoming REFER request), to use when<br/>
    * [sip] 'auto_accept_refer' property is false. <br/>
    * <br/>
    * Default behaviour is to accept and execute the transfer automatically. <br/>
    */
    public void acceptTransfer();

    /**
    * Accepts call modifications initiated by other end through an incoming reINVITE<br/>
    * or UPDATE request. <br/>
    * <br/>
    * {@link #acceptUpdate} is typically used in response to a {@link State#UpdatedByRemote}<br/>
    * state notification. When such notification arrives, the application has several<br/>
    * choices:<br/>
    * An application may use {@link #getRemoteParams} to get information about the<br/>
    * call parameters proposed by the other party (for example when he wants to add a<br/>
    * video stream), in order to decide what to do, like for example requesting the<br/>
    * end-user approval.<br/>
    * The params argument must be constructed with {@link Core#createCallParams}.<br/>
    * {@link Core#createCallParams} will initialize the returned {@link CallParams}<br/>
    * according to the offered parameters, previously used local parameters and local<br/>
    * policies. For example, if the remote user-agent wants to add a video stream but<br/>
    * the {@link VideoActivationPolicy} of the {@link Core} is to not automatically<br/>
    * accept video, then the {@link CallParams} will get its video stream disabled.<br/>
    * The application is free to modify the {@link CallParams} before passing it to<br/>
    * {@link #acceptUpdate}. Using null as params argument is allowed and equivalent<br/>
    * to passing a {@link CallParams} created by {@link Core#createCallParams} and<br/>
    * left unmodified.<br/>
    * The answer generated by {@link #acceptUpdate} at first follows RFC3264 SDP<br/>
    * offer answer model rules. The supplied {@link CallParams} allows to give<br/>
    * application instructions about the response to generate, such as accepting or<br/>
    * not the enablement of new stream. {@link #acceptUpdate} does not have the<br/>
    * pretention to control every aspect of the generation of the answer of an SDP<br/>
    * offer/answer procedure.<br/>
    * @param params A {@link CallParams} object describing the call parameters to<br/>
    * accept.   <br/>
    * @return 0 if successful, -1 otherwise (actually when this function call is<br/>
    * performed outside ot {@link State#UpdatedByRemote} state) <br/>
    */
    public int acceptUpdate(@Nullable CallParams params);

    /**
    * Accepts an incoming call, with parameters. <br/>
    * <br/>
    * Basically the application is notified of incoming calls within the<br/>
    * call_state_changed callback of the LinphoneCoreVTable structure, where it will<br/>
    * receive a #LinphoneCallStateIncoming event with the associated {@link Call}<br/>
    * object. The application can later accept the call using this method. <br/>
    * @param params The specific parameters for this call, for example whether video<br/>
    * is accepted or not. Use null to use default parameters.   <br/>
    * @return 0 on success, -1 on failure <br/>
    */
    public int acceptWithParams(@Nullable CallParams params);

    /**
    * Tells whether a call has been asked to autoanswer. <br/>
    * <br/>
    * @return A boolean value telling whether the call has been asked to autoanswer <br/>
    */
    public boolean askedToAutoanswer();

    /**
    * Stops current DTMF sequence sending. <br/>
    * <br/>
    * Please note that some DTMF could be already sent, depending on when this<br/>
    * function call is delayed from {@link #sendDtmfs}. This function will be<br/>
    * automatically called if call state change to anything but<br/>
    * LinphoneCallStreamsRunning. <br/>
    */
    public void cancelDtmfs();

    /**
    * Verifies that the half ZRTP short authentication string (SAS) selected by the<br/>
    * user is correct, and set the verification result accordingly. <br/>
    * <br/>
    * If the remote party also verifies his/her half code correctly, the ZRTP cache<br/>
    * will be updated to prevent future verification requirements for these two<br/>
    * users. <br/>
    * @param selectedValue The ZRTP SAS selected by the user, or an empty string if<br/>
    * the user cannot find the SAS <br/>
    */
    public void checkAuthenticationTokenSelected(String selectedValue);

    /**
    * Method to be called after the user confirm that he/she is notifed of the on<br/>
    * going Go Clear procedure. <br/>
    * <br/>
    * warning: this operation must be imperatevely initiate by a user action on<br/>
    * sending of the GoClear ACK <br/>
    */
    public void confirmGoClear();

    /**
    * Create a native video window id where the video is to be displayed. <br/>
    * <br/>
    * see: {@link Core#setNativeVideoWindowId} for a general discussion about window<br/>
    * IDs.<br/>
    * A context can be used to prevent Linphone from allocating the container<br/>
    * (#MSOglContextInfo for MSOGL). null if not used. <br/>
    * @param context preallocated Window ID (Used only for MSOGL)   <br/>
    * @return the native video window id (type may vary depending on platform).   <br/>
    */
    @Nullable
    public Object createNativeVideoWindowId(@Nullable Object context);

    /**
    * Create a native video window id where the video is to be displayed. <br/>
    * <br/>
    * see: {@link Core#setNativeVideoWindowId} for a general discussion about window<br/>
    * IDs.<br/>
    * @return the native video window id (type may vary depending on platform).   <br/>
    */
    @Nullable
    public Object createNativeVideoWindowId();

    /**
    * Create a {@link Event} in order to send NOTIFY requests through the SIP dialog<br/>
    * created by the call. <br/>
    * <br/>
    * The call state must have passed through {@link State#Connected}. <br/>
    * @param event The event type to be notified. <br/>
    * @return a new {@link Event}   <br/>
    */
    @Nullable
    public Event createNotify(String event);

    /**
    * Declines a pending incoming call, with a reason. <br/>
    * <br/>
    * @param reason The reason for rejecting the call: {@link Reason#Declined} or<br/>
    * {@link Reason#Busy} <br/>
    * @return 0 on success, -1 on failure <br/>
    */
    public int decline(Reason reason);

    /**
    * Declines a pending incoming call, with a {@link ErrorInfo} object. <br/>
    * <br/>
    * @param ei {@link ErrorInfo} containing more information on the call rejection. <br/>
    *  <br/>
    * @return 0 on success, -1 on failure <br/>
    */
    public int declineWithErrorInfo(@Nullable ErrorInfo ei);

    /**
    * When receiving a {@link State#UpdatedByRemote} state notification, prevent<br/>
    * {@link Core} from performing an automatic answer. <br/>
    * <br/>
    * When receiving a {@link State#UpdatedByRemote} state notification (ie an<br/>
    * incoming reINVITE), the default behaviour of {@link Core} is defined by the<br/>
    * "defer_update_default" option of the "sip" section of the config. If this<br/>
    * option is 0 (the default) then the {@link Core} automatically answers the<br/>
    * reINIVTE with call parameters unchanged. However when for example when the<br/>
    * remote party updated the call to propose a video stream, it can be useful to<br/>
    * prompt the user before answering. This can be achieved by calling<br/>
    * linphone_core_defer_call_update during the call state notification, to<br/>
    * deactivate the automatic answer that would just confirm the audio but reject<br/>
    * the video. Then, when the user responds to dialog prompt, it becomes possible<br/>
    * to call {@link #acceptUpdate} to answer the reINVITE, with video possibly<br/>
    * enabled in the {@link CallParams} argument.<br/>
    * The {@link State#UpdatedByRemote} notification can also happen when receiving<br/>
    * an INVITE without SDP. In such case, an unchanged offer is made in the 200Ok,<br/>
    * and when the ACK containing the SDP answer is received, {@link State#UpdatedByRemote}<br/>
    * is triggered to notify the application of possible changes in the media<br/>
    * session. However in such case defering the update has no meaning since we just<br/>
    * generated an offer.<br/>
    * @return 0 if successful, -1 if the {@link #deferUpdate} was done outside a<br/>
    * valid #LinphoneCallUpdatedByRemote notification <br/>
    */
    public int deferUpdate();

    /**
    * Returns a copy of the call statistics for a particular stream type. <br/>
    * <br/>
    * @param type the {@link StreamType} <br/>
    * @return a {@link CallStats} object for the given stream or null if stream isn't<br/>
    * available.     <br/>
    */
    @Nullable
    public CallStats getStats(StreamType type);

    /**
    * Returns the value of the header name. <br/>
    * <br/>
    * @param headerName the name of the header to check.   <br/>
    * @return the value of the header if exists.   <br/>
    * @deprecated 27/10/2020. Use {@link CallParams#getCustomHeader} on {@link #getRemoteParams}<br/>
    * instead. <br/>
    */
    @Deprecated
    @Nullable
    public String getToHeader(@NonNull String headerName);

    /**
    * Returns if this calls has received a transfer that has not been executed yet. <br/>
    * <br/>
    * Pending transfers are executed when this call is being paused or closed,<br/>
    * locally or by remote endpoint. If the call is already paused while receiving<br/>
    * the transfer request, the transfer immediately occurs. <br/>
    * @return true if transfer is pending, false otherwise. <br/>
    */
    public boolean hasTransferPending();

    /**
    * Indicates whether an operation is in progress at the media side. <br/>
    * <br/>
    * It can be a bad idea to initiate signaling operations (adding video, pausing<br/>
    * the call, removing video, changing video parameters) while the media is busy in<br/>
    * establishing the connection (typically ICE connectivity checks). It can result<br/>
    * in failures generating loss of time in future operations in the call.<br/>
    * Applications are invited to check this function after each call state change to<br/>
    * decide whether certain operations are permitted or not. <br/>
    * @return true if media is busy in establishing the connection, false otherwise. <br/>
    */
    public boolean mediaInProgress();

    /**
    * Starts the process of replying 180 Ringing. <br/>
    * <br/>
    * This function is used in conjonction with {@link Core#enableAutoSendRinging}.<br/>
    * If the automatic sending of the 180 Ringing is disabled, this function needs to<br/>
    * be called manually before the call timeouts.<br/>
    */
    public void notifyRinging();

    /**
    * Calls generic OpenGL render for a given call. <br/>
    * <br/>
    */
    public void oglRender();

    /**
    * Pauses the call. <br/>
    * <br/>
    * If a music file has been setup using {@link Core#setPlayFile}, this file will<br/>
    * be played to the remote user. The only way to resume a paused call is to call<br/>
    * {@link #resume}. <br/>
    * @return 0 on success, -1 on failure <br/>
    * see: {@link #resume} <br/>
    */
    public int pause();

    /**
    * Redirect the specified call to the given redirect URI. <br/>
    * <br/>
    * @param redirectUri The URI to redirect the call to   <br/>
    * @return 0 if successful, -1 on error. <br/>
    * @deprecated 27/10/2020. Use {@link #redirectTo} instead. <br/>
    */
    @Deprecated
    public int redirect(@NonNull String redirectUri);

    /**
    * Redirects the specified call to the given redirect Address. <br/>
    * <br/>
    * @param redirectAddress The {@link Address} to redirect the call to   <br/>
    * @return 0 if successful, -1 on error. <br/>
    */
    public int redirectTo(@NonNull Address redirectAddress);

    /**
    * Requests the callback passed to linphone_call_cbs_set_next_video_frame_decoded<br/>
    * to be called the next time the video decoder properly decodes a video frame. <br/>
    * <br/>
    */
    public void requestNotifyNextVideoFrameDecoded();

    /**
    * Resumes a call. <br/>
    * <br/>
    * The call needs to have been paused previously with {@link #pause}. <br/>
    * @return 0 on success, -1 on failure <br/>
    * see: {@link #pause} <br/>
    */
    public int resume();

    /**
    * Sends the specified dtmf. <br/>
    * <br/>
    * The dtmf is automatically played to the user. see: {@link Core#setUseRfc2833ForDtmf}<br/>
    * @param dtmf The dtmf name specified as a char, such as '0', '#' etc... <br/>
    * @return 0 if successful, -1 on error. <br/>
    */
    public int sendDtmf(char dtmf);

    /**
    * Sends a list of dtmf. <br/>
    * <br/>
    * The dtmfs are automatically sent to remote, separated by some needed<br/>
    * customizable delay. Sending is canceled if the call state changes to something<br/>
    * not LinphoneCallStreamsRunning. see: {@link Core#setUseRfc2833ForDtmf} <br/>
    * @param dtmfs A dtmf sequence such as '123#123123'   <br/>
    * @return -2 if there is already a DTMF sequence, -1 if call is not ready, 0<br/>
    * otherwise. <br/>
    */
    public int sendDtmfs(@NonNull String dtmfs);

    /**
    * Sends an info message through an established call. <br/>
    * <br/>
    * @param info the {@link InfoMessage} to send   <br/>
    */
    public int sendInfoMessage(@NonNull InfoMessage info);

    /**
    * Requests remote side to send us a Video Fast Update. <br/>
    * <br/>
    */
    public void sendVfuRequest();

    /**
    * If the user skips the ZRTP authentication check, stop the security alert. <br/>
    * <br/>
    */
    public void skipZrtpAuthentication();

    /**
    * Starts call recording. <br/>
    * <br/>
    * Video record is only available if this function is called in state<br/>
    * StreamRunning. The output file where audio is recorded must be previously<br/>
    * specified with {@link CallParams#setRecordFile}. <br/>
    */
    public void startRecording();

    /**
    * Stops call recording. <br/>
    * <br/>
    */
    public void stopRecording();

    /**
    * Takes a photo of currently captured video and write it into a jpeg file. <br/>
    * <br/>
    * Note that the snapshot is asynchronous, an application shall not assume that<br/>
    * the file is created when the function returns. <br/>
    * @param filePath a path where to write the jpeg content.   <br/>
    * @return 0 if successful, -1 otherwise (typically if jpeg format is not<br/>
    * supported). <br/>
    */
    public int takePreviewSnapshot(@NonNull String filePath);

    /**
    * Takes a photo of currently received video and write it into a jpeg file. <br/>
    * <br/>
    * Note that the snapshot is asynchronous, an application shall not assume that<br/>
    * the file is created when the function returns. <br/>
    * @param filePath a path where to write the jpeg content.   <br/>
    * @return 0 if successful, -1 otherwise (typically if jpeg format is not<br/>
    * supported). <br/>
    */
    public int takeVideoSnapshot(@NonNull String filePath);

    /**
    * Terminates (ends) a call. <br/>
    * <br/>
    * @return 0 on success, -1 on failure <br/>
    */
    public int terminate();

    /**
    * Terminates a call with additional information, serialized as a Reason header. <br/>
    * <br/>
    * @param ei {@link ErrorInfo}   <br/>
    * @return 0 on success, -1 on failure <br/>
    */
    public int terminateWithErrorInfo(@Nullable ErrorInfo ei);

    /**
    * Performs a simple call transfer to the specified destination. <br/>
    * <br/>
    * The remote endpoint is expected to issue a new call to the specified<br/>
    * destination. The current call remains active and thus can be later paused or<br/>
    * terminated. It is possible to follow the progress of the transfer provided that<br/>
    * transferee sends notification about it. In this case, the<br/>
    * transfer_state_changed callback of the LinphoneCoreVTable is invoked to notify<br/>
    * of the state of the new call at the other party. The notified states are<br/>
    * #LinphoneCallOutgoingInit , #LinphoneCallOutgoingProgress,<br/>
    * #LinphoneCallOutgoingRinging and #LinphoneCallConnected. <br/>
    * @param referTo The destination the call is to be referred to.   <br/>
    * @return 0 on success, -1 on failure <br/>
    * @deprecated 27/10/2020. Use {@link #transferTo} instead. <br/>
    */
    @Deprecated
    public int transfer(@NonNull String referTo);

    /**
    * Performs a simple call transfer to the specified destination. <br/>
    * <br/>
    * The remote endpoint is expected to issue a new call to the specified<br/>
    * destination. The current call remains active and thus can be later paused or<br/>
    * terminated. It is possible to follow the progress of the transfer provided that<br/>
    * transferee sends notification about it. In this case, the 'transfer state<br/>
    * changed' callback of the {@link CoreListener} is invoked to notify of the state<br/>
    * of the new call to the other party. The notified states are {@link State#OutgoingInit}<br/>
    * , {@link State#OutgoingProgress}, {@link State#OutgoingRinging} and {@link State#Connected}<br/>
    * . <br/>
    * @param referTo The {@link Address} the call is to be referred to.   <br/>
    * @return 0 on success, -1 on failure <br/>
    */
    public int transferTo(@NonNull Address referTo);

    /**
    * Transfers a call to destination of another running call. <br/>
    * <br/>
    * This is used for "attended transfer" scenarios. The transferred call is<br/>
    * supposed to be in paused state, so that it is able to accept the transfer<br/>
    * immediately. The destination call is a call previously established to introduce<br/>
    * the transferred person. This method will send a transfer request to the<br/>
    * transferred person. The phone of the transferred is then expected to<br/>
    * automatically call to the destination of the transfer. The receiver of the<br/>
    * transfer will then automatically close the call with us (the 'dest' call). It<br/>
    * is possible to follow the progress of the transfer provided that transferee<br/>
    * sends notification about it. In this case, the "transfer state changed"<br/>
    * callback of the {@link CoreListener} is invoked to notify of the state of the<br/>
    * new call to the other party. The notified states are {@link State#OutgoingInit}<br/>
    * , {@link State#OutgoingProgress}, {@link State#OutgoingRinging} and {@link State#Connected}<br/>
    * . <br/>
    * @param dest A running call whose remote person will receive the transfer   <br/>
    * @return 0 on success, -1 on failure <br/>
    */
    public int transferToAnother(@NonNull Call dest);

    /**
    * Updates a running call according to supplied call parameters or parameters<br/>
    * changed in the LinphoneCore. <br/>
    * <br/>
    * It triggers a SIP reINVITE in order to perform a new offer/answer of media<br/>
    * capabilities. Changing the size of the transmitted video after calling<br/>
    * linphone_core_set_preferred_video_size can be used by passing null as params<br/>
    * argument. In case no changes are requested through the {@link CallParams}<br/>
    * argument, then this argument can be omitted and set to null. WARNING: Updating<br/>
    * a call in the {@link State#Paused} state will still result in a paused call<br/>
    * even if the media directions set in the params are sendrecv. To resume a paused<br/>
    * call, you need to call {@link #resume}.<br/>
    * @param params The new call parameters to use (may be null).   <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    */
    public int update(@Nullable CallParams params);

    /**
    * Performs a zoom of the video displayed during a call. <br/>
    * <br/>
    * The zoom ensures that all the screen is fullfilled with the video. <br/>
    * @param zoomFactor a floating point number describing the zoom factor. A value<br/>
    * 1.0 corresponds to no zoom applied. <br/>
    * @param cx a floating point number pointing the horizontal center of the zoom to<br/>
    * be applied. This value should be between 0.0 and 1.0. <br/>
    * @param cy a floating point number pointing the vertical center of the zoom to<br/>
    * be applied. This value should be between 0.0 and 1.0. <br/>
    */
    public void zoom(float zoomFactor, float cx, float cy);

    /**
    */
    public void addListener(CallListener listener);

    /**
    */
    public void removeListener(CallListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class CallImpl implements Call {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected CallImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native CallStats getAudioStats(long nativePtr);
    @Override @Nullable
    synchronized public CallStats getAudioStats()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getAudioStats() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallStats)getAudioStats(nativePtr);
        }
    }

    private native String getAuthenticationToken(long nativePtr);
    @Override @Nullable
    synchronized public String getAuthenticationToken()  {
        synchronized(core) { 
        
        return getAuthenticationToken(nativePtr);
        }
    }

    private native boolean getAuthenticationTokenVerified(long nativePtr);
    @Override
    synchronized public boolean getAuthenticationTokenVerified()  {
        synchronized(core) { 
        
        return getAuthenticationTokenVerified(nativePtr);
        }
    }

    private native void setAuthenticationTokenVerified(long nativePtr, boolean verified);
    @Override
    synchronized public void setAuthenticationTokenVerified(boolean verified)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAuthenticationTokenVerified() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAuthenticationTokenVerified(nativePtr, verified);
        }
    }

    private native float getAverageQuality(long nativePtr);
    @Override
    synchronized public float getAverageQuality()  {
        synchronized(core) { 
        
        return getAverageQuality(nativePtr);
        }
    }

    private native void setBaudotDetectionEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setBaudotDetectionEnabled(boolean enabled)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBaudotDetectionEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBaudotDetectionEnabled(nativePtr, enabled);
        }
    }

    private native void setBaudotMode(long nativePtr, int mode);
    @Override
    synchronized public void setBaudotMode(BaudotMode mode)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBaudotMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBaudotMode(nativePtr, mode.toInt());
        }
    }

    private native void setBaudotPauseTimeout(long nativePtr, int seconds);
    @Override
    synchronized public void setBaudotPauseTimeout(int seconds)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBaudotPauseTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBaudotPauseTimeout(nativePtr, seconds);
        }
    }

    private native void setBaudotSendingStandard(long nativePtr, int standard);
    @Override
    synchronized public void setBaudotSendingStandard(BaudotStandard standard)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBaudotSendingStandard() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBaudotSendingStandard(nativePtr, standard.toInt());
        }
    }

    private native CallLog getCallLog(long nativePtr);
    @Override @NonNull
    synchronized public CallLog getCallLog()  {
        synchronized(core) { 
        
        return (CallLog)getCallLog(nativePtr);
        }
    }

    private native boolean isCameraEnabled(long nativePtr);
    @Override
    synchronized public boolean isCameraEnabled()  {
        synchronized(core) { 
        
        return isCameraEnabled(nativePtr);
        }
    }

    private native void setCameraEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setCameraEnabled(boolean enabled)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCameraEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCameraEnabled(nativePtr, enabled);
        }
    }

    private native ChatRoom getChatRoom(long nativePtr);
    @Override @Nullable
    synchronized public ChatRoom getChatRoom()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)getChatRoom(nativePtr);
        }
    }

    private native Conference getConference(long nativePtr);
    @Override @Nullable
    synchronized public Conference getConference()  {
        synchronized(core) { 
        
        return (Conference)getConference(nativePtr);
        }
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native CallParams getCurrentParams(long nativePtr);
    @Override @NonNull
    synchronized public CallParams getCurrentParams()  {
        synchronized(core) { 
        
        return (CallParams)getCurrentParams(nativePtr);
        }
    }

    private native float getCurrentQuality(long nativePtr);
    @Override
    synchronized public float getCurrentQuality()  {
        synchronized(core) { 
        
        return getCurrentQuality(nativePtr);
        }
    }

    private native int getDir(long nativePtr);
    @Override
    synchronized public Call.Dir getDir()  {
        synchronized(core) { 
        
        return Call.Dir.fromInt(getDir(nativePtr));
        }
    }

    private native Address getDiversionAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getDiversionAddress()  {
        synchronized(core) { 
        
        return (Address)getDiversionAddress(nativePtr);
        }
    }

    private native int getDuration(long nativePtr);
    @Override
    synchronized public int getDuration()  {
        synchronized(core) { 
        
        return getDuration(nativePtr);
        }
    }

    private native boolean isEchoCancellationEnabled(long nativePtr);
    @Override
    synchronized public boolean isEchoCancellationEnabled()  {
        synchronized(core) { 
        
        return isEchoCancellationEnabled(nativePtr);
        }
    }

    private native void setEchoCancellationEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setEchoCancellationEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEchoCancellationEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEchoCancellationEnabled(nativePtr, enable);
        }
    }

    private native boolean isEchoLimiterEnabled(long nativePtr);
    @Override
    synchronized public boolean isEchoLimiterEnabled()  {
        synchronized(core) { 
        
        return isEchoLimiterEnabled(nativePtr);
        }
    }

    private native void setEchoLimiterEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setEchoLimiterEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEchoLimiterEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEchoLimiterEnabled(nativePtr, enable);
        }
    }

    private native ErrorInfo getErrorInfo(long nativePtr);
    @Override @NonNull
    synchronized public ErrorInfo getErrorInfo()  {
        synchronized(core) { 
        
        return (ErrorInfo)getErrorInfo(nativePtr);
        }
    }

    private native AudioDevice getInputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getInputAudioDevice()  {
        synchronized(core) { 
        
        return (AudioDevice)getInputAudioDevice(nativePtr);
        }
    }

    private native void setInputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setInputAudioDevice(@Nullable AudioDevice audioDevice)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInputAudioDevice(nativePtr, audioDevice);
        }
    }

    private native boolean isRecording(long nativePtr);
    @Override
    synchronized public boolean isRecording()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isRecording() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isRecording(nativePtr);
        }
    }

    private native String getLocalAuthenticationToken(long nativePtr);
    @Override @Nullable
    synchronized public String getLocalAuthenticationToken()  {
        synchronized(core) { 
        
        return getLocalAuthenticationToken(nativePtr);
        }
    }

    private native String getLocalTag(long nativePtr);
    @Override @NonNull
    synchronized public String getLocalTag()  {
        synchronized(core) { 
        
        return getLocalTag(nativePtr);
        }
    }

    private native boolean getMicrophoneMuted(long nativePtr);
    @Override
    synchronized public boolean getMicrophoneMuted()  {
        synchronized(core) { 
        
        return getMicrophoneMuted(nativePtr);
        }
    }

    private native void setMicrophoneMuted(long nativePtr, boolean muted);
    @Override
    synchronized public void setMicrophoneMuted(boolean muted)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMicrophoneMuted() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMicrophoneMuted(nativePtr, muted);
        }
    }

    private native float getMicrophoneVolumeGain(long nativePtr);
    @Override
    synchronized public float getMicrophoneVolumeGain()  {
        synchronized(core) { 
        
        return getMicrophoneVolumeGain(nativePtr);
        }
    }

    private native void setMicrophoneVolumeGain(long nativePtr, float volume);
    @Override
    synchronized public void setMicrophoneVolumeGain(float volume)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMicrophoneVolumeGain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMicrophoneVolumeGain(nativePtr, volume);
        }
    }

    private native Object getNativeVideoWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object getNativeVideoWindowId()  {
        synchronized(core) { 
        
        return getNativeVideoWindowId(nativePtr);
        }
    }

    private native void setNativeVideoWindowId(long nativePtr, Object windowId);
    @Override
    synchronized public void setNativeVideoWindowId(@Nullable Object windowId)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNativeVideoWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNativeVideoWindowId(nativePtr, windowId);
        }
    }

    private native AudioDevice getOutputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getOutputAudioDevice()  {
        synchronized(core) { 
        
        return (AudioDevice)getOutputAudioDevice(nativePtr);
        }
    }

    private native void setOutputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setOutputAudioDevice(@Nullable AudioDevice audioDevice)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOutputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOutputAudioDevice(nativePtr, audioDevice);
        }
    }

    private native CallParams getParams(long nativePtr);
    @Override @NonNull
    synchronized public CallParams getParams()  {
        synchronized(core) { 
        
        return (CallParams)getParams(nativePtr);
        }
    }

    private native void setParams(long nativePtr, CallParams params);
    @Override
    synchronized public void setParams(@NonNull CallParams params)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParams(nativePtr, params);
        }
    }

    private native float getPlayVolume(long nativePtr);
    @Override
    synchronized public float getPlayVolume()  {
        synchronized(core) { 
        
        return getPlayVolume(nativePtr);
        }
    }

    private native Player getPlayer(long nativePtr);
    @Override @Nullable
    synchronized public Player getPlayer()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPlayer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Player)getPlayer(nativePtr);
        }
    }

    private native int getReason(long nativePtr);
    @Override
    synchronized public Reason getReason()  {
        synchronized(core) { 
        
        return Reason.fromInt(getReason(nativePtr));
        }
    }

    private native float getRecordVolume(long nativePtr);
    @Override
    synchronized public float getRecordVolume()  {
        synchronized(core) { 
        
        return getRecordVolume(nativePtr);
        }
    }

    private native String getReferTo(long nativePtr);
    @Override @Nullable
    synchronized public String getReferTo()  {
        synchronized(core) { 
        
        return getReferTo(nativePtr);
        }
    }

    private native Address getReferToAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getReferToAddress()  {
        synchronized(core) { 
        
        return (Address)getReferToAddress(nativePtr);
        }
    }

    private native Address getReferredByAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getReferredByAddress()  {
        synchronized(core) { 
        
        return (Address)getReferredByAddress(nativePtr);
        }
    }

    private native Address getRemoteAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getRemoteAddress()  {
        synchronized(core) { 
        
        return (Address)getRemoteAddress(nativePtr);
        }
    }

    private native String getRemoteAddressAsString(long nativePtr);
    @Override @Nullable
    synchronized public String getRemoteAddressAsString()  {
        synchronized(core) { 
        
        return getRemoteAddressAsString(nativePtr);
        }
    }

    private native String[] getRemoteAuthenticationTokens(long nativePtr);
    @Override @NonNull
    synchronized public String[] getRemoteAuthenticationTokens()  {
        synchronized(core) { 
        
        return getRemoteAuthenticationTokens(nativePtr);
        }
    }

    private native String getRemoteContact(long nativePtr);
    @Override @Nullable
    synchronized public String getRemoteContact()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRemoteContact() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getRemoteContact(nativePtr);
        }
    }

    private native Address getRemoteContactAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getRemoteContactAddress()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRemoteContactAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)getRemoteContactAddress(nativePtr);
        }
    }

    private native CallParams getRemoteParams(long nativePtr);
    @Override @Nullable
    synchronized public CallParams getRemoteParams()  {
        synchronized(core) { 
        
        return (CallParams)getRemoteParams(nativePtr);
        }
    }

    private native String getRemoteTag(long nativePtr);
    @Override @NonNull
    synchronized public String getRemoteTag()  {
        synchronized(core) { 
        
        return getRemoteTag(nativePtr);
        }
    }

    private native String getRemoteUserAgent(long nativePtr);
    @Override @Nullable
    synchronized public String getRemoteUserAgent()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRemoteUserAgent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getRemoteUserAgent(nativePtr);
        }
    }

    private native Call getReplacedCall(long nativePtr);
    @Override @Nullable
    synchronized public Call getReplacedCall()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getReplacedCall() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Call)getReplacedCall(nativePtr);
        }
    }

    private native Address getRequestAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getRequestAddress()  {
        synchronized(core) { 
        
        return (Address)getRequestAddress(nativePtr);
        }
    }

    private native boolean getSpeakerMuted(long nativePtr);
    @Override
    synchronized public boolean getSpeakerMuted()  {
        synchronized(core) { 
        
        return getSpeakerMuted(nativePtr);
        }
    }

    private native void setSpeakerMuted(long nativePtr, boolean muted);
    @Override
    synchronized public void setSpeakerMuted(boolean muted)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSpeakerMuted() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSpeakerMuted(nativePtr, muted);
        }
    }

    private native float getSpeakerVolumeGain(long nativePtr);
    @Override
    synchronized public float getSpeakerVolumeGain()  {
        synchronized(core) { 
        
        return getSpeakerVolumeGain(nativePtr);
        }
    }

    private native void setSpeakerVolumeGain(long nativePtr, float volume);
    @Override
    synchronized public void setSpeakerVolumeGain(float volume)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSpeakerVolumeGain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSpeakerVolumeGain(nativePtr, volume);
        }
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public Call.State getState()  {
        synchronized(core) { 
        
        return Call.State.fromInt(getState(nativePtr));
        }
    }

    private native int getStreamCount(long nativePtr);
    @Override
    synchronized public int getStreamCount()  {
        synchronized(core) { 
        
        return getStreamCount(nativePtr);
        }
    }

    private native CallStats getTextStats(long nativePtr);
    @Override @Nullable
    synchronized public CallStats getTextStats()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getTextStats() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallStats)getTextStats(nativePtr);
        }
    }

    private native Address getToAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getToAddress()  {
        synchronized(core) { 
        
        return (Address)getToAddress(nativePtr);
        }
    }

    private native int getTransferState(long nativePtr);
    @Override
    synchronized public Call.State getTransferState()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getTransferState() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return Call.State.fromInt(getTransferState(nativePtr));
        }
    }

    private native Call getTransferTargetCall(long nativePtr);
    @Override @Nullable
    synchronized public Call getTransferTargetCall()  {
        synchronized(core) { 
        
        return (Call)getTransferTargetCall(nativePtr);
        }
    }

    private native Call getTransfererCall(long nativePtr);
    @Override @Nullable
    synchronized public Call getTransfererCall()  {
        synchronized(core) { 
        
        return (Call)getTransfererCall(nativePtr);
        }
    }

    private native VideoSourceDescriptor getVideoSource(long nativePtr);
    @Override @Nullable
    synchronized public VideoSourceDescriptor getVideoSource()  {
        synchronized(core) { 
        
        return (VideoSourceDescriptor)getVideoSource(nativePtr);
        }
    }

    private native void setVideoSource(long nativePtr, VideoSourceDescriptor descriptor);
    @Override
    synchronized public void setVideoSource(@Nullable VideoSourceDescriptor descriptor)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoSource() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoSource(nativePtr, descriptor);
        }
    }

    private native CallStats getVideoStats(long nativePtr);
    @Override @Nullable
    synchronized public CallStats getVideoStats()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getVideoStats() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallStats)getVideoStats(nativePtr);
        }
    }

    private native boolean getZrtpCacheMismatchFlag(long nativePtr);
    @Override
    synchronized public boolean getZrtpCacheMismatchFlag()  {
        synchronized(core) { 
        
        return getZrtpCacheMismatchFlag(nativePtr);
        }
    }

    private native int accept(long nativePtr);
    @Override
    synchronized public int accept()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call accept() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return accept(nativePtr);
        }
    }

    private native int acceptEarlyMedia(long nativePtr);
    @Override
    synchronized public int acceptEarlyMedia()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call acceptEarlyMedia() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return acceptEarlyMedia(nativePtr);
        }
    }

    private native int acceptEarlyMediaWithParams(long nativePtr, CallParams params);
    @Override
    synchronized public int acceptEarlyMediaWithParams(@Nullable CallParams params)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call acceptEarlyMediaWithParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return acceptEarlyMediaWithParams(nativePtr, params);
        }
    }

    private native void acceptTransfer(long nativePtr);
    @Override
    synchronized public void acceptTransfer()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call acceptTransfer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        acceptTransfer(nativePtr);
        }
    }

    private native int acceptUpdate(long nativePtr, CallParams params);
    @Override
    synchronized public int acceptUpdate(@Nullable CallParams params)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call acceptUpdate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return acceptUpdate(nativePtr, params);
        }
    }

    private native int acceptWithParams(long nativePtr, CallParams params);
    @Override
    synchronized public int acceptWithParams(@Nullable CallParams params)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call acceptWithParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return acceptWithParams(nativePtr, params);
        }
    }

    private native boolean askedToAutoanswer(long nativePtr);
    @Override
    synchronized public boolean askedToAutoanswer()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call askedToAutoanswer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return askedToAutoanswer(nativePtr);
        }
    }

    private native void cancelDtmfs(long nativePtr);
    @Override
    synchronized public void cancelDtmfs()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call cancelDtmfs() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        cancelDtmfs(nativePtr);
        }
    }

    private native void checkAuthenticationTokenSelected(long nativePtr, String selectedValue);
    @Override
    synchronized public void checkAuthenticationTokenSelected(String selectedValue)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call checkAuthenticationTokenSelected() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        checkAuthenticationTokenSelected(nativePtr, selectedValue);
        }
    }

    private native void confirmGoClear(long nativePtr);
    @Override
    synchronized public void confirmGoClear()  {
        synchronized(core) { 
        
        confirmGoClear(nativePtr);
        }
    }

    private native Object createNativeVideoWindowId2(long nativePtr, Object context);
    @Override @Nullable
    synchronized public Object createNativeVideoWindowId(@Nullable Object context)  {
        synchronized(core) { 
        
        return createNativeVideoWindowId2(nativePtr, context);
        }
    }

    private native Object createNativeVideoWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object createNativeVideoWindowId()  {
        synchronized(core) { 
        
        return createNativeVideoWindowId(nativePtr);
        }
    }

    private native Event createNotify(long nativePtr, String event);
    @Override @Nullable
    synchronized public Event createNotify(String event)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createNotify() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Event)createNotify(nativePtr, event);
        }
    }

    private native int decline(long nativePtr, int reason);
    @Override
    synchronized public int decline(Reason reason)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call decline() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return decline(nativePtr, reason.toInt());
        }
    }

    private native int declineWithErrorInfo(long nativePtr, ErrorInfo ei);
    @Override
    synchronized public int declineWithErrorInfo(@Nullable ErrorInfo ei)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call declineWithErrorInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return declineWithErrorInfo(nativePtr, ei);
        }
    }

    private native int deferUpdate(long nativePtr);
    @Override
    synchronized public int deferUpdate()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call deferUpdate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return deferUpdate(nativePtr);
        }
    }

    private native CallStats getStats(long nativePtr, int type);
    @Override @Nullable
    synchronized public CallStats getStats(StreamType type)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getStats() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallStats)getStats(nativePtr, type.toInt());
        }
    }

    private native String getToHeader(long nativePtr, String headerName);
    @Override @Nullable
    synchronized public String getToHeader(@NonNull String headerName)  {
        synchronized(core) { 
        
        return getToHeader(nativePtr, headerName);
        }
    }

    private native boolean hasTransferPending(long nativePtr);
    @Override
    synchronized public boolean hasTransferPending()  {
        synchronized(core) { 
        
        return hasTransferPending(nativePtr);
        }
    }

    private native boolean mediaInProgress(long nativePtr);
    @Override
    synchronized public boolean mediaInProgress()  {
        synchronized(core) { 
        
        return mediaInProgress(nativePtr);
        }
    }

    private native void notifyRinging(long nativePtr);
    @Override
    synchronized public void notifyRinging()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call notifyRinging() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        notifyRinging(nativePtr);
        }
    }

    private native void oglRender(long nativePtr);
    @Override
    synchronized public void oglRender()  {
        synchronized(core) { 
        
        oglRender(nativePtr);
        }
    }

    private native int pause(long nativePtr);
    @Override
    synchronized public int pause()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call pause() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return pause(nativePtr);
        }
    }

    private native int redirect(long nativePtr, String redirectUri);
    @Override
    synchronized public int redirect(@NonNull String redirectUri)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call redirect() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return redirect(nativePtr, redirectUri);
        }
    }

    private native int redirectTo(long nativePtr, Address redirectAddress);
    @Override
    synchronized public int redirectTo(@NonNull Address redirectAddress)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call redirectTo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return redirectTo(nativePtr, redirectAddress);
        }
    }

    private native void requestNotifyNextVideoFrameDecoded(long nativePtr);
    @Override
    synchronized public void requestNotifyNextVideoFrameDecoded()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call requestNotifyNextVideoFrameDecoded() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        requestNotifyNextVideoFrameDecoded(nativePtr);
        }
    }

    private native int resume(long nativePtr);
    @Override
    synchronized public int resume()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call resume() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return resume(nativePtr);
        }
    }

    private native int sendDtmf(long nativePtr, char dtmf);
    @Override
    synchronized public int sendDtmf(char dtmf)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sendDtmf() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return sendDtmf(nativePtr, dtmf);
        }
    }

    private native int sendDtmfs(long nativePtr, String dtmfs);
    @Override
    synchronized public int sendDtmfs(@NonNull String dtmfs)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sendDtmfs() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return sendDtmfs(nativePtr, dtmfs);
        }
    }

    private native int sendInfoMessage(long nativePtr, InfoMessage info);
    @Override
    synchronized public int sendInfoMessage(@NonNull InfoMessage info)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sendInfoMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return sendInfoMessage(nativePtr, info);
        }
    }

    private native void sendVfuRequest(long nativePtr);
    @Override
    synchronized public void sendVfuRequest()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sendVfuRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        sendVfuRequest(nativePtr);
        }
    }

    private native void skipZrtpAuthentication(long nativePtr);
    @Override
    synchronized public void skipZrtpAuthentication()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call skipZrtpAuthentication() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        skipZrtpAuthentication(nativePtr);
        }
    }

    private native void startRecording(long nativePtr);
    @Override
    synchronized public void startRecording()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call startRecording() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        startRecording(nativePtr);
        }
    }

    private native void stopRecording(long nativePtr);
    @Override
    synchronized public void stopRecording()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stopRecording() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        stopRecording(nativePtr);
        }
    }

    private native int takePreviewSnapshot(long nativePtr, String filePath);
    @Override
    synchronized public int takePreviewSnapshot(@NonNull String filePath)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call takePreviewSnapshot() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return takePreviewSnapshot(nativePtr, filePath);
        }
    }

    private native int takeVideoSnapshot(long nativePtr, String filePath);
    @Override
    synchronized public int takeVideoSnapshot(@NonNull String filePath)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call takeVideoSnapshot() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return takeVideoSnapshot(nativePtr, filePath);
        }
    }

    private native int terminate(long nativePtr);
    @Override
    synchronized public int terminate()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call terminate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return terminate(nativePtr);
        }
    }

    private native int terminateWithErrorInfo(long nativePtr, ErrorInfo ei);
    @Override
    synchronized public int terminateWithErrorInfo(@Nullable ErrorInfo ei)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call terminateWithErrorInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return terminateWithErrorInfo(nativePtr, ei);
        }
    }

    private native int transfer(long nativePtr, String referTo);
    @Override
    synchronized public int transfer(@NonNull String referTo)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call transfer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return transfer(nativePtr, referTo);
        }
    }

    private native int transferTo(long nativePtr, Address referTo);
    @Override
    synchronized public int transferTo(@NonNull Address referTo)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call transferTo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return transferTo(nativePtr, referTo);
        }
    }

    private native int transferToAnother(long nativePtr, Call dest);
    @Override
    synchronized public int transferToAnother(@NonNull Call dest)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call transferToAnother() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return transferToAnother(nativePtr, dest);
        }
    }

    private native int update(long nativePtr, CallParams params);
    @Override
    synchronized public int update(@Nullable CallParams params)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call update() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return update(nativePtr, params);
        }
    }

    private native void zoom(long nativePtr, float zoomFactor, float cx, float cy);
    @Override
    synchronized public void zoom(float zoomFactor, float cx, float cy)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call zoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        zoom(nativePtr, zoomFactor, cx, cy);
        }
    }

    private native void addListener(long nativePtr, CallListener listener);
    @Override
    synchronized public void addListener(CallListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, CallListener listener);
    @Override
    synchronized public void removeListener(CallListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
