/*
TransportType.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum describing transport type for LinphoneAddress. <br/>
* <br/>
*/
public enum TransportType {
    /**
    * <br/>
    */
    Udp(0),

    /**
    * <br/>
    */
    Tcp(1),

    /**
    * <br/>
    */
    Tls(2),

    /**
    * <br/>
    */
    Dtls(3);

    protected final int mValue;

    private TransportType (int value) {
        mValue = value;
    }

    static public TransportType fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Udp;
        case 1: return Tcp;
        case 2: return Tls;
        case 3: return Dtls;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for TransportType");
        }
    }
    
    static protected TransportType[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        TransportType[] enumArray = new TransportType[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = TransportType.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(TransportType[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
