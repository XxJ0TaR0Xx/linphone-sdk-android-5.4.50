/*
ProxyConfig.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Represents an account configuration to be used by {@link Core}. <br/>
* <br/>
* In addition to the {@link AuthInfo} that stores the credentials, you need to<br/>
* configure a {@link ProxyConfig} as well to be able to connect to a proxy server.<br/>
* A minimal proxy config consists of an identity address<br/>
* (sip:username@domain.tld) and the proxy server address, see: {@link #setServerAddr}<br/>
* .<br/>
* If any, it will be stored inside the default configuration file, so it will<br/>
* survive the destruction of the {@link Core} and be available at the next start.<br/>
* The account set with {@link Core#setDefaultProxyConfig} will be used as default<br/>
* for outgoing calls & chat messages unless specified otherwise.<br/>
* @deprecated 06/04/2020 Use {@link Account} object instead <br/>
*/
public interface ProxyConfig {
    /**
    * Indicates whether AVPF/SAVPF is being used for calls using this proxy config. <br/>
    * <br/>
    * @return True if AVPF/SAVPF is enabled, false otherwise. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public boolean isAvpfEnabled();

    /**
    * Get enablement status of RTCP feedback (also known as AVPF profile). <br/>
    * <br/>
    * @return the enablement mode, which can be {@link AVPFMode#Default} (use<br/>
    * LinphoneCore's mode), {@link AVPFMode#Enabled} (avpf is enabled), or {@link AVPFMode#Disabled}<br/>
    * (disabled). <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public AVPFMode getAvpfMode();

    /**
    * Enable the use of RTCP feedback (also known as AVPF profile). <br/>
    * <br/>
    * @param mode the enablement mode, which can be {@link AVPFMode#Default} (use<br/>
    * LinphoneCore's mode), {@link AVPFMode#Enabled} (avpf is enabled), or {@link AVPFMode#Disabled}<br/>
    * (disabled). <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setAvpfMode(AVPFMode mode);

    /**
    * Get the interval between regular RTCP reports when using AVPF/SAVPF. <br/>
    * <br/>
    * @return The interval in seconds. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int getAvpfRrInterval();

    /**
    * Set the interval between regular RTCP reports when using AVPF/SAVPF. <br/>
    * <br/>
    * @param interval The interval in seconds (between 0 and 5 seconds). <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setAvpfRrInterval(int interval);

    /**
    * Get the conference factory uri. <br/>
    * <br/>
    * @return The uri of the conference factory.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getConferenceFactoryUri();

    /**
    * Set the conference factory uri. <br/>
    * <br/>
    * @param uri The uri of the conference factory.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setConferenceFactoryUri(@Nullable String uri);

    /**
    * Return the contact address of the proxy config. <br/>
    * <br/>
    * @return a {@link Address} correspong to the contact address of the proxy<br/>
    * config.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public Address getContact();

    /**
    * Returns the contact parameters. <br/>
    * <br/>
    * @return previously set contact parameters.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getContactParameters();

    /**
    * Set optional contact parameters that will be added to the contact information<br/>
    * sent in the registration. <br/>
    * <br/>
    * @param contactParams a string contaning the additional parameters in text form,<br/>
    * like "myparam=something;myparam2=something_else"  <br/>
    * The main use case for this function is provide the proxy additional information<br/>
    * regarding the user agent, like for example unique identifier or apple push id.<br/>
    * As an example, the contact address in the SIP register sent will look like<br/>
    * <sip:joe@15.128.128.93:50421>;apple-push-id=43143-DFE23F-2323-FA2232.<br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setContactParameters(@Nullable String contactParams);

    /**
    * Returns the contact URI parameters. <br/>
    * <br/>
    * @return previously set contact URI parameters.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getContactUriParameters();

    /**
    * Set optional contact parameters that will be added to the contact information<br/>
    * sent in the registration, inside the URI. <br/>
    * <br/>
    * @param contactUriParams a string containing the additional parameters in text<br/>
    * form, like "myparam=something;myparam2=something_else"  <br/>
    * The main use case for this function is provide the proxy additional information<br/>
    * regarding the user agent, like for example unique identifier or apple push id.<br/>
    * As an example, the contact address in the SIP register sent will look like<br/>
    * <sip:joe@15.128.128.93:50421;apple-push-id=43143-DFE23F-2323-FA2232>.<br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setContactUriParameters(@Nullable String contactUriParams);

    /**
    * Get the {@link Core} object to which is associated the {@link ProxyConfig}. <br/>
    * <br/>
    * @return The {@link Core} object to which is associated the {@link ProxyConfig}.<br/>
    *   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @NonNull
    public Core getCore();

    /**
    * Get the dependency of a {@link ProxyConfig}. <br/>
    * <br/>
    * @return The proxy config this one is dependent upon, or null if not marked<br/>
    * dependent.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public ProxyConfig getDependency();

    /**
    * Mark this proxy configuration as being dependent on the given one. <br/>
    * <br/>
    * The dependency must refer to a proxy config previously added to the core and<br/>
    * which idkey property is defined.<br/>
    * see: {@link #setIdkey}<br/>
    * The proxy configuration marked as dependent will wait for successful<br/>
    * registration on its dependency before triggering its own.<br/>
    * Once registered, both proxy configurations will share the same contact address<br/>
    * (the 'dependency' one).<br/>
    * This mecanism must be enabled before the proxy configuration is added to the<br/>
    * core<br/>
    * @param dependsOn The {@link ProxyConfig} this one shall be depend on.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setDependency(@Nullable ProxyConfig dependsOn);

    /**
    * Returns whether or not the + should be replaced by 00. <br/>
    * <br/>
    * @return whether liblinphone should replace "+" by "00" in dialed numbers<br/>
    * (passed to {@link Core#invite}). <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public boolean getDialEscapePlus();

    /**
    * Sets whether liblinphone should replace "+" by international calling prefix in<br/>
    * dialed numbers (passed to {@link Core#invite} ). <br/>
    * <br/>
    * @param enable true to replace + by the international prefix, false otherwise. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setDialEscapePlus(boolean enable);

    /**
    * Gets the prefix set for this proxy config. <br/>
    * <br/>
    * @return dialing prefix.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getDialPrefix();

    /**
    * Sets a dialing prefix to be automatically prepended when inviting a number with<br/>
    * {@link Core#invite}; This dialing prefix shall usually be the country code of<br/>
    * the country where the user is living, without "+". <br/>
    * <br/>
    * @param prefix the prefix to set (withouth the +)   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setDialPrefix(@Nullable String prefix);

    /**
    * Get the domain name of the given proxy config. <br/>
    * <br/>
    * @return The domain name of the proxy config.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getDomain();

    /**
    * Get the reason why registration failed when the proxy config state is<br/>
    * LinphoneRegistrationFailed. <br/>
    * <br/>
    * @return The {@link Reason} why registration failed for this proxy config. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public Reason getError();

    /**
    * Get detailed information why registration failed when the proxy config state is<br/>
    * LinphoneRegistrationFailed. <br/>
    * <br/>
    * @return The {@link ErrorInfo} explaining why registration failed for this proxy<br/>
    * config.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @NonNull
    public ErrorInfo getErrorInfo();

    /**
    * Gets the proxy config expires. <br/>
    * <br/>
    * @return the duration of registration. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int getExpires();

    /**
    * Sets the registration expiration time in seconds. <br/>
    * <br/>
    * @param expires the expiration time to set <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setExpires(int expires);

    /**
    * Gets the identity addres of the proxy config. <br/>
    * <br/>
    * @return the SIP identity that belongs to this proxy configuration.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public Address getIdentityAddress();

    /**
    * Sets the user identity as a SIP address. <br/>
    * <br/>
    * This identity is normally formed with display name, username and domain, such<br/>
    * as: Alice <sip:alice@example.net> The REGISTER messages will have from and to<br/>
    * set to this identity. <br/>
    * @param identity the {@link Address} of the identity to set   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int setIdentityAddress(@Nullable Address identity);

    /**
    * Get the idkey property of a {@link ProxyConfig}. <br/>
    * <br/>
    * @return The idkey string, or null.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getIdkey();

    /**
    * Set the idkey property on the given proxy configuration. <br/>
    * <br/>
    * This property can the be referenced by another proxy config 'depends_on' to<br/>
    * create a dependency relation between them. see:<br/>
    * linphone_proxy_config_set_depends_on()<br/>
    * @param idkey The idkey string to associate to the given {@link ProxyConfig}.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setIdkey(@Nullable String idkey);

    /**
    * Indicates whether to add to the contact parameters the push notification<br/>
    * information. <br/>
    * <br/>
    * For IOS, it indicates to VOIP push notification. <br/>
    * @return true if push notification informations should be added, false<br/>
    * otherwise. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public boolean isPushNotificationAllowed();

    /**
    * Gets whether push notifications are available or not (Android & iOS only). <br/>
    * <br/>
    * @return true if push notifications are available, false otherwise <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public boolean isPushNotificationAvailable();

    /**
    * Indicates whether to add to the contact parameters the remote push notification<br/>
    * information (IOS only). <br/>
    * <br/>
    * Default value is false. <br/>
    * @return true if remote push notification informations should be added, false<br/>
    * otherwise. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public boolean isRemotePushNotificationAllowed();

    /**
    * Get The policy that is used to pass through NATs/firewalls when using this<br/>
    * proxy config. <br/>
    * <br/>
    * If it is set to null, the default NAT policy from the core will be used<br/>
    * instead. <br/>
    * @return {@link NatPolicy} object in use.   <br/>
    * see: {@link Core#getNatPolicy} <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public NatPolicy getNatPolicy();

    /**
    * Set the policy to use to pass through NATs/firewalls when using this proxy<br/>
    * config. <br/>
    * <br/>
    * If it is set to null, the default NAT policy from the core will be used<br/>
    * instead. <br/>
    * @param policy {@link NatPolicy} object.   <br/>
    * see: {@link Core#setNatPolicy} <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setNatPolicy(@Nullable NatPolicy policy);

    /**
    * Get default privacy policy for all calls routed through this proxy. <br/>
    * <br/>
    * @return Privacy mode as LinphonePrivacyMask <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int getPrivacy();

    /**
    * Set default privacy policy for all calls routed through this proxy. <br/>
    * <br/>
    * @param privacy {@link Privacy} to configure privacy <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setPrivacy(int privacy);

    /**
    * Gets if the PUBLISH is enabled. <br/>
    * <br/>
    * @return true if PUBLISH request is enabled for this proxy. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public boolean isPublishEnabled();

    /**
    * Indicates either or not, PUBLISH must be issued for this {@link ProxyConfig}. <br/>
    * <br/>
    * In case this {@link ProxyConfig} has been added to {@link Core}, follows the<br/>
    * {@link #edit} rule. <br/>
    * @param enable if true, publish will be engaged <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setPublishEnabled(boolean enable);

    /**
    * get the publish expiration time in second. <br/>
    * <br/>
    * Default value is the registration expiration value. <br/>
    * @return expires in second <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int getPublishExpires();

    /**
    * Set the publish expiration time in second. <br/>
    * <br/>
    * @param expires in second <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setPublishExpires(int expires);

    /**
    * Indicates whether to add to the contact parameters the push notification<br/>
    * information. <br/>
    * <br/>
    * For IOS, it indicates to VOIP push notification. <br/>
    * @param allow true to allow push notification information, false otherwise. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setPushNotificationAllowed(boolean allow);

    /**
    * Retrieves the push notification configuration. <br/>
    * <br/>
    * @return The {@link PushNotificationConfig}.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @NonNull
    public PushNotificationConfig getPushNotificationConfig();

    /**
    * Sets the push notification configuration. <br/>
    * <br/>
    * @param pushCfg {@link PushNotificationConfig} to set.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setPushNotificationConfig(@NonNull PushNotificationConfig pushCfg);

    /**
    * Get the route of the collector end-point when using quality reporting. <br/>
    * <br/>
    * This SIP address should be used on server-side to process packets directly<br/>
    * before discarding packets. Collector address should be a non existing account<br/>
    * and will not receive any messages. If null, reports will be send to the proxy<br/>
    * domain. <br/>
    * @return The SIP address of the collector end-point.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getQualityReportingCollector();

    /**
    * Set the route of the collector end-point when using quality reporting. <br/>
    * <br/>
    * This SIP address should be used on server-side to process packets directly<br/>
    * before discarding packets. Collector address should be a non existing account<br/>
    * and will not receive any messages. If null, reports will be send to the proxy<br/>
    * domain. <br/>
    * @param collector route of the collector end-point, if null PUBLISH will be sent<br/>
    * to the proxy domain.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setQualityReportingCollector(@Nullable String collector);

    /**
    * Indicates whether quality statistics during call should be stored and sent to a<br/>
    * collector according to RFC 6035. <br/>
    * <br/>
    * @return True if quality repotring is enabled, false otherwise. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public boolean isQualityReportingEnabled();

    /**
    * Indicates whether quality statistics during call should be stored and sent to a<br/>
    * collector according to RFC 6035. <br/>
    * <br/>
    * @param enable True to store quality statistics and send them to the collector,<br/>
    * false to disable it. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setQualityReportingEnabled(boolean enable);

    /**
    * Get the interval between interval reports when using quality reporting. <br/>
    * <br/>
    * @return The interval in seconds, 0 means interval reports are disabled. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int getQualityReportingInterval();

    /**
    * Set the interval between 2 interval reports sending when using quality<br/>
    * reporting. <br/>
    * <br/>
    * If call exceed interval size, an interval report will be sent to the collector.<br/>
    * On call termination, a session report will be sent for the remaining period.<br/>
    * Value must be 0 (disabled) or positive. <br/>
    * @param interval The interval in seconds, 0 means interval reports are disabled. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setQualityReportingInterval(int interval);

    /**
    * Get the realm of the given proxy config. <br/>
    * <br/>
    * @return The realm of the proxy config.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getRealm();

    /**
    * Set the realm of the given proxy config. <br/>
    * <br/>
    * @param realm New realm value.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setRealm(@Nullable String realm);

    /**
    * Get the persistent reference key associated to the proxy config. <br/>
    * <br/>
    * The reference key can be for example an id to an external database. It is<br/>
    * stored in the config file, thus can survive to process exits/restarts.<br/>
    * @return The reference key string that has been associated to the proxy config,<br/>
    * or null if none has been associated.    <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getRefKey();

    /**
    * Associate a persistent reference key to the proxy config. <br/>
    * <br/>
    * The reference key can be for example an id to an external database. It is<br/>
    * stored in the config file, thus can survive to process exits/restarts.<br/>
    * @param refkey The reference key string to associate to the proxy config.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setRefKey(@Nullable String refkey);

    /**
    * Returns whether the proxy config is enabled or not. <br/>
    * <br/>
    * @return true if registration to the proxy is enabled. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public boolean isRegisterEnabled();

    /**
    * Indicates either or not, REGISTRATION must be issued for this {@link ProxyConfig}<br/>
    * . <br/>
    * <br/>
    * In case this {@link ProxyConfig} has been added to {@link Core}, follows the<br/>
    * {@link #edit} rule. <br/>
    * @param enable if true, registration will be engaged <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setRegisterEnabled(boolean enable);

    /**
    * Indicates whether to add to the contact parameters the remote push notification<br/>
    * information (IOS only). <br/>
    * <br/>
    * @param allow true to allow remote push notification information, false<br/>
    * otherwise. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setRemotePushNotificationAllowed(boolean allow);

    /**
    * Sets a SIP route. <br/>
    * <br/>
    * When a route is set, all outgoing calls will go to the route's destination if<br/>
    * this proxy is the default one (see {@link Core#setDefaultProxyConfig} ). <br/>
    * @param route the SIP route to set   <br/>
    * @return -1 if route is invalid, 0 otherwise. <br/>
    * @deprecated 08/07/2020 use {@link #setRoutes} instead <br/>
    */
    @Deprecated
    public int setRoute(@Nullable String route);

    /**
    * Gets the list of the routes set for this proxy config. <br/>
    * <br/>
    * @return The list of routes as string.    <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @NonNull
    public String[] getRoutes();

    /**
    * Sets a list of SIP route. <br/>
    * <br/>
    * When a route is set, all outgoing calls will go to the route's destination if<br/>
    * this proxy is the default one (see {@link Core#setDefaultProxyConfig} ). <br/>
    * @param routes A  of routes   <br/>
    * @return -1 if routes are invalid, 0 otherwise. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int setRoutes(@Nullable String[] routes);

    /**
    * Gets the proxy config proxy address. <br/>
    * <br/>
    * @return the proxy's SIP address.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getServerAddr();

    /**
    * Sets the proxy address. <br/>
    * <br/>
    * Examples of valid sip proxy address are:<br/>
    * @param serverAddress the proxy address to set.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int setServerAddr(@Nullable String serverAddress);

    /**
    * Get the registration state of the given proxy config. <br/>
    * <br/>
    * @return The {@link RegistrationState} of the proxy config. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public RegistrationState getState();

    /**
    * Get the transport from either service route, route or addr. <br/>
    * <br/>
    * @return The transport as a string (I.E udp, tcp, tls, dtls)   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @NonNull
    public String getTransport();

    /**
    * Return the unread chat message count for a given proxy config. <br/>
    * <br/>
    * @return The unread chat message count. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int getUnreadChatMessageCount();

    /**
    * Commits modification made to the proxy configuration. <br/>
    * <br/>
    * @return 0 if successful, -1 otherwise <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public int done();

    /**
    * Starts editing a proxy configuration. <br/>
    * <br/>
    * Because proxy configuration must be consistent, applications MUST call {@link #edit}<br/>
    * before doing any attempts to modify proxy configuration (such as identity,<br/>
    * proxy address and so on). Once the modifications are done, then the application<br/>
    * must call {@link #done} to commit the changes. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void edit();

    /**
    * Find authentication info matching proxy config, if any, similarly to<br/>
    * linphone_core_find_auth_info. <br/>
    * <br/>
    * @return a {@link AuthInfo} matching proxy config criteria if possible, null if<br/>
    * nothing can be found.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public AuthInfo findAuthInfo();

    /**
    * Obtain the value of a header sent by the server in last answer to REGISTER. <br/>
    * <br/>
    * @param headerName the header name for which to fetch corresponding value   <br/>
    * @return the value of the queried header.   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String getCustomHeader(@NonNull String headerName);

    /**
    * Normalize a human readable phone number into a basic string. <br/>
    * <br/>
    * 888-444-222 becomes 888444222 or +33888444222 depending on the {@link ProxyConfig}<br/>
    * object. This function will always generate a normalized username if input is a<br/>
    * phone number. <br/>
    * @param username the string to parse   <br/>
    * @return null if input is an invalid phone number, normalized phone number from<br/>
    * username input otherwise.      <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public String normalizePhoneNumber(@NonNull String username);

    /**
    * Normalize a human readable sip uri into a fully qualified LinphoneAddress. <br/>
    * <br/>
    * A sip address should look like DisplayName <sip:username@domain:port> .<br/>
    * Basically this function performs the following tasks<br/>
    * The result is a syntactically correct SIP address. <br/>
    * @param username the string to parse   <br/>
    * @return null if invalid input, normalized sip address otherwise.     <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    @Nullable
    public Address normalizeSipUri(@NonNull String username);

    /**
    * Prevent a proxy config from refreshing its registration. <br/>
    * <br/>
    * This is useful to let registrations to expire naturally (or) when the<br/>
    * application wants to keep control on when refreshes are sent. However,<br/>
    * linphone_core_set_network_reachable(lc,true) will always request the proxy<br/>
    * configs to refresh their registrations. The refreshing operations can be<br/>
    * resumed with {@link #refreshRegister}. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void pauseRegister();

    /**
    * Refresh a proxy registration. <br/>
    * <br/>
    * This is useful if for example you resuming from suspend, thus IP address may<br/>
    * have changed. <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void refreshRegister();

    /**
    * Set the value of a custom header sent to the server in REGISTERs request. <br/>
    * <br/>
    * @param headerName the header name   <br/>
    * @param headerValue the header's value   <br/>
    * @deprecated 06/04/2020 Use {@link Account} object instead <br/>
    */
    @Deprecated
    public void setCustomHeader(@NonNull String headerName, @Nullable String headerValue);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ProxyConfigImpl implements ProxyConfig {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected ProxyConfigImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native boolean isAvpfEnabled(long nativePtr);
    @Override
    synchronized public boolean isAvpfEnabled()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAvpfEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isAvpfEnabled(nativePtr);
        }
    }

    private native int getAvpfMode(long nativePtr);
    @Override
    synchronized public AVPFMode getAvpfMode()  {
        synchronized(core) { 
        
        return AVPFMode.fromInt(getAvpfMode(nativePtr));
        }
    }

    private native void setAvpfMode(long nativePtr, int mode);
    @Override
    synchronized public void setAvpfMode(AVPFMode mode)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAvpfMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAvpfMode(nativePtr, mode.toInt());
        }
    }

    private native int getAvpfRrInterval(long nativePtr);
    @Override
    synchronized public int getAvpfRrInterval()  {
        synchronized(core) { 
        
        return getAvpfRrInterval(nativePtr);
        }
    }

    private native void setAvpfRrInterval(long nativePtr, int interval);
    @Override
    synchronized public void setAvpfRrInterval(int interval)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAvpfRrInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAvpfRrInterval(nativePtr, interval);
        }
    }

    private native String getConferenceFactoryUri(long nativePtr);
    @Override @Nullable
    synchronized public String getConferenceFactoryUri()  {
        synchronized(core) { 
        
        return getConferenceFactoryUri(nativePtr);
        }
    }

    private native void setConferenceFactoryUri(long nativePtr, String uri);
    @Override
    synchronized public void setConferenceFactoryUri(@Nullable String uri)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceFactoryUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceFactoryUri(nativePtr, uri);
        }
    }

    private native Address getContact(long nativePtr);
    @Override @Nullable
    synchronized public Address getContact()  {
        synchronized(core) { 
        
        return (Address)getContact(nativePtr);
        }
    }

    private native String getContactParameters(long nativePtr);
    @Override @Nullable
    synchronized public String getContactParameters()  {
        synchronized(core) { 
        
        return getContactParameters(nativePtr);
        }
    }

    private native void setContactParameters(long nativePtr, String contactParams);
    @Override
    synchronized public void setContactParameters(@Nullable String contactParams)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setContactParameters() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setContactParameters(nativePtr, contactParams);
        }
    }

    private native String getContactUriParameters(long nativePtr);
    @Override @Nullable
    synchronized public String getContactUriParameters()  {
        synchronized(core) { 
        
        return getContactUriParameters(nativePtr);
        }
    }

    private native void setContactUriParameters(long nativePtr, String contactUriParams);
    @Override
    synchronized public void setContactUriParameters(@Nullable String contactUriParams)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setContactUriParameters() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setContactUriParameters(nativePtr, contactUriParams);
        }
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native ProxyConfig getDependency(long nativePtr);
    @Override @Nullable
    synchronized public ProxyConfig getDependency()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDependency() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ProxyConfig)getDependency(nativePtr);
        }
    }

    private native void setDependency(long nativePtr, ProxyConfig dependsOn);
    @Override
    synchronized public void setDependency(@Nullable ProxyConfig dependsOn)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDependency() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDependency(nativePtr, dependsOn);
        }
    }

    private native boolean getDialEscapePlus(long nativePtr);
    @Override
    synchronized public boolean getDialEscapePlus()  {
        synchronized(core) { 
        
        return getDialEscapePlus(nativePtr);
        }
    }

    private native void setDialEscapePlus(long nativePtr, boolean enable);
    @Override
    synchronized public void setDialEscapePlus(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDialEscapePlus() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDialEscapePlus(nativePtr, enable);
        }
    }

    private native String getDialPrefix(long nativePtr);
    @Override @Nullable
    synchronized public String getDialPrefix()  {
        synchronized(core) { 
        
        return getDialPrefix(nativePtr);
        }
    }

    private native void setDialPrefix(long nativePtr, String prefix);
    @Override
    synchronized public void setDialPrefix(@Nullable String prefix)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDialPrefix() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDialPrefix(nativePtr, prefix);
        }
    }

    private native String getDomain(long nativePtr);
    @Override @Nullable
    synchronized public String getDomain()  {
        synchronized(core) { 
        
        return getDomain(nativePtr);
        }
    }

    private native int getError(long nativePtr);
    @Override
    synchronized public Reason getError()  {
        synchronized(core) { 
        
        return Reason.fromInt(getError(nativePtr));
        }
    }

    private native ErrorInfo getErrorInfo(long nativePtr);
    @Override @NonNull
    synchronized public ErrorInfo getErrorInfo()  {
        synchronized(core) { 
        
        return (ErrorInfo)getErrorInfo(nativePtr);
        }
    }

    private native int getExpires(long nativePtr);
    @Override
    synchronized public int getExpires()  {
        synchronized(core) { 
        
        return getExpires(nativePtr);
        }
    }

    private native void setExpires(long nativePtr, int expires);
    @Override
    synchronized public void setExpires(int expires)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setExpires() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setExpires(nativePtr, expires);
        }
    }

    private native Address getIdentityAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getIdentityAddress()  {
        synchronized(core) { 
        
        return (Address)getIdentityAddress(nativePtr);
        }
    }

    private native int setIdentityAddress(long nativePtr, Address identity);
    @Override
    synchronized public int setIdentityAddress(@Nullable Address identity)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIdentityAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setIdentityAddress(nativePtr, identity);
        }
    }

    private native String getIdkey(long nativePtr);
    @Override @Nullable
    synchronized public String getIdkey()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getIdkey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getIdkey(nativePtr);
        }
    }

    private native void setIdkey(long nativePtr, String idkey);
    @Override
    synchronized public void setIdkey(@Nullable String idkey)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIdkey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setIdkey(nativePtr, idkey);
        }
    }

    private native boolean isPushNotificationAllowed(long nativePtr);
    @Override
    synchronized public boolean isPushNotificationAllowed()  {
        synchronized(core) { 
        
        return isPushNotificationAllowed(nativePtr);
        }
    }

    private native boolean isPushNotificationAvailable(long nativePtr);
    @Override
    synchronized public boolean isPushNotificationAvailable()  {
        synchronized(core) { 
        
        return isPushNotificationAvailable(nativePtr);
        }
    }

    private native boolean isRemotePushNotificationAllowed(long nativePtr);
    @Override
    synchronized public boolean isRemotePushNotificationAllowed()  {
        synchronized(core) { 
        
        return isRemotePushNotificationAllowed(nativePtr);
        }
    }

    private native NatPolicy getNatPolicy(long nativePtr);
    @Override @Nullable
    synchronized public NatPolicy getNatPolicy()  {
        synchronized(core) { 
        
        return (NatPolicy)getNatPolicy(nativePtr);
        }
    }

    private native void setNatPolicy(long nativePtr, NatPolicy policy);
    @Override
    synchronized public void setNatPolicy(@Nullable NatPolicy policy)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNatPolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNatPolicy(nativePtr, policy);
        }
    }

    private native int getPrivacy(long nativePtr);
    @Override
    synchronized public int getPrivacy()  {
        synchronized(core) { 
        
        return getPrivacy(nativePtr);
        }
    }

    private native void setPrivacy(long nativePtr, int privacy);
    @Override
    synchronized public void setPrivacy(int privacy)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPrivacy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPrivacy(nativePtr, privacy);
        }
    }

    private native boolean isPublishEnabled(long nativePtr);
    @Override
    synchronized public boolean isPublishEnabled()  {
        synchronized(core) { 
        
        return isPublishEnabled(nativePtr);
        }
    }

    private native void setPublishEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setPublishEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPublishEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPublishEnabled(nativePtr, enable);
        }
    }

    private native int getPublishExpires(long nativePtr);
    @Override
    synchronized public int getPublishExpires()  {
        synchronized(core) { 
        
        return getPublishExpires(nativePtr);
        }
    }

    private native void setPublishExpires(long nativePtr, int expires);
    @Override
    synchronized public void setPublishExpires(int expires)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPublishExpires() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPublishExpires(nativePtr, expires);
        }
    }

    private native void setPushNotificationAllowed(long nativePtr, boolean allow);
    @Override
    synchronized public void setPushNotificationAllowed(boolean allow)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPushNotificationAllowed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPushNotificationAllowed(nativePtr, allow);
        }
    }

    private native PushNotificationConfig getPushNotificationConfig(long nativePtr);
    @Override @NonNull
    synchronized public PushNotificationConfig getPushNotificationConfig()  {
        synchronized(core) { 
        
        return (PushNotificationConfig)getPushNotificationConfig(nativePtr);
        }
    }

    private native void setPushNotificationConfig(long nativePtr, PushNotificationConfig pushCfg);
    @Override
    synchronized public void setPushNotificationConfig(@NonNull PushNotificationConfig pushCfg)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPushNotificationConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPushNotificationConfig(nativePtr, pushCfg);
        }
    }

    private native String getQualityReportingCollector(long nativePtr);
    @Override @Nullable
    synchronized public String getQualityReportingCollector()  {
        synchronized(core) { 
        
        return getQualityReportingCollector(nativePtr);
        }
    }

    private native void setQualityReportingCollector(long nativePtr, String collector);
    @Override
    synchronized public void setQualityReportingCollector(@Nullable String collector)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setQualityReportingCollector() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setQualityReportingCollector(nativePtr, collector);
        }
    }

    private native boolean isQualityReportingEnabled(long nativePtr);
    @Override
    synchronized public boolean isQualityReportingEnabled()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isQualityReportingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isQualityReportingEnabled(nativePtr);
        }
    }

    private native void setQualityReportingEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setQualityReportingEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setQualityReportingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setQualityReportingEnabled(nativePtr, enable);
        }
    }

    private native int getQualityReportingInterval(long nativePtr);
    @Override
    synchronized public int getQualityReportingInterval()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getQualityReportingInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getQualityReportingInterval(nativePtr);
        }
    }

    private native void setQualityReportingInterval(long nativePtr, int interval);
    @Override
    synchronized public void setQualityReportingInterval(int interval)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setQualityReportingInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setQualityReportingInterval(nativePtr, interval);
        }
    }

    private native String getRealm(long nativePtr);
    @Override @Nullable
    synchronized public String getRealm()  {
        synchronized(core) { 
        
        return getRealm(nativePtr);
        }
    }

    private native void setRealm(long nativePtr, String realm);
    @Override
    synchronized public void setRealm(@Nullable String realm)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRealm() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRealm(nativePtr, realm);
        }
    }

    private native String getRefKey(long nativePtr);
    @Override @Nullable
    synchronized public String getRefKey()  {
        synchronized(core) { 
        
        return getRefKey(nativePtr);
        }
    }

    private native void setRefKey(long nativePtr, String refkey);
    @Override
    synchronized public void setRefKey(@Nullable String refkey)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRefKey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRefKey(nativePtr, refkey);
        }
    }

    private native boolean isRegisterEnabled(long nativePtr);
    @Override
    synchronized public boolean isRegisterEnabled()  {
        synchronized(core) { 
        
        return isRegisterEnabled(nativePtr);
        }
    }

    private native void setRegisterEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setRegisterEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRegisterEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRegisterEnabled(nativePtr, enable);
        }
    }

    private native void setRemotePushNotificationAllowed(long nativePtr, boolean allow);
    @Override
    synchronized public void setRemotePushNotificationAllowed(boolean allow)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRemotePushNotificationAllowed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRemotePushNotificationAllowed(nativePtr, allow);
        }
    }

    private native int setRoute(long nativePtr, String route);
    @Override
    synchronized public int setRoute(@Nullable String route)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRoute() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setRoute(nativePtr, route);
        }
    }

    private native String[] getRoutes(long nativePtr);
    @Override @NonNull
    synchronized public String[] getRoutes()  {
        synchronized(core) { 
        
        return getRoutes(nativePtr);
        }
    }

    private native int setRoutes(long nativePtr, String[] routes);
    @Override
    synchronized public int setRoutes(@Nullable String[] routes)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRoutes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setRoutes(nativePtr, routes);
        }
    }

    private native String getServerAddr(long nativePtr);
    @Override @Nullable
    synchronized public String getServerAddr()  {
        synchronized(core) { 
        
        return getServerAddr(nativePtr);
        }
    }

    private native int setServerAddr(long nativePtr, String serverAddress);
    @Override
    synchronized public int setServerAddr(@Nullable String serverAddress)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setServerAddr() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setServerAddr(nativePtr, serverAddress);
        }
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public RegistrationState getState()  {
        synchronized(core) { 
        
        return RegistrationState.fromInt(getState(nativePtr));
        }
    }

    private native String getTransport(long nativePtr);
    @Override @NonNull
    synchronized public String getTransport()  {
        synchronized(core) { 
        
        return getTransport(nativePtr);
        }
    }

    private native int getUnreadChatMessageCount(long nativePtr);
    @Override
    synchronized public int getUnreadChatMessageCount()  {
        synchronized(core) { 
        
        return getUnreadChatMessageCount(nativePtr);
        }
    }

    private native int done(long nativePtr);
    @Override
    synchronized public int done()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call done() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return done(nativePtr);
        }
    }

    private native void edit(long nativePtr);
    @Override
    synchronized public void edit()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call edit() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        edit(nativePtr);
        }
    }

    private native AuthInfo findAuthInfo(long nativePtr);
    @Override @Nullable
    synchronized public AuthInfo findAuthInfo()  {
        synchronized(core) { 
        
        return (AuthInfo)findAuthInfo(nativePtr);
        }
    }

    private native String getCustomHeader(long nativePtr, String headerName);
    @Override @Nullable
    synchronized public String getCustomHeader(@NonNull String headerName)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCustomHeader(nativePtr, headerName);
        }
    }

    private native String normalizePhoneNumber(long nativePtr, String username);
    @Override @Nullable
    synchronized public String normalizePhoneNumber(@NonNull String username)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call normalizePhoneNumber() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return normalizePhoneNumber(nativePtr, username);
        }
    }

    private native Address normalizeSipUri(long nativePtr, String username);
    @Override @Nullable
    synchronized public Address normalizeSipUri(@NonNull String username)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call normalizeSipUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)normalizeSipUri(nativePtr, username);
        }
    }

    private native void pauseRegister(long nativePtr);
    @Override
    synchronized public void pauseRegister()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call pauseRegister() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        pauseRegister(nativePtr);
        }
    }

    private native void refreshRegister(long nativePtr);
    @Override
    synchronized public void refreshRegister()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call refreshRegister() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        refreshRegister(nativePtr);
        }
    }

    private native void setCustomHeader(long nativePtr, String headerName, String headerValue);
    @Override
    synchronized public void setCustomHeader(@NonNull String headerName, @Nullable String headerValue)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCustomHeader(nativePtr, headerName, headerValue);
        }
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
