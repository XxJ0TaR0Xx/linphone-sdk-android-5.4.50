/*
ConferenceInfo.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object defining all information related to a past or future conference. <br/>
* <br/>
*/
public interface ConferenceInfo {
    public enum State {
        /**
        * New conference. <br/>
        * <br/>
        */
        New(0),

        /**
        * Conference has been updated. <br/>
        * <br/>
        */
        Updated(1),

        /**
        * Canceling a conference. <br/>
        * <br/>
        */
        Cancelled(2);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return New;
            case 1: return Updated;
            case 2: return Cancelled;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Retrieve the CCMP URI of the conference. <br/>
    * <br/>
    * @return The URI of the conference stored in the CCMP server.   <br/>
    */
    @Nullable
    public String getCcmpUri();

    /**
    * Set the CCMP URI of the conference. <br/>
    * <br/>
    * @param uri The URI of the conference in the CCMP server.   <br/>
    */
    public void setCcmpUri(@Nullable String uri);

    /**
    * Retrieve the date and time of the conference. <br/>
    * <br/>
    * @return The date and time of the conference. <br/>
    */
    public long getDateTime();

    /**
    * Set the date and time of the conference. <br/>
    * <br/>
    * @param datetime The date and time of the conference. <br/>
    */
    public void setDateTime(long datetime);

    /**
    * Retrieve the description of the conference. <br/>
    * <br/>
    * @return The description of the conference.   <br/>
    */
    @Nullable
    public String getDescription();

    /**
    * Set the description of the conference. <br/>
    * <br/>
    * @param description The description of the conference.   <br/>
    */
    public void setDescription(@Nullable String description);

    /**
    * Retrieve the description of the conference. <br/>
    * <br/>
    * @return The description of the conference.   <br/>
    */
    @Nullable
    public String getDescriptionUtf8();

    /**
    * Set the description of the conference. <br/>
    * <br/>
    * @param description The description of the conference.   <br/>
    */
    public void setDescriptionUtf8(@Nullable String description);

    /**
    * Retrieve the duration (in minutes) of the conference. <br/>
    * <br/>
    * @return The duration of the conference. <br/>
    */
    public int getDuration();

    /**
    * Set the duration (in minutes) of the conference. <br/>
    * <br/>
    * @param duration The duration of the conference. <br/>
    */
    public void setDuration(int duration);

    /**
    * Retrieve the conference as an Icalendar string. <br/>
    * <br/>
    * @return The conference as an Icalendar string. The returned char* must be freed<br/>
    * by the caller.     <br/>
    */
    @Nullable
    public String getIcalendarString();

    /**
    * Retrieve the ICS UID linked to a conference info. <br/>
    * <br/>
    * @return the ICS UID.   <br/>
    */
    @Nullable
    public String getIcsUid();

    /**
    * Store the ICS UID in the conference info. <br/>
    * <br/>
    * @param uid the ICS UID to be associated to the {@link ConferenceInfo} object.   <br/>
    */
    public void setIcsUid(@Nullable String uid);

    /**
    * Retrieve the organizer of the conference. <br/>
    * <br/>
    * @return The {@link Address} of the conference's organizer.   <br/>
    */
    @Nullable
    public Address getOrganizer();

    /**
    * Set the organizer of the conference. <br/>
    * <br/>
    * @param organizer The {@link Address} of the conference's organizer.   <br/>
    */
    public void setOrganizer(@Nullable Address organizer);

    /**
    * Retrieve the organizer of the conference. <br/>
    * <br/>
    * @return The {@link ParticipantInfo} of the conference's organizer.   <br/>
    */
    @Nullable
    public ParticipantInfo getOrganizerInfo();

    /**
    * Retrieve the list of participants as list of participant infos. <br/>
    * <br/>
    * @return The list of participant informations.    <br/>
    */
    @NonNull
    public ParticipantInfo[] getParticipantInfos();

    /**
    * Set the list of participants. <br/>
    * <br/>
    * @param participantInfos The list of participant informations to set.    <br/>
    */
    public void setParticipantInfos(@Nullable ParticipantInfo[] participantInfos);

    /**
    * Retrieve the list of participants as list of addresses. <br/>
    * <br/>
    * @return The list of participants.    <br/>
    * @deprecated 24/08/2023 use linphone_conference_info_get_participant_infos<br/>
    * instead <br/>
    */
    @Deprecated
    @NonNull
    public Address[] getParticipants();

    /**
    * Set the list of participants. <br/>
    * <br/>
    * @param participants The list of participants to set.    <br/>
    * @deprecated 24/08/2023 use linphone_conference_info_set_participant_infos<br/>
    * instead <br/>
    */
    @Deprecated
    public void setParticipants(@Nullable Address[] participants);

    /**
    * Retrieve the desired security level of the conference. <br/>
    * <br/>
    * @return The desired security level of the conference. <br/>
    */
    public Conference.SecurityLevel getSecurityLevel();

    /**
    * Set the desired security level of the conference. <br/>
    * <br/>
    * @param securityLevel The desired security level of the conference. <br/>
    */
    public void setSecurityLevel(Conference.SecurityLevel securityLevel);

    /**
    * Retrieve the state of the conference info. <br/>
    * <br/>
    * @return {@link State} object.   <br/>
    */
    @Nullable
    public ConferenceInfo.State getState();

    /**
    * Retrieve the subject of the conference. <br/>
    * <br/>
    * @return The subject of the conference.   <br/>
    */
    @Nullable
    public String getSubject();

    /**
    * Set the subject of the conference. <br/>
    * <br/>
    * @param subject The subject of the conference.   <br/>
    */
    public void setSubject(@Nullable String subject);

    /**
    * Retrieve the subject of the conference. <br/>
    * <br/>
    * @return The subject of the conference.   <br/>
    */
    @Nullable
    public String getSubjectUtf8();

    /**
    * Set the subject of the conference. <br/>
    * <br/>
    * @param subject The subject of the conference.   <br/>
    */
    public void setSubjectUtf8(@Nullable String subject);

    /**
    * Retrieve the URI of the conference. <br/>
    * <br/>
    * @return The URI of the conference ({@link Address}).   <br/>
    */
    @Nullable
    public Address getUri();

    /**
    * Add a participant to the conference. <br/>
    * <br/>
    * @param participant The participant ({@link Address}) to add.   <br/>
    */
    public void addParticipant(@NonNull Address participant);

    /**
    * Add a participant to the conference. <br/>
    * <br/>
    * @param participantInfo The participant information ({@link ParticipantInfo}) to<br/>
    * add. This method can be called to set attributes such as the role to the<br/>
    * organizer of the conference   <br/>
    */
    public void addParticipant(@NonNull ParticipantInfo participantInfo);

    /**
    * Add a list of participants. <br/>
    * <br/>
    * @param participantInfos The list of participant informations to add.    <br/>
    */
    public void addParticipantInfos(@Nullable ParticipantInfo[] participantInfos);

    /**
    * Clone an object {@link ConferenceInfo}. <br/>
    * <br/>
    * @return the cloned {@link ConferenceInfo} object.   <br/>
    */
    @NonNull
    public ConferenceInfo clone();

    /**
    * Find a participant information in the conference information. <br/>
    * <br/>
    * @param participant The participant ({@link Address}) to search.   <br/>
    * @return The participant information ({@link ParticipantInfo}).   <br/>
    */
    @Nullable
    public ParticipantInfo findParticipant(@NonNull Address participant);

    /**
    * Get the capability of the conference. <br/>
    * <br/>
    * The capability information represents the capability for the conference linked<br/>
    * to the #ConferenceInfo to handle a given stream type (audio, video or text). <br/>
    * @param streamType A {@link StreamType} <br/>
    * @return the capability of the conference linked to conference information<br/>
    * {@link ConferenceInfo} <br/>
    */
    public boolean getCapability(StreamType streamType);

    /**
    * Remove a participant from the conference. <br/>
    * <br/>
    * @param participant The participant ({@link Address}) to remove.   <br/>
    */
    public void removeParticipant(@NonNull Address participant);

    /**
    * Set the capability of the conference. <br/>
    * <br/>
    * The capability information represents the capability for the conference linked<br/>
    * to the #ConferenceInfo to handle a given stream type (audio, video or text). <br/>
    * @param streamType A {@link StreamType} <br/>
    * @param enable the capability of the conference linked to conference information<br/>
    * {@link ConferenceInfo} <br/>
    */
    public void setCapability(StreamType streamType, boolean enable);

    /**
    * Update the participant information in the conference informations. <br/>
    * <br/>
    * @param participantInfo The participant information ({@link ParticipantInfo}) to<br/>
    * update. This method can be called to change attributes such as the role to the<br/>
    * organizer of the conference   <br/>
    */
    public void updateParticipant(@NonNull ParticipantInfo participantInfo);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ConferenceInfoImpl implements ConferenceInfo {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ConferenceInfoImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getCcmpUri(long nativePtr);
    @Override @Nullable
    synchronized public String getCcmpUri()  {
        
        
        return getCcmpUri(nativePtr);
    }

    private native void setCcmpUri(long nativePtr, String uri);
    @Override
    synchronized public void setCcmpUri(@Nullable String uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCcmpUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCcmpUri(nativePtr, uri);
    }

    private native long getDateTime(long nativePtr);
    @Override
    synchronized public long getDateTime()  {
        
        
        return getDateTime(nativePtr);
    }

    private native void setDateTime(long nativePtr, long datetime);
    @Override
    synchronized public void setDateTime(long datetime)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDateTime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDateTime(nativePtr, datetime);
    }

    private native String getDescription(long nativePtr);
    @Override @Nullable
    synchronized public String getDescription()  {
        
        
        return getDescription(nativePtr);
    }

    private native void setDescription(long nativePtr, String description);
    @Override
    synchronized public void setDescription(@Nullable String description)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDescription() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDescription(nativePtr, description);
    }

    private native String getDescriptionUtf88(long nativePtr);
    @Override @Nullable
    synchronized public String getDescriptionUtf8()  {
        
        
        return getDescriptionUtf88(nativePtr);
    }

    private native void setDescriptionUtf88(long nativePtr, String description);
    @Override
    synchronized public void setDescriptionUtf8(@Nullable String description)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDescriptionUtf8() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDescriptionUtf88(nativePtr, description);
    }

    private native int getDuration(long nativePtr);
    @Override
    synchronized public int getDuration()  {
        
        
        return getDuration(nativePtr);
    }

    private native void setDuration(long nativePtr, int duration);
    @Override
    synchronized public void setDuration(int duration)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDuration() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDuration(nativePtr, duration);
    }

    private native String getIcalendarString(long nativePtr);
    @Override @Nullable
    synchronized public String getIcalendarString()  {
        
        
        return getIcalendarString(nativePtr);
    }

    private native String getIcsUid(long nativePtr);
    @Override @Nullable
    synchronized public String getIcsUid()  {
        
        
        return getIcsUid(nativePtr);
    }

    private native void setIcsUid(long nativePtr, String uid);
    @Override
    synchronized public void setIcsUid(@Nullable String uid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIcsUid() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setIcsUid(nativePtr, uid);
    }

    private native Address getOrganizer(long nativePtr);
    @Override @Nullable
    synchronized public Address getOrganizer()  {
        
        
        return (Address)getOrganizer(nativePtr);
    }

    private native void setOrganizer(long nativePtr, Address organizer);
    @Override
    synchronized public void setOrganizer(@Nullable Address organizer)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOrganizer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOrganizer(nativePtr, organizer);
    }

    private native ParticipantInfo getOrganizerInfo(long nativePtr);
    @Override @Nullable
    synchronized public ParticipantInfo getOrganizerInfo()  {
        
        
        return (ParticipantInfo)getOrganizerInfo(nativePtr);
    }

    private native ParticipantInfo[] getParticipantInfos(long nativePtr);
    @Override @NonNull
    synchronized public ParticipantInfo[] getParticipantInfos()  {
        
        
        return getParticipantInfos(nativePtr);
    }

    private native void setParticipantInfos(long nativePtr, ParticipantInfo[] participantInfos);
    @Override
    synchronized public void setParticipantInfos(@Nullable ParticipantInfo[] participantInfos)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParticipantInfos() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParticipantInfos(nativePtr, participantInfos);
    }

    private native Address[] getParticipants(long nativePtr);
    @Override @NonNull
    synchronized public Address[] getParticipants()  {
        
        
        return getParticipants(nativePtr);
    }

    private native void setParticipants(long nativePtr, Address[] participants);
    @Override
    synchronized public void setParticipants(@Nullable Address[] participants)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParticipants() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParticipants(nativePtr, participants);
    }

    private native int getSecurityLevel(long nativePtr);
    @Override
    synchronized public Conference.SecurityLevel getSecurityLevel()  {
        
        
        return Conference.SecurityLevel.fromInt(getSecurityLevel(nativePtr));
    }

    private native void setSecurityLevel(long nativePtr, int securityLevel);
    @Override
    synchronized public void setSecurityLevel(Conference.SecurityLevel securityLevel)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSecurityLevel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSecurityLevel(nativePtr, securityLevel.toInt());
    }

    private native int getState(long nativePtr);
    @Override @Nullable
    synchronized public ConferenceInfo.State getState()  {
        
        
        return ConferenceInfo.State.fromInt(getState(nativePtr));
    }

    private native String getSubject(long nativePtr);
    @Override @Nullable
    synchronized public String getSubject()  {
        
        
        return getSubject(nativePtr);
    }

    private native void setSubject(long nativePtr, String subject);
    @Override
    synchronized public void setSubject(@Nullable String subject)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubject() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubject(nativePtr, subject);
    }

    private native String getSubjectUtf88(long nativePtr);
    @Override @Nullable
    synchronized public String getSubjectUtf8()  {
        
        
        return getSubjectUtf88(nativePtr);
    }

    private native void setSubjectUtf88(long nativePtr, String subject);
    @Override
    synchronized public void setSubjectUtf8(@Nullable String subject)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubjectUtf8() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubjectUtf88(nativePtr, subject);
    }

    private native Address getUri(long nativePtr);
    @Override @Nullable
    synchronized public Address getUri()  {
        
        
        return (Address)getUri(nativePtr);
    }

    private native void addParticipant(long nativePtr, Address participant);
    @Override
    synchronized public void addParticipant(@NonNull Address participant)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addParticipant(nativePtr, participant);
    }

    private native void addParticipant2(long nativePtr, ParticipantInfo participantInfo);
    @Override
    synchronized public void addParticipant(@NonNull ParticipantInfo participantInfo)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addParticipant2(nativePtr, participantInfo);
    }

    private native void addParticipantInfos(long nativePtr, ParticipantInfo[] participantInfos);
    @Override
    synchronized public void addParticipantInfos(@Nullable ParticipantInfo[] participantInfos)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipantInfos() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addParticipantInfos(nativePtr, participantInfos);
    }

    private native ConferenceInfo clone(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceInfo clone()  {
        
        
        return (ConferenceInfo)clone(nativePtr);
    }

    private native ParticipantInfo findParticipant(long nativePtr, Address participant);
    @Override @Nullable
    synchronized public ParticipantInfo findParticipant(@NonNull Address participant)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ParticipantInfo)findParticipant(nativePtr, participant);
    }

    private native boolean getCapability(long nativePtr, int streamType);
    @Override
    synchronized public boolean getCapability(StreamType streamType)  {
        
        
        return getCapability(nativePtr, streamType.toInt());
    }

    private native void removeParticipant(long nativePtr, Address participant);
    @Override
    synchronized public void removeParticipant(@NonNull Address participant)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeParticipant(nativePtr, participant);
    }

    private native void setCapability(long nativePtr, int streamType, boolean enable);
    @Override
    synchronized public void setCapability(StreamType streamType, boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCapability() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCapability(nativePtr, streamType.toInt(), enable);
    }

    private native void updateParticipant(long nativePtr, ParticipantInfo participantInfo);
    @Override
    synchronized public void updateParticipant(@NonNull ParticipantInfo participantInfo)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call updateParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        updateParticipant(nativePtr, participantInfo);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
