/*
AccountManagerServicesRequestListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for {@link AccountManagerServicesRequest}<br/>
* object. <br/>
* <br/>
*/
public interface AccountManagerServicesRequestListener {
    /**
    * Callback for notifying a request was successful. <br/>
    * <br/>
    * @param request {@link AccountManagerServicesRequest} object.   <br/>
    * @param data any relevant data depending on the request (for example SIP<br/>
    * identity for account creation).   <br/>
    */
    public void onRequestSuccessful(@NonNull AccountManagerServicesRequest request, @Nullable String data);

    /**
    * Callback for notifying a request has failed. <br/>
    * <br/>
    * @param request {@link AccountManagerServicesRequest} object.   <br/>
    * @param statusCode The error status code. <br/>
    * @param errorMessage An error message, if any.   <br/>
    * @param parameterErrors A {@link Dictionary} with parameter specific errors, if<br/>
    * any.   <br/>
    */
    public void onRequestError(@NonNull AccountManagerServicesRequest request, int statusCode, @Nullable String errorMessage, @Nullable Dictionary parameterErrors);

    /**
    * Callback for notifying when the<br/>
    * #LinphoneAccountManagerServicesRequestGetDevicesList request has results<br/>
    * available. <br/>
    * <br/>
    * @param request {@link AccountManagerServicesRequest} object.   <br/>
    * @param devicesList the  of fetched devices.   <br/>
    */
    public void onDevicesListFetched(@NonNull AccountManagerServicesRequest request, @NonNull AccountDevice[] devicesList);

}