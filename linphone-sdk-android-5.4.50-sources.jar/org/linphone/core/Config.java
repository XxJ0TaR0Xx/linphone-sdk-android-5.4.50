/*
Config.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* This object is used to manipulate a configuration file. <br/>
* <br/>
* The format of the configuration file is a .ini like format:<br/>
* Various types can be used: strings and lists of strings, integers, floats,<br/>
* booleans (written as 0 or 1) and range of integers.<br/>
* Usually a {@link Core} is initialized using two {@link Config}, one default<br/>
* (where configuration changes through API calls will be saved) and one named<br/>
* 'factory' which is read-only and overwrites any setting that may exists in the<br/>
* default one.<br/>
* It is also possible to use only one (either default or factory) or even none. <br/>
*/
public interface Config {
    /**
    * Indicates whether the LinphoneConfig object is readonly, in other words it has<br/>
    * no file backend or file is opened without write permission. <br/>
    * <br/>
    * @return a boolean. <br/>
    */
    public boolean isReadonly();

    /**
    * Returns the list of sections' names in the LinphoneConfig. <br/>
    * <br/>
    * @return A list of strings.    <br/>
    */
    @NonNull
    public String[] getSectionsNamesList();

    /**
    * Removes entries for key,value in a section. <br/>
    * <br/>
    * @param section the section for which to clean the key entry   <br/>
    * @param key the key to clean   <br/>
    */
    public void cleanEntry(@NonNull String section, @NonNull String key);

    /**
    * Removes every pair of key,value in a section and remove the section. <br/>
    * <br/>
    * @param section the section to clean   <br/>
    */
    public void cleanSection(@NonNull String section);

    /**
    * Dumps the {@link Config} as INI into a buffer. <br/>
    * <br/>
    * @return The buffer that contains the config dump     <br/>
    */
    @NonNull
    public String dump();

    /**
    * Dumps the {@link Config} as XML into a buffer. <br/>
    * <br/>
    * @return The buffer that contains the XML dump     <br/>
    */
    @NonNull
    public String dumpAsXml();

    /**
    * Retrieves a configuration item as a boolean, given its section, key, and<br/>
    * default value. <br/>
    * <br/>
    * The default boolean value is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found <br/>
    * @return the found value or default_value if not found. <br/>
    */
    public boolean getBool(@NonNull String section, @NonNull String key, boolean defaultValue);

    /**
    * Retrieves a default configuration item as a float, given its section, key, and<br/>
    * default value. <br/>
    * <br/>
    * The default float value is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve the default value   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found <br/>
    * @return the found default value or default_value if not found. <br/>
    */
    public float getDefaultFloat(@NonNull String section, @NonNull String key, float defaultValue);

    /**
    * Retrieves a default configuration item as an integer, given its section, key,<br/>
    * and default value. <br/>
    * <br/>
    * The default integer value is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve the default value   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found <br/>
    * @return the found default value or default_value if not found. <br/>
    */
    public int getDefaultInt(@NonNull String section, @NonNull String key, int defaultValue);

    /**
    * Retrieves a default configuration item as a 64 bit integer, given its section,<br/>
    * key, and default value. <br/>
    * <br/>
    * The default integer value is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve the default value   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found <br/>
    * @return the found default value or default_value if not found. <br/>
    */
    public int getDefaultInt64(@NonNull String section, @NonNull String key, int defaultValue);

    /**
    * Retrieves a default configuration item as a string, given its section, key, and<br/>
    * default value. <br/>
    * <br/>
    * The default value string is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve the default value   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found <br/>
    * @return the found default value or default_value if not found. <br/>
    */
    public String getDefaultString(@NonNull String section, @NonNull String key, String defaultValue);

    /**
    * Retrieves a configuration item as a float, given its section, key, and default<br/>
    * value. <br/>
    * <br/>
    * The default float value is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found <br/>
    * @return the found value or default_value if not found. <br/>
    */
    public float getFloat(@NonNull String section, @NonNull String key, float defaultValue);

    /**
    * Retrieves a configuration item as an integer, given its section, key, and<br/>
    * default value. <br/>
    * <br/>
    * The default integer value is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found <br/>
    * @return the found value or default_value if not found. <br/>
    */
    public int getInt(@NonNull String section, @NonNull String key, int defaultValue);

    /**
    * Retrieves a configuration item as a 64 bit integer, given its section, key, and<br/>
    * default value. <br/>
    * <br/>
    * The default integer value is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found <br/>
    * @return the found value or default_value if not found. <br/>
    */
    public int getInt64(@NonNull String section, @NonNull String key, int defaultValue);

    /**
    * Returns the list of keys' names for a section in the LinphoneConfig. <br/>
    * <br/>
    * @param section The section name   <br/>
    * @return A list of strings.    <br/>
    */
    @NonNull
    public String[] getKeysNamesList(@NonNull String section);

    /**
    * Retrieves the overwrite flag for a config item. <br/>
    * <br/>
    * @param section The section from which to retrieve the overwrite flag   <br/>
    * @param key The name of the configuration item to retrieve the overwrite flag<br/>
    * from.   <br/>
    * @return true if overwrite flag is set, false otherwise. <br/>
    */
    public boolean getOverwriteFlagForEntry(@NonNull String section, @NonNull String key);

    /**
    * Retrieves the overwrite flag for a config section. <br/>
    * <br/>
    * @param section The section from which to retrieve the overwrite flag   <br/>
    * @return true if overwrite flag is set, false otherwise. <br/>
    */
    public boolean getOverwriteFlagForSection(@NonNull String section);

    /**
    * Retrieves a section parameter item as a string, given its section and key. <br/>
    * <br/>
    * The default value string is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve the default value   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultValue The default value to return if not found.   <br/>
    * @return the found default value or default_value if not found.   <br/>
    */
    @Nullable
    public String getSectionParamString(@NonNull String section, @NonNull String key, @Nullable String defaultValue);

    /**
    * Retrieves the skip flag for a config item. <br/>
    * <br/>
    * @param section The section from which to retrieve the skip flag   <br/>
    * @param key The name of the configuration item to retrieve the skip flag from <br/>
    * @return true if skip flag is set, false otherwise. <br/>
    */
    public boolean getSkipFlagForEntry(@NonNull String section, String key);

    /**
    * Retrieves the skip flag for a config section. <br/>
    * <br/>
    * @param section The section from which to retrieve the skip flag   <br/>
    * @return true if skip flag is set, false otherwise. <br/>
    */
    public boolean getSkipFlagForSection(@NonNull String section);

    /**
    * Retrieves a configuration item as a string, given its section, key, and default<br/>
    * value. <br/>
    * <br/>
    * The default value string is returned if the config item isn't found. <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultString The default value to return if not found.   <br/>
    * @return the found value or the default one if not found.   <br/>
    */
    @Nullable
    public String getString(@NonNull String section, @NonNull String key, @Nullable String defaultString);

    /**
    * Retrieves a configuration item as a list of strings, given its section, key,<br/>
    * and default value. <br/>
    * <br/>
    * The default value is returned if the config item is not found. <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param defaultList The list to return when the key doesn't exist.    <br/>
    * @return A list of strings.    <br/>
    */
    @NonNull
    public String[] getStringList(@NonNull String section, @NonNull String key, @Nullable String[] defaultList);

    /**
    * Returns if a given section with a given key is present in the configuration. <br/>
    * <br/>
    * @param section to check if the given entry exists   <br/>
    * @param key to check if it exists   <br/>
    * @return 1 if it exists, 0 otherwise <br/>
    */
    public int hasEntry(@NonNull String section, @NonNull String key);

    /**
    * Returns if a given section is present in the configuration. <br/>
    * <br/>
    * @param section the section to check if exists   <br/>
    * @return 1 if it exists, 0 otherwise <br/>
    */
    public int hasSection(@NonNull String section);

    /**
    * Reads a xml config file and fill the {@link Config} with the read config<br/>
    * dynamic values. <br/>
    * <br/>
    * @param filename The filename of the config file to read to fill the {@link Config}<br/>
    *   <br/>
    */
    public String loadFromXmlFile(@NonNull String filename);

    /**
    * Reads a xml config string and fill the {@link Config} with the read config<br/>
    * dynamic values. <br/>
    * <br/>
    * @param buffer The string of the config file to fill the {@link Config}   <br/>
    * @return 0 in case of success <br/>
    */
    public int loadFromXmlString(@NonNull String buffer);

    /**
    * Reads a user config file and fill the {@link Config} with the read config<br/>
    * values. <br/>
    * <br/>
    * @param filename The filename of the config file to read to fill the {@link Config}<br/>
    *   <br/>
    */
    public int readFile(@NonNull String filename);

    /**
    * Check if given file name exists relatively to the current location. <br/>
    * <br/>
    * @param filename The file name to check if exists   <br/>
    * @return true if file exists relative to the to the current location <br/>
    */
    public boolean relativeFileExists(@NonNull String filename);

    /**
    * Reload the config from the file. <br/>
    * <br/>
    */
    public void reload();

    /**
    * Sets a boolean config item. <br/>
    * <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param value the value to set <br/>
    */
    public void setBool(@NonNull String section, @NonNull String key, boolean value);

    /**
    * Sets a float config item. <br/>
    * <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param value the value to set <br/>
    */
    public void setFloat(@NonNull String section, @NonNull String key, float value);

    /**
    * Sets an integer config item. <br/>
    * <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param value the value to set <br/>
    */
    public void setInt(@NonNull String section, @NonNull String key, int value);

    /**
    * Sets a 64 bits integer config item. <br/>
    * <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param value the value to set <br/>
    */
    public void setInt64(@NonNull String section, @NonNull String key, int value);

    /**
    * Sets an integer config item, but store it as hexadecimal. <br/>
    * <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param value the value to set <br/>
    */
    public void setIntHex(@NonNull String section, @NonNull String key, int value);

    /**
    * Sets the overwrite flag for a config item (used when dumping config as xml) <br/>
    * <br/>
    * @param section The section from which to set the overwrite flag   <br/>
    * @param key The name of the configuration item to set the overwrite flag from   <br/>
    * @param value The overwrite flag value to set <br/>
    */
    public void setOverwriteFlagForEntry(@NonNull String section, @NonNull String key, boolean value);

    /**
    * Sets the overwrite flag for a config section (used when dumping config as xml) <br/>
    * <br/>
    * @param section The section from which to set the overwrite flag   <br/>
    * @param value The overwrite flag value to set <br/>
    */
    public void setOverwriteFlagForSection(@NonNull String section, boolean value);

    /**
    * Sets a range config item. <br/>
    * <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param minValue the min value to set <br/>
    * @param maxValue the max value to set <br/>
    */
    public void setRange(@NonNull String section, @NonNull String key, int minValue, int maxValue);

    /**
    * Sets the skip flag for a config item (used when dumping config as xml) <br/>
    * <br/>
    * @param section The section from which to set the skip flag   <br/>
    * @param key The name of the configuration item to set the skip flag from   <br/>
    * @param value The skip flag value to set <br/>
    */
    public void setSkipFlagForEntry(@NonNull String section, @NonNull String key, boolean value);

    /**
    * Sets the skip flag for a config section (used when dumping config as xml) <br/>
    * <br/>
    * @param section The section from which to set the skip flag   <br/>
    * @param value The skip flag value to set <br/>
    */
    public void setSkipFlagForSection(@NonNull String section, boolean value);

    /**
    * Sets a string config item. <br/>
    * <br/>
    * @param section The section from which to retrieve a configuration item   <br/>
    * @param key The name of the configuration item to retrieve   <br/>
    * @param value The value to set   <br/>
    */
    public void setString(@NonNull String section, @NonNull String key, @Nullable String value);

    /**
    * Sets a string list config item. <br/>
    * <br/>
    * @param section The name of the section to put the configuration item into   <br/>
    * @param key The name of the configuration item to set   <br/>
    * @param value The value to set.    <br/>
    */
    public void setStringList(@NonNull String section, @NonNull String key, @Nullable String[] value);

    /**
    * Writes the config file to disk. <br/>
    * <br/>
    * @return 0 if successful, -1 otherwise <br/>
    */
    public int sync();

    /**
    * Write a string in a file placed relatively with the Linphone configuration<br/>
    * file. <br/>
    * <br/>
    * @param filename Name of the file where to write data. The name is relative to<br/>
    * the place of the config file   <br/>
    * @param data String to write   <br/>
    */
    public void writeRelativeFile(@NonNull String filename, @NonNull String data);

    /**
    * Instantiates a {@link Config} object from a user provided buffer. <br/>
    * <br/>
    * The caller of this constructor owns a reference. linphone_config_unref must be<br/>
    * called when this object is no longer needed.<br/>
    * @param buffer the buffer from which the {@link Config} will be retrieved. We<br/>
    * expect the buffer to be null-terminated.   <br/>
    * see: {@link #newWithFactory} <br/>
    * see: linphone_config_new <br/>
    * @return a {@link Config} object   <br/>
    */
    @NonNull
    public Config newFromBuffer(@NonNull String buffer);

    /**
    * Instantiates a {@link Config} object from a user config file and a factory<br/>
    * config file. <br/>
    * <br/>
    * The caller of this constructor owns a reference. linphone_config_unref must be<br/>
    * called when this object is no longer needed.<br/>
    * @param configFilename the filename of the user config file to read to fill the<br/>
    * instantiated {@link Config}    <br/>
    * @param factoryConfigFilename the filename of the factory config file to read to<br/>
    * fill the instantiated {@link Config}   <br/>
    * see: linphone_config_new <br/>
    * @return a {@link Config} object  <br/>
    * The user config file is read first to fill the {@link Config} and then the<br/>
    * factory config file is read. Therefore the configuration parameters defined in<br/>
    * the user config file will be overwritten by the parameters defined in the<br/>
    * factory config file. <br/>
    */
    @Nullable
    public Config newWithFactory(@Nullable String configFilename, @Nullable String factoryConfigFilename);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ConfigImpl implements Config {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ConfigImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native boolean isReadonly(long nativePtr);
    @Override
    synchronized public boolean isReadonly()  {
        
        
        return isReadonly(nativePtr);
    }

    private native String[] getSectionsNamesList(long nativePtr);
    @Override @NonNull
    synchronized public String[] getSectionsNamesList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSectionsNamesList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getSectionsNamesList(nativePtr);
    }

    private native void cleanEntry(long nativePtr, String section, String key);
    @Override
    synchronized public void cleanEntry(@NonNull String section, @NonNull String key)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call cleanEntry() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        cleanEntry(nativePtr, section, key);
    }

    private native void cleanSection(long nativePtr, String section);
    @Override
    synchronized public void cleanSection(@NonNull String section)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call cleanSection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        cleanSection(nativePtr, section);
    }

    private native String dump(long nativePtr);
    @Override @NonNull
    synchronized public String dump()  {
        
        
        return dump(nativePtr);
    }

    private native String dumpAsXml(long nativePtr);
    @Override @NonNull
    synchronized public String dumpAsXml()  {
        
        
        return dumpAsXml(nativePtr);
    }

    private native boolean getBool(long nativePtr, String section, String key, boolean defaultValue);
    @Override
    synchronized public boolean getBool(@NonNull String section, @NonNull String key, boolean defaultValue)  {
        
        
        return getBool(nativePtr, section, key, defaultValue);
    }

    private native float getDefaultFloat(long nativePtr, String section, String key, float defaultValue);
    @Override
    synchronized public float getDefaultFloat(@NonNull String section, @NonNull String key, float defaultValue)  {
        
        
        return getDefaultFloat(nativePtr, section, key, defaultValue);
    }

    private native int getDefaultInt(long nativePtr, String section, String key, int defaultValue);
    @Override
    synchronized public int getDefaultInt(@NonNull String section, @NonNull String key, int defaultValue)  {
        
        
        return getDefaultInt(nativePtr, section, key, defaultValue);
    }

    private native int getDefaultInt644(long nativePtr, String section, String key, int defaultValue);
    @Override
    synchronized public int getDefaultInt64(@NonNull String section, @NonNull String key, int defaultValue)  {
        
        
        return getDefaultInt644(nativePtr, section, key, defaultValue);
    }

    private native String getDefaultString(long nativePtr, String section, String key, String defaultValue);
    @Override
    synchronized public String getDefaultString(@NonNull String section, @NonNull String key, String defaultValue)  {
        
        
        return getDefaultString(nativePtr, section, key, defaultValue);
    }

    private native float getFloat(long nativePtr, String section, String key, float defaultValue);
    @Override
    synchronized public float getFloat(@NonNull String section, @NonNull String key, float defaultValue)  {
        
        
        return getFloat(nativePtr, section, key, defaultValue);
    }

    private native int getInt(long nativePtr, String section, String key, int defaultValue);
    @Override
    synchronized public int getInt(@NonNull String section, @NonNull String key, int defaultValue)  {
        
        
        return getInt(nativePtr, section, key, defaultValue);
    }

    private native int getInt644(long nativePtr, String section, String key, int defaultValue);
    @Override
    synchronized public int getInt64(@NonNull String section, @NonNull String key, int defaultValue)  {
        
        
        return getInt644(nativePtr, section, key, defaultValue);
    }

    private native String[] getKeysNamesList(long nativePtr, String section);
    @Override @NonNull
    synchronized public String[] getKeysNamesList(@NonNull String section)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getKeysNamesList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getKeysNamesList(nativePtr, section);
    }

    private native boolean getOverwriteFlagForEntry(long nativePtr, String section, String key);
    @Override
    synchronized public boolean getOverwriteFlagForEntry(@NonNull String section, @NonNull String key)  {
        
        
        return getOverwriteFlagForEntry(nativePtr, section, key);
    }

    private native boolean getOverwriteFlagForSection(long nativePtr, String section);
    @Override
    synchronized public boolean getOverwriteFlagForSection(@NonNull String section)  {
        
        
        return getOverwriteFlagForSection(nativePtr, section);
    }

    private native String getSectionParamString(long nativePtr, String section, String key, String defaultValue);
    @Override @Nullable
    synchronized public String getSectionParamString(@NonNull String section, @NonNull String key, @Nullable String defaultValue)  {
        
        
        return getSectionParamString(nativePtr, section, key, defaultValue);
    }

    private native boolean getSkipFlagForEntry(long nativePtr, String section, String key);
    @Override
    synchronized public boolean getSkipFlagForEntry(@NonNull String section, String key)  {
        
        
        return getSkipFlagForEntry(nativePtr, section, key);
    }

    private native boolean getSkipFlagForSection(long nativePtr, String section);
    @Override
    synchronized public boolean getSkipFlagForSection(@NonNull String section)  {
        
        
        return getSkipFlagForSection(nativePtr, section);
    }

    private native String getString(long nativePtr, String section, String key, String defaultString);
    @Override @Nullable
    synchronized public String getString(@NonNull String section, @NonNull String key, @Nullable String defaultString)  {
        
        
        return getString(nativePtr, section, key, defaultString);
    }

    private native String[] getStringList(long nativePtr, String section, String key, String[] defaultList);
    @Override @NonNull
    synchronized public String[] getStringList(@NonNull String section, @NonNull String key, @Nullable String[] defaultList)  {
        
        
        return getStringList(nativePtr, section, key, defaultList);
    }

    private native int hasEntry(long nativePtr, String section, String key);
    @Override
    synchronized public int hasEntry(@NonNull String section, @NonNull String key)  {
        
        
        return hasEntry(nativePtr, section, key);
    }

    private native int hasSection(long nativePtr, String section);
    @Override
    synchronized public int hasSection(@NonNull String section)  {
        
        
        return hasSection(nativePtr, section);
    }

    private native String loadFromXmlFile(long nativePtr, String filename);
    @Override
    synchronized public String loadFromXmlFile(@NonNull String filename)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call loadFromXmlFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return loadFromXmlFile(nativePtr, filename);
    }

    private native int loadFromXmlString(long nativePtr, String buffer);
    @Override
    synchronized public int loadFromXmlString(@NonNull String buffer)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call loadFromXmlString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return loadFromXmlString(nativePtr, buffer);
    }

    private native int readFile(long nativePtr, String filename);
    @Override
    synchronized public int readFile(@NonNull String filename)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call readFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return readFile(nativePtr, filename);
    }

    private native boolean relativeFileExists(long nativePtr, String filename);
    @Override
    synchronized public boolean relativeFileExists(@NonNull String filename)  {
        
        
        return relativeFileExists(nativePtr, filename);
    }

    private native void reload(long nativePtr);
    @Override
    synchronized public void reload()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call reload() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        reload(nativePtr);
    }

    private native void setBool(long nativePtr, String section, String key, boolean value);
    @Override
    synchronized public void setBool(@NonNull String section, @NonNull String key, boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBool() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBool(nativePtr, section, key, value);
    }

    private native void setFloat(long nativePtr, String section, String key, float value);
    @Override
    synchronized public void setFloat(@NonNull String section, @NonNull String key, float value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFloat() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFloat(nativePtr, section, key, value);
    }

    private native void setInt(long nativePtr, String section, String key, int value);
    @Override
    synchronized public void setInt(@NonNull String section, @NonNull String key, int value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInt() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInt(nativePtr, section, key, value);
    }

    private native void setInt644(long nativePtr, String section, String key, int value);
    @Override
    synchronized public void setInt64(@NonNull String section, @NonNull String key, int value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInt64() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInt644(nativePtr, section, key, value);
    }

    private native void setIntHex(long nativePtr, String section, String key, int value);
    @Override
    synchronized public void setIntHex(@NonNull String section, @NonNull String key, int value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIntHex() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setIntHex(nativePtr, section, key, value);
    }

    private native void setOverwriteFlagForEntry(long nativePtr, String section, String key, boolean value);
    @Override
    synchronized public void setOverwriteFlagForEntry(@NonNull String section, @NonNull String key, boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOverwriteFlagForEntry() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOverwriteFlagForEntry(nativePtr, section, key, value);
    }

    private native void setOverwriteFlagForSection(long nativePtr, String section, boolean value);
    @Override
    synchronized public void setOverwriteFlagForSection(@NonNull String section, boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOverwriteFlagForSection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOverwriteFlagForSection(nativePtr, section, value);
    }

    private native void setRange(long nativePtr, String section, String key, int minValue, int maxValue);
    @Override
    synchronized public void setRange(@NonNull String section, @NonNull String key, int minValue, int maxValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRange() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRange(nativePtr, section, key, minValue, maxValue);
    }

    private native void setSkipFlagForEntry(long nativePtr, String section, String key, boolean value);
    @Override
    synchronized public void setSkipFlagForEntry(@NonNull String section, @NonNull String key, boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSkipFlagForEntry() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSkipFlagForEntry(nativePtr, section, key, value);
    }

    private native void setSkipFlagForSection(long nativePtr, String section, boolean value);
    @Override
    synchronized public void setSkipFlagForSection(@NonNull String section, boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSkipFlagForSection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSkipFlagForSection(nativePtr, section, value);
    }

    private native void setString(long nativePtr, String section, String key, String value);
    @Override
    synchronized public void setString(@NonNull String section, @NonNull String key, @Nullable String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setString(nativePtr, section, key, value);
    }

    private native void setStringList(long nativePtr, String section, String key, String[] value);
    @Override
    synchronized public void setStringList(@NonNull String section, @NonNull String key, @Nullable String[] value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStringList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStringList(nativePtr, section, key, value);
    }

    private native int sync(long nativePtr);
    @Override
    synchronized public int sync()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sync() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return sync(nativePtr);
    }

    private native void writeRelativeFile(long nativePtr, String filename, String data);
    @Override
    synchronized public void writeRelativeFile(@NonNull String filename, @NonNull String data)  {
        
        
        writeRelativeFile(nativePtr, filename, data);
    }

    private native Config newFromBuffer(long nativePtr, String buffer);
    @Override @NonNull
    synchronized public Config newFromBuffer(@NonNull String buffer)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newFromBuffer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Config)newFromBuffer(nativePtr, buffer);
    }

    private native Config newWithFactory(long nativePtr, String configFilename, String factoryConfigFilename);
    @Override @Nullable
    synchronized public Config newWithFactory(@Nullable String configFilename, @Nullable String factoryConfigFilename)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newWithFactory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Config)newWithFactory(nativePtr, configFilename, factoryConfigFilename);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
