/*
SecurityLevel.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Security level determined by type of encryption (point-to-point, end-to-end,<br/>
* etc...) and whether or not a SAS validation was made with the remote(s) end(s). <br/>
* <br/>
* A {@link SecurityLevel#EndToEndEncryptedAndVerified} level means it's<br/>
* end-to-end encrypted and SAS validation was made. An {@link SecurityLevel#Unsafe}<br/>
* level means end-to-end-encrypted but it's likely a man-in-the-middle exists<br/>
* between you and one device. <br/>
*/
public enum SecurityLevel {
    /**
    * Security failure. <br/>
    * <br/>
    */
    Unsafe(0),

    /**
    * No encryption. <br/>
    * <br/>
    */
    None(1),

    /**
    * End-to-end encrypted. <br/>
    * <br/>
    */
    EndToEndEncrypted(2),

    /**
    * End-to-end encrypted and verified. <br/>
    * <br/>
    */
    EndToEndEncryptedAndVerified(3),

    /**
    * Point-to-point encrypted. <br/>
    * <br/>
    */
    PointToPointEncrypted(4);

    protected final int mValue;

    private SecurityLevel (int value) {
        mValue = value;
    }

    static public SecurityLevel fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Unsafe;
        case 1: return None;
        case 2: return EndToEndEncrypted;
        case 3: return EndToEndEncryptedAndVerified;
        case 4: return PointToPointEncrypted;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for SecurityLevel");
        }
    }
    
    static protected SecurityLevel[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        SecurityLevel[] enumArray = new SecurityLevel[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = SecurityLevel.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(SecurityLevel[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
