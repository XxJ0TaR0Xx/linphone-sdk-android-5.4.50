/*
PublishState.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum for publish states. <br/>
* <br/>
*/
public enum PublishState {
    /**
    * Initial state, do not use. <br/>
    * <br/>
    */
    None(0),

    /**
    * An incoming publish is received. <br/>
    * <br/>
    */
    IncomingReceived(1),

    /**
    * Publish is accepted. <br/>
    * <br/>
    */
    Ok(2),

    /**
    * Publish encoutered an error, {@link Event#getReason} gives reason code. <br/>
    * <br/>
    */
    Error(3),

    /**
    * Publish is about to expire, only sent if [sip]->refresh_generic_publish<br/>
    * property is set to 0. <br/>
    * <br/>
    */
    Expiring(4),

    /**
    * Event has been un published. <br/>
    * <br/>
    */
    Cleared(5),

    /**
    * Publish is about to terminate. <br/>
    * <br/>
    */
    Terminating(6),

    /**
    * An outgoing publish was created and submitted. <br/>
    * <br/>
    */
    OutgoingProgress(7),

    /**
    * Publish is about to refresh. <br/>
    * <br/>
    */
    Refreshing(8);

    protected final int mValue;

    private PublishState (int value) {
        mValue = value;
    }

    static public PublishState fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return None;
        case 1: return IncomingReceived;
        case 2: return Ok;
        case 3: return Error;
        case 4: return Expiring;
        case 5: return Cleared;
        case 6: return Terminating;
        case 7: return OutgoingProgress;
        case 8: return Refreshing;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for PublishState");
        }
    }
    
    static protected PublishState[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        PublishState[] enumArray = new PublishState[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = PublishState.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(PublishState[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
