/*
RegistrationState.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Describes proxy registration states. <br/>
* <br/>
* It is notified via the registration_state_changed() callback in {@link CoreListener}<br/>
* . <br/>
*/
public enum RegistrationState {
    /**
    * Initial state for registrations. <br/>
    * <br/>
    */
    None(0),

    /**
    * Registration is in progress. <br/>
    * <br/>
    */
    Progress(1),

    /**
    * Registration is successful. <br/>
    * <br/>
    */
    Ok(2),

    /**
    * Unregistration succeeded. <br/>
    * <br/>
    */
    Cleared(3),

    /**
    * Registration failed. <br/>
    * <br/>
    */
    Failed(4),

    /**
    * Registration refreshing. <br/>
    * <br/>
    */
    Refreshing(5);

    protected final int mValue;

    private RegistrationState (int value) {
        mValue = value;
    }

    static public RegistrationState fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return None;
        case 1: return Progress;
        case 2: return Ok;
        case 3: return Cleared;
        case 4: return Failed;
        case 5: return Refreshing;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for RegistrationState");
        }
    }
    
    static protected RegistrationState[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        RegistrationState[] enumArray = new RegistrationState[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = RegistrationState.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(RegistrationState[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
