/*
VideoSourceScreenSharingType.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum representing the sub type of the screen sharing. <br/>
* <br/>
*/
public enum VideoSourceScreenSharingType {
    /**
    * The screen sharing is done from a display. <br/>
    * <br/>
    */
    Display(0),

    /**
    * The screen sharing is done from a window. <br/>
    * <br/>
    */
    Window(1),

    /**
    * The screen sharing is done from an area. <br/>
    * <br/>
    */
    Area(2);

    protected final int mValue;

    private VideoSourceScreenSharingType (int value) {
        mValue = value;
    }

    static public VideoSourceScreenSharingType fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Display;
        case 1: return Window;
        case 2: return Area;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for VideoSourceScreenSharingType");
        }
    }
    
    static protected VideoSourceScreenSharingType[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        VideoSourceScreenSharingType[] enumArray = new VideoSourceScreenSharingType[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = VideoSourceScreenSharingType.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(VideoSourceScreenSharingType[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
