/*
ConfiguringState.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Describes the state of the remote configuring process of the {@link Core}<br/>
* object, 'Skipped' when the feature is disabled. <br/>
* <br/>
* It is notified via the configuring_status() callback in {@link CoreListener}. <br/>
*/
public enum ConfiguringState {
    /**
    * <br/>
    */
    Successful(0),

    /**
    * <br/>
    */
    Failed(1),

    /**
    * <br/>
    */
    Skipped(2);

    protected final int mValue;

    private ConfiguringState (int value) {
        mValue = value;
    }

    static public ConfiguringState fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Successful;
        case 1: return Failed;
        case 2: return Skipped;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for ConfiguringState");
        }
    }
    
    static protected ConfiguringState[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        ConfiguringState[] enumArray = new ConfiguringState[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = ConfiguringState.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(ConfiguringState[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
