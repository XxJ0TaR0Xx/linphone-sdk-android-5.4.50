/*
ConferenceListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for the handling a {@link Conference}<br/>
* objects. <br/>
* <br/>
* Use {@link Factory#createConferenceCbs} to create an instance. Then pass the<br/>
* object to a {@link Conference} instance through {@link Conference#addListener}. <br/>
*/
public interface ConferenceListener {
    /**
    * Callback used to notify a conference that the list of participants allowed to<br/>
    * join the conference has changed. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    */
    public void onAllowedParticipantListChanged(@NonNull Conference conference);

    /**
    * Callback used to notify a conference that a participant has been added. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param participant LinphoneParticipant that has been added to the conference   <br/>
    */
    public void onParticipantAdded(@NonNull Conference conference, @NonNull Participant participant);

    /**
    * Callback used to notify a conference that a participant has been removed. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param participant LinphoneParticipant that has been removed to the conference <br/>
    *  <br/>
    */
    public void onParticipantRemoved(@NonNull Conference conference, @NonNull Participant participant);

    /**
    * Callback used to notify a conference that a participant device has been added. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param participantDevice LinphoneParticipantDevice that has been added to the<br/>
    * conference   <br/>
    */
    public void onParticipantDeviceAdded(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice);

    /**
    * Callback used to notify a conference that a participant device has been<br/>
    * removed. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param participantDevice LinphoneParticipantDevice that has been removed to the<br/>
    * conference   <br/>
    */
    public void onParticipantDeviceRemoved(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice);

    /**
    * Callback used to notify a conference that a participant has requested to join<br/>
    * the conference. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    * @param participantDevice {@link ParticipantDevice} that has requested to join<br/>
    * the conference   <br/>
    */
    public void onParticipantDeviceJoiningRequest(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice);

    /**
    * Callback used to notify a conference that the role of a participant has been<br/>
    * changed. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    * @param participant {@link Participant} whose role has changed   <br/>
    */
    public void onParticipantRoleChanged(@NonNull Conference conference, @NonNull Participant participant);

    /**
    * Callback used to notify a conference that the admin status of a participant has<br/>
    * been changed. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param participant LinphoneParticipant whose admin status has changed   <br/>
    */
    public void onParticipantAdminStatusChanged(@NonNull Conference conference, @NonNull Participant participant);

    /**
    * Callback used to notify a conference that a participant device has changed<br/>
    * state. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param device LinphoneParticipantDevice who change state   <br/>
    * @param state new participant device state <br/>
    */
    public void onParticipantDeviceStateChanged(@NonNull Conference conference, @NonNull ParticipantDevice device, ParticipantDevice.State state);

    /**
    * Callback used to notify a conference that a participant device starts or stops<br/>
    * screen sharing. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    * @param device {@link ParticipantDevice} who starts or stops screen sharing   <br/>
    * @param enabled whether the screen sharing is enabled or disabled <br/>
    */
    public void onParticipantDeviceScreenSharingChanged(@NonNull Conference conference, @NonNull ParticipantDevice device, boolean enabled);

    /**
    * Callback used to notify a conference that the media availability of a<br/>
    * participant device has been changed. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param device LinphoneParticipantDevice whose media availability changed has<br/>
    * changed   <br/>
    */
    public void onParticipantDeviceMediaAvailabilityChanged(@NonNull Conference conference, @NonNull ParticipantDevice device);

    /**
    * Callback used to notify a conference that the media capability of a participant<br/>
    * device has been changed. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    * @param device {@link ParticipantDevice} whose media capability changed has<br/>
    * changed   <br/>
    */
    public void onParticipantDeviceMediaCapabilityChanged(@NonNull Conference conference, @NonNull ParticipantDevice device);

    /**
    * Callback used to notify a conference state has changed. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param newState The new state of the conference <br/>
    */
    public void onStateChanged(@NonNull Conference conference, Conference.State newState);

    /**
    * Callback used to notify that the available media of a conference has changed. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    */
    public void onAvailableMediaChanged(@NonNull Conference conference);

    /**
    * Callback used to notify that the subject of a conference has changed. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param subject subject of the conference   <br/>
    */
    public void onSubjectChanged(@NonNull Conference conference, @NonNull String subject);

    /**
    * Callback used to notify that a participant device is speaking or isn't speaking<br/>
    * anymore. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    * @param participantDevice the participant device   <br/>
    * @param isSpeaking true if is speaking, false otherwise <br/>
    */
    public void onParticipantDeviceIsSpeakingChanged(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice, boolean isSpeaking);

    /**
    * Callback used to notify that a participant device is muted or is no longer<br/>
    * muted. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    * @param participantDevice the participant device   <br/>
    * @param isMuted true if is muted, false otherwise <br/>
    */
    public void onParticipantDeviceIsMuted(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice, boolean isMuted);

    /**
    * Callback used to notify that the audio device of a conference has changed. <br/>
    * <br/>
    * @param conference LinphoneConference object   <br/>
    * @param audioDevice audio device of the conference   <br/>
    */
    public void onAudioDeviceChanged(@NonNull Conference conference, @NonNull AudioDevice audioDevice);

    /**
    * Callback used to notify which participant device video is being displayed as<br/>
    * "actively speaking". <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    * @param participantDevice the participant device currently displayed as active<br/>
    * speaker   <br/>
    */
    public void onActiveSpeakerParticipantDevice(@NonNull Conference conference, @Nullable ParticipantDevice participantDevice);

    /**
    * Callback used to notify when a notify full state has been received. <br/>
    * <br/>
    * @param conference {@link Conference} object   <br/>
    */
    public void onFullStateReceived(@NonNull Conference conference);

}