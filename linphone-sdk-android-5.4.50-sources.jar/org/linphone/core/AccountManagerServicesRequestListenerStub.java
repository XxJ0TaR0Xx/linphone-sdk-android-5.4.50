/*
AccountManagerServicesRequestListenerStub.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

public class AccountManagerServicesRequestListenerStub implements AccountManagerServicesRequestListener {
    @Override
    public void onRequestSuccessful(@NonNull AccountManagerServicesRequest request, @Nullable String data) {
        // Auto-generated method stub
    }

    @Override
    public void onRequestError(@NonNull AccountManagerServicesRequest request, int statusCode, @Nullable String errorMessage, @Nullable Dictionary parameterErrors) {
        // Auto-generated method stub
    }

    @Override
    public void onDevicesListFetched(@NonNull AccountManagerServicesRequest request, @NonNull AccountDevice[] devicesList) {
        // Auto-generated method stub
    }

}