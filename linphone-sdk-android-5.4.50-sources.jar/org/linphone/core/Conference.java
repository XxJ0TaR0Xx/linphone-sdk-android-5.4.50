/*
Conference.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* A conference is the object that allow to make calls when there are 2 or more<br/>
* participants. <br/>
* <br/>
* To create (or find) a {@link Conference}, you first need a {@link ConferenceParams}<br/>
* object. {@link Core#createConferenceWithParams} allows you to create a<br/>
* conference. A conference is uniquely identified by a conference address,<br/>
* meaning you can have more than one conference between two accounts. To find a<br/>
* conference among those a core is part of, you can call {@link Core#searchConference}<br/>
* .<br/>
* A {@link Conference} may be created automatically and implicitely when an<br/>
* outgoing call is made to a conference server. Thanks to the standard 'isfocus'<br/>
* contact parameter, the call is identified as belonging to a conference. The<br/>
* conference object can then be retrieved with {@link Call#getConference}. <br/>
*/
public interface Conference {
    public enum SecurityLevel {
        /**
        * No security. <br/>
        * <br/>
        */
        None(0),

        /**
        * Point-to-point encryption. <br/>
        * <br/>
        */
        PointToPoint(1),

        /**
        * End-to-end encryption. <br/>
        * <br/>
        */
        EndToEnd(2);

        protected final int mValue;

        private SecurityLevel (int value) {
            mValue = value;
        }

        static public SecurityLevel fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1: return PointToPoint;
            case 2: return EndToEnd;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for SecurityLevel");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum ParticipantListType {
        /**
        * Only participants in the initiating INVITE are allowed to join the conference. <br/>
        * <br/>
        */
        Closed(0),

        /**
        * All devices calling the conference URI are allowed to join the conference. <br/>
        * <br/>
        */
        Open(1);

        protected final int mValue;

        private ParticipantListType (int value) {
            mValue = value;
        }

        static public ParticipantListType fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Closed;
            case 1: return Open;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for ParticipantListType");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum JoiningMode {
        /**
        * Participants must dial the conference server. <br/>
        * <br/>
        */
        DialIn(0),

        /**
        * Conference server dials participants. <br/>
        * <br/>
        */
        DialOut(1);

        protected final int mValue;

        private JoiningMode (int value) {
            mValue = value;
        }

        static public JoiningMode fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return DialIn;
            case 1: return DialOut;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for JoiningMode");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Layout {
        /**
        * Grid - each participant is given an equal sized image size. <br/>
        * <br/>
        */
        Grid(0),

        /**
        * Active speaker - participant who speaks is prominently displayed in the center<br/>
        * of the screen and other participants are minimized. <br/>
        * <br/>
        */
        ActiveSpeaker(1);

        protected final int mValue;

        private Layout (int value) {
            mValue = value;
        }

        static public Layout fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Grid;
            case 1: return ActiveSpeaker;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Layout");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum State {
        /**
        * Initial state. <br/>
        * <br/>
        */
        None(0),

        /**
        * Conference is now instantiated locally. <br/>
        * <br/>
        */
        Instantiated(1),

        /**
        * One creation request was sent to the service. <br/>
        * <br/>
        */
        CreationPending(2),

        /**
        * Conference was created on the service. <br/>
        * <br/>
        */
        Created(3),

        /**
        * Conference creation on service failed. <br/>
        * <br/>
        */
        CreationFailed(4),

        /**
        * Wait for conference termination. <br/>
        * <br/>
        */
        TerminationPending(5),

        /**
        * The conference is terminated locally, though it may still exist on the service<br/>
        * for other participants. <br/>
        * <br/>
        */
        Terminated(6),

        /**
        * Conference termination failed. <br/>
        * <br/>
        */
        TerminationFailed(7),

        /**
        * Conference was deleted locally and on the service. <br/>
        * <br/>
        */
        Deleted(8);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1: return Instantiated;
            case 2: return CreationPending;
            case 3: return Created;
            case 4: return CreationFailed;
            case 5: return TerminationPending;
            case 6: return Terminated;
            case 7: return TerminationFailed;
            case 8: return Deleted;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Gets the {@link Account} object associated with the conference. <br/>
    * <br/>
    * @return A {@link Account} object.   <br/>
    */
    @Nullable
    public Account getAccount();

    /**
    * Get the currently active speaker participant device. <br/>
    * <br/>
    * @return the {@link ParticipantDevice} currently displayed as active speaker.   <br/>
    */
    @Nullable
    public ParticipantDevice getActiveSpeakerParticipantDevice();

    /**
    * Gets the call that is controlling a conference. <br/>
    * <br/>
    * @return the {@link Call} controlling the conference or null if none or local<br/>
    * conference   <br/>
    */
    @Nullable
    public Call getCall();

    /**
    * Returns the {@link ChatRoom} linked to the {@link Conference}. <br/>
    * <br/>
    * @return back pointer to {@link ChatRoom} object.   <br/>
    */
    @Nullable
    public ChatRoom getChatRoom();

    /**
    * Get the conference address of the conference. <br/>
    * <br/>
    * This function may be return a null pointer if called before the conference<br/>
    * switches to the Created state <br/>
    * @return The conference address of the conference.   <br/>
    */
    @Nullable
    public Address getConferenceAddress();

    /**
    * Set the conference address. <br/>
    * <br/>
    * @param address the conference address to set.   <br/>
    * warning: This is only allowed for a client conference if it is in state<br/>
    * CreationPending or Instantiated <br/>
    */
    public void setConferenceAddress(@Nullable Address address);

    /**
    * Returns core for a {@link Conference}. <br/>
    * <br/>
    * @return back pointer to {@link Core} object.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Get current parameters of the conference. <br/>
    * <br/>
    * @return a {@link ConferenceParams} .   <br/>
    */
    @NonNull
    public ConferenceParams getCurrentParams();

    /**
    * Get the conference duration. <br/>
    * <br/>
    * @return conference duration.   <br/>
    */
    @Nullable
    public int getDuration();

    /**
    * Returns the conference identifier. <br/>
    * <br/>
    * warning: This method returns a null pointer if the Conference is in the<br/>
    * Instantiated state <br/>
    * @return the conference identifier.   <br/>
    */
    @Nullable
    public String getIdentifier();

    /**
    * Gets the {@link ConferenceInfo} object associated with a conference. <br/>
    * <br/>
    * @return A {@link ConferenceInfo} object.   <br/>
    */
    @Nullable
    public ConferenceInfo getInfo();

    /**
    * Gets the current input device for this conference. <br/>
    * <br/>
    * @return the {@link AudioDevice} used by this conference as input or null if<br/>
    * there is currently no soundcard configured (depending on the state of the<br/>
    * conference)   <br/>
    */
    @Nullable
    public AudioDevice getInputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as input for this conference only. <br/>
    * <br/>
    * @param audioDevice The {@link AudioDevice}. null does nothing.   <br/>
    */
    public void setInputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Retrieves the volume of a specific participant. <br/>
    * <br/>
    * @return The volume of the participant expressed in dbm0. <br/>
    */
    public float getInputVolume();

    /**
    * For a local conference, it returns whether the local participant is enabled For<br/>
    * a client conference, it return whether the remote participant has left the<br/>
    * conference without bein removed from it. <br/>
    * <br/>
    * @return true if the local participant is in a conference, false otherwise. <br/>
    */
    public boolean isIn();

    /**
    * Gets whether the conference is currently being recorded. <br/>
    * <br/>
    * @return true if conference is being recorded, false otherwise. <br/>
    */
    public boolean isRecording();

    /**
    * For a local audio video conference, this function returns the participant<br/>
    * hosting the conference For a remote audio video conference, this function<br/>
    * returns the local participant of the conference. <br/>
    * <br/>
    * @return a {@link Participant} .   <br/>
    */
    @NonNull
    public Participant getMe();

    /**
    * Retrieves the volume of a specific participant. <br/>
    * <br/>
    * @return true if the microphone is muted, false otherwise <br/>
    */
    public boolean getMicrophoneMuted();

    /**
    * Get microphone muted state. <br/>
    * <br/>
    * Note that the microphone may be disabled globally if false was given to {@link Core#enableMic}<br/>
    * . <br/>
    * @param muted The microphone muted state <br/>
    */
    public void setMicrophoneMuted(boolean muted);

    /**
    * Gets the current output device for this conference. <br/>
    * <br/>
    * @return the {@link AudioDevice} used by this conference as output or null if<br/>
    * there is currently no soundcard configured (depending on the state of the<br/>
    * conference)   <br/>
    */
    @Nullable
    public AudioDevice getOutputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as output for this conference only. <br/>
    * <br/>
    * @param audioDevice The {@link AudioDevice}. null does nothing.   <br/>
    */
    public void setOutputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Get number of participants without me. <br/>
    * <br/>
    * @return the number of participants excluding me in a {@link Conference} <br/>
    */
    public int getParticipantCount();

    /**
    * Get list of all participant devices of a conference including me if it is in. <br/>
    * <br/>
    * @return The list of participant devices of the conference.       <br/>
    */
    @NonNull
    public ParticipantDevice[] getParticipantDeviceList();

    /**
    * Get list of all participants of a conference. <br/>
    * <br/>
    * warning: The returned list does not include me. <br/>
    * @return The list of participants of the conference.      <br/>
    */
    @NonNull
    public Participant[] getParticipantList();

    /**
    * Get URIs of all participants of one conference The returned bctbx_list_t<br/>
    * contains URIs of all participants. <br/>
    * <br/>
    * That list must be freed after use and each URI must be unref with<br/>
    * linphone_address_unref warning: The returned list does not include me. <br/>
    * @return The list of the participants' address active in the conference.       <br/>
    * @deprecated 10/07/2020 Use {@link #getParticipantList} instead. <br/>
    */
    @Deprecated
    @NonNull
    public Address[] getParticipants();

    /**
    * Gets a player associated with the conference to play a local file and stream it<br/>
    * to the remote peers. <br/>
    * <br/>
    * @return A {@link Player} object.   <br/>
    */
    @Nullable
    public Player getPlayer();

    /**
    * Get the participant that is currently screen sharing. <br/>
    * <br/>
    * @return a pointer to the participant found or nullptr.   <br/>
    */
    @Nullable
    public Participant getScreenSharingParticipant();

    /**
    * Get the participant device that is currently screen sharing. <br/>
    * <br/>
    * @return a pointer to the participant device found or nullptr.   <br/>
    */
    @Nullable
    public ParticipantDevice getScreenSharingParticipantDevice();

    /**
    * Get the conference start time. <br/>
    * <br/>
    * @return conference start time.   <br/>
    */
    @Nullable
    public long getStartTime();

    /**
    * Get the current state of the conference. <br/>
    * <br/>
    * @return the {@link State} of the conference. <br/>
    */
    public Conference.State getState();

    /**
    * Get the conference subject. <br/>
    * <br/>
    * @return conference subject.   <br/>
    */
    @Nullable
    public String getSubject();

    /**
    * Set the conference subject. <br/>
    * <br/>
    * @param subject conference subject   <br/>
    */
    public void setSubject(@Nullable String subject);

    /**
    * Get the conference subject as an UTF-8 string. <br/>
    * <br/>
    * @return conference subject.   <br/>
    */
    @Nullable
    public String getSubjectUtf8();

    /**
    * Set the conference subject as an UTF-8 string. <br/>
    * <br/>
    * @param subject conference subject   <br/>
    */
    public void setSubjectUtf8(@Nullable String subject);

    /**
    * Get the conference username. <br/>
    * <br/>
    * @return conference subject.   <br/>
    */
    @Nullable
    public String getUsername();

    /**
    * Set the conference username. <br/>
    * <br/>
    * @param username conference subject   <br/>
    */
    public void setUsername(@Nullable String username);

    /**
    * Join an existing call to the conference. <br/>
    * <br/>
    * If the conference is in the state LinphoneConferenceStateCreationPending, then<br/>
    * the conference will start on the input and output audio devices used for the<br/>
    * currently active call, if any <br/>
    * @param call a {@link Call} that has to be added to the conference.   <br/>
    * warning: This function guarantees that the local endpoint is added to the<br/>
    * conference only if one of calls added is in state StreamsRunning. It is highly<br/>
    * recommended to call linphone_confererence_enter() to guarantee that the local<br/>
    * endpoint is added to the conference. <br/>
    */
    public int addParticipant(@NonNull Call call);

    /**
    * Join a participant to the conference. <br/>
    * <br/>
    * @param uri a {@link Address} that has to be added to the conference.   <br/>
    * warning: This function guarantees that the local endpoint is added to the<br/>
    * conference only if there is a call state StreamsRunning towards one of the<br/>
    * addresses. It is highly recommended to call linphone_confererence_enter() to<br/>
    * guarantee that the local endpoint is added to the conference. <br/>
    */
    public int addParticipant(@NonNull Address uri);

    /**
    * Add participants to the conference, by supplying a list of {@link Call}. <br/>
    * <br/>
    * If the conference is in the state LinphoneConferenceStateCreationPending, then<br/>
    * the conference will start on the input and output audio devices used for the<br/>
    * currently active call, if any <br/>
    * @param calls A list of calls to add to the conference.    <br/>
    */
    public int addParticipants(@NonNull Call[] calls);

    /**
    * Add participants to the conference, by supplying a list of {@link Address}. <br/>
    * <br/>
    * @param addresses A list of calls to add to the conference.    <br/>
    */
    public int addParticipants(@NonNull Address[] addresses);

    /**
    * For a local conference, the local participant joins the conference For a client<br/>
    * conference, the participant rejoins the conference after leaving it earlier on. <br/>
    * <br/>
    * @return 0 if succeeded. Negative number if failed <br/>
    */
    public int enter();

    /**
    * Find a participant from a conference. <br/>
    * <br/>
    * @param uri SIP URI of the participant to search.   <br/>
    * @return a pointer to the participant found or nullptr.   <br/>
    */
    @Nullable
    public Participant findParticipant(@NonNull Address uri);

    /**
    * Retrieves the volume of a specific participant. <br/>
    * <br/>
    * @param device The Participant   <br/>
    * @return The volume of the participant expressed in dbm0. <br/>
    */
    public int getParticipantDeviceVolume(@NonNull ParticipantDevice device);

    /**
    * Invite participants to the conference, by supplying a list of {@link Address}<br/>
    * If the conference is in the state LinphoneConferenceStateCreationPending, then<br/>
    * the conference will start on the input and output audio devices used for the<br/>
    * currently active call, if any This method will call every address supplied and<br/>
    * add it to a conference on devices hosting a conference. <br/>
    * <br/>
    * On the other hand, if the conference is created on a server, this method will<br/>
    * allow to create either a chat only conference or an ad-hoc audio video<br/>
    * conference <br/>
    * @param addresses A list of SIP addresses to invite.    <br/>
    * @param params {@link CallParams} to use for inviting the participants.   <br/>
    * warning: The {@link CallParams} are only honored by conference servers and<br/>
    * devices that host the conference locally. <br/>
    */
    public int inviteParticipants(@NonNull Address[] addresses, @Nullable CallParams params);

    /**
    * For a local audio video conference, this function compares the address provided<br/>
    * as argument with that of participant hosting the conference For a remote audio<br/>
    * video conference, this function compares the address provided as argument with<br/>
    * that of the local participant of the conference. <br/>
    * <br/>
    * @param uri A {@link Address} object   <br/>
    * @return true if the participant is me, false otherwise. <br/>
    */
    public boolean isMe(@NonNull Address uri);

    /**
    * For a local conference, the local participant leaves the conference For a<br/>
    * client conference, the participant leaves the conference after joining it<br/>
    * earlier on. <br/>
    * <br/>
    * @return 0 if succeeded. Negative number if failed <br/>
    */
    public int leave();

    /**
    * <br/>
    * @param uri URI of the participant to remove   <br/>
    * warning: The passed participant uri must be one of those returned by {@link #getParticipants}<br/>
    * @return 0 if succeeded, -1 if failed <br/>
    * @deprecated 10/07/2020 Use {@link #removeParticipant} instead. <br/>
    */
    @Deprecated
    public int removeParticipant(@NonNull Address uri);

    /**
    * <br/>
    * @param participant participant to remove   <br/>
    * warning: The passed participant must be one of those returned by {@link #getParticipantList}<br/>
    * warning: This method may destroy the conference if the only remaining<br/>
    * participant had an existing call to the local participant before the conference<br/>
    * was created <br/>
    * @return 0 if succeeded, -1 if failed <br/>
    */
    public int removeParticipant(@NonNull Participant participant);

    /**
    * <br/>
    * @param call call to remove   <br/>
    * @return 0 if succeeded, -1 if failed <br/>
    * @deprecated 10/07/2020 Use {@link #removeParticipant} instead. <br/>
    */
    @Deprecated
    public int removeParticipant(@NonNull Call call);

    /**
    * Set stream capability on 'me' device of a local conference. <br/>
    * <br/>
    * @param direction the direction of stream of type stream_type <br/>
    * @param streamType A {@link StreamType} <br/>
    */
    public void setLocalParticipantStreamCapability(MediaDirection direction, StreamType streamType);

    /**
    * Change the admin status of a participant of a conference (you need to be an<br/>
    * admin yourself to do this). <br/>
    * <br/>
    * @param participant The Participant for which to change the admin status   <br/>
    * @param isAdmin A boolean value telling whether the participant should now be an<br/>
    * admin or not <br/>
    */
    public void setParticipantAdminStatus(@NonNull Participant participant, boolean isAdmin);

    /**
    * Starts recording the conference. <br/>
    * <br/>
    * @param path Where to record the conference   <br/>
    * @return 0 if succeeded. Negative number in case of failure. <br/>
    */
    public int startRecording(@NonNull String path);

    /**
    * Stops the conference recording. <br/>
    * <br/>
    * @return 0 if succeeded. Negative number in case of failure. <br/>
    */
    public int stopRecording();

    /**
    * Terminates conference. <br/>
    * <br/>
    * @return 0 if the termination is successful, -1 otherwise. <br/>
    */
    public int terminate();

    /**
    * Update parameters of the conference. <br/>
    * <br/>
    * This is typically used enable or disable the video stream in the conference. <br/>
    * @param params the new parameters to apply.   <br/>
    */
    public int updateParams(@NonNull ConferenceParams params);

    /**
    * A function to convert a {@link State} into a string. <br/>
    * <br/>
    */
    public String stateToString(Conference.State state);

    /**
    */
    public void addListener(ConferenceListener listener);

    /**
    */
    public void removeListener(ConferenceListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ConferenceImpl implements Conference {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ConferenceImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Account getAccount(long nativePtr);
    @Override @Nullable
    synchronized public Account getAccount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Account)getAccount(nativePtr);
    }

    private native ParticipantDevice getActiveSpeakerParticipantDevice(long nativePtr);
    @Override @Nullable
    synchronized public ParticipantDevice getActiveSpeakerParticipantDevice()  {
        
        
        return (ParticipantDevice)getActiveSpeakerParticipantDevice(nativePtr);
    }

    private native Call getCall(long nativePtr);
    @Override @Nullable
    synchronized public Call getCall()  {
        
        
        return (Call)getCall(nativePtr);
    }

    private native ChatRoom getChatRoom(long nativePtr);
    @Override @Nullable
    synchronized public ChatRoom getChatRoom()  {
        
        
        return (ChatRoom)getChatRoom(nativePtr);
    }

    private native Address getConferenceAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getConferenceAddress()  {
        
        
        return (Address)getConferenceAddress(nativePtr);
    }

    private native void setConferenceAddress(long nativePtr, Address address);
    @Override
    synchronized public void setConferenceAddress(@Nullable Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceAddress(nativePtr, address);
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native ConferenceParams getCurrentParams(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceParams getCurrentParams()  {
        
        
        return (ConferenceParams)getCurrentParams(nativePtr);
    }

    private native int getDuration(long nativePtr);
    @Override @Nullable
    synchronized public int getDuration()  {
        
        
        return getDuration(nativePtr);
    }

    private native String getIdentifier(long nativePtr);
    @Override @Nullable
    synchronized public String getIdentifier()  {
        
        
        return getIdentifier(nativePtr);
    }

    private native ConferenceInfo getInfo(long nativePtr);
    @Override @Nullable
    synchronized public ConferenceInfo getInfo()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceInfo)getInfo(nativePtr);
    }

    private native AudioDevice getInputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getInputAudioDevice()  {
        
        
        return (AudioDevice)getInputAudioDevice(nativePtr);
    }

    private native void setInputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setInputAudioDevice(@Nullable AudioDevice audioDevice)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInputAudioDevice(nativePtr, audioDevice);
    }

    private native float getInputVolume(long nativePtr);
    @Override
    synchronized public float getInputVolume()  {
        
        
        return getInputVolume(nativePtr);
    }

    private native boolean isIn(long nativePtr);
    @Override
    synchronized public boolean isIn()  {
        
        
        return isIn(nativePtr);
    }

    private native boolean isRecording(long nativePtr);
    @Override
    synchronized public boolean isRecording()  {
        
        
        return isRecording(nativePtr);
    }

    private native Participant getMe(long nativePtr);
    @Override @NonNull
    synchronized public Participant getMe()  {
        
        
        return (Participant)getMe(nativePtr);
    }

    private native boolean getMicrophoneMuted(long nativePtr);
    @Override
    synchronized public boolean getMicrophoneMuted()  {
        
        
        return getMicrophoneMuted(nativePtr);
    }

    private native void setMicrophoneMuted(long nativePtr, boolean muted);
    @Override
    synchronized public void setMicrophoneMuted(boolean muted)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMicrophoneMuted() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMicrophoneMuted(nativePtr, muted);
    }

    private native AudioDevice getOutputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getOutputAudioDevice()  {
        
        
        return (AudioDevice)getOutputAudioDevice(nativePtr);
    }

    private native void setOutputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setOutputAudioDevice(@Nullable AudioDevice audioDevice)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOutputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOutputAudioDevice(nativePtr, audioDevice);
    }

    private native int getParticipantCount(long nativePtr);
    @Override
    synchronized public int getParticipantCount()  {
        
        
        return getParticipantCount(nativePtr);
    }

    private native ParticipantDevice[] getParticipantDeviceList(long nativePtr);
    @Override @NonNull
    synchronized public ParticipantDevice[] getParticipantDeviceList()  {
        
        
        return getParticipantDeviceList(nativePtr);
    }

    private native Participant[] getParticipantList(long nativePtr);
    @Override @NonNull
    synchronized public Participant[] getParticipantList()  {
        
        
        return getParticipantList(nativePtr);
    }

    private native Address[] getParticipants(long nativePtr);
    @Override @NonNull
    synchronized public Address[] getParticipants()  {
        
        
        return getParticipants(nativePtr);
    }

    private native Player getPlayer(long nativePtr);
    @Override @Nullable
    synchronized public Player getPlayer()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPlayer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Player)getPlayer(nativePtr);
    }

    private native Participant getScreenSharingParticipant(long nativePtr);
    @Override @Nullable
    synchronized public Participant getScreenSharingParticipant()  {
        
        
        return (Participant)getScreenSharingParticipant(nativePtr);
    }

    private native ParticipantDevice getScreenSharingParticipantDevice(long nativePtr);
    @Override @Nullable
    synchronized public ParticipantDevice getScreenSharingParticipantDevice()  {
        
        
        return (ParticipantDevice)getScreenSharingParticipantDevice(nativePtr);
    }

    private native long getStartTime(long nativePtr);
    @Override @Nullable
    synchronized public long getStartTime()  {
        
        
        return getStartTime(nativePtr);
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public Conference.State getState()  {
        
        
        return Conference.State.fromInt(getState(nativePtr));
    }

    private native String getSubject(long nativePtr);
    @Override @Nullable
    synchronized public String getSubject()  {
        
        
        return getSubject(nativePtr);
    }

    private native void setSubject(long nativePtr, String subject);
    @Override
    synchronized public void setSubject(@Nullable String subject)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubject() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubject(nativePtr, subject);
    }

    private native String getSubjectUtf88(long nativePtr);
    @Override @Nullable
    synchronized public String getSubjectUtf8()  {
        
        
        return getSubjectUtf88(nativePtr);
    }

    private native void setSubjectUtf88(long nativePtr, String subject);
    @Override
    synchronized public void setSubjectUtf8(@Nullable String subject)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubjectUtf8() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubjectUtf88(nativePtr, subject);
    }

    private native String getUsername(long nativePtr);
    @Override @Nullable
    synchronized public String getUsername()  {
        
        
        return getUsername(nativePtr);
    }

    private native void setUsername(long nativePtr, String username);
    @Override
    synchronized public void setUsername(@Nullable String username)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUsername() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUsername(nativePtr, username);
    }

    private native int addParticipant(long nativePtr, Call call);
    @Override
    synchronized public int addParticipant(@NonNull Call call)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addParticipant(nativePtr, call);
    }

    private native int addParticipant2(long nativePtr, Address uri);
    @Override
    synchronized public int addParticipant(@NonNull Address uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addParticipant2(nativePtr, uri);
    }

    private native int addParticipants(long nativePtr, Call[] calls);
    @Override
    synchronized public int addParticipants(@NonNull Call[] calls)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipants() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addParticipants(nativePtr, calls);
    }

    private native int addParticipants2(long nativePtr, Address[] addresses);
    @Override
    synchronized public int addParticipants(@NonNull Address[] addresses)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipants() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addParticipants2(nativePtr, addresses);
    }

    private native int enter(long nativePtr);
    @Override
    synchronized public int enter()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return enter(nativePtr);
    }

    private native Participant findParticipant(long nativePtr, Address uri);
    @Override @Nullable
    synchronized public Participant findParticipant(@NonNull Address uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Participant)findParticipant(nativePtr, uri);
    }

    private native int getParticipantDeviceVolume(long nativePtr, ParticipantDevice device);
    @Override
    synchronized public int getParticipantDeviceVolume(@NonNull ParticipantDevice device)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getParticipantDeviceVolume() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getParticipantDeviceVolume(nativePtr, device);
    }

    private native int inviteParticipants(long nativePtr, Address[] addresses, CallParams params);
    @Override
    synchronized public int inviteParticipants(@NonNull Address[] addresses, @Nullable CallParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call inviteParticipants() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return inviteParticipants(nativePtr, addresses, params);
    }

    private native boolean isMe(long nativePtr, Address uri);
    @Override
    synchronized public boolean isMe(@NonNull Address uri)  {
        
        
        return isMe(nativePtr, uri);
    }

    private native int leave(long nativePtr);
    @Override
    synchronized public int leave()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call leave() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return leave(nativePtr);
    }

    private native int removeParticipant(long nativePtr, Address uri);
    @Override
    synchronized public int removeParticipant(@NonNull Address uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return removeParticipant(nativePtr, uri);
    }

    private native int removeParticipant2(long nativePtr, Participant participant);
    @Override
    synchronized public int removeParticipant(@NonNull Participant participant)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return removeParticipant2(nativePtr, participant);
    }

    private native int removeParticipant3(long nativePtr, Call call);
    @Override
    synchronized public int removeParticipant(@NonNull Call call)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return removeParticipant3(nativePtr, call);
    }

    private native void setLocalParticipantStreamCapability(long nativePtr, int direction, int streamType);
    @Override
    synchronized public void setLocalParticipantStreamCapability(MediaDirection direction, StreamType streamType)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLocalParticipantStreamCapability() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLocalParticipantStreamCapability(nativePtr, direction.toInt(), streamType.toInt());
    }

    private native void setParticipantAdminStatus(long nativePtr, Participant participant, boolean isAdmin);
    @Override
    synchronized public void setParticipantAdminStatus(@NonNull Participant participant, boolean isAdmin)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParticipantAdminStatus() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParticipantAdminStatus(nativePtr, participant, isAdmin);
    }

    private native int startRecording(long nativePtr, String path);
    @Override
    synchronized public int startRecording(@NonNull String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call startRecording() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return startRecording(nativePtr, path);
    }

    private native int stopRecording(long nativePtr);
    @Override
    synchronized public int stopRecording()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stopRecording() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return stopRecording(nativePtr);
    }

    private native int terminate(long nativePtr);
    @Override
    synchronized public int terminate()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call terminate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return terminate(nativePtr);
    }

    private native int updateParams(long nativePtr, ConferenceParams params);
    @Override
    synchronized public int updateParams(@NonNull ConferenceParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call updateParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return updateParams(nativePtr, params);
    }

    private native String stateToString(long nativePtr, int state);
    @Override
    synchronized public String stateToString(Conference.State state)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stateToString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return stateToString(nativePtr, state.toInt());
    }

    private native void addListener(long nativePtr, ConferenceListener listener);
    @Override
    synchronized public void addListener(ConferenceListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, ConferenceListener listener);
    @Override
    synchronized public void removeListener(ConferenceListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
