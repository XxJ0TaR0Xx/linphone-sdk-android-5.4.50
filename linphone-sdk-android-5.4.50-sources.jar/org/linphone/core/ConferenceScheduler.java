/*
ConferenceScheduler.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Creates and manages conferences on a conferenceing service, and send conference<br/>
* invitations to notify participants. <br/>
* <br/>
*/
public interface ConferenceScheduler {
    public enum Type {
        /**
        * SIP conference scheduler type. <br/>
        * <br/>
        */
        SIP(0),

        /**
        * Database conference scheduler type. <br/>
        * <br/>
        */
        DB(1),

        /**
        * CCMP conference scheduler type. <br/>
        * <br/>
        */
        CCMP(2);

        protected final int mValue;

        private Type (int value) {
            mValue = value;
        }

        static public Type fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return SIP;
            case 1: return DB;
            case 2: return CCMP;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Type");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum State {
        /**
        * Default state of a freshly created {@link ConferenceScheduler}. <br/>
        * <br/>
        */
        Idle(0),

        /**
        * An error has happened during conference creation. <br/>
        * <br/>
        */
        Error(1),

        /**
        * Conference creation is in progress. <br/>
        * <br/>
        */
        AllocationPending(2),

        /**
        * Confererence has been created. <br/>
        * <br/>
        */
        Ready(3),

        /**
        * Conference has been updated. <br/>
        * <br/>
        */
        Updating(4);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Idle;
            case 1: return Error;
            case 2: return AllocationPending;
            case 3: return Ready;
            case 4: return Updating;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Get the {@link Account} that is used for the conference scheduler. <br/>
    * <br/>
    * @return The selected {@link Account} for the call, or null if none has been<br/>
    * selected.   <br/>
    */
    @Nullable
    public Account getAccount();

    /**
    * Set the {@link Account} to use for the conference scheduler. <br/>
    * <br/>
    * @param account The {@link Account} to use, or null if none has been selected.<br/>
    * The LinphoneConferenceScheduler keeps a reference to it and removes the<br/>
    * previous one, if any.   <br/>
    */
    public void setAccount(@Nullable Account account);

    /**
    * Gets the {@link Core} from a {@link ConferenceScheduler} object. <br/>
    * <br/>
    * @return the {@link Core} object.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Returns the {@link ConferenceInfo} currently set in this scheduler. <br/>
    * <br/>
    * @return the currently configured {@link ConferenceInfo} or null if none is set.<br/>
    *   <br/>
    */
    @Nullable
    public ConferenceInfo getInfo();

    /**
    * Sets the {@link ConferenceInfo} to use to create/update the conference, which<br/>
    * will be done right away. <br/>
    * <br/>
    * @param conferenceInfo the {@link ConferenceInfo} object to use to start<br/>
    * creating/updating the client conference.    <br/>
    */
    public void setInfo(@Nullable ConferenceInfo conferenceInfo);

    /**
    * Cancel the conference linked to the {@link ConferenceInfo} provided as<br/>
    * argument. <br/>
    * <br/>
    * @param conferenceInfo the {@link ConferenceInfo} object to linked to the<br/>
    * conference to cancel.   <br/>
    */
    public void cancelConference(@Nullable ConferenceInfo conferenceInfo);

    /**
    * Sends an invitation to the scheduled conference to each participant by chat,<br/>
    * using given chat rooms params to use/create the chat room in which to send it. <br/>
    * <br/>
    * @param chatRoomParams the {@link ChatRoomParams} object to use to use/create<br/>
    * the {@link ChatRoom} that will be used to send the invite.   <br/>
    * @deprecated 28/08/2024 Use {@link #sendInvitations} instead. <br/>
    */
    @Deprecated
    public void sendInvitations(@NonNull ChatRoomParams chatRoomParams);

    /**
    * Sends an invitation to the scheduled conference to each participant by chat,<br/>
    * using given conference params to use/create the chat room in which to send it. <br/>
    * <br/>
    * @param conferenceParams the {@link ConferenceParams} object to use to<br/>
    * use/create the {@link ChatRoom} that will be used to send the invite.   <br/>
    */
    public void sendInvitations(@NonNull ConferenceParams conferenceParams);

    /**
    */
    public void addListener(ConferenceSchedulerListener listener);

    /**
    */
    public void removeListener(ConferenceSchedulerListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ConferenceSchedulerImpl implements ConferenceScheduler {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ConferenceSchedulerImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Account getAccount(long nativePtr);
    @Override @Nullable
    synchronized public Account getAccount()  {
        
        
        return (Account)getAccount(nativePtr);
    }

    private native void setAccount(long nativePtr, Account account);
    @Override
    synchronized public void setAccount(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccount(nativePtr, account);
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native ConferenceInfo getInfo(long nativePtr);
    @Override @Nullable
    synchronized public ConferenceInfo getInfo()  {
        
        
        return (ConferenceInfo)getInfo(nativePtr);
    }

    private native void setInfo(long nativePtr, ConferenceInfo conferenceInfo);
    @Override
    synchronized public void setInfo(@Nullable ConferenceInfo conferenceInfo)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInfo(nativePtr, conferenceInfo);
    }

    private native void cancelConference(long nativePtr, ConferenceInfo conferenceInfo);
    @Override
    synchronized public void cancelConference(@Nullable ConferenceInfo conferenceInfo)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call cancelConference() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        cancelConference(nativePtr, conferenceInfo);
    }

    private native void sendInvitations(long nativePtr, ChatRoomParams chatRoomParams);
    @Override
    synchronized public void sendInvitations(@NonNull ChatRoomParams chatRoomParams)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sendInvitations() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        sendInvitations(nativePtr, chatRoomParams);
    }

    private native void sendInvitations2(long nativePtr, ConferenceParams conferenceParams);
    @Override
    synchronized public void sendInvitations(@NonNull ConferenceParams conferenceParams)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sendInvitations() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        sendInvitations2(nativePtr, conferenceParams);
    }

    private native void addListener(long nativePtr, ConferenceSchedulerListener listener);
    @Override
    synchronized public void addListener(ConferenceSchedulerListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, ConferenceSchedulerListener listener);
    @Override
    synchronized public void removeListener(ConferenceSchedulerListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
