/*
CallListenerStub.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

public class CallListenerStub implements CallListener {
    @Override
    public void onDtmfReceived(@NonNull Call call, int dtmf) {
        // Auto-generated method stub
    }

    @Override
    public void onGoclearAckSent(@NonNull Call call) {
        // Auto-generated method stub
    }

    @Override
    public void onSecurityLevelDowngraded(@NonNull Call call) {
        // Auto-generated method stub
    }

    @Override
    public void onEncryptionChanged(@NonNull Call call, boolean on, @Nullable String authenticationToken) {
        // Auto-generated method stub
    }

    @Override
    public void onAuthenticationTokenVerified(@NonNull Call call, boolean verified) {
        // Auto-generated method stub
    }

    @Override
    public void onSendMasterKeyChanged(@NonNull Call call, @Nullable String sendMasterKey) {
        // Auto-generated method stub
    }

    @Override
    public void onReceiveMasterKeyChanged(@NonNull Call call, @Nullable String receiveMasterKey) {
        // Auto-generated method stub
    }

    @Override
    public void onInfoMessageReceived(@NonNull Call call, @NonNull InfoMessage message) {
        // Auto-generated method stub
    }

    @Override
    public void onStateChanged(@NonNull Call call, Call.State state, @NonNull String message) {
        // Auto-generated method stub
    }

    @Override
    public void onStatsUpdated(@NonNull Call call, @NonNull CallStats stats) {
        // Auto-generated method stub
    }

    @Override
    public void onTransferStateChanged(@NonNull Call call, Call.State state) {
        // Auto-generated method stub
    }

    @Override
    public void onReferRequested(@NonNull Call call, @NonNull Address referTo) {
        // Auto-generated method stub
    }

    @Override
    public void onAckProcessing(@NonNull Call call, @NonNull Headers ack, boolean isReceived) {
        // Auto-generated method stub
    }

    @Override
    public void onTmmbrReceived(@NonNull Call call, int streamIndex, int tmmbr) {
        // Auto-generated method stub
    }

    @Override
    public void onSnapshotTaken(@NonNull Call call, @NonNull String filePath) {
        // Auto-generated method stub
    }

    @Override
    public void onNextVideoFrameDecoded(@NonNull Call call) {
        // Auto-generated method stub
    }

    @Override
    public void onCameraNotWorking(@NonNull Call call, @NonNull String cameraName) {
        // Auto-generated method stub
    }

    @Override
    public void onVideoDisplayErrorOccurred(@NonNull Call call, int errorCode) {
        // Auto-generated method stub
    }

    @Override
    public void onAudioDeviceChanged(@NonNull Call call, @NonNull AudioDevice audioDevice) {
        // Auto-generated method stub
    }

    @Override
    public void onRemoteRecording(@NonNull Call call, boolean recording) {
        // Auto-generated method stub
    }

    @Override
    public void onBaudotDetected(@NonNull Call call, BaudotStandard standard) {
        // Auto-generated method stub
    }

}