/*
Vcard.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object storing contact information using vCard 4.0 format. <br/>
* <br/>
*/
public interface Vcard {
    /**
    * Gets the eTag of the vCard. <br/>
    * <br/>
    * @return the eTag of the vCard in the CardDAV server, otherwise null.   <br/>
    */
    @Nullable
    public String getEtag();

    /**
    * Sets the eTAG of the vCard. <br/>
    * <br/>
    * @param etag the eTAG.   <br/>
    */
    public void setEtag(@Nullable String etag);

    /**
    * Returns the family name in the N attribute of the vCard, or null if it isn't<br/>
    * set yet. <br/>
    * <br/>
    * @return the family name of the vCard, or null   <br/>
    */
    @Nullable
    public String getFamilyName();

    /**
    * Sets the family name in the N attribute of the vCard. <br/>
    * <br/>
    * @param name the family name to set for the vCard   <br/>
    */
    public void setFamilyName(@Nullable String name);

    /**
    * Returns the FN attribute of the vCard, or null if it isn't set yet. <br/>
    * <br/>
    * @return the display name of the vCard, or null.   <br/>
    */
    @Nullable
    public String getFullName();

    /**
    * Sets the FN attribute of the vCard (which is mandatory). <br/>
    * <br/>
    * @param name the display name to set for the vCard   <br/>
    */
    public void setFullName(@Nullable String name);

    /**
    * Returns the given name in the N attribute of the vCard, or null if it isn't set<br/>
    * yet. <br/>
    * <br/>
    * @return the given name of the vCard, or null   <br/>
    */
    @Nullable
    public String getGivenName();

    /**
    * Sets the given name in the N attribute of the vCard. <br/>
    * <br/>
    * @param name the given name to set for the vCard   <br/>
    */
    public void setGivenName(@Nullable String name);

    /**
    * Gets the Title of the vCard. <br/>
    * <br/>
    * @return the Title of the vCard or null.   <br/>
    */
    @Nullable
    public String getJobTitle();

    /**
    * Fills the Title field of the vCard. <br/>
    * <br/>
    * @param jobTitle the job title.   <br/>
    */
    public void setJobTitle(@Nullable String jobTitle);

    /**
    * Gets the Organization of the vCard. <br/>
    * <br/>
    * @return the Organization of the vCard or null.   <br/>
    */
    @Nullable
    public String getOrganization();

    /**
    * Fills the Organization field of the vCard. <br/>
    * <br/>
    * @param organization the Organization.   <br/>
    */
    public void setOrganization(@Nullable String organization);

    /**
    * Returns the list of phone numbers in the vCard (all the TEL attributes) or<br/>
    * null. <br/>
    * <br/>
    * @return The phone numbers as string.      <br/>
    */
    @NonNull
    public String[] getPhoneNumbers();

    /**
    * Returns the list of phone numbers in the vCard (all the TEL attributes) or<br/>
    * null. <br/>
    * <br/>
    * @return The phone numbers as {@link FriendPhoneNumber}.      <br/>
    */
    @NonNull
    public FriendPhoneNumber[] getPhoneNumbersWithLabel();

    /**
    * Returns the first PHOTO property or null. <br/>
    * <br/>
    * @return The picture URI as string or null if none has been set.   <br/>
    */
    @Nullable
    public String getPhoto();

    /**
    * Sets a picture URI in the vCard, using the PHOTO property. <br/>
    * <br/>
    * @param picture the picture URI to add. If null it will have the same effet as<br/>
    * {@link #removePhoto}.    <br/>
    */
    public void setPhoto(@Nullable String picture);

    /**
    * Returns the list of SIP addresses in the vCard (all the IMPP attributes that<br/>
    * has an URI value starting by "sip:") or null. <br/>
    * <br/>
    * @return The SIP addresses.    <br/>
    */
    @NonNull
    public Address[] getSipAddresses();

    /**
    * Gets the UID of the vCard. <br/>
    * <br/>
    * @return the UID of the vCard, otherwise null.   <br/>
    */
    @Nullable
    public String getUid();

    /**
    * Sets the unique ID of the vCard. <br/>
    * <br/>
    * @param uid the unique id   <br/>
    */
    public void setUid(@Nullable String uid);

    /**
    * Gets the URL of the vCard. <br/>
    * <br/>
    * @return the URL of the vCard in the CardDAV server, otherwise null.   <br/>
    */
    @Nullable
    public String getUrl();

    /**
    * Sets the URL of the vCard. <br/>
    * <br/>
    * @param url the URL.   <br/>
    */
    public void setUrl(@Nullable String url);

    /**
    * Adds an extended property to the vCard. <br/>
    * <br/>
    * @param name the name of the extended property to add   <br/>
    * @param value the value of the extended property to add   <br/>
    */
    public void addExtendedProperty(@NonNull String name, @NonNull String value);

    /**
    * Adds a phone number in the vCard, using the TEL property. <br/>
    * <br/>
    * @param phone the phone number to add   <br/>
    */
    public void addPhoneNumber(@NonNull String phone);

    /**
    * Adds a {@link FriendPhoneNumber} in the vCard, using the TEL property. <br/>
    * <br/>
    * @param phoneNumber the {@link FriendPhoneNumber} to add   <br/>
    */
    public void addPhoneNumberWithLabel(@NonNull FriendPhoneNumber phoneNumber);

    /**
    * Adds a SIP address in the vCard, using the IMPP property. <br/>
    * <br/>
    * @param sipAddress the SIP address to add   <br/>
    */
    public void addSipAddress(@NonNull String sipAddress);

    /**
    * Returns the vCard4 representation of the LinphoneVcard. <br/>
    * <br/>
    * @return a const char * that represents the vCard.   <br/>
    */
    @Nullable
    public String asVcard4String();

    /**
    * Returns the vCard4 representation of the LinphoneVcard, but if a local file is<br/>
    * detected in a PHOTO field, it will be converted to base64. <br/>
    * <br/>
    * @return a const char * that represents the vCard.   <br/>
    */
    @Nullable
    public String asVcard4StringWithBase64Picture();

    /**
    * Clone a {@link Vcard}. <br/>
    * <br/>
    * @return a new {@link Vcard} object   <br/>
    */
    @NonNull
    public Vcard clone();

    /**
    * Edits the preferred SIP address in the vCard (or the first one), using the IMPP<br/>
    * property. <br/>
    * <br/>
    * @param sipAddress the new SIP address   <br/>
    */
    public void editMainSipAddress(@NonNull String sipAddress);

    /**
    * Generates a random unique id for the vCard. <br/>
    * <br/>
    * If is required to be able to synchronize the vCard with a CardDAV server <br/>
    * @return true if operation is successful, otherwise false (for example if it<br/>
    * already has an unique ID) <br/>
    */
    public boolean generateUniqueId();

    /**
    * Get the vCard extended properties values per property name. <br/>
    * <br/>
    * @param name the name to filter the extended properties on.   <br/>
    * @return The extended properties values as string.      <br/>
    */
    @NonNull
    public String[] getExtendedPropertiesValuesByName(@NonNull String name);

    /**
    * Remove all the extend properties per property name. <br/>
    * <br/>
    * @param name the name to remove the extended properties on.   <br/>
    */
    public void removeExtentedPropertiesByName(@NonNull String name);

    /**
    * Removes the Title field of the vCard. <br/>
    * <br/>
    */
    public void removeJobTitle();

    /**
    * Removes the Organization field of the vCard. <br/>
    * <br/>
    */
    public void removeOrganization();

    /**
    * Removes a phone number in the vCard (if it exists), using the TEL property. <br/>
    * <br/>
    * @param phone the phone number to remove   <br/>
    */
    public void removePhoneNumber(@NonNull String phone);

    /**
    * Removes a {@link FriendPhoneNumber} in the vCard (if it exists), using the TEL<br/>
    * property. <br/>
    * <br/>
    * @param phoneNumber the {@link FriendPhoneNumber} to remove   <br/>
    */
    public void removePhoneNumberWithLabel(@NonNull FriendPhoneNumber phoneNumber);

    /**
    * Removes any existing PHOTO property. <br/>
    * <br/>
    */
    public void removePhoto();

    /**
    * Removes a SIP address in the vCard (if it exists), using the IMPP property. <br/>
    * <br/>
    * @param sipAddress the SIP address to remove   <br/>
    */
    public void removeSipAddress(@NonNull String sipAddress);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class VcardImpl implements Vcard {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected VcardImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getEtag(long nativePtr);
    @Override @Nullable
    synchronized public String getEtag()  {
        
        
        return getEtag(nativePtr);
    }

    private native void setEtag(long nativePtr, String etag);
    @Override
    synchronized public void setEtag(@Nullable String etag)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEtag() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEtag(nativePtr, etag);
    }

    private native String getFamilyName(long nativePtr);
    @Override @Nullable
    synchronized public String getFamilyName()  {
        
        
        return getFamilyName(nativePtr);
    }

    private native void setFamilyName(long nativePtr, String name);
    @Override
    synchronized public void setFamilyName(@Nullable String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFamilyName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFamilyName(nativePtr, name);
    }

    private native String getFullName(long nativePtr);
    @Override @Nullable
    synchronized public String getFullName()  {
        
        
        return getFullName(nativePtr);
    }

    private native void setFullName(long nativePtr, String name);
    @Override
    synchronized public void setFullName(@Nullable String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFullName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFullName(nativePtr, name);
    }

    private native String getGivenName(long nativePtr);
    @Override @Nullable
    synchronized public String getGivenName()  {
        
        
        return getGivenName(nativePtr);
    }

    private native void setGivenName(long nativePtr, String name);
    @Override
    synchronized public void setGivenName(@Nullable String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setGivenName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setGivenName(nativePtr, name);
    }

    private native String getJobTitle(long nativePtr);
    @Override @Nullable
    synchronized public String getJobTitle()  {
        
        
        return getJobTitle(nativePtr);
    }

    private native void setJobTitle(long nativePtr, String jobTitle);
    @Override
    synchronized public void setJobTitle(@Nullable String jobTitle)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setJobTitle() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setJobTitle(nativePtr, jobTitle);
    }

    private native String getOrganization(long nativePtr);
    @Override @Nullable
    synchronized public String getOrganization()  {
        
        
        return getOrganization(nativePtr);
    }

    private native void setOrganization(long nativePtr, String organization);
    @Override
    synchronized public void setOrganization(@Nullable String organization)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOrganization() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOrganization(nativePtr, organization);
    }

    private native String[] getPhoneNumbers(long nativePtr);
    @Override @NonNull
    synchronized public String[] getPhoneNumbers()  {
        
        
        return getPhoneNumbers(nativePtr);
    }

    private native FriendPhoneNumber[] getPhoneNumbersWithLabel(long nativePtr);
    @Override @NonNull
    synchronized public FriendPhoneNumber[] getPhoneNumbersWithLabel()  {
        
        
        return getPhoneNumbersWithLabel(nativePtr);
    }

    private native String getPhoto(long nativePtr);
    @Override @Nullable
    synchronized public String getPhoto()  {
        
        
        return getPhoto(nativePtr);
    }

    private native void setPhoto(long nativePtr, String picture);
    @Override
    synchronized public void setPhoto(@Nullable String picture)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPhoto() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPhoto(nativePtr, picture);
    }

    private native Address[] getSipAddresses(long nativePtr);
    @Override @NonNull
    synchronized public Address[] getSipAddresses()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSipAddresses() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getSipAddresses(nativePtr);
    }

    private native String getUid(long nativePtr);
    @Override @Nullable
    synchronized public String getUid()  {
        
        
        return getUid(nativePtr);
    }

    private native void setUid(long nativePtr, String uid);
    @Override
    synchronized public void setUid(@Nullable String uid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUid() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUid(nativePtr, uid);
    }

    private native String getUrl(long nativePtr);
    @Override @Nullable
    synchronized public String getUrl()  {
        
        
        return getUrl(nativePtr);
    }

    private native void setUrl(long nativePtr, String url);
    @Override
    synchronized public void setUrl(@Nullable String url)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUrl(nativePtr, url);
    }

    private native void addExtendedProperty(long nativePtr, String name, String value);
    @Override
    synchronized public void addExtendedProperty(@NonNull String name, @NonNull String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addExtendedProperty() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addExtendedProperty(nativePtr, name, value);
    }

    private native void addPhoneNumber(long nativePtr, String phone);
    @Override
    synchronized public void addPhoneNumber(@NonNull String phone)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addPhoneNumber() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addPhoneNumber(nativePtr, phone);
    }

    private native void addPhoneNumberWithLabel(long nativePtr, FriendPhoneNumber phoneNumber);
    @Override
    synchronized public void addPhoneNumberWithLabel(@NonNull FriendPhoneNumber phoneNumber)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addPhoneNumberWithLabel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addPhoneNumberWithLabel(nativePtr, phoneNumber);
    }

    private native void addSipAddress(long nativePtr, String sipAddress);
    @Override
    synchronized public void addSipAddress(@NonNull String sipAddress)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addSipAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addSipAddress(nativePtr, sipAddress);
    }

    private native String asVcard4String(long nativePtr);
    @Override @Nullable
    synchronized public String asVcard4String()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call asVcard4String() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return asVcard4String(nativePtr);
    }

    private native String asVcard4StringWithBase64Picture(long nativePtr);
    @Override @Nullable
    synchronized public String asVcard4StringWithBase64Picture()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call asVcard4StringWithBase64Picture() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return asVcard4StringWithBase64Picture(nativePtr);
    }

    private native Vcard clone(long nativePtr);
    @Override @NonNull
    synchronized public Vcard clone()  {
        
        
        return (Vcard)clone(nativePtr);
    }

    private native void editMainSipAddress(long nativePtr, String sipAddress);
    @Override
    synchronized public void editMainSipAddress(@NonNull String sipAddress)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call editMainSipAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        editMainSipAddress(nativePtr, sipAddress);
    }

    private native boolean generateUniqueId(long nativePtr);
    @Override
    synchronized public boolean generateUniqueId()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call generateUniqueId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return generateUniqueId(nativePtr);
    }

    private native String[] getExtendedPropertiesValuesByName(long nativePtr, String name);
    @Override @NonNull
    synchronized public String[] getExtendedPropertiesValuesByName(@NonNull String name)  {
        
        
        return getExtendedPropertiesValuesByName(nativePtr, name);
    }

    private native void removeExtentedPropertiesByName(long nativePtr, String name);
    @Override
    synchronized public void removeExtentedPropertiesByName(@NonNull String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeExtentedPropertiesByName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeExtentedPropertiesByName(nativePtr, name);
    }

    private native void removeJobTitle(long nativePtr);
    @Override
    synchronized public void removeJobTitle()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeJobTitle() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeJobTitle(nativePtr);
    }

    private native void removeOrganization(long nativePtr);
    @Override
    synchronized public void removeOrganization()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeOrganization() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeOrganization(nativePtr);
    }

    private native void removePhoneNumber(long nativePtr, String phone);
    @Override
    synchronized public void removePhoneNumber(@NonNull String phone)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removePhoneNumber() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removePhoneNumber(nativePtr, phone);
    }

    private native void removePhoneNumberWithLabel(long nativePtr, FriendPhoneNumber phoneNumber);
    @Override
    synchronized public void removePhoneNumberWithLabel(@NonNull FriendPhoneNumber phoneNumber)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removePhoneNumberWithLabel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removePhoneNumberWithLabel(nativePtr, phoneNumber);
    }

    private native void removePhoto(long nativePtr);
    @Override
    synchronized public void removePhoto()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removePhoto() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removePhoto(nativePtr);
    }

    private native void removeSipAddress(long nativePtr, String sipAddress);
    @Override
    synchronized public void removeSipAddress(@NonNull String sipAddress)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeSipAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeSipAddress(nativePtr, sipAddress);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
