/*
CoreListenerStub.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

public class CoreListenerStub implements CoreListener {
    @Override
    public void onGlobalStateChanged(@NonNull Core core, GlobalState state, @NonNull String message) {
        // Auto-generated method stub
    }

    @Override
    public void onRegistrationStateChanged(@NonNull Core core, @NonNull ProxyConfig proxyConfig, RegistrationState state, @NonNull String message) {
        // Auto-generated method stub
    }

    @Override
    public void onConferenceInfoReceived(@NonNull Core core, @NonNull ConferenceInfo conferenceInfo) {
        // Auto-generated method stub
    }

    @Override
    public void onPushNotificationReceived(@NonNull Core core, @Nullable String payload) {
        // Auto-generated method stub
    }

    @Override
    public void onPreviewDisplayErrorOccurred(@NonNull Core core, int errorCode) {
        // Auto-generated method stub
    }

    @Override
    public void onCallStateChanged(@NonNull Core core, @NonNull Call call, Call.State state, @NonNull String message) {
        // Auto-generated method stub
    }

    @Override
    public void onNotifyPresenceReceived(@NonNull Core core, @NonNull Friend linphoneFriend) {
        // Auto-generated method stub
    }

    @Override
    public void onNotifyPresenceReceivedForUriOrTel(@NonNull Core core, @NonNull Friend linphoneFriend, @NonNull String uriOrTel, @NonNull PresenceModel presenceModel) {
        // Auto-generated method stub
    }

    @Override
    public void onNewSubscriptionRequested(@NonNull Core core, @NonNull Friend linphoneFriend, @NonNull String url) {
        // Auto-generated method stub
    }

    @Override
    public void onAuthenticationRequested(@NonNull Core core, @NonNull AuthInfo authInfo, @NonNull AuthMethod method) {
        // Auto-generated method stub
    }

    @Override
    public void onCallLogUpdated(@NonNull Core core, @NonNull CallLog callLog) {
        // Auto-generated method stub
    }

    @Override
    public void onCallIdUpdated(@NonNull Core core, @NonNull String previousCallId, @NonNull String currentCallId) {
        // Auto-generated method stub
    }

    @Override
    public void onRemainingNumberOfFileTransferChanged(@NonNull Core core, int downloadCount, int uploadCount) {
        // Auto-generated method stub
    }

    @Override
    public void onMessageReceived(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message) {
        // Auto-generated method stub
    }

    @Override
    public void onNewMessageReaction(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message, @NonNull ChatMessageReaction reaction) {
        // Auto-generated method stub
    }

    @Override
    public void onReactionRemoved(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message, @NonNull Address address) {
        // Auto-generated method stub
    }

    @Override
    public void onMessagesReceived(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage[] messages) {
        // Auto-generated method stub
    }

    @Override
    public void onMessageSent(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message) {
        // Auto-generated method stub
    }

    @Override
    public void onChatRoomSessionStateChanged(@NonNull Core core, @NonNull ChatRoom chatRoom, Call.State state, @NonNull String message) {
        // Auto-generated method stub
    }

    @Override
    public void onChatRoomRead(@NonNull Core core, @NonNull ChatRoom chatRoom) {
        // Auto-generated method stub
    }

    @Override
    public void onMessageReceivedUnableDecrypt(@NonNull Core core, @NonNull ChatRoom chatRoom, @NonNull ChatMessage message) {
        // Auto-generated method stub
    }

    @Override
    public void onIsComposingReceived(@NonNull Core core, @NonNull ChatRoom chatRoom) {
        // Auto-generated method stub
    }

    @Override
    public void onDtmfReceived(@NonNull Core core, @NonNull Call call, int dtmf) {
        // Auto-generated method stub
    }

    @Override
    public void onReferReceived(@NonNull Core core, @NonNull Address referToAddr, @NonNull Headers customHeaders, @Nullable Content content) {
        // Auto-generated method stub
    }

    @Override
    public void onCallGoclearAckSent(@NonNull Core core, @NonNull Call call) {
        // Auto-generated method stub
    }

    @Override
    public void onCallEncryptionChanged(@NonNull Core core, @NonNull Call call, boolean mediaEncryptionEnabled, @Nullable String authenticationToken) {
        // Auto-generated method stub
    }

    @Override
    public void onCallSendMasterKeyChanged(@NonNull Core core, @NonNull Call call, @Nullable String masterKey) {
        // Auto-generated method stub
    }

    @Override
    public void onCallReceiveMasterKeyChanged(@NonNull Core core, @NonNull Call call, @Nullable String masterKey) {
        // Auto-generated method stub
    }

    @Override
    public void onTransferStateChanged(@NonNull Core core, @NonNull Call transferred, Call.State callState) {
        // Auto-generated method stub
    }

    @Override
    public void onBuddyInfoUpdated(@NonNull Core core, @NonNull Friend linphoneFriend) {
        // Auto-generated method stub
    }

    @Override
    public void onCallStatsUpdated(@NonNull Core core, @NonNull Call call, @NonNull CallStats callStats) {
        // Auto-generated method stub
    }

    @Override
    public void onInfoReceived(@NonNull Core core, @NonNull Call call, @NonNull InfoMessage message) {
        // Auto-generated method stub
    }

    @Override
    public void onSubscriptionStateChanged(@NonNull Core core, @NonNull Event linphoneEvent, SubscriptionState state) {
        // Auto-generated method stub
    }

    @Override
    public void onNotifySent(@NonNull Core core, @NonNull Event linphoneEvent, @Nullable Content body) {
        // Auto-generated method stub
    }

    @Override
    public void onNotifyReceived(@NonNull Core core, @NonNull Event linphoneEvent, @NonNull String notifiedEvent, @Nullable Content body) {
        // Auto-generated method stub
    }

    @Override
    public void onSubscribeReceived(@NonNull Core core, @NonNull Event linphoneEvent, @NonNull String subscribeEvent, @Nullable Content body) {
        // Auto-generated method stub
    }

    @Override
    public void onPublishStateChanged(@NonNull Core core, @NonNull Event linphoneEvent, PublishState state) {
        // Auto-generated method stub
    }

    @Override
    public void onPublishReceived(@NonNull Core core, @NonNull Event linphoneEvent, @NonNull String publishEvent, @Nullable Content body) {
        // Auto-generated method stub
    }

    @Override
    public void onConfiguringStatus(@NonNull Core core, ConfiguringState status, @Nullable String message) {
        // Auto-generated method stub
    }

    @Override
    public void onNetworkReachable(@NonNull Core core, boolean reachable) {
        // Auto-generated method stub
    }

    @Override
    public void onLogCollectionUploadStateChanged(@NonNull Core core, Core.LogCollectionUploadState state, @NonNull String info) {
        // Auto-generated method stub
    }

    @Override
    public void onLogCollectionUploadProgressIndication(@NonNull Core core, int offset, int total) {
        // Auto-generated method stub
    }

    @Override
    public void onFriendListCreated(@NonNull Core core, @NonNull FriendList friendList) {
        // Auto-generated method stub
    }

    @Override
    public void onFriendListRemoved(@NonNull Core core, @NonNull FriendList friendList) {
        // Auto-generated method stub
    }

    @Override
    public void onCallCreated(@NonNull Core core, @NonNull Call call) {
        // Auto-generated method stub
    }

    @Override
    public void onVersionUpdateCheckResultReceived(@NonNull Core core, @NonNull VersionUpdateCheckResult result, @Nullable String version, @Nullable String url) {
        // Auto-generated method stub
    }

    @Override
    public void onConferenceStateChanged(@NonNull Core core, @NonNull Conference conference, Conference.State state) {
        // Auto-generated method stub
    }

    @Override
    public void onChatRoomStateChanged(@NonNull Core core, @NonNull ChatRoom chatRoom, ChatRoom.State state) {
        // Auto-generated method stub
    }

    @Override
    public void onChatRoomSubjectChanged(@NonNull Core core, @NonNull ChatRoom chatRoom) {
        // Auto-generated method stub
    }

    @Override
    public void onChatRoomEphemeralMessageDeleted(@NonNull Core core, @NonNull ChatRoom chatRoom) {
        // Auto-generated method stub
    }

    @Override
    public void onImeeUserRegistration(@NonNull Core core, boolean status, @NonNull String userId, @NonNull String info) {
        // Auto-generated method stub
    }

    @Override
    public void onQrcodeFound(@NonNull Core core, @Nullable String result) {
        // Auto-generated method stub
    }

    @Override
    public void onFirstCallStarted(@NonNull Core core) {
        // Auto-generated method stub
    }

    @Override
    public void onLastCallEnded(@NonNull Core core) {
        // Auto-generated method stub
    }

    @Override
    public void onAudioDeviceChanged(@NonNull Core core, @NonNull AudioDevice audioDevice) {
        // Auto-generated method stub
    }

    @Override
    public void onAudioDevicesListUpdated(@NonNull Core core) {
        // Auto-generated method stub
    }

    @Override
    public void onEcCalibrationResult(@NonNull Core core, EcCalibratorStatus status, int delayMs) {
        // Auto-generated method stub
    }

    @Override
    public void onEcCalibrationAudioInit(@NonNull Core core) {
        // Auto-generated method stub
    }

    @Override
    public void onEcCalibrationAudioUninit(@NonNull Core core) {
        // Auto-generated method stub
    }

    @Override
    public void onAccountRegistrationStateChanged(@NonNull Core core, @NonNull Account account, RegistrationState state, @NonNull String message) {
        // Auto-generated method stub
    }

    @Override
    public void onDefaultAccountChanged(@NonNull Core core, @Nullable Account account) {
        // Auto-generated method stub
    }

    @Override
    public void onAccountAdded(@NonNull Core core, @NonNull Account account) {
        // Auto-generated method stub
    }

    @Override
    public void onAccountRemoved(@NonNull Core core, @NonNull Account account) {
        // Auto-generated method stub
    }

    @Override
    public void onMessageWaitingIndicationChanged(@NonNull Core core, @NonNull Event lev, @NonNull MessageWaitingIndication mwi) {
        // Auto-generated method stub
    }

    @Override
    public void onSnapshotTaken(@NonNull Core core, @NonNull String filePath) {
        // Auto-generated method stub
    }

    @Override
    public void onNewAlertTriggered(@NonNull Core core, @NonNull Alert alert) {
        // Auto-generated method stub
    }

}