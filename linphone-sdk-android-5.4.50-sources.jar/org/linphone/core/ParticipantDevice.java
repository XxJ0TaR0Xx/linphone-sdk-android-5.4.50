/*
ParticipantDevice.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* This object represents a unique device for a member of a {@link Conference} or<br/>
* {@link ChatRoom}. <br/>
* <br/>
* Devices are identified by the gruu parameter inside the {@link Address} which<br/>
* can be obtained by {@link #getAddress}. It is specially usefull to know the<br/>
* security level of each device inside an end-to-end encrypted {@link ChatRoom}.<br/>
* You can get a list of all {@link ParticipantDevice} using {@link Participant#getDevices}<br/>
* . <br/>
*/
public interface ParticipantDevice {
    public enum JoiningMethod {
        /**
        * device called the conference <br/>
        * <br/>
        */
        DialedIn(0),

        /**
        * device is called the conference <br/>
        * <br/>
        */
        DialedOut(1),

        /**
        * device is the focus <br/>
        * <br/>
        */
        FocusOwner(2);

        protected final int mValue;

        private JoiningMethod (int value) {
            mValue = value;
        }

        static public JoiningMethod fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return DialedIn;
            case 1: return DialedOut;
            case 2: return FocusOwner;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for JoiningMethod");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum DisconnectionMethod {
        /**
        * an admin removes the device from a conference <br/>
        * <br/>
        */
        Booted(0),

        /**
        * the device disconnects from the conference <br/>
        * <br/>
        */
        Departed(1),

        /**
        * device is busy <br/>
        * <br/>
        */
        Busy(2),

        /**
        * an error occurred while the device is leaving the conference or he declined a<br/>
        * call from the server <br/>
        * <br/>
        */
        Failed(3);

        protected final int mValue;

        private DisconnectionMethod (int value) {
            mValue = value;
        }

        static public DisconnectionMethod fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Booted;
            case 1: return Departed;
            case 2: return Busy;
            case 3: return Failed;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for DisconnectionMethod");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum State {
        /**
        * an INVITE has been sent <br/>
        * <br/>
        */
        Joining(0),

        /**
        * the SIP session has been concluded, participant is part of the conference <br/>
        * <br/>
        */
        Present(1),

        /**
        * A BYE is pending. <br/>
        * <br/>
        */
        Leaving(2),

        /**
        * The Session is terminated. <br/>
        * <br/>
        */
        Left(3),

        /**
        * Initial state for the server group chatroom, when the participant has not yet<br/>
        * been INVITEd. <br/>
        * <br/>
        */
        ScheduledForJoining(4),

        /**
        * Transitional state for a participant that will receive a BYE shortly. <br/>
        * <br/>
        */
        ScheduledForLeaving(5),

        /**
        * the SIP session has been concluded, participant is not media mixed <br/>
        * <br/>
        */
        OnHold(6),

        /**
        * 180 Ringing <br/>
        * <br/>
        */
        Alerting(7),

        /**
        * Some medias have been muted by the focus. <br/>
        * <br/>
        */
        MutedByFocus(8),

        /**
        * the participant has sent a request to join the conference as he/she didn't<br/>
        * receive any invitation for <br/>
        * <br/>
        */
        RequestingToJoin(9);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Joining;
            case 1: return Present;
            case 2: return Leaving;
            case 3: return Left;
            case 4: return ScheduledForJoining;
            case 5: return ScheduledForLeaving;
            case 6: return OnHold;
            case 7: return Alerting;
            case 8: return MutedByFocus;
            case 9: return RequestingToJoin;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Gets the address of a participant's device. <br/>
    * <br/>
    * @return The {@link Address} of the participant's device   <br/>
    */
    @NonNull
    public Address getAddress();

    /**
    * Gets the disconnection method. <br/>
    * <br/>
    * @return disconnection method {@link DisconnectionMethod} <br/>
    */
    public ParticipantDevice.DisconnectionMethod getDisconnectionMethod();

    /**
    * Gets the disconnection reason. <br/>
    * <br/>
    * @return disconnection reason   <br/>
    */
    @Nullable
    public String getDisconnectionReason();

    /**
    * Returns whether the participant device is in a conference or not. <br/>
    * <br/>
    * @return a boolean to state whether the device is in a conference <br/>
    */
    public boolean isInConference();

    /**
    * Returns whether the participant device is muted or not. <br/>
    * <br/>
    * @return true if the participant device is muted, false otherwise. <br/>
    */
    public boolean getIsMuted();

    /**
    * Returns whether the participant device is speaking or not. <br/>
    * <br/>
    * @return true if the participant device is speaking, false otherwise. <br/>
    */
    public boolean getIsSpeaking();

    /**
    * Gets the joining method or it the device is the focus owner. <br/>
    * <br/>
    * @return joining method or focus owner {@link JoiningMethod} <br/>
    */
    public ParticipantDevice.JoiningMethod getJoiningMethod();

    /**
    * Returns the name of the device. <br/>
    * <br/>
    * @return the name of the device or null.   <br/>
    */
    @Nullable
    public String getName();

    /**
    * Gets the native window ID where video for this participant device is to be<br/>
    * rendered. <br/>
    * <br/>
    * @return the window ID of the device   <br/>
    */
    @Nullable
    public Object getNativeVideoWindowId();

    /**
    * Sets the the native window ID where video for this participant device is to be<br/>
    * rendered. <br/>
    * <br/>
    * @param windowId the window ID of the device   <br/>
    */
    public void setNativeVideoWindowId(@Nullable Object windowId);

    /**
    * Returns the {@link Participant} this {@link ParticipantDevice} belongs to. <br/>
    * <br/>
    * @return the {@link Participant} this device belongs to   <br/>
    */
    @NonNull
    public Participant getParticipant();

    /**
    * Returns whether the participant device is screen sharing or not. <br/>
    * <br/>
    * @return true if the participant device is screen sharing, false otherwise. <br/>
    */
    public boolean isScreenSharingEnabled();

    /**
    * Gets the security level of a participant's device. <br/>
    * <br/>
    * @return The {@link ChatRoom#SecurityLevel} of the device <br/>
    */
    public ChatRoom.SecurityLevel getSecurityLevel();

    /**
    * Gets the state of a participant device. <br/>
    * <br/>
    * @return The {@link State} of the device <br/>
    */
    public ParticipantDevice.State getState();

    /**
    * Get the thumbnail stream SSRC of the device. <br/>
    * <br/>
    * @return the thumbnail stream's SSRC of the device <br/>
    */
    public int getThumbnailSsrc();

    /**
    * Gets the thumbnail stream availability of the device. <br/>
    * <br/>
    * The availability information represents whether a given stream type is<br/>
    * currently available to be presented in the conference for a {@link ParticipantDevice}<br/>
    * @return true if the stream of type stream_type is available for device, false<br/>
    * otherwise <br/>
    */
    public boolean getThumbnailStreamAvailability();

    /**
    * Gets the thumbnail stream capability of the device. <br/>
    * <br/>
    * @return the capability of the thumbnail stream of the device {@link MediaDirection}<br/>
    */
    public MediaDirection getThumbnailStreamCapability();

    /**
    * Gets the thumbnail stream label of the device. <br/>
    * <br/>
    * @return the label of the thumbnail stream of the device   <br/>
    */
    @Nullable
    public String getThumbnailStreamLabel();

    /**
    * Gets the timestamp the device left a conference. <br/>
    * <br/>
    * @return time of disconnection a conference as returned by time(nullptr). For<br/>
    * UNIX based systems it is the number of seconds since 00:00:00 of the 1st of<br/>
    * January 1970 <br/>
    */
    public long getTimeOfDisconnection();

    /**
    * Gets the timestamp the device joined a conference. <br/>
    * <br/>
    * @return time of joining a conference expressed as a number of seconds since<br/>
    * 00:00:00 of the 1st of January 1970 <br/>
    */
    public long getTimeOfJoining();

    /**
    * Creates a window ID and return it. <br/>
    * <br/>
    * see: {@link Core#setNativeVideoWindowId} for a general discussion about window<br/>
    * IDs.<br/>
    * A context can be used to prevent Linphone from allocating the container<br/>
    * (#MSOglContextInfo for MSOGL). null if not used.<br/>
    * @param context preallocated Window ID (Used only for MSOGL)   <br/>
    * @return the native video window id (type may vary depending on platform).   <br/>
    */
    @Nullable
    public Object createNativeVideoWindowId(@Nullable Object context);

    /**
    * Creates a window ID and return it. <br/>
    * <br/>
    * see: {@link Core#setNativeVideoWindowId} for a general discussion about window<br/>
    * IDs.<br/>
    * @return the native video window id (type may vary depending on platform).   <br/>
    */
    @Nullable
    public Object createNativeVideoWindowId();

    /**
    * Get the audio stream SSRC of the device. <br/>
    * <br/>
    * @param streamType A {@link StreamType} <br/>
    * @return the stream's SSRC of the device <br/>
    */
    public int getSsrc(StreamType streamType);

    /**
    * Gets the stream availability of the device. <br/>
    * <br/>
    * The availability information represents whether a given stream type is<br/>
    * currently available to be presented in the conference for a {@link ParticipantDevice}<br/>
    * @param streamType A {@link StreamType} <br/>
    * @return true if the stream of type stream_type is available for device, false<br/>
    * otherwise <br/>
    */
    public boolean getStreamAvailability(StreamType streamType);

    /**
    * Gets the stream capability of the device. <br/>
    * <br/>
    * The capability information represents the capability for the #ParticipantDevice<br/>
    * to handle a given stream type (audio, video or text). <br/>
    * @param streamType A {@link StreamType} <br/>
    * @return the capability of stream of type stream_type of the device {@link MediaDirection}<br/>
    */
    public MediaDirection getStreamCapability(StreamType streamType);

    /**
    * Gets the stream label of the device. <br/>
    * <br/>
    * The capability information represents the capability for the #ParticipantDevice<br/>
    * to handle a given stream type (audio, video or text). <br/>
    * @param streamType A {@link StreamType} <br/>
    * @return the label of stream of type stream_type of the device   <br/>
    */
    @Nullable
    public String getStreamLabel(StreamType streamType);

    /**
    */
    public void addListener(ParticipantDeviceListener listener);

    /**
    */
    public void removeListener(ParticipantDeviceListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ParticipantDeviceImpl implements ParticipantDevice {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ParticipantDeviceImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Address getAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getAddress()  {
        
        
        return (Address)getAddress(nativePtr);
    }

    private native int getDisconnectionMethod(long nativePtr);
    @Override
    synchronized public ParticipantDevice.DisconnectionMethod getDisconnectionMethod()  {
        
        
        return ParticipantDevice.DisconnectionMethod.fromInt(getDisconnectionMethod(nativePtr));
    }

    private native String getDisconnectionReason(long nativePtr);
    @Override @Nullable
    synchronized public String getDisconnectionReason()  {
        
        
        return getDisconnectionReason(nativePtr);
    }

    private native boolean isInConference(long nativePtr);
    @Override
    synchronized public boolean isInConference()  {
        
        
        return isInConference(nativePtr);
    }

    private native boolean getIsMuted(long nativePtr);
    @Override
    synchronized public boolean getIsMuted()  {
        
        
        return getIsMuted(nativePtr);
    }

    private native boolean getIsSpeaking(long nativePtr);
    @Override
    synchronized public boolean getIsSpeaking()  {
        
        
        return getIsSpeaking(nativePtr);
    }

    private native int getJoiningMethod(long nativePtr);
    @Override
    synchronized public ParticipantDevice.JoiningMethod getJoiningMethod()  {
        
        
        return ParticipantDevice.JoiningMethod.fromInt(getJoiningMethod(nativePtr));
    }

    private native String getName(long nativePtr);
    @Override @Nullable
    synchronized public String getName()  {
        
        
        return getName(nativePtr);
    }

    private native Object getNativeVideoWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object getNativeVideoWindowId()  {
        
        
        return getNativeVideoWindowId(nativePtr);
    }

    private native void setNativeVideoWindowId(long nativePtr, Object windowId);
    @Override
    synchronized public void setNativeVideoWindowId(@Nullable Object windowId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNativeVideoWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNativeVideoWindowId(nativePtr, windowId);
    }

    private native Participant getParticipant(long nativePtr);
    @Override @NonNull
    synchronized public Participant getParticipant()  {
        
        
        return (Participant)getParticipant(nativePtr);
    }

    private native boolean isScreenSharingEnabled(long nativePtr);
    @Override
    synchronized public boolean isScreenSharingEnabled()  {
        
        
        return isScreenSharingEnabled(nativePtr);
    }

    private native int getSecurityLevel(long nativePtr);
    @Override
    synchronized public ChatRoom.SecurityLevel getSecurityLevel()  {
        
        
        return ChatRoom.SecurityLevel.fromInt(getSecurityLevel(nativePtr));
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public ParticipantDevice.State getState()  {
        
        
        return ParticipantDevice.State.fromInt(getState(nativePtr));
    }

    private native int getThumbnailSsrc(long nativePtr);
    @Override
    synchronized public int getThumbnailSsrc()  {
        
        
        return getThumbnailSsrc(nativePtr);
    }

    private native boolean getThumbnailStreamAvailability(long nativePtr);
    @Override
    synchronized public boolean getThumbnailStreamAvailability()  {
        
        
        return getThumbnailStreamAvailability(nativePtr);
    }

    private native int getThumbnailStreamCapability(long nativePtr);
    @Override
    synchronized public MediaDirection getThumbnailStreamCapability()  {
        
        
        return MediaDirection.fromInt(getThumbnailStreamCapability(nativePtr));
    }

    private native String getThumbnailStreamLabel(long nativePtr);
    @Override @Nullable
    synchronized public String getThumbnailStreamLabel()  {
        
        
        return getThumbnailStreamLabel(nativePtr);
    }

    private native long getTimeOfDisconnection(long nativePtr);
    @Override
    synchronized public long getTimeOfDisconnection()  {
        
        
        return getTimeOfDisconnection(nativePtr);
    }

    private native long getTimeOfJoining(long nativePtr);
    @Override
    synchronized public long getTimeOfJoining()  {
        
        
        return getTimeOfJoining(nativePtr);
    }

    private native Object createNativeVideoWindowId2(long nativePtr, Object context);
    @Override @Nullable
    synchronized public Object createNativeVideoWindowId(@Nullable Object context)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createNativeVideoWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return createNativeVideoWindowId2(nativePtr, context);
    }

    private native Object createNativeVideoWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object createNativeVideoWindowId()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createNativeVideoWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return createNativeVideoWindowId(nativePtr);
    }

    private native int getSsrc(long nativePtr, int streamType);
    @Override
    synchronized public int getSsrc(StreamType streamType)  {
        
        
        return getSsrc(nativePtr, streamType.toInt());
    }

    private native boolean getStreamAvailability(long nativePtr, int streamType);
    @Override
    synchronized public boolean getStreamAvailability(StreamType streamType)  {
        
        
        return getStreamAvailability(nativePtr, streamType.toInt());
    }

    private native int getStreamCapability(long nativePtr, int streamType);
    @Override
    synchronized public MediaDirection getStreamCapability(StreamType streamType)  {
        
        
        return MediaDirection.fromInt(getStreamCapability(nativePtr, streamType.toInt()));
    }

    private native String getStreamLabel(long nativePtr, int streamType);
    @Override @Nullable
    synchronized public String getStreamLabel(StreamType streamType)  {
        
        
        return getStreamLabel(nativePtr, streamType.toInt());
    }

    private native void addListener(long nativePtr, ParticipantDeviceListener listener);
    @Override
    synchronized public void addListener(ParticipantDeviceListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, ParticipantDeviceListener listener);
    @Override
    synchronized public void removeListener(ParticipantDeviceListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
