/*
ChatRoomParams.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object defining parameters for a {@link ChatRoom}. <br/>
* <br/>
* Can be created with {@link Core#createDefaultChatRoomParams}. You can use<br/>
* {@link #isValid} to check if your configuration is valid or not.<br/>
* If the {@link ChatRoom} backend is {@link ChatRoom#Backend#Basic}, then no<br/>
* other parameter is required, but {@link ChatMessage} sent and received won't<br/>
* benefit from all features a {@link ChatRoom#Backend#FlexisipChat} can offer<br/>
* like conversation with multiple participants and a subject, end-to-end<br/>
* encryption, ephemeral messages, etc... but this type is the only one that can<br/>
* interoperate with other SIP clients or with non-flexisip SIP proxies. <br/>
*/
public interface ChatRoomParams {
    /**
    * Get the backend implementation of the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @return the {@link ChatRoom#Backend} <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#getBackend} instead. <br/>
    */
    @Deprecated
    public ChatRoom.Backend getBackend();

    /**
    * Set the backend implementation of these chat room parameters. <br/>
    * <br/>
    * @param backend The {@link ChatRoom#Backend} enum value <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#setBackend} instead. <br/>
    */
    @Deprecated
    public void setBackend(ChatRoom.Backend backend);

    /**
    * Get the encryption implementation of the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @return the {@link ChatRoom#EncryptionBackend} <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#getEncryptionBackend} instead. <br/>
    */
    @Deprecated
    public ChatRoom.EncryptionBackend getEncryptionBackend();

    /**
    * Set the encryption backend implementation of these chat room parameters. <br/>
    * <br/>
    * @param backend The {@link ChatRoom#EncryptionBackend} enum value <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#setEncryptionBackend} instead. <br/>
    */
    @Deprecated
    public void setEncryptionBackend(ChatRoom.EncryptionBackend backend);

    /**
    * Get the encryption status of the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @return true if encryption is enabled, false otherwise <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#encryptionEnabled} instead. <br/>
    */
    @Deprecated
    public boolean isEncryptionEnabled();

    /**
    * Enables or disables encryption for the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @param encrypted true to enable encryption, false to disable. <br/>
    * @deprecated 20/05/2024. Use linphone_conference_params_enable_encryption()<br/>
    * instead. <br/>
    */
    @Deprecated
    public void setEncryptionEnabled(boolean encrypted);

    /**
    * Get lifetime (in seconds) for all new ephemeral messages in the chat room. <br/>
    * <br/>
    * After the message is read, it will be deleted after "time" seconds. see:<br/>
    * linphone_chat_room_params_ephemeral_enabled() <br/>
    * @return the ephemeral lifetime (in seconds) <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#getEphemeralLifetime} instead. <br/>
    */
    @Deprecated
    public long getEphemeralLifetime();

    /**
    * Set lifetime (in seconds) for all new ephemral messages in the chat room. <br/>
    * <br/>
    * After the message is read, it will be deleted after "time" seconds. see:<br/>
    * linphone_chat_room_params_ephemeral_enabled() <br/>
    * @param time The ephemeral lifetime, default is disabled (0) <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#setEphemeralLifetime} instead. <br/>
    */
    @Deprecated
    public void setEphemeralLifetime(long time);

    /**
    * Get the ephemeral message mode of the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @return the ephemeral message mode {@link ChatRoom#EphemeralMode} <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#getEphemeralMode} instead. <br/>
    */
    @Deprecated
    public ChatRoom.EphemeralMode getEphemeralMode();

    /**
    * Enables or disables forcing of ephemeral messages for the chat room associated<br/>
    * with the given parameters. <br/>
    * <br/>
    * @param mode Ephemeral message mode {@link ChatRoom#EphemeralMode}. <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#setEphemeralMode} instead. <br/>
    */
    @Deprecated
    public void setEphemeralMode(ChatRoom.EphemeralMode mode);

    /**
    * Get the group chat status of the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @return true if group chat is enabled, false if one-to-one <br/>
    * @deprecated 20/05/2024. Use {@link ConferenceParams#groupEnabled} instead. <br/>
    */
    @Deprecated
    public boolean isGroupEnabled();

    /**
    * Enables or disables group chat for the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @param group true to enable group chat, false to disable (resulting in<br/>
    * one-to-one chat room) <br/>
    * @deprecated 20/05/2024. Use {@link ConferenceParams#enableGroup} instead. <br/>
    */
    @Deprecated
    public void setGroupEnabled(boolean group);

    /**
    * Returns whether the given parameters are valid or not. <br/>
    * <br/>
    * @return true if the given parameters are valid, false otherwise <br/>
    * @deprecated 20/05/2024. Use {@link ConferenceParams#isValid} instead. <br/>
    */
    @Deprecated
    public boolean isValid();

    /**
    * Get the real time text status of the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @return true if real time text is enabled, false otherwise <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#rttEnabled} instead. <br/>
    */
    @Deprecated
    public boolean isRttEnabled();

    /**
    * Enables or disables real time text for the chat room associated with the given<br/>
    * parameters. <br/>
    * <br/>
    * @param rtt true to enable real time text, false to disable. <br/>
    * @deprecated 20/05/2024. Use {@link ChatParams#enableRtt} instead. <br/>
    */
    @Deprecated
    public void setRttEnabled(boolean rtt);

    /**
    * Get the subject of the chat room. <br/>
    * <br/>
    * @return The subject.   <br/>
    * @deprecated 20/05/2024. Use {@link ConferenceParams#getSubject} instead. <br/>
    */
    @Deprecated
    @Nullable
    public String getSubject();

    /**
    * Set the subject of the chat room. <br/>
    * <br/>
    * @param subject The subject to set.   <br/>
    * @deprecated 20/05/2024. Use {@link ConferenceParams#setSubject} instead. <br/>
    */
    @Deprecated
    public void setSubject(@Nullable String subject);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ChatRoomParamsImpl implements ChatRoomParams {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ChatRoomParamsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getBackend(long nativePtr);
    @Override
    synchronized public ChatRoom.Backend getBackend()  {
        
        
        return ChatRoom.Backend.fromInt(getBackend(nativePtr));
    }

    private native void setBackend(long nativePtr, int backend);
    @Override
    synchronized public void setBackend(ChatRoom.Backend backend)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBackend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBackend(nativePtr, backend.toInt());
    }

    private native int getEncryptionBackend(long nativePtr);
    @Override
    synchronized public ChatRoom.EncryptionBackend getEncryptionBackend()  {
        
        
        return ChatRoom.EncryptionBackend.fromInt(getEncryptionBackend(nativePtr));
    }

    private native void setEncryptionBackend(long nativePtr, int backend);
    @Override
    synchronized public void setEncryptionBackend(ChatRoom.EncryptionBackend backend)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEncryptionBackend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEncryptionBackend(nativePtr, backend.toInt());
    }

    private native boolean isEncryptionEnabled(long nativePtr);
    @Override
    synchronized public boolean isEncryptionEnabled()  {
        
        
        return isEncryptionEnabled(nativePtr);
    }

    private native void setEncryptionEnabled(long nativePtr, boolean encrypted);
    @Override
    synchronized public void setEncryptionEnabled(boolean encrypted)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEncryptionEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEncryptionEnabled(nativePtr, encrypted);
    }

    private native long getEphemeralLifetime(long nativePtr);
    @Override
    synchronized public long getEphemeralLifetime()  {
        
        
        return getEphemeralLifetime(nativePtr);
    }

    private native void setEphemeralLifetime(long nativePtr, long time);
    @Override
    synchronized public void setEphemeralLifetime(long time)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEphemeralLifetime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEphemeralLifetime(nativePtr, time);
    }

    private native int getEphemeralMode(long nativePtr);
    @Override
    synchronized public ChatRoom.EphemeralMode getEphemeralMode()  {
        
        
        return ChatRoom.EphemeralMode.fromInt(getEphemeralMode(nativePtr));
    }

    private native void setEphemeralMode(long nativePtr, int mode);
    @Override
    synchronized public void setEphemeralMode(ChatRoom.EphemeralMode mode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEphemeralMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEphemeralMode(nativePtr, mode.toInt());
    }

    private native boolean isGroupEnabled(long nativePtr);
    @Override
    synchronized public boolean isGroupEnabled()  {
        
        
        return isGroupEnabled(nativePtr);
    }

    private native void setGroupEnabled(long nativePtr, boolean group);
    @Override
    synchronized public void setGroupEnabled(boolean group)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setGroupEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setGroupEnabled(nativePtr, group);
    }

    private native boolean isValid(long nativePtr);
    @Override
    synchronized public boolean isValid()  {
        
        
        return isValid(nativePtr);
    }

    private native boolean isRttEnabled(long nativePtr);
    @Override
    synchronized public boolean isRttEnabled()  {
        
        
        return isRttEnabled(nativePtr);
    }

    private native void setRttEnabled(long nativePtr, boolean rtt);
    @Override
    synchronized public void setRttEnabled(boolean rtt)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRttEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRttEnabled(nativePtr, rtt);
    }

    private native String getSubject(long nativePtr);
    @Override @Nullable
    synchronized public String getSubject()  {
        
        
        return getSubject(nativePtr);
    }

    private native void setSubject(long nativePtr, String subject);
    @Override
    synchronized public void setSubject(@Nullable String subject)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubject() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubject(nativePtr, subject);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
