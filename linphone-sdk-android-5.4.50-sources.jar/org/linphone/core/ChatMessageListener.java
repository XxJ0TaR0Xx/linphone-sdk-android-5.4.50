/*
ChatMessageListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for the handling a {@link ChatMessage}<br/>
* objects. <br/>
* <br/>
*/
public interface ChatMessageListener {
    /**
    * Call back used to notify message delivery status. <br/>
    * <br/>
    * @param message {@link ChatMessage} object   <br/>
    * @param state {@link ChatMessage#State} <br/>
    */
    public void onMsgStateChanged(@NonNull ChatMessage message, ChatMessage.State state);

    /**
    * Callback used to notify a reaction has been received or sent for a given<br/>
    * message. <br/>
    * <br/>
    * @param message LinphoneChatMessage object   <br/>
    * @param reaction the LinphoneChatMessageReaction reaction that was sent or<br/>
    * received   <br/>
    */
    public void onNewMessageReaction(@NonNull ChatMessage message, @NonNull ChatMessageReaction reaction);

    /**
    * Callback used to notify a reaction has been removed from a given message. <br/>
    * <br/>
    * @param message LinphoneChatMessage object   <br/>
    * @param address the LinphoneAddress of the person that removed it's reaction   <br/>
    */
    public void onReactionRemoved(@NonNull ChatMessage message, @NonNull Address address);

    /**
    * File transfer terminated callback prototype. <br/>
    * <br/>
    * @param message {@link ChatMessage} message from which the body is received.   <br/>
    * @param content {@link Content} incoming content information   <br/>
    */
    public void onFileTransferTerminated(@NonNull ChatMessage message, @NonNull Content content);

    /**
    * File transfer receive callback prototype. <br/>
    * <br/>
    * This function is called by the core upon an incoming File transfer is started.<br/>
    * This function may be call several time for the same file in case of large file. <br/>
    * @param message {@link ChatMessage} message from which the body is received.   <br/>
    * @param content {@link Content} incoming content information   <br/>
    * @param buffer {@link Buffer} holding the received data. Empty buffer means end<br/>
    * of file.   <br/>
    */
    public void onFileTransferRecv(@NonNull ChatMessage message, @NonNull Content content, @NonNull Buffer buffer);

    /**
    * File transfer send callback prototype. <br/>
    * <br/>
    * This function is called by the core when an outgoing file transfer is started.<br/>
    * This function is called until size is set to 0. <br/>
    * @param message {@link ChatMessage} message from which the body is received.   <br/>
    * @param content {@link Content} outgoing content   <br/>
    * @param offset the offset in the file from where to get the data to be sent <br/>
    * @param size the number of bytes expected by the framework <br/>
    * @return A {@link Buffer} object holding the data written by the application. An<br/>
    * empty buffer means end of file.    <br/>
    * warning: The returned value isn't used, hence the deprecation! <br/>
    * @deprecated 17/08/2020 Use LinphoneChatMessageCbsFileTransferSendChunkCb<br/>
    * instead. <br/>
    */
    public Buffer onFileTransferSend(@NonNull ChatMessage message, @NonNull Content content, int offset, int size);

    /**
    * File transfer send callback prototype. <br/>
    * <br/>
    * This function is called by the core when an outgoing file transfer is started.<br/>
    * This function is called until size is set to 0. <br/>
    * @param message {@link ChatMessage} message from which the body is received.   <br/>
    * @param content {@link Content} outgoing content   <br/>
    * @param offset the offset in the file from where to get the data to be sent <br/>
    * @param size the number of bytes expected by the framework <br/>
    * @param buffer A {@link Buffer} to be filled. Leave it empty when end of file<br/>
    * has been reached.   <br/>
    */
    public void onFileTransferSendChunk(@NonNull ChatMessage message, @NonNull Content content, int offset, int size, @NonNull Buffer buffer);

    /**
    * File transfer progress indication callback prototype. <br/>
    * <br/>
    * @param message {@link ChatMessage} message from which the body is received.   <br/>
    * @param content {@link Content} incoming content information   <br/>
    * @param offset The number of bytes sent/received since the beginning of the<br/>
    * transfer. <br/>
    * @param total The total number of bytes to be sent/received. <br/>
    */
    public void onFileTransferProgressIndication(@NonNull ChatMessage message, @NonNull Content content, int offset, int total);

    /**
    * Call back used to notify participant IMDN state. <br/>
    * <br/>
    * @param message {@link ChatMessage} object   <br/>
    * @param state {@link ParticipantImdnState}   <br/>
    */
    public void onParticipantImdnStateChanged(@NonNull ChatMessage message, @NonNull ParticipantImdnState state);

    /**
    * Callback used to notify an ephemeral message that its lifespan before<br/>
    * disappearing has started to decrease. <br/>
    * <br/>
    * This callback is called when the ephemeral message is read by the receiver. <br/>
    * @param message LinphoneChatMessage object   <br/>
    */
    public void onEphemeralMessageTimerStarted(@NonNull ChatMessage message);

    /**
    * Call back used to notify ephemeral message is deleted. <br/>
    * <br/>
    * @param message LinphoneChatMessage object   <br/>
    */
    public void onEphemeralMessageDeleted(@NonNull ChatMessage message);

}