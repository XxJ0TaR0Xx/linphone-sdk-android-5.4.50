/*
PresenceModel.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Presence model type holding information about the presence of a person. <br/>
* <br/>
*/
public interface PresenceModel {
    /**
    * Gets the first activity of a presence model (there is usually only one). <br/>
    * <br/>
    * @return A {@link PresenceActivity} object if successful, null otherwise.   <br/>
    */
    @Nullable
    public PresenceActivity getActivity();

    /**
    * Gets the basic status of a presence model. <br/>
    * <br/>
    * @return The {@link PresenceBasicStatus} of the {@link PresenceModel} object<br/>
    * given as parameter. <br/>
    */
    public PresenceBasicStatus getBasicStatus();

    /**
    * Sets the basic status of a presence model. <br/>
    * <br/>
    * @param basicStatus The {@link PresenceBasicStatus} to set for the {@link PresenceModel}<br/>
    * object. <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int setBasicStatus(PresenceBasicStatus basicStatus);

    /**
    * Gets the capabilities of a {@link PresenceModel} object. <br/>
    * <br/>
    * @return the capabilities. <br/>
    */
    public int getCapabilities();

    /**
    * Get the consolidated presence from a presence model. <br/>
    * <br/>
    * @return The {@link ConsolidatedPresence} corresponding to the presence model <br/>
    */
    public ConsolidatedPresence getConsolidatedPresence();

    /**
    * Gets the contact of a presence model. <br/>
    * <br/>
    * @return A pointer to a dynamically allocated string containing the contact, or<br/>
    * null if no contact is found.     <br/>
    * The returned string is to be freed by calling ms_free(). <br/>
    */
    @Nullable
    public String getContact();

    /**
    * Sets the contact of a presence model. <br/>
    * <br/>
    * @param contact The contact string to set.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int setContact(@Nullable String contact);

    /**
    * Tells whether a presence model is considered online. <br/>
    * <br/>
    * It is any of theses cases:<br/>
    */
    public boolean isOnline();

    /**
    * Gets the latest activity timestamp of a presence model. <br/>
    * <br/>
    * @return The activity timestamp of the {@link PresenceModel} object or -1 if<br/>
    * there is no activity (such as when status is Online). <br/>
    */
    public long getLatestActivityTimestamp();

    /**
    * Gets the number of activities included in the presence model. <br/>
    * <br/>
    * @return The number of activities included in the {@link PresenceModel} object. <br/>
    */
    public int getNbActivities();

    /**
    * Gets the number of persons included in the presence model. <br/>
    * <br/>
    * @return The number of persons included in the {@link PresenceModel} object. <br/>
    */
    public int getNbPersons();

    /**
    * Gets the number of services included in the presence model. <br/>
    * <br/>
    * @return The number of services included in the {@link PresenceModel} object. <br/>
    */
    public int getNbServices();

    /**
    * Gets the presentity of a presence model. <br/>
    * <br/>
    * @return A pointer to a const {@link Address}, or null if no contact is found.   <br/>
    */
    @Nullable
    public Address getPresentity();

    /**
    * Sets the presentity of a presence model. <br/>
    * <br/>
    * @param presentity The presentity address to set (presentity is copied).   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int setPresentity(@Nullable Address presentity);

    /**
    * Gets the timestamp of a presence model. <br/>
    * <br/>
    * @return The timestamp of the {@link PresenceModel} object or -1 on error. <br/>
    */
    public long getTimestamp();

    /**
    * Adds an activity to a presence model. <br/>
    * <br/>
    * @param activity The {@link PresenceActivity} object to add to the model.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int addActivity(@NonNull PresenceActivity activity);

    /**
    * Adds a note to a presence model. <br/>
    * <br/>
    * @param noteContent The note to be added to the presence model.   <br/>
    * @param lang The language of the note to be added. Can be null if no language is<br/>
    * to be specified for the note.    <br/>
    * @return 0 if successful, a value < 0 in case of error.<br/>
    * Only one note for each language can be set, so e.g. setting a note for the 'fr'<br/>
    * language if there is only one will replace the existing one. <br/>
    */
    public int addNote(@NonNull String noteContent, @Nullable String lang);

    /**
    * Adds a person to a presence model. <br/>
    * <br/>
    * @param person The {@link PresencePerson} object to add to the model.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int addPerson(@NonNull PresencePerson person);

    /**
    * Adds a service to a presence model. <br/>
    * <br/>
    * @param service The {@link PresenceService} object to add to the model.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int addService(@NonNull PresenceService service);

    /**
    * Clears the activities of a presence model. <br/>
    * <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int clearActivities();

    /**
    * Clears all the notes of a presence model. <br/>
    * <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int clearNotes();

    /**
    * Clears the persons of a presence model. <br/>
    * <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int clearPersons();

    /**
    * Clears the services of a presence model. <br/>
    * <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int clearServices();

    /**
    * Returns the version of the capability of a {@link PresenceModel}. <br/>
    * <br/>
    * @param capability The {@link Friend#Capability} to test. <br/>
    * @return the version of the capability of a {@link PresenceModel} or -1.0 if the<br/>
    * model has not the capability. <br/>
    */
    public float getCapabilityVersion(Friend.Capability capability);

    /**
    * Gets the first note of a presence model (there is usually only one). <br/>
    * <br/>
    * @param lang The language of the note to get. Can be null to get a note that has<br/>
    * no language specified or to get the first note whatever language it is written<br/>
    * into.   <br/>
    * @return A pointer to a {@link PresenceNote} object if successful, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public PresenceNote getNote(@Nullable String lang);

    /**
    * Gets the nth activity of a presence model. <br/>
    * <br/>
    * @param index The index of the activity to get (the first activity having the<br/>
    * index 0). <br/>
    * @return A pointer to a {@link PresenceActivity} object if successful, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public PresenceActivity getNthActivity(int index);

    /**
    * Gets the nth person of a presence model. <br/>
    * <br/>
    * @param index The index of the person to get (the first person having the index<br/>
    * 0). <br/>
    * @return A pointer to a {@link PresencePerson} object if successful, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public PresencePerson getNthPerson(int index);

    /**
    * Gets the nth service of a presence model. <br/>
    * <br/>
    * @param index The index of the service to get (the first service having the<br/>
    * index 0). <br/>
    * @return A pointer to a {@link PresenceService} object if successful, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public PresenceService getNthService(int index);

    /**
    * Returns whether or not the {@link PresenceModel} object has a given capability. <br/>
    * <br/>
    * @param capability The capability to test. <br/>
    * @return whether or not the {@link PresenceModel} object has a given capability. <br/>
    */
    public boolean hasCapability(Friend.Capability capability);

    /**
    * Returns whether or not the {@link PresenceModel} object has a given capability<br/>
    * with a certain version. <br/>
    * <br/>
    * @param capability The {@link Friend#Capability} to test. <br/>
    * @param version The wanted version to test. <br/>
    * @return whether or not the {@link PresenceModel} object has a given capability<br/>
    * with a certain version. <br/>
    */
    public boolean hasCapabilityWithVersion(Friend.Capability capability, float version);

    /**
    * Returns whether or not the {@link PresenceModel} object has a given capability<br/>
    * with a certain version or more. <br/>
    * <br/>
    * @param capability The {@link Friend#Capability} to test. <br/>
    * @param version The wanted version to test. <br/>
    * @return whether or not the {@link PresenceModel} object has a given capability<br/>
    * with a certain version or more. <br/>
    */
    public boolean hasCapabilityWithVersionOrMore(Friend.Capability capability, float version);

    /**
    * Sets the activity of a presence model (limits to only one activity). <br/>
    * <br/>
    * @param activity The {@link PresenceActivity#Type} to set for the model. <br/>
    * @param description An additional description of the activity to set for the<br/>
    * model. Can be null if no additional description is to be added.   <br/>
    * @return 0 if successful, a value < 0 in case of error.<br/>
    * WARNING: This function will modify the basic status of the model according to<br/>
    * the activity being set. If you don't want the basic status to be modified<br/>
    * automatically, you can use the combination of {@link #setBasicStatus}, {@link #clearActivities}<br/>
    * and {@link #addActivity}. <br/>
    */
    public int setActivity(PresenceActivity.Type activity, @Nullable String description);

    /**
    * Creates a presence model specifying an activity. <br/>
    * <br/>
    * @param activity The {@link PresenceActivity#Type} to set for the created<br/>
    * presence model. <br/>
    * @param description An additional description of the activity (mainly useful for<br/>
    * the 'other' activity). Set it to null to not add a description.   <br/>
    * @return The created {@link PresenceModel}, or null if an error occured.   <br/>
    * see: linphone_presence_model_new, {@link #newWithActivityAndNote}<br/>
    * The created presence model has the activity specified in the parameters. <br/>
    */
    @Nullable
    public PresenceModel newWithActivity(PresenceActivity.Type activity, @Nullable String description);

    /**
    * Creates a presence model specifying an activity and adding a note. <br/>
    * <br/>
    * @param activity The {@link PresenceActivity#Type} to set for the created<br/>
    * presence model. <br/>
    * @param description An additional description of the activity (mainly useful for<br/>
    * the 'other' activity). Set it to null to not add a description.   <br/>
    * @param note An additional note giving additional information about the contact<br/>
    * presence.   <br/>
    * @param lang The language the note is written in. It can be set to null in order<br/>
    * to not specify the language of the note.   <br/>
    * @return The created {@link PresenceModel}, or null if an error occured.   <br/>
    * see: {@link #newWithActivity}, {@link #newWithActivityAndNote}<br/>
    * The created presence model has the activity and the note specified in the<br/>
    * parameters. <br/>
    */
    @Nullable
    public PresenceModel newWithActivityAndNote(PresenceActivity.Type activity, @Nullable String description, @NonNull String note, @Nullable String lang);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class PresenceModelImpl implements PresenceModel {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected PresenceModelImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native PresenceActivity getActivity(long nativePtr);
    @Override @Nullable
    synchronized public PresenceActivity getActivity()  {
        
        
        return (PresenceActivity)getActivity(nativePtr);
    }

    private native int getBasicStatus(long nativePtr);
    @Override
    synchronized public PresenceBasicStatus getBasicStatus()  {
        
        
        return PresenceBasicStatus.fromInt(getBasicStatus(nativePtr));
    }

    private native int setBasicStatus(long nativePtr, int basicStatus);
    @Override
    synchronized public int setBasicStatus(PresenceBasicStatus basicStatus)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBasicStatus() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setBasicStatus(nativePtr, basicStatus.toInt());
    }

    private native int getCapabilities(long nativePtr);
    @Override
    synchronized public int getCapabilities()  {
        
        
        return getCapabilities(nativePtr);
    }

    private native int getConsolidatedPresence(long nativePtr);
    @Override
    synchronized public ConsolidatedPresence getConsolidatedPresence()  {
        
        
        return ConsolidatedPresence.fromInt(getConsolidatedPresence(nativePtr));
    }

    private native String getContact(long nativePtr);
    @Override @Nullable
    synchronized public String getContact()  {
        
        
        return getContact(nativePtr);
    }

    private native int setContact(long nativePtr, String contact);
    @Override
    synchronized public int setContact(@Nullable String contact)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setContact() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setContact(nativePtr, contact);
    }

    private native boolean isOnline(long nativePtr);
    @Override
    synchronized public boolean isOnline()  {
        
        
        return isOnline(nativePtr);
    }

    private native long getLatestActivityTimestamp(long nativePtr);
    @Override
    synchronized public long getLatestActivityTimestamp()  {
        
        
        return getLatestActivityTimestamp(nativePtr);
    }

    private native int getNbActivities(long nativePtr);
    @Override
    synchronized public int getNbActivities()  {
        
        
        return getNbActivities(nativePtr);
    }

    private native int getNbPersons(long nativePtr);
    @Override
    synchronized public int getNbPersons()  {
        
        
        return getNbPersons(nativePtr);
    }

    private native int getNbServices(long nativePtr);
    @Override
    synchronized public int getNbServices()  {
        
        
        return getNbServices(nativePtr);
    }

    private native Address getPresentity(long nativePtr);
    @Override @Nullable
    synchronized public Address getPresentity()  {
        
        
        return (Address)getPresentity(nativePtr);
    }

    private native int setPresentity(long nativePtr, Address presentity);
    @Override
    synchronized public int setPresentity(@Nullable Address presentity)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPresentity() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setPresentity(nativePtr, presentity);
    }

    private native long getTimestamp(long nativePtr);
    @Override
    synchronized public long getTimestamp()  {
        
        
        return getTimestamp(nativePtr);
    }

    private native int addActivity(long nativePtr, PresenceActivity activity);
    @Override
    synchronized public int addActivity(@NonNull PresenceActivity activity)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addActivity() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addActivity(nativePtr, activity);
    }

    private native int addNote(long nativePtr, String noteContent, String lang);
    @Override
    synchronized public int addNote(@NonNull String noteContent, @Nullable String lang)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addNote() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addNote(nativePtr, noteContent, lang);
    }

    private native int addPerson(long nativePtr, PresencePerson person);
    @Override
    synchronized public int addPerson(@NonNull PresencePerson person)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addPerson() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addPerson(nativePtr, person);
    }

    private native int addService(long nativePtr, PresenceService service);
    @Override
    synchronized public int addService(@NonNull PresenceService service)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addService() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addService(nativePtr, service);
    }

    private native int clearActivities(long nativePtr);
    @Override
    synchronized public int clearActivities()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearActivities() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return clearActivities(nativePtr);
    }

    private native int clearNotes(long nativePtr);
    @Override
    synchronized public int clearNotes()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearNotes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return clearNotes(nativePtr);
    }

    private native int clearPersons(long nativePtr);
    @Override
    synchronized public int clearPersons()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearPersons() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return clearPersons(nativePtr);
    }

    private native int clearServices(long nativePtr);
    @Override
    synchronized public int clearServices()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearServices() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return clearServices(nativePtr);
    }

    private native float getCapabilityVersion(long nativePtr, int capability);
    @Override
    synchronized public float getCapabilityVersion(Friend.Capability capability)  {
        
        
        return getCapabilityVersion(nativePtr, capability.toInt());
    }

    private native PresenceNote getNote(long nativePtr, String lang);
    @Override @Nullable
    synchronized public PresenceNote getNote(@Nullable String lang)  {
        
        
        return (PresenceNote)getNote(nativePtr, lang);
    }

    private native PresenceActivity getNthActivity(long nativePtr, int index);
    @Override @Nullable
    synchronized public PresenceActivity getNthActivity(int index)  {
        
        
        return (PresenceActivity)getNthActivity(nativePtr, index);
    }

    private native PresencePerson getNthPerson(long nativePtr, int index);
    @Override @Nullable
    synchronized public PresencePerson getNthPerson(int index)  {
        
        
        return (PresencePerson)getNthPerson(nativePtr, index);
    }

    private native PresenceService getNthService(long nativePtr, int index);
    @Override @Nullable
    synchronized public PresenceService getNthService(int index)  {
        
        
        return (PresenceService)getNthService(nativePtr, index);
    }

    private native boolean hasCapability(long nativePtr, int capability);
    @Override
    synchronized public boolean hasCapability(Friend.Capability capability)  {
        
        
        return hasCapability(nativePtr, capability.toInt());
    }

    private native boolean hasCapabilityWithVersion(long nativePtr, int capability, float version);
    @Override
    synchronized public boolean hasCapabilityWithVersion(Friend.Capability capability, float version)  {
        
        
        return hasCapabilityWithVersion(nativePtr, capability.toInt(), version);
    }

    private native boolean hasCapabilityWithVersionOrMore(long nativePtr, int capability, float version);
    @Override
    synchronized public boolean hasCapabilityWithVersionOrMore(Friend.Capability capability, float version)  {
        
        
        return hasCapabilityWithVersionOrMore(nativePtr, capability.toInt(), version);
    }

    private native int setActivity(long nativePtr, int activity, String description);
    @Override
    synchronized public int setActivity(PresenceActivity.Type activity, @Nullable String description)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setActivity() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setActivity(nativePtr, activity.toInt(), description);
    }

    private native PresenceModel newWithActivity(long nativePtr, int activity, String description);
    @Override @Nullable
    synchronized public PresenceModel newWithActivity(PresenceActivity.Type activity, @Nullable String description)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newWithActivity() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresenceModel)newWithActivity(nativePtr, activity.toInt(), description);
    }

    private native PresenceModel newWithActivityAndNote(long nativePtr, int activity, String description, String note, String lang);
    @Override @Nullable
    synchronized public PresenceModel newWithActivityAndNote(PresenceActivity.Type activity, @Nullable String description, @NonNull String note, @Nullable String lang)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newWithActivityAndNote() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresenceModel)newWithActivityAndNote(nativePtr, activity.toInt(), description, note, lang);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
