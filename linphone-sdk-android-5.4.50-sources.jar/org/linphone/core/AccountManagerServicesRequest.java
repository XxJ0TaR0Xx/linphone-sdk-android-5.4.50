/*
AccountManagerServicesRequest.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Request object created by {@link AccountManagerServices}. <br/>
* <br/>
*/
public interface AccountManagerServicesRequest {
    public enum Type {
        /**
        * Asks the account manager to send us an account creation token by push<br/>
        * notification. <br/>
        * <br/>
        */
        SendAccountCreationTokenByPush(0),

        /**
        * Asks the account manager to create a request token to be validated in a web<br/>
        * browser (captcha) and that can later be used to create an account creation<br/>
        * token. <br/>
        * <br/>
        */
        AccountCreationRequestToken(1),

        /**
        * Asks the account manager to consume the account creation request token to<br/>
        * create an account creation token. <br/>
        * <br/>
        */
        AccountCreationTokenFromAccountCreationRequestToken(2),

        /**
        * Uses an account creation token to create the account. <br/>
        * <br/>
        */
        CreateAccountUsingToken(3),

        /**
        * Asks for a code to be sent by SMS to a given phone number to link that phone<br/>
        * number with an account. <br/>
        * <br/>
        */
        SendPhoneNumberLinkingCodeBySms(4),

        /**
        * Uses the code received by SMS to confirm the link between an account and a<br/>
        * phone number. <br/>
        * <br/>
        */
        LinkPhoneNumberUsingCode(5),

        /**
        * Asks for a code to be sent by email to a given email address to link that<br/>
        * address with an account. <br/>
        * <br/>
        */
        SendEmailLinkingCodeByEmail(6),

        /**
        * Uses the code received by email to confirm the link between an account and an<br/>
        * email address. <br/>
        * <br/>
        */
        LinkEmailUsingCode(7),

        /**
        * Gets the list of devices for account. <br/>
        * <br/>
        */
        GetDevicesList(8),

        /**
        * Removes an account device. <br/>
        * <br/>
        */
        DeleteDevice(9),

        /**
        * <br/>
        */
        GetCreationTokenAsAdmin(100),

        /**
        * <br/>
        */
        GetAccountInfoAsAdmin(101),

        /**
        * <br/>
        */
        DeleteAccountAsAdmin(102);

        protected final int mValue;

        private Type (int value) {
            mValue = value;
        }

        static public Type fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return SendAccountCreationTokenByPush;
            case 1: return AccountCreationRequestToken;
            case 2: return AccountCreationTokenFromAccountCreationRequestToken;
            case 3: return CreateAccountUsingToken;
            case 4: return SendPhoneNumberLinkingCodeBySms;
            case 5: return LinkPhoneNumberUsingCode;
            case 6: return SendEmailLinkingCodeByEmail;
            case 7: return LinkEmailUsingCode;
            case 8: return GetDevicesList;
            case 9: return DeleteDevice;
            case 100: return GetCreationTokenAsAdmin;
            case 101: return GetAccountInfoAsAdmin;
            case 102: return DeleteAccountAsAdmin;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Type");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Gets the {@link Type} representing this request. <br/>
    * <br/>
    * @return the {@link Type}. <br/>
    */
    public AccountManagerServicesRequest.Type getType();

    /**
    * Executes the request represented by {@link AccountManagerServicesRequest}. <br/>
    * <br/>
    */
    public void submit();

    /**
    */
    public void addListener(AccountManagerServicesRequestListener listener);

    /**
    */
    public void removeListener(AccountManagerServicesRequestListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AccountManagerServicesRequestImpl implements AccountManagerServicesRequest {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AccountManagerServicesRequestImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public AccountManagerServicesRequest.Type getType()  {
        
        
        return AccountManagerServicesRequest.Type.fromInt(getType(nativePtr));
    }

    private native void submit(long nativePtr);
    @Override
    synchronized public void submit()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call submit() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        submit(nativePtr);
    }

    private native void addListener(long nativePtr, AccountManagerServicesRequestListener listener);
    @Override
    synchronized public void addListener(AccountManagerServicesRequestListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, AccountManagerServicesRequestListener listener);
    @Override
    synchronized public void removeListener(AccountManagerServicesRequestListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
