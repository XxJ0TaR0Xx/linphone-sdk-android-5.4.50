/*
MediaFileFormat.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum representing the file format of a recording. <br/>
* <br/>
*/
public enum MediaFileFormat {
    /**
    * <br/>
    */
    Unknown(0),

    /**
    * <br/>
    */
    Wav(1),

    /**
    * < WAVE file format, .wav file extension. <br/>
    * <br/>
    */
    Mkv(2),

    /**
    * < Standard Matroska file format, supports video, .mkv or .mka file extension. <br/>
    * <br/>
    * < Simple Multimedia File Format, a proprietary format that supports video,<br/>
    * .smff file extension. <br/>
    */
    Smff(3);

    protected final int mValue;

    private MediaFileFormat (int value) {
        mValue = value;
    }

    static public MediaFileFormat fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Unknown;
        case 1: return Wav;
        case 2: return Mkv;
        case 3: return Smff;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for MediaFileFormat");
        }
    }
    
    static protected MediaFileFormat[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        MediaFileFormat[] enumArray = new MediaFileFormat[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = MediaFileFormat.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(MediaFileFormat[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
