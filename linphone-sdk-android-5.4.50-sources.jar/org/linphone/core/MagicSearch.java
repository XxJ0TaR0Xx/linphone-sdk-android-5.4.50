/*
MagicSearch.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* A {@link MagicSearch} is used to search for contacts from various sources: <br/>
* <br/>
*/
public interface MagicSearch {
    public enum Aggregation {
        /**
        * No aggregation is done, you can have multiple SearchResult with the same<br/>
        * Friend. <br/>
        * <br/>
        */
        None(0),

        /**
        * Aggregation is done by friend, you will have at most a SearchResult per Friend. <br/>
        * <br/>
        */
        Friend(1);

        protected final int mValue;

        private Aggregation (int value) {
            mValue = value;
        }

        static public Aggregation fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1: return Friend;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Aggregation");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Source {
        /**
        * no Source specified. <br/>
        * <br/>
        * If requested in search, the list should be empty <br/>
        */
        None(0),

        /**
        * Search in friends only. <br/>
        * <br/>
        */
        Friends(1<<0),

        /**
        * Search in Call Logs. <br/>
        * <br/>
        */
        CallLogs(1<<1),

        /**
        * Search in LDAP servers. <br/>
        * <br/>
        */
        LdapServers(1<<2),

        /**
        * Search in Chat rooms participants. <br/>
        * <br/>
        */
        ChatRooms(1<<3),

        /**
        * Search from request : it is usually an address built from the request. <br/>
        * <br/>
        */
        Request(1<<4),

        /**
        * Search in "starred" friends only. <br/>
        * <br/>
        */
        FavoriteFriends(1<<5),

        /**
        * Search in conferences info (organizer and participants) <br/>
        * <br/>
        */
        ConferencesInfo(1<<6),

        /**
        * Search in remote CardDAV servers (not locally synched ones) if any. <br/>
        * <br/>
        */
        RemoteCardDAV(1<<7),

        /**
        * Search in all sources. <br/>
        * <br/>
        */
        All(-1);

        protected final int mValue;

        private Source (int value) {
            mValue = value;
        }

        static public Source fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1<<0: return Friends;
            case 1<<1: return CallLogs;
            case 1<<2: return LdapServers;
            case 1<<3: return ChatRooms;
            case 1<<4: return Request;
            case 1<<5: return FavoriteFriends;
            case 1<<6: return ConferencesInfo;
            case 1<<7: return RemoteCardDAV;
            case -1: return All;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Source");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Get the delimiter used for the search. <br/>
    * <br/>
    * @return the delimiter used to find matched filter word   <br/>
    */
    @Nullable
    public String getDelimiter();

    /**
    * Set the delimiter used to find matched filter word. <br/>
    * <br/>
    * @param delimiter delimiter (example "-_.,")   <br/>
    */
    public void setDelimiter(@Nullable String delimiter);

    /**
    * <br/>
    * @return sorted list of      <br/>
    */
    @NonNull
    public SearchResult[] getLastSearch();

    /**
    * Returns whether or not the search is limited or not. <br/>
    * <br/>
    * If not limited, the {@link #getSearchLimit} won't be applied. <br/>
    * @return true if the search is limited, false otherwise <br/>
    */
    public boolean getLimitedSearch();

    /**
    * Enables or disables the limited search. <br/>
    * <br/>
    * Even if configured as unlimited, the LDAP maxResults configuration parameter<br/>
    * still applies. <br/>
    * @param limited true to limit the search, false otherwise <br/>
    */
    public void setLimitedSearch(boolean limited);

    /**
    * Get the maximum value used to calculate the weight in search. <br/>
    * <br/>
    * @return the maximum value used to calculate the weight in search <br/>
    */
    public int getMaxWeight();

    /**
    * Set the maximum value used to calculate the weight in search. <br/>
    * <br/>
    * @param weight maximum weight <br/>
    */
    public void setMaxWeight(int weight);

    /**
    * Get the minimum value used to calculate the weight in search. <br/>
    * <br/>
    * @return the minimum value used to calculate the weight in search <br/>
    */
    public int getMinWeight();

    /**
    * Set the minimum value used to calculate the weight in search. <br/>
    * <br/>
    * @param weight minimum weight <br/>
    */
    public void setMinWeight(int weight);

    /**
    * Gets the number of maximum search result the search will return. <br/>
    * <br/>
    * The returned value doesn't take into account the "limited search" mode, so make<br/>
    * sure to check {@link #getLimitedSearch} result as well. <br/>
    * @return the number of the maximum {@link SearchResult} which will be returned<br/>
    * if magic search is in limited mode. <br/>
    */
    public int getSearchLimit();

    /**
    * Sets the number of the maximum SearchResult which will be returned, if the<br/>
    * magic search isn't configured as unlimited with {@link #setLimitedSearch}. <br/>
    * <br/>
    * @param limit the maximum number of {@link SearchResult} the search will return<br/>
    * if magic search is in limited mode. <br/>
    */
    public void setSearchLimit(int limit);

    /**
    * Returns whether the delimiter is being used for the search. <br/>
    * <br/>
    * @return if the delimiter search is used <br/>
    */
    public boolean getUseDelimiter();

    /**
    * Enable or disable the delimiter in search. <br/>
    * <br/>
    * @param enable true to use the delimiter, false otherwise <br/>
    */
    public void setUseDelimiter(boolean enable);

    /**
    * Create a sorted list of SearchResult which match with a filter word, from<br/>
    * SipUri in this order : Contact's display name, address username, address domain<br/>
    * and phone number. <br/>
    * <br/>
    * The last item list will be an address formed with "filter" if a proxy config<br/>
    * exist and requested in sourceFlags During the first search, a cache is created<br/>
    * and used for the next search Use {@link #resetSearchCache} to begin a new<br/>
    * search <br/>
    * @param filter word we search   <br/>
    * @param domain domain which we want to search only  <br/>
    * @param sourceFlags Flags that specify where to search : {@link Source} <br/>
    * @param aggregation a {@link Aggregation} mode to indicate how to merge results <br/>
    * @return sorted list of      <br/>
    */
    @NonNull
    public SearchResult[] getContactsList(@Nullable String filter, @Nullable String domain, int sourceFlags, MagicSearch.Aggregation aggregation);

    /**
    * This is the asynchronous version of linphone_magic_search_get_contacts(). <br/>
    * <br/>
    * Create a sorted list of SearchResult which match with a filter word, from<br/>
    * SipUri in this order : Contact's display name, address username, address domain<br/>
    * and phone number. The last item list will be an address formed with "filter" if<br/>
    * a proxy config exist and requested in sourceFlags During the first search, a<br/>
    * cache is created and used for the next search Use {@link #resetSearchCache} to<br/>
    * begin a new search <br/>
    * @param filter word we search   <br/>
    * @param domain domain which we want to search only  <br/>
    * @param sourceFlags Flags that specify where to search : {@link Source} <br/>
    * @param aggregation a {@link Aggregation} mode to indicate how to merge results <br/>
    */
    public void getContactsListAsync(@Nullable String filter, @Nullable String domain, int sourceFlags, MagicSearch.Aggregation aggregation);

    /**
    * Reset the cache to begin a new search. <br/>
    * <br/>
    */
    public void resetSearchCache();

    /**
    */
    public void addListener(MagicSearchListener listener);

    /**
    */
    public void removeListener(MagicSearchListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class MagicSearchImpl implements MagicSearch {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected MagicSearchImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getDelimiter(long nativePtr);
    @Override @Nullable
    synchronized public String getDelimiter()  {
        
        
        return getDelimiter(nativePtr);
    }

    private native void setDelimiter(long nativePtr, String delimiter);
    @Override
    synchronized public void setDelimiter(@Nullable String delimiter)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDelimiter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDelimiter(nativePtr, delimiter);
    }

    private native SearchResult[] getLastSearch(long nativePtr);
    @Override @NonNull
    synchronized public SearchResult[] getLastSearch()  {
        
        
        return getLastSearch(nativePtr);
    }

    private native boolean getLimitedSearch(long nativePtr);
    @Override
    synchronized public boolean getLimitedSearch()  {
        
        
        return getLimitedSearch(nativePtr);
    }

    private native void setLimitedSearch(long nativePtr, boolean limited);
    @Override
    synchronized public void setLimitedSearch(boolean limited)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLimitedSearch() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLimitedSearch(nativePtr, limited);
    }

    private native int getMaxWeight(long nativePtr);
    @Override
    synchronized public int getMaxWeight()  {
        
        
        return getMaxWeight(nativePtr);
    }

    private native void setMaxWeight(long nativePtr, int weight);
    @Override
    synchronized public void setMaxWeight(int weight)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMaxWeight() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMaxWeight(nativePtr, weight);
    }

    private native int getMinWeight(long nativePtr);
    @Override
    synchronized public int getMinWeight()  {
        
        
        return getMinWeight(nativePtr);
    }

    private native void setMinWeight(long nativePtr, int weight);
    @Override
    synchronized public void setMinWeight(int weight)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMinWeight() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMinWeight(nativePtr, weight);
    }

    private native int getSearchLimit(long nativePtr);
    @Override
    synchronized public int getSearchLimit()  {
        
        
        return getSearchLimit(nativePtr);
    }

    private native void setSearchLimit(long nativePtr, int limit);
    @Override
    synchronized public void setSearchLimit(int limit)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSearchLimit() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSearchLimit(nativePtr, limit);
    }

    private native boolean getUseDelimiter(long nativePtr);
    @Override
    synchronized public boolean getUseDelimiter()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUseDelimiter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUseDelimiter(nativePtr);
    }

    private native void setUseDelimiter(long nativePtr, boolean enable);
    @Override
    synchronized public void setUseDelimiter(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUseDelimiter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUseDelimiter(nativePtr, enable);
    }

    private native SearchResult[] getContactsList(long nativePtr, String filter, String domain, int sourceFlags, int aggregation);
    @Override @NonNull
    synchronized public SearchResult[] getContactsList(@Nullable String filter, @Nullable String domain, int sourceFlags, MagicSearch.Aggregation aggregation)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getContactsList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getContactsList(nativePtr, filter, domain, sourceFlags, aggregation.toInt());
    }

    private native void getContactsListAsync(long nativePtr, String filter, String domain, int sourceFlags, int aggregation);
    @Override
    synchronized public void getContactsListAsync(@Nullable String filter, @Nullable String domain, int sourceFlags, MagicSearch.Aggregation aggregation)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getContactsListAsync() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        getContactsListAsync(nativePtr, filter, domain, sourceFlags, aggregation.toInt());
    }

    private native void resetSearchCache(long nativePtr);
    @Override
    synchronized public void resetSearchCache()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call resetSearchCache() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        resetSearchCache(nativePtr);
    }

    private native void addListener(long nativePtr, MagicSearchListener listener);
    @Override
    synchronized public void addListener(MagicSearchListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, MagicSearchListener listener);
    @Override
    synchronized public void removeListener(MagicSearchListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
