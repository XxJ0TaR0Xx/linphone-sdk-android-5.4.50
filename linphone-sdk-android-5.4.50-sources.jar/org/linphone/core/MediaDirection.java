/*
MediaDirection.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Indicates for a given media the stream direction. <br/>
* <br/>
*/
public enum MediaDirection {
    /**
    * Default value, shouldn't be used. <br/>
    * <br/>
    */
    Invalid(-1),

    /**
    * No active media not supported yet. <br/>
    * <br/>
    */
    Inactive(0),

    /**
    * Media is only being sent, it won't be received. <br/>
    * <br/>
    */
    SendOnly(1),

    /**
    * Media will only be received, nothing will be sent. <br/>
    * <br/>
    */
    RecvOnly(2),

    /**
    * Media will be sent and received. <br/>
    * <br/>
    */
    SendRecv(3);

    protected final int mValue;

    private MediaDirection (int value) {
        mValue = value;
    }

    static public MediaDirection fromInt(int value) throws RuntimeException {
        switch(value) {
        case -1: return Invalid;
        case 0: return Inactive;
        case 1: return SendOnly;
        case 2: return RecvOnly;
        case 3: return SendRecv;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for MediaDirection");
        }
    }
    
    static protected MediaDirection[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        MediaDirection[] enumArray = new MediaDirection[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = MediaDirection.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(MediaDirection[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
