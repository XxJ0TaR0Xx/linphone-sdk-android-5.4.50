/*
FriendListListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for {@link Friend} synchronization. <br/>
* <br/>
*/
public interface FriendListListener {
    /**
    * Callback used to notify a new contact has been created on the CardDAV server<br/>
    * and downloaded locally. <br/>
    * <br/>
    * @param friendList The {@link FriendList} object the new contact is added to   <br/>
    * @param linphoneFriend The {@link Friend} object that has been created   <br/>
    */
    public void onContactCreated(@NonNull FriendList friendList, @NonNull Friend linphoneFriend);

    /**
    * Callback used to notify a contact has been deleted on the CardDAV server. <br/>
    * <br/>
    * @param friendList The {@link FriendList} object a contact has been removed from<br/>
    *   <br/>
    * @param linphoneFriend The {@link Friend} object that has been deleted   <br/>
    */
    public void onContactDeleted(@NonNull FriendList friendList, @NonNull Friend linphoneFriend);

    /**
    * Callback used to notify a contact has been updated on the CardDAV server. <br/>
    * <br/>
    * @param friendList The {@link FriendList} object in which a contact has been<br/>
    * updated   <br/>
    * @param newFriend The new {@link Friend} object corresponding to the updated<br/>
    * contact   <br/>
    * @param oldFriend The old {@link Friend} object before update   <br/>
    */
    public void onContactUpdated(@NonNull FriendList friendList, @NonNull Friend newFriend, @NonNull Friend oldFriend);

    /**
    * Callback used to notify the status of the synchronization has changed. <br/>
    * <br/>
    * @param friendList The {@link FriendList} object for which the status has<br/>
    * changed   <br/>
    * @param status The new {@link FriendList#SyncStatus} <br/>
    * @param message An additional information on the status update   <br/>
    */
    public void onSyncStatusChanged(@NonNull FriendList friendList, FriendList.SyncStatus status, @Nullable String message);

    /**
    * Callback used to notify a list with all friends that have received presence<br/>
    * information. <br/>
    * <br/>
    * @param friendList The LinphoneFriendList object for which the status has<br/>
    * changed   <br/>
    * @param friends A  of the relevant friends   <br/>
    */
    public void onPresenceReceived(@NonNull FriendList friendList, @NonNull Friend[] friends);

    /**
    * Callback used to notify a list that a new SIP address was discovered through<br/>
    * long term presence mechanism. <br/>
    * <br/>
    * @param friendList The {@link FriendList} object for which the status has<br/>
    * changed   <br/>
    * @param linphoneFriend The {@link Friend} for which the SIP address was<br/>
    * discovered   <br/>
    * @param sipUri The newly discovered SIP URI   <br/>
    */
    public void onNewSipAddressDiscovered(@NonNull FriendList friendList, @NonNull Friend linphoneFriend, @NonNull String sipUri);

}