/*
PayloadType.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object representing an RTP payload type. <br/>
* <br/>
*/
public interface PayloadType {
    /**
    * Get the number of channels. <br/>
    * <br/>
    * @return The number of channels. <br/>
    */
    public int getChannels();

    /**
    * Get the clock rate of a payload type. <br/>
    * <br/>
    * @return The clock rate in Hz. <br/>
    */
    public int getClockRate();

    /**
    * Return a string describing a payload type. <br/>
    * <br/>
    * The format of the string is <mime_type>/<clock_rate>/<channels>. <br/>
    * @return The description of the payload type.   <br/>
    */
    @NonNull
    public String getDescription();

    /**
    * Get a description of the encoder used to provide a payload type. <br/>
    * <br/>
    * @return The description of the encoder. Can be null if the payload type is not<br/>
    * supported by Mediastreamer2.   <br/>
    */
    @Nullable
    public String getEncoderDescription();

    /**
    * Check whether the payload is usable according the bandwidth targets set in the<br/>
    * core. <br/>
    * <br/>
    * @return true if the payload type is usable. <br/>
    */
    public boolean isUsable();

    /**
    * Tells whether the specified payload type represents a variable bitrate codec. <br/>
    * <br/>
    * @return true if the payload type represents a VBR codec, false instead. <br/>
    */
    public boolean isVbr();

    /**
    * Get the mime type. <br/>
    * <br/>
    * @return The mime type.   <br/>
    */
    @NonNull
    public String getMimeType();

    /**
    * Get the normal bitrate in bits/s. <br/>
    * <br/>
    * @return The normal bitrate in bits/s or -1 if an error has occured. <br/>
    */
    public int getNormalBitrate();

    /**
    * Change the normal bitrate of a payload type. <br/>
    * <br/>
    * @param bitrate The new bitrate in kbits/s. <br/>
    */
    public void setNormalBitrate(int bitrate);

    /**
    * Returns the payload type number assigned for this codec. <br/>
    * <br/>
    * @return The number of the payload type. <br/>
    */
    public int getNumber();

    /**
    * Force a number for a payload type. <br/>
    * <br/>
    * The {@link Core} does payload type number assignment automatically. This<br/>
    * function is mainly to be used for tests, in order to override the automatic<br/>
    * assignment mechanism. <br/>
    * @param number The number to assign to the payload type. <br/>
    */
    public void setNumber(int number);

    /**
    * Get the format parameters for incoming streams. <br/>
    * <br/>
    * @return The format parameters as string.   <br/>
    */
    @Nullable
    public String getRecvFmtp();

    /**
    * Set the format parameters for incoming streams. <br/>
    * <br/>
    * @param recvFmtp The new format parameters as string. The string will be copied.<br/>
    *   <br/>
    */
    public void setRecvFmtp(@Nullable String recvFmtp);

    /**
    * Get the format parameters for outgoing streams. <br/>
    * <br/>
    * @return The format parameters as string.   <br/>
    */
    @Nullable
    public String getSendFmtp();

    /**
    * Set the format parameters for outgoing streams. <br/>
    * <br/>
    * @param sendFmtp The new format parameters as string. The string will be copied.<br/>
    *   <br/>
    */
    public void setSendFmtp(@Nullable String sendFmtp);

    /**
    * Get the type of a payload type. <br/>
    * <br/>
    * @return The type of the payload e.g. PAYLOAD_AUDIO_CONTINUOUS or PAYLOAD_VIDEO. <br/>
    */
    public int getType();

    /**
    * Instantiates a new payload type with values from source. <br/>
    * <br/>
    * @return The newly created {@link PayloadType} object.   <br/>
    */
    @NonNull
    public PayloadType clone();

    /**
    * Enable/disable a payload type. <br/>
    * <br/>
    * @param enabled Set true for enabling and false for disabling. <br/>
    * @return 0 for success, -1 for failure. <br/>
    */
    public int enable(boolean enabled);

    /**
    * Check whether a palyoad type is enabled. <br/>
    * <br/>
    * @return true if enabled, false if disabled. <br/>
    */
    public boolean enabled();

    /**
    * Compare two payload types, and returns true if they are equal. <br/>
    * <br/>
    * Parameters (fmtp strings) are not compared, hence the name 'weak equals'. <br/>
    * @param otherPayloadType another {@link PayloadType} object   <br/>
    * @return true if the payload types are "almost" equals. <br/>
    */
    public boolean weakEquals(@NonNull PayloadType otherPayloadType);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class PayloadTypeImpl implements PayloadType {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected PayloadTypeImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getChannels(long nativePtr);
    @Override
    synchronized public int getChannels()  {
        
        
        return getChannels(nativePtr);
    }

    private native int getClockRate(long nativePtr);
    @Override
    synchronized public int getClockRate()  {
        
        
        return getClockRate(nativePtr);
    }

    private native String getDescription(long nativePtr);
    @Override @NonNull
    synchronized public String getDescription()  {
        
        
        return getDescription(nativePtr);
    }

    private native String getEncoderDescription(long nativePtr);
    @Override @Nullable
    synchronized public String getEncoderDescription()  {
        
        
        return getEncoderDescription(nativePtr);
    }

    private native boolean isUsable(long nativePtr);
    @Override
    synchronized public boolean isUsable()  {
        
        
        return isUsable(nativePtr);
    }

    private native boolean isVbr(long nativePtr);
    @Override
    synchronized public boolean isVbr()  {
        
        
        return isVbr(nativePtr);
    }

    private native String getMimeType(long nativePtr);
    @Override @NonNull
    synchronized public String getMimeType()  {
        
        
        return getMimeType(nativePtr);
    }

    private native int getNormalBitrate(long nativePtr);
    @Override
    synchronized public int getNormalBitrate()  {
        
        
        return getNormalBitrate(nativePtr);
    }

    private native void setNormalBitrate(long nativePtr, int bitrate);
    @Override
    synchronized public void setNormalBitrate(int bitrate)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNormalBitrate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNormalBitrate(nativePtr, bitrate);
    }

    private native int getNumber(long nativePtr);
    @Override
    synchronized public int getNumber()  {
        
        
        return getNumber(nativePtr);
    }

    private native void setNumber(long nativePtr, int number);
    @Override
    synchronized public void setNumber(int number)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNumber() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNumber(nativePtr, number);
    }

    private native String getRecvFmtp(long nativePtr);
    @Override @Nullable
    synchronized public String getRecvFmtp()  {
        
        
        return getRecvFmtp(nativePtr);
    }

    private native void setRecvFmtp(long nativePtr, String recvFmtp);
    @Override
    synchronized public void setRecvFmtp(@Nullable String recvFmtp)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRecvFmtp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRecvFmtp(nativePtr, recvFmtp);
    }

    private native String getSendFmtp(long nativePtr);
    @Override @Nullable
    synchronized public String getSendFmtp()  {
        
        
        return getSendFmtp(nativePtr);
    }

    private native void setSendFmtp(long nativePtr, String sendFmtp);
    @Override
    synchronized public void setSendFmtp(@Nullable String sendFmtp)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSendFmtp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSendFmtp(nativePtr, sendFmtp);
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public int getType()  {
        
        
        return getType(nativePtr);
    }

    private native PayloadType clone(long nativePtr);
    @Override @NonNull
    synchronized public PayloadType clone()  {
        
        
        return (PayloadType)clone(nativePtr);
    }

    private native int enable(long nativePtr, boolean enabled);
    @Override
    synchronized public int enable(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return enable(nativePtr, enabled);
    }

    private native boolean enabled(long nativePtr);
    @Override
    synchronized public boolean enabled()  {
        
        
        return enabled(nativePtr);
    }

    private native boolean weakEquals(long nativePtr, PayloadType otherPayloadType);
    @Override
    synchronized public boolean weakEquals(@NonNull PayloadType otherPayloadType)  {
        
        
        return weakEquals(nativePtr, otherPayloadType);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
