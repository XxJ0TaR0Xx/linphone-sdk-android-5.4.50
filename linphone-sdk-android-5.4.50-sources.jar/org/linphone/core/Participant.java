/*
Participant.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Identifies a member of a {@link Conference} or {@link ChatRoom}. <br/>
* <br/>
* A participant is identified by it's SIP address. It can have many {@link ParticipantDevice}<br/>
* . <br/>
*/
public interface Participant {
    public enum Role {
        /**
        * participant is a speaker in the conference <br/>
        * <br/>
        */
        Speaker(0),

        /**
        * participant is a listener in the conference. <br/>
        * <br/>
        * He/She cannot speak <br/>
        */
        Listener(1),

        /**
        * participant role is unknown <br/>
        * <br/>
        */
        Unknown(2);

        protected final int mValue;

        private Role (int value) {
            mValue = value;
        }

        static public Role fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Speaker;
            case 1: return Listener;
            case 2: return Unknown;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Role");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Get the address of a conference participant. <br/>
    * <br/>
    * @return The {@link Address} of the participant   <br/>
    */
    @NonNull
    public Address getAddress();

    /**
    * Get the timestamp of the creation of the participant. <br/>
    * <br/>
    * @return time of creation of the participant as returned by time(nullptr). For<br/>
    * UNIX based systems it is the number of seconds since 00:00hours of the 1st of<br/>
    * January 1970 <br/>
    */
    public long getCreationTime();

    /**
    * Gets the list of devices from a chat room's participant. <br/>
    * <br/>
    * @return List of devices.      <br/>
    */
    @NonNull
    public ParticipantDevice[] getDevices();

    /**
    * Tells whether a conference participant is an administrator of the conference. <br/>
    * <br/>
    * @return A boolean value telling whether the participant is an administrator <br/>
    */
    public boolean isAdmin();

    /**
    * Tells whether a conference participant is the focus of the conference. <br/>
    * <br/>
    * @return A boolean value telling whether the participant is a focus of a<br/>
    * conference <br/>
    */
    public boolean isFocus();

    /**
    * Get the role of the participant within the conference. <br/>
    * <br/>
    * @return role within the conference {@link Role} <br/>
    */
    public Participant.Role getRole();

    /**
    * Get the security level of a participant. <br/>
    * <br/>
    * @return The {@link ChatRoom#SecurityLevel} of the participant <br/>
    */
    public ChatRoom.SecurityLevel getSecurityLevel();

    /**
    * Find a device in the list of devices from a chat room's participant. <br/>
    * <br/>
    * @param call A {@link Call} object   <br/>
    * @return a {@link ParticipantDevice} or null if not found.   <br/>
    */
    @Nullable
    public ParticipantDevice findDevice(@NonNull Call call);

    /**
    * Find a device in the list of devices from a chat room's participant. <br/>
    * <br/>
    * @param address A {@link Address} object   <br/>
    * @return a {@link ParticipantDevice} or null if not found.   <br/>
    */
    @Nullable
    public ParticipantDevice findDevice(@NonNull Address address);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ParticipantImpl implements Participant {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ParticipantImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Address getAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getAddress()  {
        
        
        return (Address)getAddress(nativePtr);
    }

    private native long getCreationTime(long nativePtr);
    @Override
    synchronized public long getCreationTime()  {
        
        
        return getCreationTime(nativePtr);
    }

    private native ParticipantDevice[] getDevices(long nativePtr);
    @Override @NonNull
    synchronized public ParticipantDevice[] getDevices()  {
        
        
        return getDevices(nativePtr);
    }

    private native boolean isAdmin(long nativePtr);
    @Override
    synchronized public boolean isAdmin()  {
        
        
        return isAdmin(nativePtr);
    }

    private native boolean isFocus(long nativePtr);
    @Override
    synchronized public boolean isFocus()  {
        
        
        return isFocus(nativePtr);
    }

    private native int getRole(long nativePtr);
    @Override
    synchronized public Participant.Role getRole()  {
        
        
        return Participant.Role.fromInt(getRole(nativePtr));
    }

    private native int getSecurityLevel(long nativePtr);
    @Override
    synchronized public ChatRoom.SecurityLevel getSecurityLevel()  {
        
        
        return ChatRoom.SecurityLevel.fromInt(getSecurityLevel(nativePtr));
    }

    private native ParticipantDevice findDevice2(long nativePtr, Call call);
    @Override @Nullable
    synchronized public ParticipantDevice findDevice(@NonNull Call call)  {
        
        
        return (ParticipantDevice)findDevice2(nativePtr, call);
    }

    private native ParticipantDevice findDevice(long nativePtr, Address address);
    @Override @Nullable
    synchronized public ParticipantDevice findDevice(@NonNull Address address)  {
        
        
        return (ParticipantDevice)findDevice(nativePtr, address);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
