/*
PushNotificationConfig.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object holding push notification configuration that will be set in the contact<br/>
* URI parameters of the Contact header in the REGISTER, if the {@link AccountParams}<br/>
* is configured to allow push notifications, see {@link AccountParams#setPushNotificationAllowed}<br/>
* . <br/>
* <br/>
* This object can be accessed through the {@link AccountParams} object, which can<br/>
* be obtained from your {@link Account} object. <br/>
*/
public interface PushNotificationConfig {
    /**
    * Gets the app's bundle identifier for "contact uri parameter". <br/>
    * <br/>
    * @return The app's bundle identifier if set, null otherwise.   <br/>
    */
    @Nullable
    public String getBundleIdentifier();

    /**
    * Sets the bundle_identifier for "contact uri parameter". <br/>
    * <br/>
    * It's not necessary if param is set. See {@link #setParam}. <br/>
    * @param bundleIdentifier The new bundle_identifier set for push notification<br/>
    * config.   <br/>
    */
    public void setBundleIdentifier(@Nullable String bundleIdentifier);

    /**
    * Gets the call_snd for "contact uri parameter". <br/>
    * <br/>
    * @return The call_snd, default value "notes_of_the_optimistic.caf".   <br/>
    */
    @NonNull
    public String getCallSnd();

    /**
    * Sets the call_snd for "contact uri parameter", specific for remote push<br/>
    * notification. <br/>
    * <br/>
    * @param callSnd The new call_snd set for push notification config.   <br/>
    */
    public void setCallSnd(@NonNull String callSnd);

    /**
    * Gets the call_str for "contact uri parameter". <br/>
    * <br/>
    * @return The call_str, default value "IC_MSG".   <br/>
    */
    @NonNull
    public String getCallStr();

    /**
    * Sets the call_str for "contact uri parameter", specific for remote push<br/>
    * notification. <br/>
    * <br/>
    * @param callStr The new call_str set for push notification config.   <br/>
    */
    public void setCallStr(@NonNull String callStr);

    /**
    * Gets the groupchat_str for "contact uri parameter". <br/>
    * <br/>
    * @return The groupchat_str, default value "GC_MSG".   <br/>
    */
    @NonNull
    public String getGroupChatStr();

    /**
    * Sets the group_chat_str for "contact uri parameter", specific for remote push<br/>
    * notification. <br/>
    * <br/>
    * @param groupChatStr The new group_chat_str set for push notification config.   <br/>
    */
    public void setGroupChatStr(@NonNull String groupChatStr);

    /**
    * Gets the msg_snd for "contact uri parameter". <br/>
    * <br/>
    * @return The msg_snd, default value "msg.caf".   <br/>
    */
    @NonNull
    public String getMsgSnd();

    /**
    * Sets the msg_snd for "contact uri parameter", specific for remote push<br/>
    * notification. <br/>
    * <br/>
    * @param msgSnd The new msg_snd set for push notification config.   <br/>
    */
    public void setMsgSnd(@NonNull String msgSnd);

    /**
    * Gets the msg_str for "contact uri parameter". <br/>
    * <br/>
    * @return The msg_str, default value "IM_MSG".   <br/>
    */
    @NonNull
    public String getMsgStr();

    /**
    * Sets the msg_str for "contact uri parameter", specific for remote push<br/>
    * notification. <br/>
    * <br/>
    * @param msgStr The new msg_str set for push notification config.   <br/>
    */
    public void setMsgStr(@NonNull String msgStr);

    /**
    * Gets the param for "contact uri parameter". <br/>
    * <br/>
    * @return The param if set, null otherwise.   <br/>
    */
    @Nullable
    public String getParam();

    /**
    * Sets the param for "contact uri parameter". <br/>
    * <br/>
    * If it's not set, "team_id.bundle_identifier.services" will be used. <br/>
    * @param param The new param set for push notification config.   <br/>
    */
    public void setParam(@Nullable String param);

    /**
    * Gets the prid for "contact uri parameter". <br/>
    * <br/>
    * @return The prid if set, null otherwise.   <br/>
    */
    @Nullable
    public String getPrid();

    /**
    * Sets the prid for "contact uri parameter". <br/>
    * <br/>
    * If it's not set, "voip_token&remote_token" will be used. <br/>
    * @param prid The new prid set for push notification config.   <br/>
    */
    public void setPrid(@Nullable String prid);

    /**
    * Gets the provider for "contact uri parameter". <br/>
    * <br/>
    * @return The provider if set, null otherwise.   <br/>
    */
    @Nullable
    public String getProvider();

    /**
    * Sets the provider for "contact uri parameter". <br/>
    * <br/>
    * If not set, the default value will be used for "contact uri<br/>
    * parameter", "firebase" for android or "apns" for ios. <br/>
    * @param provider The new provider set for push notification config.   <br/>
    */
    public void setProvider(@Nullable String provider);

    /**
    * Specifies the interval in seconds between to subsequent remote push<br/>
    * notifications when remote push notifications are used to notify a call invite<br/>
    * to clients that haven't published any token for VoIP and background push<br/>
    * notifications. <br/>
    * <br/>
    * In that case, several PNs are sent subsequently until the call is picked up,<br/>
    * declined or canceled. This parameter sets a value for<br/>
    * 'pn-call-remote-push-interval' Contact header inside SIP REGISTER requests. A<br/>
    * value of zero will cause the deactivation of push notification repetitions and<br/>
    * the sending of the final notification. Thus, only the first push notification<br/>
    * will be sent. If specified the value must be in [0;30] If not specified<br/>
    * 'pn-call-remote-push-interval' will not be added to Contact header. <br/>
    * @param remotePushInterval The new remote push interval set for push<br/>
    * notification config.   <br/>
    */
    public void setRemotePushInterval(@NonNull String remotePushInterval);

    /**
    * Gets the remote token for "contact uri parameter". <br/>
    * <br/>
    * @return The remote token if set, null otherwise.   <br/>
    */
    @Nullable
    public String getRemoteToken();

    /**
    * Sets the remote_token for "contact uri parameter", specific for remote push<br/>
    * notification. <br/>
    * <br/>
    * It's not necessary if prid is set. See {@link #setPrid}. <br/>
    * @param remoteToken The new remote_token set for push notification config.   <br/>
    */
    public void setRemoteToken(@Nullable String remoteToken);

    /**
    * Gets the team id for "contact uri parameter". <br/>
    * <br/>
    * @return The team id if set, null otherwise.   <br/>
    */
    @Nullable
    public String getTeamId();

    /**
    * Sets the team id for "contact uri parameter". <br/>
    * <br/>
    * It's not necessary if param is set. See {@link #setParam}. <br/>
    * @param teamId The new team id set for push notification config.   <br/>
    */
    public void setTeamId(@Nullable String teamId);

    /**
    * Gets the voip token for "contact uri parameter". <br/>
    * <br/>
    * @return The voip token if set, null otherwise.   <br/>
    */
    @Nullable
    public String getVoipToken();

    /**
    * Sets the voip_token for "contact uri parameter", specific for voip push<br/>
    * notification. <br/>
    * <br/>
    * It's not necessary if prid is set. See {@link #setPrid}. <br/>
    * @param voipToken The new voip_token set for push notification config.   <br/>
    */
    public void setVoipToken(@Nullable String voipToken);

    /**
    * Instantiate a new push notification parameters with values from source. <br/>
    * <br/>
    * @return The newly created {@link PushNotificationConfig} object.   <br/>
    */
    @NonNull
    public PushNotificationConfig clone();

    /**
    * Checks if two Push Notification Configurations are identical. <br/>
    * <br/>
    * @param otherConfig The {@link PushNotificationConfig} object to compare to.   <br/>
    * @return True only if the two configurations are identical.   <br/>
    */
    @NonNull
    public boolean isEqual(@NonNull PushNotificationConfig otherConfig);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class PushNotificationConfigImpl implements PushNotificationConfig {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected PushNotificationConfigImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getBundleIdentifier(long nativePtr);
    @Override @Nullable
    synchronized public String getBundleIdentifier()  {
        
        
        return getBundleIdentifier(nativePtr);
    }

    private native void setBundleIdentifier(long nativePtr, String bundleIdentifier);
    @Override
    synchronized public void setBundleIdentifier(@Nullable String bundleIdentifier)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBundleIdentifier() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBundleIdentifier(nativePtr, bundleIdentifier);
    }

    private native String getCallSnd(long nativePtr);
    @Override @NonNull
    synchronized public String getCallSnd()  {
        
        
        return getCallSnd(nativePtr);
    }

    private native void setCallSnd(long nativePtr, String callSnd);
    @Override
    synchronized public void setCallSnd(@NonNull String callSnd)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCallSnd() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCallSnd(nativePtr, callSnd);
    }

    private native String getCallStr(long nativePtr);
    @Override @NonNull
    synchronized public String getCallStr()  {
        
        
        return getCallStr(nativePtr);
    }

    private native void setCallStr(long nativePtr, String callStr);
    @Override
    synchronized public void setCallStr(@NonNull String callStr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCallStr() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCallStr(nativePtr, callStr);
    }

    private native String getGroupChatStr(long nativePtr);
    @Override @NonNull
    synchronized public String getGroupChatStr()  {
        
        
        return getGroupChatStr(nativePtr);
    }

    private native void setGroupChatStr(long nativePtr, String groupChatStr);
    @Override
    synchronized public void setGroupChatStr(@NonNull String groupChatStr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setGroupChatStr() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setGroupChatStr(nativePtr, groupChatStr);
    }

    private native String getMsgSnd(long nativePtr);
    @Override @NonNull
    synchronized public String getMsgSnd()  {
        
        
        return getMsgSnd(nativePtr);
    }

    private native void setMsgSnd(long nativePtr, String msgSnd);
    @Override
    synchronized public void setMsgSnd(@NonNull String msgSnd)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMsgSnd() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMsgSnd(nativePtr, msgSnd);
    }

    private native String getMsgStr(long nativePtr);
    @Override @NonNull
    synchronized public String getMsgStr()  {
        
        
        return getMsgStr(nativePtr);
    }

    private native void setMsgStr(long nativePtr, String msgStr);
    @Override
    synchronized public void setMsgStr(@NonNull String msgStr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMsgStr() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMsgStr(nativePtr, msgStr);
    }

    private native String getParam(long nativePtr);
    @Override @Nullable
    synchronized public String getParam()  {
        
        
        return getParam(nativePtr);
    }

    private native void setParam(long nativePtr, String param);
    @Override
    synchronized public void setParam(@Nullable String param)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParam() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParam(nativePtr, param);
    }

    private native String getPrid(long nativePtr);
    @Override @Nullable
    synchronized public String getPrid()  {
        
        
        return getPrid(nativePtr);
    }

    private native void setPrid(long nativePtr, String prid);
    @Override
    synchronized public void setPrid(@Nullable String prid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPrid() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPrid(nativePtr, prid);
    }

    private native String getProvider(long nativePtr);
    @Override @Nullable
    synchronized public String getProvider()  {
        
        
        return getProvider(nativePtr);
    }

    private native void setProvider(long nativePtr, String provider);
    @Override
    synchronized public void setProvider(@Nullable String provider)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setProvider() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setProvider(nativePtr, provider);
    }

    private native void setRemotePushInterval(long nativePtr, String remotePushInterval);
    @Override
    synchronized public void setRemotePushInterval(@NonNull String remotePushInterval)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRemotePushInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRemotePushInterval(nativePtr, remotePushInterval);
    }

    private native String getRemoteToken(long nativePtr);
    @Override @Nullable
    synchronized public String getRemoteToken()  {
        
        
        return getRemoteToken(nativePtr);
    }

    private native void setRemoteToken(long nativePtr, String remoteToken);
    @Override
    synchronized public void setRemoteToken(@Nullable String remoteToken)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRemoteToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRemoteToken(nativePtr, remoteToken);
    }

    private native String getTeamId(long nativePtr);
    @Override @Nullable
    synchronized public String getTeamId()  {
        
        
        return getTeamId(nativePtr);
    }

    private native void setTeamId(long nativePtr, String teamId);
    @Override
    synchronized public void setTeamId(@Nullable String teamId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTeamId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTeamId(nativePtr, teamId);
    }

    private native String getVoipToken(long nativePtr);
    @Override @Nullable
    synchronized public String getVoipToken()  {
        
        
        return getVoipToken(nativePtr);
    }

    private native void setVoipToken(long nativePtr, String voipToken);
    @Override
    synchronized public void setVoipToken(@Nullable String voipToken)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVoipToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVoipToken(nativePtr, voipToken);
    }

    private native PushNotificationConfig clone(long nativePtr);
    @Override @NonNull
    synchronized public PushNotificationConfig clone()  {
        
        
        return (PushNotificationConfig)clone(nativePtr);
    }

    private native boolean isEqual(long nativePtr, PushNotificationConfig otherConfig);
    @Override @NonNull
    synchronized public boolean isEqual(@NonNull PushNotificationConfig otherConfig)  {
        
        
        return isEqual(nativePtr, otherConfig);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
