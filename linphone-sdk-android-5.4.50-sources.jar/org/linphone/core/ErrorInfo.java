/*
ErrorInfo.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object representing full details about a signaling error or status. <br/>
* <br/>
* All {@link ErrorInfo} object returned by the liblinphone API are readonly and<br/>
* transcients. For safety they must be used immediately after obtaining them. Any<br/>
* other function call to the liblinphone may change their content or invalidate<br/>
* the pointer. <br/>
*/
public interface ErrorInfo {
    /**
    * Get textual phrase from the error info. <br/>
    * <br/>
    * This is the text that is provided by the peer in the protocol (SIP). <br/>
    * @return The error phrase   <br/>
    */
    @Nullable
    public String getPhrase();

    /**
    * Assign phrase to a {@link ErrorInfo} object. <br/>
    * <br/>
    * @param phrase the phrase explaining the error   <br/>
    */
    public void setPhrase(@Nullable String phrase);

    /**
    * Get protocol from the error info. <br/>
    * <br/>
    * @return The protocol.   <br/>
    */
    @Nullable
    public String getProtocol();

    /**
    * Assign protocol name to a {@link ErrorInfo} object. <br/>
    * <br/>
    * @param protocol the protocol name   <br/>
    */
    public void setProtocol(@Nullable String protocol);

    /**
    * Get the status code from the low level protocol (ex a SIP status code). <br/>
    * <br/>
    * @return The status code <br/>
    */
    public int getProtocolCode();

    /**
    * Assign protocol code to a {@link ErrorInfo} object. <br/>
    * <br/>
    * @param code the protocol code <br/>
    */
    public void setProtocolCode(int code);

    /**
    * Get reason code from the error info. <br/>
    * <br/>
    * @return A {@link Reason} object <br/>
    */
    public Reason getReason();

    /**
    * Assign reason {@link Reason} to a {@link ErrorInfo} object. <br/>
    * <br/>
    * @param reason reason from {@link Reason} enum <br/>
    */
    public void setReason(Reason reason);

    /**
    * Get Retry-After delay second from the error info. <br/>
    * <br/>
    * @return The Retry-After delay second <br/>
    */
    public int getRetryAfter();

    /**
    * Assign retry-after value to a {@link ErrorInfo} object. <br/>
    * <br/>
    * @param retryAfter the retry-after value <br/>
    */
    public void setRetryAfter(int retryAfter);

    /**
    * Get pointer to chained {@link ErrorInfo} set in sub_ei. <br/>
    * <br/>
    * It corresponds to a Reason header in a received SIP response. <br/>
    * @return {@link ErrorInfo} pointer defined in the ei object.   <br/>
    */
    @Nullable
    public ErrorInfo getSubErrorInfo();

    /**
    * Set the sub_ei in {@link ErrorInfo} to another {@link ErrorInfo}. <br/>
    * <br/>
    * Used when a reason header is to be added in a SIP response. The first level<br/>
    * {@link ErrorInfo} defines the SIP response code and phrase, the second (sub)<br/>
    * #LinphoneErroInfo defining the content of the Reason header. <br/>
    * @param appendedErrorInfo {@link ErrorInfo} to append   <br/>
    */
    public void setSubErrorInfo(@Nullable ErrorInfo appendedErrorInfo);

    /**
    * Provides additional information regarding the failure. <br/>
    * <br/>
    * With SIP protocol, the content of "Warning" headers are returned. <br/>
    * @return More details about the failure.   <br/>
    */
    @Nullable
    public String getWarnings();

    /**
    * Assign warnings to a {@link ErrorInfo} object. <br/>
    * <br/>
    * @param warnings the warnings   <br/>
    */
    public void setWarnings(@Nullable String warnings);

    /**
    * Assign information to a {@link ErrorInfo} object. <br/>
    * <br/>
    * @param protocol protocol name   <br/>
    * @param reason reason from {@link Reason} enum <br/>
    * @param code protocol code <br/>
    * @param status description of the reason   <br/>
    * @param warning warning message   <br/>
    */
    public void set(@Nullable String protocol, Reason reason, int code, @Nullable String status, @Nullable String warning);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ErrorInfoImpl implements ErrorInfo {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ErrorInfoImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getPhrase(long nativePtr);
    @Override @Nullable
    synchronized public String getPhrase()  {
        
        
        return getPhrase(nativePtr);
    }

    private native void setPhrase(long nativePtr, String phrase);
    @Override
    synchronized public void setPhrase(@Nullable String phrase)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPhrase() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPhrase(nativePtr, phrase);
    }

    private native String getProtocol(long nativePtr);
    @Override @Nullable
    synchronized public String getProtocol()  {
        
        
        return getProtocol(nativePtr);
    }

    private native void setProtocol(long nativePtr, String protocol);
    @Override
    synchronized public void setProtocol(@Nullable String protocol)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setProtocol() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setProtocol(nativePtr, protocol);
    }

    private native int getProtocolCode(long nativePtr);
    @Override
    synchronized public int getProtocolCode()  {
        
        
        return getProtocolCode(nativePtr);
    }

    private native void setProtocolCode(long nativePtr, int code);
    @Override
    synchronized public void setProtocolCode(int code)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setProtocolCode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setProtocolCode(nativePtr, code);
    }

    private native int getReason(long nativePtr);
    @Override
    synchronized public Reason getReason()  {
        
        
        return Reason.fromInt(getReason(nativePtr));
    }

    private native void setReason(long nativePtr, int reason);
    @Override
    synchronized public void setReason(Reason reason)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setReason() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setReason(nativePtr, reason.toInt());
    }

    private native int getRetryAfter(long nativePtr);
    @Override
    synchronized public int getRetryAfter()  {
        
        
        return getRetryAfter(nativePtr);
    }

    private native void setRetryAfter(long nativePtr, int retryAfter);
    @Override
    synchronized public void setRetryAfter(int retryAfter)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRetryAfter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRetryAfter(nativePtr, retryAfter);
    }

    private native ErrorInfo getSubErrorInfo(long nativePtr);
    @Override @Nullable
    synchronized public ErrorInfo getSubErrorInfo()  {
        
        
        return (ErrorInfo)getSubErrorInfo(nativePtr);
    }

    private native void setSubErrorInfo(long nativePtr, ErrorInfo appendedErrorInfo);
    @Override
    synchronized public void setSubErrorInfo(@Nullable ErrorInfo appendedErrorInfo)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubErrorInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubErrorInfo(nativePtr, appendedErrorInfo);
    }

    private native String getWarnings(long nativePtr);
    @Override @Nullable
    synchronized public String getWarnings()  {
        
        
        return getWarnings(nativePtr);
    }

    private native void setWarnings(long nativePtr, String warnings);
    @Override
    synchronized public void setWarnings(@Nullable String warnings)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setWarnings() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setWarnings(nativePtr, warnings);
    }

    private native void set(long nativePtr, String protocol, int reason, int code, String status, String warning);
    @Override
    synchronized public void set(@Nullable String protocol, Reason reason, int code, @Nullable String status, @Nullable String warning)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call set() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        set(nativePtr, protocol, reason.toInt(), code, status, warning);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
