/*
TunnelConfig.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Tunnel settings. <br/>
* <br/>
*/
public interface TunnelConfig {
    /**
    * Get the UDP packet round trip delay in ms for a tunnel configuration. <br/>
    * <br/>
    * @return The UDP packet round trip delay in ms. <br/>
    */
    public int getDelay();

    /**
    * Set the UDP packet round trip delay in ms for a tunnel configuration. <br/>
    * <br/>
    * @param delay The UDP packet round trip delay in ms considered as acceptable<br/>
    * (recommended value is 1000 ms). <br/>
    */
    public void setDelay(int delay);

    /**
    * Get the IP address or hostname of the tunnel server. <br/>
    * <br/>
    * @return The tunnel server IP address or hostname.   <br/>
    */
    @Nullable
    public String getHost();

    /**
    * Set the IP address or hostname of the tunnel server. <br/>
    * <br/>
    * @param host The tunnel server IP address or hostname.   <br/>
    */
    public void setHost(@Nullable String host);

    /**
    * Get the IP address or hostname of the second tunnel server when using dual<br/>
    * tunnel client. <br/>
    * <br/>
    * @return The tunnel server IP address or hostname.   <br/>
    */
    @Nullable
    public String getHost2();

    /**
    * Set the IP address or hostname of the second tunnel server when using dual<br/>
    * tunnel client. <br/>
    * <br/>
    * @param host The tunnel server IP address or hostname.   <br/>
    */
    public void setHost2(@Nullable String host);

    /**
    * Get the TLS port of the tunnel server. <br/>
    * <br/>
    * @return The TLS port of the tunnel server <br/>
    */
    public int getPort();

    /**
    * Set tls port of server. <br/>
    * <br/>
    * @param port The tunnel server TLS port, recommended value is 443 <br/>
    */
    public void setPort(int port);

    /**
    * Get the TLS port of the second tunnel server when using dual tunnel client. <br/>
    * <br/>
    * @return The TLS port of the tunnel server <br/>
    */
    public int getPort2();

    /**
    * Set tls port of the second server when using dual tunnel client. <br/>
    * <br/>
    * @param port The tunnel server TLS port, recommended value is 443 <br/>
    */
    public void setPort2(int port);

    /**
    * Get the remote port on the tunnel server side used to test UDP reachability. <br/>
    * <br/>
    * This is used when the mode is set auto, to detect whether the tunnel has to be<br/>
    * enabled or not. <br/>
    * @return The remote port on the tunnel server side used to test UDP reachability <br/>
    */
    public int getRemoteUdpMirrorPort();

    /**
    * Set the remote port on the tunnel server side used to test UDP reachability. <br/>
    * <br/>
    * This is used when the mode is set auto, to detect whether the tunnel has to be<br/>
    * enabled or not. <br/>
    * @param remoteUdpMirrorPort The remote port on the tunnel server side used to<br/>
    * test UDP reachability, set to -1 to disable the feature <br/>
    */
    public void setRemoteUdpMirrorPort(int remoteUdpMirrorPort);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class TunnelConfigImpl implements TunnelConfig {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected TunnelConfigImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getDelay(long nativePtr);
    @Override
    synchronized public int getDelay()  {
        
        
        return getDelay(nativePtr);
    }

    private native void setDelay(long nativePtr, int delay);
    @Override
    synchronized public void setDelay(int delay)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDelay() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDelay(nativePtr, delay);
    }

    private native String getHost(long nativePtr);
    @Override @Nullable
    synchronized public String getHost()  {
        
        
        return getHost(nativePtr);
    }

    private native void setHost(long nativePtr, String host);
    @Override
    synchronized public void setHost(@Nullable String host)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHost() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHost(nativePtr, host);
    }

    private native String getHost22(long nativePtr);
    @Override @Nullable
    synchronized public String getHost2()  {
        
        
        return getHost22(nativePtr);
    }

    private native void setHost22(long nativePtr, String host);
    @Override
    synchronized public void setHost2(@Nullable String host)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHost2() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHost22(nativePtr, host);
    }

    private native int getPort(long nativePtr);
    @Override
    synchronized public int getPort()  {
        
        
        return getPort(nativePtr);
    }

    private native void setPort(long nativePtr, int port);
    @Override
    synchronized public void setPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPort(nativePtr, port);
    }

    private native int getPort22(long nativePtr);
    @Override
    synchronized public int getPort2()  {
        
        
        return getPort22(nativePtr);
    }

    private native void setPort22(long nativePtr, int port);
    @Override
    synchronized public void setPort2(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPort2() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPort22(nativePtr, port);
    }

    private native int getRemoteUdpMirrorPort(long nativePtr);
    @Override
    synchronized public int getRemoteUdpMirrorPort()  {
        
        
        return getRemoteUdpMirrorPort(nativePtr);
    }

    private native void setRemoteUdpMirrorPort(long nativePtr, int remoteUdpMirrorPort);
    @Override
    synchronized public void setRemoteUdpMirrorPort(int remoteUdpMirrorPort)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRemoteUdpMirrorPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRemoteUdpMirrorPort(nativePtr, remoteUdpMirrorPort);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
