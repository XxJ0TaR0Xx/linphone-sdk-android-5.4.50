/*
ChatRoomListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for the handling a {@link ChatRoom} objects. <br/>
* <br/>
* Use {@link Factory#createChatRoomCbs} to create an instance. Then pass the<br/>
* object to a {@link ChatRoom} instance through {@link ChatRoom#addListener}. <br/>
*/
public interface ChatRoomListener {
    /**
    * Is composing notification callback prototype. <br/>
    * <br/>
    * @param chatRoom LinphoneChatRoom involved in the conversation   <br/>
    * @param remoteAddress The LinphoneAddress that has sent the is-composing<br/>
    * notification   <br/>
    * @param isComposing A boolean value telling whether the remote is composing or<br/>
    * not <br/>
    */
    public void onIsComposingReceived(@NonNull ChatRoom chatRoom, @NonNull Address remoteAddress, boolean isComposing);

    /**
    * Callback used to notify a chat room that a message has been received. <br/>
    * <br/>
    * @param chatRoom LinphoneChatRoom object   <br/>
    * @param message The LinphoneChatMessage that has been received   <br/>
    */
    public void onMessageReceived(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message);

    /**
    * Callback used to notify a chat room that many chat messages have been received. <br/>
    * <br/>
    * Only called when aggregation is enabled (aka [sip] chat_messages_aggregation ==<br/>
    * 1 or using linphone_core_set_chat_messages_aggregation_enabled), it replaces<br/>
    * the single message received callback. <br/>
    * @param chatRoom LinphoneChatRoom object   <br/>
    * @param chatMessages The  list of events to be notified   <br/>
    */
    public void onMessagesReceived(@NonNull ChatRoom chatRoom, @NonNull ChatMessage[] chatMessages);

    /**
    * Callback used to notify a chat room that an event log has been created. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onNewEvent(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that many event logs have been created. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLogs The  list of events to be notified   <br/>
    */
    public void onNewEvents(@NonNull ChatRoom chatRoom, @NonNull EventLog[] eventLogs);

    /**
    * Callback used to notify a chat room that a chat message has been received. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onChatMessageReceived(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that one or many chat messages have been<br/>
    * received. <br/>
    * <br/>
    * Only called when aggregation is enabled (aka [sip] chat_messages_aggregation ==<br/>
    * 1 or using {@link Core#setChatMessagesAggregationEnabled}), it replaces the<br/>
    * single chat message received callback. <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLogs The  list of events to be notified   <br/>
    */
    public void onChatMessagesReceived(@NonNull ChatRoom chatRoom, @NonNull EventLog[] eventLogs);

    /**
    * Callback used to notify a chat room that a chat message is being sent. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onChatMessageSending(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that a chat message has been sent. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onChatMessageSent(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that a participant has been added. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onParticipantAdded(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that a participant has been removed. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onParticipantRemoved(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that the admin status of a participant has<br/>
    * been changed. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onParticipantAdminStatusChanged(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room state has changed. <br/>
    * <br/>
    * @param chatRoom LinphoneChatRoom object   <br/>
    * @param newState The new LinphoneChatRoomState of the chat room <br/>
    */
    public void onStateChanged(@NonNull ChatRoom chatRoom, ChatRoom.State newState);

    /**
    * Callback used to notify a security event in the chat room. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onSecurityEvent(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify that the subject of a chat room has changed. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onSubjectChanged(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that a message has been received but we<br/>
    * were unable to decrypt it. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} involved in this conversation   <br/>
    * @param message The {@link ChatMessage} that has been received   <br/>
    */
    public void onUndecryptableMessageReceived(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message);

    /**
    * Callback used to notify a chat room that a participant has been added. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onParticipantDeviceAdded(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that a participant has been removed. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onParticipantDeviceRemoved(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a conference that a participant device has changed<br/>
    * state. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    * @param state new participant device state <br/>
    */
    public void onParticipantDeviceStateChanged(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog, ParticipantDevice.State state);

    /**
    * Callback used to notify a conference that the media availability of a<br/>
    * participant device has been changed. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onParticipantDeviceMediaAvailabilityChanged(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room has been joined. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onConferenceJoined(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room has been left. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onConferenceLeft(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that an ephemeral related event has been<br/>
    * generated. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onEphemeralEvent(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that the lifespan of an ephemeral message<br/>
    * before disappearing has started to decrease. <br/>
    * <br/>
    * This callback is called when the ephemeral message is read by the receiver. <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onEphemeralMessageTimerStarted(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used to notify a chat room that an ephemeral message has been deleted. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param eventLog {@link EventLog} The event to be notified   <br/>
    */
    public void onEphemeralMessageDeleted(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog);

    /**
    * Callback used when a group chat room is created server-side to generate the<br/>
    * address of the chat room. <br/>
    * <br/>
    * The function {@link ChatRoom#setConferenceAddress} needs to be called by this<br/>
    * callback. <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    */
    public void onConferenceAddressGeneration(@NonNull ChatRoom chatRoom);

    /**
    * Callback used when a group chat room server is subscribing to registration<br/>
    * state of a participant. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param participantAddress {@link Address} object   <br/>
    */
    public void onParticipantRegistrationSubscriptionRequested(@NonNull ChatRoom chatRoom, @NonNull Address participantAddress);

    /**
    * Callback used when a group chat room server is unsubscribing to registration<br/>
    * state of a participant. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param participantAddress {@link Address} object   <br/>
    */
    public void onParticipantRegistrationUnsubscriptionRequested(@NonNull ChatRoom chatRoom, @NonNull Address participantAddress);

    /**
    * Callback used to tell the core whether or not to store the incoming message in<br/>
    * db or not using {@link ChatMessage#setToBeStored}. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param message The {@link ChatMessage} that is being received   <br/>
    */
    public void onChatMessageShouldBeStored(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message);

    /**
    * Callback used to notify a participant state has changed in a message of this<br/>
    * chat room. <br/>
    * <br/>
    * @param chatRoom {@link ChatRoom} object   <br/>
    * @param message The {@link ChatMessage} for which a participant has it's state<br/>
    * changed   <br/>
    * @param state The {@link ParticipantImdnState}   <br/>
    */
    public void onChatMessageParticipantImdnStateChanged(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message, @NonNull ParticipantImdnState state);

    /**
    * Callback used to notify a chat room was "marked as read". <br/>
    * <br/>
    * @param chatRoom The LinphoneChatRoom object that was marked as read   <br/>
    */
    public void onChatRoomRead(@NonNull ChatRoom chatRoom);

    /**
    * Callback used to notify a reaction has been received or sent for a given<br/>
    * message. <br/>
    * <br/>
    * @param chatRoom LinphoneChatRoom object   <br/>
    * @param message LinphoneChatMessage object for which we received a reaction   <br/>
    * @param reaction the LinphoneChatMessageReaction reaction that was sent or<br/>
    * received   <br/>
    */
    public void onNewMessageReaction(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message, @NonNull ChatMessageReaction reaction);

}