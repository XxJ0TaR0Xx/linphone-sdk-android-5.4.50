/*
ChatRoomListenerStub.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

public class ChatRoomListenerStub implements ChatRoomListener {
    @Override
    public void onIsComposingReceived(@NonNull ChatRoom chatRoom, @NonNull Address remoteAddress, boolean isComposing) {
        // Auto-generated method stub
    }

    @Override
    public void onMessageReceived(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message) {
        // Auto-generated method stub
    }

    @Override
    public void onMessagesReceived(@NonNull ChatRoom chatRoom, @NonNull ChatMessage[] chatMessages) {
        // Auto-generated method stub
    }

    @Override
    public void onNewEvent(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onNewEvents(@NonNull ChatRoom chatRoom, @NonNull EventLog[] eventLogs) {
        // Auto-generated method stub
    }

    @Override
    public void onChatMessageReceived(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onChatMessagesReceived(@NonNull ChatRoom chatRoom, @NonNull EventLog[] eventLogs) {
        // Auto-generated method stub
    }

    @Override
    public void onChatMessageSending(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onChatMessageSent(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantAdded(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantRemoved(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantAdminStatusChanged(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onStateChanged(@NonNull ChatRoom chatRoom, ChatRoom.State newState) {
        // Auto-generated method stub
    }

    @Override
    public void onSecurityEvent(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onSubjectChanged(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onUndecryptableMessageReceived(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceAdded(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceRemoved(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceStateChanged(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog, ParticipantDevice.State state) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceMediaAvailabilityChanged(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onConferenceJoined(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onConferenceLeft(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onEphemeralEvent(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onEphemeralMessageTimerStarted(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onEphemeralMessageDeleted(@NonNull ChatRoom chatRoom, @NonNull EventLog eventLog) {
        // Auto-generated method stub
    }

    @Override
    public void onConferenceAddressGeneration(@NonNull ChatRoom chatRoom) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantRegistrationSubscriptionRequested(@NonNull ChatRoom chatRoom, @NonNull Address participantAddress) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantRegistrationUnsubscriptionRequested(@NonNull ChatRoom chatRoom, @NonNull Address participantAddress) {
        // Auto-generated method stub
    }

    @Override
    public void onChatMessageShouldBeStored(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message) {
        // Auto-generated method stub
    }

    @Override
    public void onChatMessageParticipantImdnStateChanged(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message, @NonNull ParticipantImdnState state) {
        // Auto-generated method stub
    }

    @Override
    public void onChatRoomRead(@NonNull ChatRoom chatRoom) {
        // Auto-generated method stub
    }

    @Override
    public void onNewMessageReaction(@NonNull ChatRoom chatRoom, @NonNull ChatMessage message, @NonNull ChatMessageReaction reaction) {
        // Auto-generated method stub
    }

}