/*
Core.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Main object to instanciate and on which to keep a reference. <br/>
* <br/>
* This object is the first object to instanciante, and will allow you to perform<br/>
* all kind of tasks. To create it, use either {@link Factory#createCore} or<br/>
* {@link Factory#createCoreWithConfig}, see {@link Config} for more information<br/>
* about factory and default config. On some platforms like Android or iOS you<br/>
* will need to give it the Context of your application.<br/>
* Once the {@link Core} is in state {@link GlobalState#Ready}, use {@link #start}<br/>
* . It will then go to state {@link GlobalState#On} and from that you can start<br/>
* using it for calls and chat messages. It is recommended to add a {@link CoreListener}<br/>
* listener using {@link #addListener} to monitor different events.<br/>
* To be able to receive events from the network, you must schedule a call {@link #iterate}<br/>
* often, like every 20ms. On Android & iOS linphone_core_is_auto_iterate_enabled<br/>
* is enabled by default so you don't have to worry about that unless you disable<br/>
* it using {@link #enableAutoIterate} or by setting in the [misc] section of your<br/>
* configuration auto_iterate=0. warning: Our API isn't thread-safe but also isn't<br/>
* blocking, so it is strongly recommend to always call our methods from the main<br/>
* thread.<br/>
* Once you don't need it anymore, call {@link #stop} and release the reference on<br/>
* it so it can gracefully shutdown. <br/>
*/
public interface Core {
    public enum LogCollectionUploadState {
        /**
        * Delivery in progress. <br/>
        * <br/>
        */
        InProgress(0),

        /**
        * Log collection upload successfully delivered and acknowledged by remote end<br/>
        * point. <br/>
        * <br/>
        */
        Delivered(1),

        /**
        * Log collection upload was not delivered. <br/>
        * <br/>
        */
        NotDelivered(2);

        protected final int mValue;

        private LogCollectionUploadState (int value) {
            mValue = value;
        }

        static public LogCollectionUploadState fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return InProgress;
            case 1: return Delivered;
            case 2: return NotDelivered;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for LogCollectionUploadState");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
      * Gets the mediastreamer's factory
      */
    public org.linphone.mediastream.Factory getMediastreamerFactory();
    /**
    * Gets the {@link AccountCreator} backend set for the {@link Core}. <br/>
    * <br/>
    * @return The {@link AccountCreator#Backend} <br/>
    */
    public AccountCreator.Backend getAccountCreatorBackend();

    /**
    * Sets the {@link AccountCreator} backend on the {@link Core}. <br/>
    * <br/>
    * @param backend The {@link AccountCreator#Backend} <br/>
    */
    public void setAccountCreatorBackend(AccountCreator.Backend backend);

    /**
    * Gets the {@link AccountCreator} url on the {@link Core}. <br/>
    * <br/>
    * @return url The URL to reach.   <br/>
    */
    @Nullable
    public String getAccountCreatorUrl();

    /**
    * Sets the {@link AccountCreator} url on the {@link Core}. <br/>
    * <br/>
    * @param url The URL to reach   <br/>
    */
    public void setAccountCreatorUrl(@Nullable String url);

    /**
    * Returns an unmodifiable list of entered accounts. <br/>
    * <br/>
    * @return     <br/>
    */
    @NonNull
    public Account[] getAccountList();

    /**
    * Returns which adaptive rate algorithm is currently configured for future calls. <br/>
    * <br/>
    * see: {@link #setAdaptiveRateAlgorithm} <br/>
    * @return the adaptive rate algorithm. Currently two values are supported:<br/>
    * 'advanced', which is the default value, or 'basic'.   <br/>
    */
    @NonNull
    public String getAdaptiveRateAlgorithm();

    /**
    * Sets adaptive rate algorithm. <br/>
    * <br/>
    * It will be used for each new calls starting from now. Calls already started<br/>
    * will not be updated. <br/>
    * @param algorithm the adaptive rate control algorithm. Currently two values are<br/>
    * supported: 'advanced', which is the default value, or 'basic'.   <br/>
    */
    public void setAdaptiveRateAlgorithm(@NonNull String algorithm);

    /**
    * Returns whether adaptive rate control is enabled. <br/>
    * <br/>
    * see: {@link #enableAdaptiveRateControl}<br/>
    * @return true if adaptive rate control is enabled, false otherwise <br/>
    */
    public boolean isAdaptiveRateControlEnabled();

    /**
    * Enable adaptive rate control. <br/>
    * <br/>
    * Adaptive rate control consists in using RTCP feedback provided information to<br/>
    * dynamically control the output bitrate of the audio and video encoders, so that<br/>
    * we can adapt to the network conditions and available bandwidth. Control of the<br/>
    * audio encoder is done in case of audio-only call, and control of the video<br/>
    * encoder is done for audio & video calls. Adaptive rate control feature is<br/>
    * enabled by default.<br/>
    * @param enabled true to enable adaptive rate control, false otherwise <br/>
    */
    public void setAdaptiveRateControlEnabled(boolean enabled);

    /**
    * Tells whether the experimental software Automatic Gain Control is activated. <br/>
    * <br/>
    * This algorithm is very experimental, not usable in its current state. <br/>
    * @return true if the AGC is enabled, false otherwise. <br/>
    */
    public boolean isAgcEnabled();

    /**
    * Enables the experimental software Automatic Gain Control. <br/>
    * <br/>
    * This algorithm is very experimental, not usable in its current state. Automatic<br/>
    * Gain Control is usally provided by sound devices, typically on iOS and Android. <br/>
    * @param val a boolean value <br/>
    */
    public void setAgcEnabled(boolean val);

    /**
    * Returns whether alert reporting is enabled. <br/>
    * <br/>
    * See {@link Alert} for more details. <br/>
    * @return whether alert reporting is enabled. <br/>
    */
    public boolean isAlertsEnabled();

    /**
    * Enables alerts. <br/>
    * <br/>
    * See {@link Alert} for more details. <br/>
    * @param enable whether alert reporting is enabled or not. <br/>
    */
    public void setAlertsEnabled(boolean enable);

    /**
    * Tells whether the audio adaptive jitter compensation is enabled. <br/>
    * <br/>
    * @return true if the audio adaptive jitter compensation is enabled, false<br/>
    * otherwise. <br/>
    */
    public boolean isAudioAdaptiveJittcompEnabled();

    /**
    * Enables or disables the audio adaptive jitter compensation. <br/>
    * <br/>
    * It is enabled by default and should be disabled only to verify how<br/>
    * communication over IP is a disaster without jitter compensation. <br/>
    * @param enable true to enable the audio adaptive jitter compensation, false to<br/>
    * disable it. <br/>
    */
    public void setAudioAdaptiveJittcompEnabled(boolean enable);

    /**
    * Returns a list of audio devices, with only the first device for each type To<br/>
    * have the list of all audio devices, use {@link #getExtendedAudioDevices} <br/>
    * <br/>
    * @return   A list with the first {@link AudioDevice} of each type      <br/>
    */
    @NonNull
    public AudioDevice[] getAudioDevices();

    /**
    * Gets the DSCP field for outgoing audio streams. <br/>
    * <br/>
    * The DSCP defines the quality of service in IP packets. <br/>
    * @return The current DSCP value <br/>
    */
    public int getAudioDscp();

    /**
    * Sets the DSCP field for outgoing audio streams. <br/>
    * <br/>
    * The DSCP defines the quality of service in IP packets. note: It is usually<br/>
    * useless or a bad idea to try to play with DSCP bits unless having full control<br/>
    * on the network. <br/>
    * warning: Setting the DSCP bits is more or less well supported by operating<br/>
    * systems and sometimes requires to disable IPv6. <br/>
    * @param dscp The DSCP value to set <br/>
    */
    public void setAudioDscp(int dscp);

    /**
    * Returns the nominal audio jitter buffer size in milliseconds. <br/>
    * <br/>
    * @return The nominal audio jitter buffer size in milliseconds <br/>
    */
    public int getAudioJittcomp();

    /**
    * Sets the nominal audio jitter buffer size in milliseconds. <br/>
    * <br/>
    * The value takes effect immediately for all running and pending calls, if any. A<br/>
    * value of 0 disables the jitter buffer.<br/>
    * @param milliseconds the audio jitter buffer size to set in milliseconds <br/>
    */
    public void setAudioJittcomp(int milliseconds);

    /**
    * Use to get multicast address to be used for audio stream. <br/>
    * <br/>
    * @return an ipv4/6 multicast address or default value.   <br/>
    */
    @Nullable
    public String getAudioMulticastAddr();

    /**
    * Use to set multicast address to be used for audio stream. <br/>
    * <br/>
    * @param ip an ipv4/6 multicast address.   <br/>
    * @return 0 in case of success <br/>
    */
    public int setAudioMulticastAddr(@Nullable String ip);

    /**
    * Use to get multicast state of audio stream. <br/>
    * <br/>
    * @return true if subsequent calls will propose multicast ip set by {@link #setAudioMulticastAddr}<br/>
    */
    public boolean isAudioMulticastEnabled();

    /**
    * Use to enable multicast rtp for audio stream. <br/>
    * <br/>
    * If enabled, outgoing calls put a multicast address from {@link #getVideoMulticastAddr}<br/>
    * into audio cline. In case of outgoing call audio stream is sent to this<br/>
    * multicast address. For incoming calls behavior is unchanged. <br/>
    * @param yesno if yes, subsequent calls will propose multicast ip set by {@link #setAudioMulticastAddr}<br/>
    */
    public void setAudioMulticastEnabled(boolean yesno);

    /**
    * Use to get multicast ttl to be used for audio stream. <br/>
    * <br/>
    * @return a time to leave value <br/>
    */
    public int getAudioMulticastTtl();

    /**
    * Use to set multicast ttl to be used for audio stream. <br/>
    * <br/>
    * @param ttl value or -1 if not used. [0..255] default value is 1 <br/>
    * @return 0 in case of success <br/>
    */
    public int setAudioMulticastTtl(int ttl);

    /**
    * Returns the list of the available audio payload types. <br/>
    * <br/>
    * @return A freshly allocated list of the available payload types.       <br/>
    */
    @NonNull
    public PayloadType[] getAudioPayloadTypes();

    /**
    * Redefines the list of the available payload types (codecs). <br/>
    * <br/>
    * @param payloadTypes The new list of payload types.    <br/>
    */
    public void setAudioPayloadTypes(@Nullable PayloadType[] payloadTypes);

    /**
    * Gets the UDP port used for audio streaming. <br/>
    * <br/>
    * @return The UDP port used for audio streaming <br/>
    */
    public int getAudioPort();

    /**
    * Sets the UDP port used for audio streaming. <br/>
    * <br/>
    * A value of -1 will request the system to allocate the local port randomly. This<br/>
    * is recommended in order to avoid firewall warnings. <br/>
    * @param port The UDP port to use for audio streaming <br/>
    */
    public void setAudioPort(int port);

    /**
    * Get the audio port range from which is randomly chosen the UDP port used for<br/>
    * audio streaming. <br/>
    * <br/>
    * @return a {@link Range} object     <br/>
    */
    @NonNull
    public Range getAudioPortsRange();

    /**
    * Returns an unmodifiable list of currently entered {@link AuthInfo}. <br/>
    * <br/>
    * @return A list of {@link AuthInfo}.    <br/>
    */
    @NonNull
    public AuthInfo[] getAuthInfoList();

    /**
    * Gets if the automatic download of incoming icalendars is enabled or not. <br/>
    * <br/>
    * @return true if icalendars will be automatically downloaded, false otherwise. <br/>
    */
    public boolean isAutoDownloadIcalendarsEnabled();

    /**
    * Automatically downloads files attached to a chat message if it's content type<br/>
    * matches the one we use for icalendars. <br/>
    * <br/>
    * @param autoDownloadIcalendars true to automatically download incoming<br/>
    * icalendars, false to disable it. <br/>
    */
    public void setAutoDownloadIcalendarsEnabled(boolean autoDownloadIcalendars);

    /**
    * Gets if the auto download for incoming voice recordings is enabled or not. <br/>
    * <br/>
    * @return true if voice recordings will be automatically downloaded, false<br/>
    * otherwise. <br/>
    */
    public boolean isAutoDownloadVoiceRecordingsEnabled();

    /**
    * Enables automatic download of files attached to a chat message if it's content<br/>
    * type matches the one we use for voice recordings. <br/>
    * <br/>
    * @param autoDownloadVoiceRecordings true to automatically download incoming<br/>
    * voice recordings, false to disable it. <br/>
    */
    public void setAutoDownloadVoiceRecordingsEnabled(boolean autoDownloadVoiceRecordings);

    /**
    * Gets the timer used to schedule the call to core.iterate() method when in<br/>
    * background (Android only). <br/>
    * <br/>
    * This is only used when {@link #autoIterateEnabled} returns true. <br/>
    * @return The timing in milliseconds used to schedule the call while in<br/>
    * background (default is 500ms). <br/>
    */
    public int getAutoIterateBackgroundSchedule();

    /**
    * Sets the timer used to schedule the call to core.iterate() method when in<br/>
    * background (Android only). <br/>
    * <br/>
    * @param schedule The timing in milliseconds used to schedule the call while in<br/>
    * background. <br/>
    */
    public void setAutoIterateBackgroundSchedule(int schedule);

    /**
    * Gets whether auto iterate is enabled or not (Android & iOS only). <br/>
    * <br/>
    * @return true if {@link #iterate} is scheduled automatically, false otherwise <br/>
    */
    public boolean isAutoIterateEnabled();

    /**
    * Enable or disable the automatic schedule of {@link #iterate} method on Android<br/>
    * & iOS. <br/>
    * <br/>
    * If enabled, {@link #iterate} will be called on the main thread every 20ms<br/>
    * automatically. If disabled, it is the application that must do this job. <br/>
    * @param enable true to enable auto iterate, false to disable <br/>
    */
    public void setAutoIterateEnabled(boolean enable);

    /**
    * Gets the timer used to schedule the call to core.iterate() method when in<br/>
    * foreground (Android only). <br/>
    * <br/>
    * This is only used when {@link #autoIterateEnabled} returns true. <br/>
    * @return The timing in milliseconds used to schedule the call while in<br/>
    * foreground (default is 20ms). <br/>
    */
    public int getAutoIterateForegroundSchedule();

    /**
    * Sets the timer used to schedule the call to core.iterate() method when in<br/>
    * foreground (Android only). <br/>
    * <br/>
    * @param schedule The timing in milliseconds used to schedule the call while in<br/>
    * foreground. <br/>
    */
    public void setAutoIterateForegroundSchedule(int schedule);

    /**
    * Gets if the automatic sending of 180 Ringing is enabled or not. <br/>
    * <br/>
    * @return true if the automatic sending of 180 Ringing is enabled, false<br/>
    * otherwise. <br/>
    */
    public boolean isAutoSendRingingEnabled();

    /**
    * Enables the automatic sending of 180 Ringing when receiving a call. <br/>
    * <br/>
    * @param enable true to activate the automatic 180 Ringing, false to disable it. <br/>
    */
    public void setAutoSendRingingEnabled(boolean enable);

    /**
    * Returns whether automatic http proxy is enabled. <br/>
    * <br/>
    * @return true if automatic http proxy is enabled or false. <br/>
    */
    public boolean isAutomaticHttpProxyDetectionEnabled();

    /**
    * Enables or disables automatic http proxy detection. <br/>
    * <br/>
    * @param enable true if automatic http proxy is enabled or false. <br/>
    */
    public void setAutomaticHttpProxyDetectionEnabled(boolean enable);

    /**
    * Returns AVPF enablement. <br/>
    * <br/>
    * See {@link #setAvpfMode} . <br/>
    * @return The current {@link AVPFMode} mode <br/>
    */
    public AVPFMode getAvpfMode();

    /**
    * Enables RTCP feedback (also known as RTP/AVPF profile). <br/>
    * <br/>
    * Setting {@link AVPFMode#Default} is equivalent to LinphoneAVPFDisabled. This<br/>
    * setting can be overriden per {@link Account} with {@link AccountParams#setAvpfMode}<br/>
    * . The value set here is used for calls placed or received out of any account<br/>
    * configured, or if the account is configured with LinphoneAVPFDefault. <br/>
    * @param mode The AVPF mode to use. <br/>
    */
    public void setAvpfMode(AVPFMode mode);

    /**
    * Returns the avpf report interval in seconds. <br/>
    * <br/>
    * @return The current AVPF report interval in seconds <br/>
    */
    public int getAvpfRrInterval();

    /**
    * Sets the avpf report interval in seconds. <br/>
    * <br/>
    * This value can be overriden at Account level using<br/>
    * linphone_account_params__set_avpf_rr_interval(). <br/>
    * @param interval The report interval in seconds <br/>
    */
    public void setAvpfRrInterval(int interval);

    /**
    * Returns enablement of text sending via Baudot tones in the audio stream. <br/>
    * <br/>
    * @return true if text sending via Baudot tones in the audio stream is enabled,<br/>
    * false otherwise. <br/>
    */
    public boolean isBaudotEnabled();

    /**
    * Enable text sending via Baudot tones in the audio stream. <br/>
    * <br/>
    * It is disabled by default. Enablement requires a SDK built with full Baudot<br/>
    * support: -DENABLE_BAUDOT=ON . <br/>
    * @param enabled true if enabled, false otherwise. <br/>
    */
    public void setBaudotEnabled(boolean enabled);

    /**
    * Get the list of call logs (past calls). <br/>
    * <br/>
    * @return A list of {@link CallLog}.    <br/>
    */
    @NonNull
    public CallLog[] getCallLogs();

    /**
    * Gets the database filename where call logs will be stored. <br/>
    * <br/>
    * @return filesystem path.   <br/>
    * @deprecated 07/12/2021: Use only for migration purposes <br/>
    */
    @Deprecated
    @Nullable
    public String getCallLogsDatabasePath();

    /**
    * Sets the database filename where call logs will be stored. <br/>
    * <br/>
    * If the file does not exist, it will be created.<br/>
    * @param path filesystem path   <br/>
    * @deprecated 07/12/2021: Use only for migration purposes <br/>
    */
    @Deprecated
    public void setCallLogsDatabasePath(@Nullable String path);

    /**
    * Check whether tone indications of calls are enabled. <br/>
    * <br/>
    * @return true if call tone indications are enabled <br/>
    */
    public boolean isCallToneIndicationsEnabled();

    /**
    * Enables or disables call tone indications. <br/>
    * <br/>
    * This value is taken into account from next time call parameters are created.<br/>
    * This feature can also be enabled per-call using {@link CallParams}. <br/>
    * @param yesno a boolean to indicate whether the feature is to be enabled. <br/>
    */
    public void setCallToneIndicationsEnabled(boolean yesno);

    /**
    * Special function to check if the callkit is enabled, False by default. <br/>
    * <br/>
    * @return true if callkit is enabled, false otherwise. <br/>
    */
    public boolean isCallkitEnabled();

    /**
    * Special function to enable the callkit. <br/>
    * <br/>
    * @param enabled true to enable callkit, false to disable it. <br/>
    */
    public void setCallkitEnabled(boolean enabled);

    /**
    * Gets the current list of calls. <br/>
    * <br/>
    * Note that this list is read-only and might be changed by the core after a<br/>
    * function call to {@link #iterate}. Similarly the {@link Call} objects inside it<br/>
    * might be destroyed without prior notice. To hold references to {@link Call}<br/>
    * object into your program, you must use linphone_call_ref. <br/>
    * @return A list of {@link Call}    <br/>
    */
    @NonNull
    public Call[] getCalls();

    /**
    * Gets the number of Call. <br/>
    * <br/>
    * @return The current number of calls <br/>
    */
    public int getCallsNb();

    /**
    * Get the camera sensor rotation. <br/>
    * <br/>
    * This is needed on some mobile platforms to get the number of degrees the camera<br/>
    * sensor is rotated relative to the screen. <br/>
    * @return The camera sensor rotation in degrees (0 to 360) or -1 if it could not<br/>
    * be retrieved <br/>
    */
    public int getCameraSensorRotation();

    /**
    * Gets the whitebalance of the camera (currently only supported by Android). <br/>
    * <br/>
    * @return The whitebalance of the camera, default is -1 (disabled). <br/>
    */
    public int getCameraWhitebalance();

    /**
    * Sets the whitebalance of the camera (currently only supported by Android). <br/>
    * <br/>
    * @param whitebalance The whitebalance of the camera. <br/>
    */
    public int setCameraWhitebalance(int whitebalance);

    /**
    * Checks if the capability negotiation (RFC5939) is supported or not. <br/>
    * <br/>
    * @return true if capability negotiation is supported; false otherwise. <br/>
    */
    public boolean isCapabilityNegociationEnabled();

    /**
    * Defines whether capability negotiation (RFC5939) is supported. <br/>
    * <br/>
    * @param enable true to support RFC5939; false otherwise. <br/>
    */
    public void setCapabilityNegociationEnabled(boolean enable);

    /**
    * Checks if the capability negotiation (RFC5939) reINVITE is enabled or not. <br/>
    * <br/>
    * @return true if capability negotiation reINVITE is enabled; false otherwise. <br/>
    */
    public boolean isCapabilityNegotiationReinviteEnabled();

    /**
    * Defines whether capability negotiation (RFC5939) reINVITE is enabled. <br/>
    * <br/>
    * @param enable true to enable capability negotiation reINVITE; false otherwise. <br/>
    */
    public void setCapabilityNegotiationReinviteEnabled(boolean enable);

    /**
    * Gets the name of the currently assigned sound device for capture. <br/>
    * <br/>
    * @return The name of the currently assigned sound device for capture.   <br/>
    * @deprecated 11/09/2024 use {@link #getInputAudioDevice} or {@link #getDefaultInputAudioDevice}<br/>
    * instead.<br/>
    */
    @Deprecated
    @Nullable
    public String getCaptureDevice();

    /**
    * Sets the sound device used for capture. <br/>
    * <br/>
    * @param devid The device name as returned by linphone_core_get_sound_devices   <br/>
    * @return 0 <br/>
    * @deprecated 11/09/2024 use {@link #setInputAudioDevice} or {@link #setDefaultInputAudioDevice}<br/>
    * instead.<br/>
    */
    @Deprecated
    public int setCaptureDevice(@Nullable String devid);

    /**
    * Checks if cfg lines are going to the merged if the capability negotiation<br/>
    * (RFC5939) is supported or not. <br/>
    * <br/>
    * @return true if acfg and pcfg lines with consecutive indexes are going to be<br/>
    * merged; false otherwise. <br/>
    */
    public boolean isCfgLinesMergingEnabled();

    /**
    * Defines whether cfg lines are going to be merged if capability negotiation<br/>
    * (RFC5939) is supported. <br/>
    * <br/>
    * @param merge true to merge acfg and pcfg lines with consecutive indexes; false<br/>
    * otherwise. <br/>
    */
    public void setCfgLinesMergingEnabled(boolean merge);

    /**
    * Returns whether chat is enabled. <br/>
    * <br/>
    * @return true if chat is enabled, false otherwise <br/>
    */
    public boolean isChatEnabled();

    /**
    * End of group ldap. <br/>
    * <br/>
    * Returns whether chat messages grouping is enabled or not. <br/>
    * @return true if received chat messages will be notified as a bundle, false<br/>
    * otherwise. <br/>
    */
    public boolean getChatMessagesAggregationEnabled();

    /**
    * Sets whether chat messages grouping is enabled or not. <br/>
    * <br/>
    * This optimisation is turned on by default. It allows to receive bulks of<br/>
    * incoming message faster, and notify them to the application in a row. Set [sip]<br/>
    * chat_messages_aggregation in your configuration file for the timer, default is<br/>
    * 500ms. <br/>
    * @param enabled true to wait for chat messages and notify them as at once, false<br/>
    * to keep legacy behavior. <br/>
    */
    public void setChatMessagesAggregationEnabled(boolean enabled);

    /**
    * Returns a list of chat rooms. <br/>
    * <br/>
    * @return List of chat rooms.    <br/>
    */
    @NonNull
    public ChatRoom[] getChatRooms();

    /**
    * Gets the conference availability before start. <br/>
    * <br/>
    * @return the number of seconds the conference can be joined early<br/>
    * warning: This setting is only applicable to conference servers <br/>
    */
    public long getConferenceAvailabilityBeforeStart();

    /**
    * Set the conference availability before start. <br/>
    * <br/>
    * It is the number of seconds clients can join the conference before its actual<br/>
    * start time. <br/>
    * @param seconds number of seconds the conference can be joined early. A negative<br/>
    * value means always<br/>
    * warning: This setting is only applicable to conference servers <br/>
    */
    public void setConferenceAvailabilityBeforeStart(long seconds);

    /**
    * Gets the conference cleanup timer period. <br/>
    * <br/>
    * @return the period of the conference cleanup timer <br/>
    */
    public long getConferenceCleanupPeriod();

    /**
    * Set the conference cleanup timer period. <br/>
    * <br/>
    * This timer helps managing the automatic deletion of ended conferences. In fact,<br/>
    * under normal circumstances a conference is deleted only if it transition from<br/>
    * an active to an inactive state after its end time. Nonetheless a side effect is<br/>
    * that there may be a conference that never became active or it was terminate<br/>
    * before its due date and time. This timer, if setup, therefore periodically<br/>
    * looks for expired conference and cleans then up <br/>
    * @param seconds period of the timer. A 0 or negative value stops the timer <br/>
    */
    public void setConferenceCleanupPeriod(long seconds);

    /**
    * Gets the conference expire period. <br/>
    * <br/>
    * @return the number of second after which the conference cannot be joined<br/>
    * warning: This setting is only applicable to conference servers <br/>
    */
    public long getConferenceExpirePeriod();

    /**
    * Set the conference expire period. <br/>
    * <br/>
    * It is the number of seconds after the end time or the last participant joined -<br/>
    * whichever is later - the conference cannot be joined anymore <br/>
    * @param seconds number of seconds before the conference expires. A 0 or negative<br/>
    * value means immediately after the end<br/>
    * warning: This setting is only applicable to conference servers <br/>
    */
    public void setConferenceExpirePeriod(long seconds);

    /**
    * Gets wether conference invitations will be sent in the chat message body or as<br/>
    * a file attachment. <br/>
    * <br/>
    * @return true if ICS will be sent in the message body (by default), false if it<br/>
    * will be sent as a file attachment. <br/>
    */
    public boolean isConferenceIcsInMessageBodyEnabled();

    /**
    * Enable sending conference invitations in the chat message body instead of as a<br/>
    * file attachment. <br/>
    * <br/>
    * @param enable true to send ICS as message body, false to send it as file<br/>
    * transfer <br/>
    */
    public void setConferenceIcsInMessageBodyEnabled(boolean enable);

    /**
    * Retrieve the list of conference information on DB. <br/>
    * <br/>
    * @return The list of conference infos .     <br/>
    */
    @NonNull
    public ConferenceInfo[] getConferenceInformationList();

    /**
    * Returns the input volume of the local participant. <br/>
    * <br/>
    * @return A value inside [0.0 ; 1.0] <br/>
    * @deprecated 23/01/2025 Use {@link Conference#getInputVolume} instead. <br/>
    */
    @Deprecated
    public float getConferenceLocalInputVolume();

    /**
    * Gets the maximum number of thumbnails requested in the SDP during a conference<br/>
    * call {@link Account#getCallLogs}. <br/>
    * <br/>
    * @return the maximum number of thumbnails requested in the SDP during a<br/>
    * conference call <br/>
    */
    public int getConferenceMaxThumbnails();

    /**
    * Sets the maximum number of thumbnails requested in the SDP during a conference<br/>
    * call. <br/>
    * <br/>
    * @param max the maximum number of thumbnails requested in the SDP during a<br/>
    * conference call <br/>
    */
    public void setConferenceMaxThumbnails(int max);

    /**
    * Tells whether the default conference participant list is open or closed. <br/>
    * <br/>
    * @return A {@link Conference#ParticipantListType} participant list type <br/>
    */
    public Conference.ParticipantListType getConferenceParticipantListType();

    /**
    * Selects whether the default conference participant list is open or closed. <br/>
    * <br/>
    * @param type A {@link Conference#ParticipantListType} participant list type <br/>
    */
    public void setConferenceParticipantListType(Conference.ParticipantListType type);

    /**
    * Tells whether the conference server feature is enabled. <br/>
    * <br/>
    * @return A boolean value telling whether the conference server feature is<br/>
    * enabled or not <br/>
    */
    public boolean isConferenceServerEnabled();

    /**
    * Enables the conference server mode. <br/>
    * <br/>
    * This has the effect to listen of the conference factory uri to create new<br/>
    * conferences when receiving INVITE messages there. Enabling this mode is<br/>
    * required when using liblinphone in a conference server application, but shall<br/>
    * not be be employed in any client application. <br/>
    * @param enable A boolean value telling whether to enable or disable the<br/>
    * conference server feature <br/>
    */
    public void setConferenceServerEnabled(boolean enable);

    /**
    * Returns the config object used to manage the storage (config) file. <br/>
    * <br/>
    * @return a {@link Config} object.   <br/>
    */
    @NonNull
    public Config getConfig();

    /**
    * Gets my consolidated presence. <br/>
    * <br/>
    * @return My {@link ConsolidatedPresence} presence <br/>
    */
    public ConsolidatedPresence getConsolidatedPresence();

    /**
    * Sets my consolidated presence. <br/>
    * <br/>
    * @param presence {@link ConsolidatedPresence} value <br/>
    */
    public void setConsolidatedPresence(ConsolidatedPresence presence);

    /**
    * Gets the current call. <br/>
    * <br/>
    * The current call is defined as follows: If multiple concurrent calls exist, it<br/>
    * is the only one that currelty uses the microphone or speaker, otherwise it is<br/>
    * the unique call that exists unless this call is in {@link Call#State#Paused}<br/>
    * state. <br/>
    * @return The current call or null if no call is running.   <br/>
    */
    @Nullable
    public Call getCurrentCall();

    /**
    * Gets the remote address of the current call. <br/>
    * <br/>
    * @return The remote address of the current call or null if there is no current<br/>
    * call.   <br/>
    */
    @Nullable
    public Address getCurrentCallRemoteAddress();

    /**
    * Get the effective video definition provided by the camera for the captured<br/>
    * video. <br/>
    * <br/>
    * When preview is disabled or not yet started this function returns a 0x0 video<br/>
    * definition. <br/>
    * @return The captured {@link VideoDefinition}.  <br/>
    * see: {@link #setPreviewVideoDefinition} <br/>
    */
    @NonNull
    public VideoDefinition getCurrentPreviewVideoDefinition();

    /**
    * Returns whether the database is enabled. <br/>
    * <br/>
    * @return a boolean indicating the enablement of the database. <br/>
    */
    public boolean isDatabaseEnabled();

    /**
    * Enables or disables database usage. <br/>
    * <br/>
    * This function can only be called before starting the core up <br/>
    * @param value a boolean to indicate whether the database is to be enabled. <br/>
    */
    public void setDatabaseEnabled(boolean value);

    /**
    * Returns the default account, that is the one used to determine the current<br/>
    * identity. <br/>
    * <br/>
    * @return The default account.   <br/>
    */
    @Nullable
    public Account getDefaultAccount();

    /**
    * Sets the default account. <br/>
    * <br/>
    * This default account must be part of the list of already entered<br/>
    * LinphoneAccount. Toggling it as default will make {@link Core} default to the<br/>
    * identity associated with the account in all incoming and outgoing calls if the<br/>
    * destination SIP uri does not explicitely match any other accounts. <br/>
    * @param account The account to use as the default one.   <br/>
    */
    public void setDefaultAccount(@Nullable Account account);

    /**
    * Gets the default conference layout. <br/>
    * <br/>
    * @return conference layout <br/>
    */
    public Conference.Layout getDefaultConferenceLayout();

    /**
    * Set the default conference layout. <br/>
    * <br/>
    * @param value layout <br/>
    */
    public void setDefaultConferenceLayout(Conference.Layout value);

    /**
    * Gets the default lifetime of ephemeral messages in seconds. <br/>
    * <br/>
    * @return lifetime of ephemeral messages in seconds <br/>
    */
    public long getDefaultEphemeralLifetime();

    /**
    * Set the default ephemeral lifetime in seconds. <br/>
    * <br/>
    * @param value lifetime of ephemeral messages in seconds <br/>
    */
    public void setDefaultEphemeralLifetime(long value);

    /**
    * Retrieves the first list of {@link Friend} from the core. <br/>
    * <br/>
    * @return the first {@link FriendList} object or null.   <br/>
    */
    @Nullable
    public FriendList getDefaultFriendList();

    /**
    * Gets the default input audio device. <br/>
    * <br/>
    * @return The default input audio device   <br/>
    */
    @Nullable
    public AudioDevice getDefaultInputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as default input for next calls. <br/>
    * <br/>
    * @param audioDevice The {@link AudioDevice}   <br/>
    */
    public void setDefaultInputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Gets the default output audio device. <br/>
    * <br/>
    * @return The default output audio device   <br/>
    */
    @Nullable
    public AudioDevice getDefaultOutputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as default output for next calls. <br/>
    * <br/>
    * @param audioDevice The {@link AudioDevice}   <br/>
    */
    public void setDefaultOutputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Returns the default proxy configuration, that is the one used to determine the<br/>
    * current identity. <br/>
    * <br/>
    * @return The default proxy configuration.   <br/>
    * @deprecated 04/09/2024 Use {@link #getDefaultAccount} <br/>
    */
    @Deprecated
    @Nullable
    public ProxyConfig getDefaultProxyConfig();

    /**
    * Sets the default proxy. <br/>
    * <br/>
    * This default proxy must be part of the list of already entered<br/>
    * LinphoneProxyConfig. Toggling it as default will make {@link Core} use the<br/>
    * identity associated with the proxy configuration in all incoming and outgoing<br/>
    * calls. <br/>
    * @param config The proxy configuration to use as the default one.   <br/>
    * @deprecated 04/09/2024 Use {@link #setDefaultAccount} <br/>
    */
    @Deprecated
    public void setDefaultProxyConfig(@Nullable ProxyConfig config);

    /**
    * Gets the name of the default mediastreamer2 filter used for rendering video on<br/>
    * the current platform. <br/>
    * <br/>
    * This is for advanced users of the library, mainly to expose mediastreamer video<br/>
    * filter name and status. <br/>
    * @return The default video display filter.   <br/>
    */
    @NonNull
    public String getDefaultVideoDisplayFilter();

    /**
    * Gets the delayed timeout See {@link #setDelayedTimeout} for details. <br/>
    * <br/>
    * @return The current delayed timeout in seconds<br/>
    * @deprecated 04/09/2024 Obscure. <br/>
    */
    @Deprecated
    public int getDelayedTimeout();

    /**
    * Set the in delayed timeout in seconds. <br/>
    * <br/>
    * After this timeout period, a delayed call (internal call initialisation or<br/>
    * resolution) is resumed. <br/>
    * @param seconds The new delayed timeout<br/>
    * @deprecated 04/09/2024 Obscure. <br/>
    */
    @Deprecated
    public void setDelayedTimeout(int seconds);

    /**
    * Gets the current device orientation. <br/>
    * <br/>
    * @return The current device orientation<br/>
    * see: {@link #setDeviceRotation} <br/>
    */
    public int getDeviceRotation();

    /**
    * Tells the core the device current orientation. <br/>
    * <br/>
    * This can be used by capture filters on mobile devices to select between<br/>
    * portrait/landscape mode and to produce properly oriented images. The exact<br/>
    * meaning of the value in rotation if left to each device specific<br/>
    * implementations. IOS supported values are 0 for UIInterfaceOrientationPortrait<br/>
    * and 270 for UIInterfaceOrientationLandscapeRight. <br/>
    * @param rotation The orientation to use <br/>
    */
    public void setDeviceRotation(int rotation);

    /**
    * Get the current digest authentication policy applicable for SIP and HTTP. <br/>
    * <br/>
    * @return The current digest authentication policy.   <br/>
    */
    @NonNull
    public DigestAuthenticationPolicy getDigestAuthenticationPolicy();

    /**
    * Setup a new digest authentication policy applicable for SIP and HTTP. <br/>
    * <br/>
    * @param policy a {@link DigestAuthenticationPolicy}   <br/>
    * see: {@link Factory#createDigestAuthenticationPolicy} <br/>
    */
    public void setDigestAuthenticationPolicy(@NonNull DigestAuthenticationPolicy policy);

    /**
    * Get whether the microphone will be completely deactivated when muted. <br/>
    * <br/>
    * Please refer to {@link #setDisableRecordOnMute}.<br/>
    * @return True if you wish to entirely stop the audio recording when muting the<br/>
    * microphone. <br/>
    */
    public boolean getDisableRecordOnMute();

    /**
    * Calling this method with disable=true will cause the microhone to be completely<br/>
    * deactivated when muted, when given possible by the implementation on the<br/>
    * platform on which liblinphone is running. <br/>
    * <br/>
    * Otherwise, sound recording remains active but silence is sent instead of<br/>
    * recorded audio. Playback sound will be briefly interrupted while the audio is<br/>
    * reconfigured. Currently only implemented for IOS, it will also disable Apple's<br/>
    * microphone recording indicator when microphone is muted.<br/>
    * @param disable True if you wish to entirely stop the audio recording when<br/>
    * muting the microphone. <br/>
    */
    public void setDisableRecordOnMute(boolean disable);

    /**
    * Tells whether DNS search (use of local domain if the fully qualified name did<br/>
    * return results) is enabled. <br/>
    * <br/>
    * @return true if DNS search is enabled, false if disabled. <br/>
    */
    public boolean isDnsSearchEnabled();

    /**
    * Enable or disable DNS search (use of local domain if the fully qualified name<br/>
    * did return results). <br/>
    * <br/>
    * @param enable true to enable DNS search, false to disable it. <br/>
    */
    public void setDnsSearchEnabled(boolean enable);

    /**
    * Forces liblinphone to use the supplied list of dns servers, instead of system's<br/>
    * ones. <br/>
    * <br/>
    * @param servers A list of strings containing the IP addresses of DNS servers to<br/>
    * be used.  Setting to null restores default behaviour, which is to use the DNS<br/>
    * server list provided by the system. The list is copied internally.   <br/>
    */
    public void setDnsServers(@Nullable String[] servers);

    /**
    * Forces liblinphone to use the supplied list of dns servers, instead of system's<br/>
    * ones and set dns_set_by_app at true or false according to value of servers<br/>
    * list. <br/>
    * <br/>
    * see: {@link #getDnsSetByApp} <br/>
    * @param servers A list of strings containing the IP addresses of DNS servers to<br/>
    * be used.  Setting to null restores default behaviour, which is to use the DNS<br/>
    * server list provided by the system. The list is copied internally.   <br/>
    */
    public void setDnsServersApp(@Nullable String[] servers);

    /**
    * Tells if the DNS was set by an application. <br/>
    * <br/>
    * @return true if DNS was set by app, false otherwise. <br/>
    */
    public boolean getDnsSetByApp();

    /**
    * Tells whether DNS SRV resolution is enabled. <br/>
    * <br/>
    * @return true if DNS SRV resolution is enabled, false if disabled. <br/>
    */
    public boolean isDnsSrvEnabled();

    /**
    * Enable or disable DNS SRV resolution. <br/>
    * <br/>
    * @param enable true to enable DNS SRV resolution, false to disable it. <br/>
    */
    public void setDnsSrvEnabled(boolean enable);

    /**
    * Retrieve the maximum available download bandwidth. <br/>
    * <br/>
    * This value was set by {@link #setDownloadBandwidth}. <br/>
    * @return the download bandiwdth in kbits/s, 0 for unknown. <br/>
    */
    public int getDownloadBandwidth();

    /**
    * Sets maximum available download bandwidth This is IP bandwidth, in kbit/s. <br/>
    * <br/>
    * This information is signaled to other parties during calls (within SDP<br/>
    * messages) so that the remote end can have sufficient knowledge to properly<br/>
    * configure its audio & video codec output bitrate to not overflow available<br/>
    * bandwidth. By default, the download and upload bandwidth are unknowns (set to<br/>
    * zero), in which case adaptive algorithms are run during calls in order to<br/>
    * detect available bandwidth and adapt audio and video bitrate usage. see: {@link #enableAdaptiveRateControl}<br/>
    * .<br/>
    * @param bandwidth the bandwidth in kbits/s, 0 if unknown. <br/>
    */
    public void setDownloadBandwidth(int bandwidth);

    /**
    * Get audio packetization time linphone expects to receive from peer. <br/>
    * <br/>
    * A value of zero means that ptime is not specified. <br/>
    * @return the download packetization time set <br/>
    */
    public int getDownloadPtime();

    /**
    * Set audio packetization time linphone expects to receive from peer. <br/>
    * <br/>
    * A value of zero means that ptime is not specified. <br/>
    * @param ptime the download packetization time to set <br/>
    */
    public void setDownloadPtime(int ptime);

    /**
    * Gets the currently stored calibration delay for the software echo cancellation. <br/>
    * <br/>
    * @return the current calibration value, -1 if it failed, 0 if not done or not<br/>
    * needed, a positive value if a software echo canceller is required after running<br/>
    * {@link #startEchoCancellerCalibration}. <br/>
    */
    public int getEchoCancellationCalibration();

    /**
    * Returns true if echo cancellation is enabled. <br/>
    * <br/>
    * @return A boolean value telling whether echo cancellation is enabled or<br/>
    * disabled <br/>
    */
    public boolean isEchoCancellationEnabled();

    /**
    * Enables or disables echo cancellation. <br/>
    * <br/>
    * Value is saved and used for subsequent calls. This actually controls software<br/>
    * echo cancellation only. When 'enable' is set to false, software echo<br/>
    * cancellation is disabled, but hardware one, if available, remains activated.<br/>
    * When set to true, software echo cancellation is activated in either of these<br/>
    * two conditions:<br/>
    */
    public void setEchoCancellationEnabled(boolean enable);

    /**
    * Gets the name of the mediastreamer2 filter used for echo cancelling. <br/>
    * <br/>
    * @return The name of the mediastreamer2 filter used for echo cancellation.   <br/>
    */
    @Nullable
    public String getEchoCancellerFilterName();

    /**
    * Sets the name of the mediastreamer2 filter to be used for echo cancelling. <br/>
    * <br/>
    * @param filtername The name of the mediastreamer2 filter to be used for echo<br/>
    * cancellation.   <br/>
    */
    public void setEchoCancellerFilterName(@Nullable String filtername);

    /**
    * Tells whether echo limiter is enabled. <br/>
    * <br/>
    * Enables or disable echo limiter. "Echo limiter" refers to an algorithm that<br/>
    * creates half-duplex conversation in order to suppress echo. It is experimental<br/>
    * and shall be used only in rare cases where echo cancellation cannot perform<br/>
    * because of non-linear speaker/mic coupling. You shall not expected good audio<br/>
    * quality with the echo limiter. <br/>
    * @return true if the echo limiter is enabled, false otherwise. <br/>
    */
    public boolean isEchoLimiterEnabled();

    /**
    * Enables or disable echo limiter. <br/>
    * <br/>
    * "Echo limiter" refers to an algorithm that creates half-duplex conversation in<br/>
    * order to suppress echo. It is experimental and shall be used only in rare cases<br/>
    * where echo cancellation cannot perform because of non-linear speaker/mic<br/>
    * coupling. You shall not expected good audio quality with the echo limiter. <br/>
    * @param enable true to enable echo limiter, false to disable it. <br/>
    */
    public void setEchoLimiterEnabled(boolean enable);

    /**
    * sets the state of the EKT plugin in the Linphone core instance. <br/>
    * <br/>
    * @param ektPluginLoaded whether the EKT plugin is loaded or not <br/>
    */
    public void setEktPluginLoaded(boolean ektPluginLoaded);

    /**
    * Tells whether empty chat rooms are deleted or not. <br/>
    * <br/>
    * @return A boolean value telling whether the deletion of empty chatrooms is<br/>
    * enabled or not (Applicable to servers only) <br/>
    */
    public boolean isEmptyChatroomsDeletionEnabled();

    /**
    * Enable the deletion of empty chatrooms (i.e. <br/>
    * <br/>
    * chatrooms with no participants) <br/>
    * @param enable A boolean value telling whether to enable or disable the deletion<br/>
    * of chat rooms with no participants in (Applicable to servers only) it <br/>
    */
    public void setEmptyChatroomsDeletionEnabled(boolean enable);

    /**
    * Enable or disable the UPDATE method support. <br/>
    * <br/>
    * @param value Enable or disable it <br/>
    */
    public void setEnableSipUpdate(int value);

    /**
    * Do not use, this function does nothing. <br/>
    * <br/>
    * @param bandwidth the bandwidth in kbits/s, 0 for infinite<br/>
    * @deprecated 04/09/2024 this function does nothing. <br/>
    */
    @Deprecated
    public void setExpectedBandwidth(int bandwidth);

    /**
    * Returns the list of all audio devices. <br/>
    * <br/>
    * @return   A list of all {@link AudioDevice}     <br/>
    */
    @NonNull
    public AudioDevice[] getExtendedAudioDevices();

    /**
    * Tells whether the flexible FEC feature (RFC8627) is enabled for this {@link Core}<br/>
    * object. <br/>
    * <br/>
    * @return A boolean value telling whether the flexible FEC feature is enabled or<br/>
    * not for this {@link Core} object <br/>
    */
    public boolean isFecEnabled();

    /**
    * Enables the flexible FEC feature (RFC8627) for video calls to recover RTP<br/>
    * packet loss. <br/>
    * <br/>
    * @param enable A boolean value telling whether to enable or disable the flexible<br/>
    * FEC feature <br/>
    */
    public void setFecEnabled(boolean enable);

    /**
    * Gets the globaly set http file transfer server to be used for content type<br/>
    * application/vnd.gsma.rcs-ft-http+xml. <br/>
    * <br/>
    * Url may be like: "https://file.linphone.org/upload.php". <br/>
    * @return URL of the file server.   <br/>
    */
    @Nullable
    public String getFileTransferServer();

    /**
    * Globaly sets an http file transfer server to be used for content type<br/>
    * application/vnd.gsma.rcs-ft-http+xml. <br/>
    * <br/>
    * Url may be like: "https://file.linphone.org/upload.php". This value can also be<br/>
    * set for a dedicated account using<br/>
    * linphone_account_params_set_file_transfer_server. <br/>
    * @param serverUrl URL of the file server.   <br/>
    */
    public void setFileTransferServer(@Nullable String serverUrl);

    /**
    * Indicates whether the ICE relay path is forcibly selected. <br/>
    * <br/>
    * @return a boolean value indicating whether forced relay is enabled.<br/>
    * see: {@link #enableForcedIceRelay}. <br/>
    */
    public boolean isForcedIceRelayEnabled();

    /**
    * Artificially cause the relay path to be selected when ICE is used. <br/>
    * <br/>
    * This is mainly a function for test, for example to validate that the relay<br/>
    * service (ever TURN or media-aware SIP proxy) is working as expected. Indeed, in<br/>
    * many cases a path through host or server reflexive candidate will be found by<br/>
    * ICE, which makes difficult to make sure that the relay service is working as<br/>
    * expected. <br/>
    * @param enable boolean value <br/>
    */
    public void setForcedIceRelayEnabled(boolean enable);

    /**
    * Returns whether or not friend lists subscription are enabled. <br/>
    * <br/>
    * @return whether or not the feature is enabled <br/>
    */
    public boolean isFriendListSubscriptionEnabled();

    /**
    * Sets whether or not to start friend lists subscription when in foreground. <br/>
    * <br/>
    * @param enable whether or not to enable the feature <br/>
    */
    public void setFriendListSubscriptionEnabled(boolean enable);

    /**
    * Gets the database filename where friends will be stored. <br/>
    * <br/>
    * @return filesystem path.   <br/>
    * @deprecated 27/10/2023 Friends are now stored in the main db <br/>
    */
    @Deprecated
    @Nullable
    public String getFriendsDatabasePath();

    /**
    * Sets the database filename where friends will be stored. <br/>
    * <br/>
    * If the file does not exist, it will be created.<br/>
    * @param path filesystem path.   <br/>
    * @deprecated 27/10/2023 Friends are now stored in the main db <br/>
    */
    @Deprecated
    public void setFriendsDatabasePath(@Nullable String path);

    /**
    * Retrieves the list of {@link FriendList} from the core. <br/>
    * <br/>
    * @return A list of {@link FriendList}.    <br/>
    */
    @NonNull
    public FriendList[] getFriendsLists();

    /**
    * Retrieve the list of future conference information on DB. <br/>
    * <br/>
    * @return The list of future conference infos .     <br/>
    */
    @NonNull
    public ConferenceInfo[] getFutureConferenceInformationList();

    /**
    * Returns enablement of RFC3389 generic comfort noise algorithm. <br/>
    * <br/>
    * @return true if generic comfort noise is enabled, false otherwise. <br/>
    */
    public boolean isGenericComfortNoiseEnabled();

    /**
    * Enable RFC3389 generic comfort noise algorithm (CN payload type). <br/>
    * <br/>
    * It is disabled by default, because this algorithm is only relevant for legacy<br/>
    * codecs (PCMU, PCMA, G722). Enablement requires a SDK built with full G729<br/>
    * support: -DENABLE_G729=ON -DENABLE_G729B_CNG=ON . warning: : the G729 support<br/>
    * is not included in Liblinphone default licence - the purchase of a license<br/>
    * extension is required. <br/>
    * @param enabled true if enabled, false otherwise. <br/>
    */
    public void setGenericComfortNoiseEnabled(boolean enabled);

    /**
    * Returns the global state of core. <br/>
    * <br/>
    * @return a {@link GlobalState} enum.   <br/>
    */
    @NonNull
    public GlobalState getGlobalState();

    /**
    * Returns whether the gr parameter is kept in the conference address. <br/>
    * <br/>
    * @return true if the "gr" parameter is kept in the conference address, false<br/>
    * otherwise. <br/>
    * see: {@link #enableGruuInConferenceAddress} for more informations <br/>
    */
    public boolean isGruuInConferenceAddressEnabled();

    /**
    * Sets whether to keep GRUU parameter in the conference addresses. <br/>
    * <br/>
    * @param enabled true if enabled, false otherwise. <br/>
    * warning: This setting will also remove the GRUU parameter from all conference<br/>
    * and chat room addresses stored in the database at startup. Setting it to false<br/>
    * after it being set to true earlier on does not restore the previous state of<br/>
    * the database <br/>
    */
    public void setGruuInConferenceAddressEnabled(boolean enabled);

    /**
    * Returns true if hostname part of primary contact is guessed automatically. <br/>
    * <br/>
    * @return true if guess hostname enabled, false otherwise. <br/>
    */
    public boolean getGuessHostname();

    /**
    * Tells {@link Core} to guess local hostname automatically in primary contact. <br/>
    * <br/>
    * @param enable whether to enable the guess hostname feature or not <br/>
    */
    public void setGuessHostname(boolean enable);

    /**
    * Gets http proxy address to be used for signaling. <br/>
    * <br/>
    * @return hostname of IP adress of the http proxy (can be null to disable).   <br/>
    */
    @Nullable
    public String getHttpProxyHost();

    /**
    * Sets http proxy address to be used for signaling during next channel<br/>
    * connection. <br/>
    * <br/>
    * Use {@link #setNetworkReachable} FASLE/true to force channel restart. <br/>
    * @param host Hostname of IP adress of the http proxy (can be null to disable).   <br/>
    */
    public void setHttpProxyHost(@Nullable String host);

    /**
    * Gets http proxy port to be used for signaling. <br/>
    * <br/>
    * @return port of the http proxy. <br/>
    */
    public int getHttpProxyPort();

    /**
    * Sets http proxy port to be used for signaling. <br/>
    * <br/>
    * @param port of the http proxy. <br/>
    */
    public void setHttpProxyPort(int port);

    /**
    * Gets the default identity SIP address. <br/>
    * <br/>
    * This is an helper function. If no default proxy is set, this will return the<br/>
    * primary contact ( see {@link #getPrimaryContact} ). If a default proxy is set<br/>
    * it returns the registered identity on the proxy. <br/>
    * @return The default identity SIP address.   <br/>
    */
    @NonNull
    public String getIdentity();

    /**
    * Gets the {@link ImNotifPolicy} object controlling the instant messaging<br/>
    * delivery and displayed service notifications. <br/>
    * <br/>
    * @return A {@link ImNotifPolicy} object.   <br/>
    */
    @Nullable
    public ImNotifPolicy getImNotifPolicy();

    /**
    * Gets the IMDN resend period. <br/>
    * <br/>
    * @return the number of second to resend an failed IMDN message <br/>
    */
    public long getImdnResendPeriod();

    /**
    * Set the IMDN resend period. <br/>
    * <br/>
    * It is the number of seconds after the first attempt to send, an IMDN message is<br/>
    * sent again on startup if failed earlier on <br/>
    * @param seconds number of seconds after the first attempt to send an IMDN, it is<br/>
    * retried at startup. A negative value means all IMDNs are resent at startup. <br/>
    */
    public void setImdnResendPeriod(long seconds);

    /**
    * Returns the threshold for sending IMDN to all participants to a {@link ChatRoom}<br/>
    * . <br/>
    * <br/>
    * @return An integer value telling the threshold for sending IMDN to all<br/>
    * participants to a {@link ChatRoom} <br/>
    */
    public int getImdnToEverybodyThreshold();

    /**
    * Sets the threshold for sending IMDN to all participants to a {@link ChatRoom}. <br/>
    * <br/>
    * @param threshold the threshold for sending IMDN to all participants to a {@link ChatRoom}<br/>
    */
    public void setImdnToEverybodyThreshold(int threshold);

    /**
    * Gets the maximum duration of a call. <br/>
    * <br/>
    * See {@link #setInCallTimeout} for details. <br/>
    * @return The current in call timeout in seconds <br/>
    */
    public int getInCallTimeout();

    /**
    * Sets the maximum duration of a call in seconds. <br/>
    * <br/>
    * After this timeout period, the call is automatically hangup. A value of 0<br/>
    * disables this feature. <br/>
    * @param seconds The new timeout in seconds <br/>
    */
    public void setInCallTimeout(int seconds);

    /**
    * Returns the incoming call timeout See {@link #setIncTimeout} for details. <br/>
    * <br/>
    * @return The current incoming call timeout in seconds <br/>
    */
    public int getIncTimeout();

    /**
    * Sets the incoming call timeout in seconds. <br/>
    * <br/>
    * If an incoming call isn't answered for this timeout period, it is automatically<br/>
    * declined. <br/>
    * @param seconds The new timeout in seconds <br/>
    */
    public void setIncTimeout(int seconds);

    /**
    * Gets the input audio device for the current call. <br/>
    * <br/>
    * @return The input audio device for the current or first call, null if there is<br/>
    * no call.   <br/>
    */
    @Nullable
    public AudioDevice getInputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as input for all active calls. <br/>
    * <br/>
    * @param audioDevice The {@link AudioDevice}. null does nothing.   <br/>
    */
    public void setInputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Tells whether IPv6 is enabled or not. <br/>
    * <br/>
    * @return A boolean value telling whether IPv6 is enabled or not <br/>
    */
    public boolean isIpv6Enabled();

    /**
    * Turns IPv6 support on or off. <br/>
    * <br/>
    * @param enable A boolean value telling whether to enable IPv6 support <br/>
    */
    public void setIpv6Enabled(boolean enable);

    /**
    * Check whether the device is echo canceller calibration is required. <br/>
    * <br/>
    * @return true if it is required, false otherwise <br/>
    */
    public boolean isEchoCancellerCalibrationRequired();

    /**
    * Gets if the EKT plugin is currently loaded in the Linphone core instance. <br/>
    * <br/>
    * @return true if the EKT plugin is loaded <br/>
    */
    public boolean isEktPluginLoaded();

    /**
    * Gets whether the Core is considering itself in background or not. <br/>
    * <br/>
    * The Core foreground/background state depends on the last call made to {@link #enterBackground}<br/>
    * or {@link #enterForeground}. <br/>
    * @return true if the Core is in background, false otherwise. <br/>
    */
    public boolean isInBackground();

    /**
    * Indicates whether the local participant is part of a conference. <br/>
    * <br/>
    * warning: That function automatically fails in the case of conferences using a<br/>
    * conferencet server (focus). If you use such a conference, you should use {@link Conference#removeParticipant}<br/>
    * instead. <br/>
    * @return true if the local participant is in a conference, false otherwise. <br/>
    * @deprecated 09/03/2021 Use {@link Conference#isIn} instead. <br/>
    */
    @Deprecated
    public boolean isInConference();

    /**
    * Tells whether there is an incoming invite pending. <br/>
    * <br/>
    * @return A boolean telling whether an incoming invite is pending or not. <br/>
    */
    public boolean isIncomingInvitePending();

    /**
    * Checks if the configured media encryption is mandatory or not. <br/>
    * <br/>
    * @return true if media encryption is mandatory; false otherwise. <br/>
    */
    public boolean isMediaEncryptionMandatory();

    /**
    * return network state either as positioned by the application or by linphone<br/>
    * itself. <br/>
    * <br/>
    * @return true if network is reachable, false otherwise <br/>
    */
    public boolean isNetworkReachable();

    /**
    * Gets whether push notifications are available or not (Android & iOS only). <br/>
    * <br/>
    * @return true if push notifications are available, false otherwise <br/>
    */
    public boolean isPushNotificationAvailable();

    /**
    * Returns whether or not sender name is hidden in a forwarded message. <br/>
    * <br/>
    * @return whether or not the feature <br/>
    */
    public boolean isSenderNameHiddenInForwardMessage();

    /**
    * Get whether the tls server certificate must be verified when connecting to a<br/>
    * SIP/TLS server. <br/>
    * <br/>
    * @return True if the tls server certificate must be verified <br/>
    */
    public boolean isVerifyServerCertificates();

    /**
    * Get whether the tls server certificate common name must be verified when<br/>
    * connecting to a SIP/TLS server. <br/>
    * <br/>
    * @return True if the tls server certificate common name must be verified <br/>
    */
    public boolean isVerifyServerCn();

    /**
    * Is signaling keep alive enabled. <br/>
    * <br/>
    * @return A boolean value telling whether signaling keep alive is enabled <br/>
    */
    public boolean isKeepAliveEnabled();

    /**
    * Enables signaling keep alive, small udp packet sent periodically to keep udp<br/>
    * NAT association. <br/>
    * <br/>
    * @param enable A boolean value telling whether signaling keep alive is to be<br/>
    * enabled <br/>
    */
    public void setKeepAliveEnabled(boolean enable);

    /**
    * Get the label assigned to the LinphoneCore. <br/>
    * <br/>
    * The default value is null (no label). <br/>
    * @return the assigned label. <br/>
    */
    public String getLabel();

    /**
    * Set a label - for logging/troubleshooting purpose - to the core object. <br/>
    * <br/>
    * This label is used by the logger to give context. When running an application<br/>
    * with several {@link Core} objects, (such as a test), it is useful to enhance<br/>
    * the log's readability'. <br/>
    * @param label a developer-friendly label. <br/>
    */
    public void setLabel(String label);

    /**
    * Gets the latest outgoing call log. <br/>
    * <br/>
    * Conference calls are not returned by this function! Requires ENABLE_DB_STORAGE<br/>
    * to work. <br/>
    * @return The last outgoing call log if any.   <br/>
    */
    @Nullable
    public CallLog getLastOutgoingCallLog();

    /**
    * Returns a list of entered LDAPs. <br/>
    * <br/>
    * Items must be freed with linphone_ldap_unref <br/>
    * @return       <br/>
    * @deprecated 18/11/2024 use {@link #getRemoteContactDirectories} instead. <br/>
    */
    @Deprecated
    @NonNull
    public Ldap[] getLdapList();

    /**
    * Tells wether LIME X3DH is enabled or not. <br/>
    * <br/>
    * @return The current lime state <br/>
    */
    public boolean isLimeX3DhEnabled();

    /**
    * Tells to LinphoneCore to use LIME X3DH. <br/>
    * <br/>
    * @param enable A boolean value telling whether to enable or disable LIME X3DH <br/>
    */
    public void setLimeX3DhEnabled(boolean enable);

    /**
    * Get the x3dh server url. <br/>
    * <br/>
    * @return The x3dh server url.  <br/>
    * @deprecated 26/08/2022 Use {@link AccountParams#getLimeServerUrl} instead. <br/>
    */
    @Deprecated
    @Nullable
    public String getLimeX3DhServerUrl();

    /**
    * Set the x3dh server url. <br/>
    * <br/>
    * If empty, this function will disable LIME X3DH from core. Otherwise, or if<br/>
    * different from the existing value, this will (re-)initialize the LIME X3DH<br/>
    * engine. <br/>
    * @param url The x3dh server url.  <br/>
    * @deprecated 26/08/2022 Use {@link AccountParams#setLimeServerUrl} instead. <br/>
    */
    @Deprecated
    public void setLimeX3DhServerUrl(@Nullable String url);

    /**
    * Get the list of linphone specs string values representing what functionalities<br/>
    * the linphone client supports. <br/>
    * <br/>
    * see: {@link #setLinphoneSpecsList} <br/>
    * @return A list of supported specs. The list must be freed with<br/>
    * bctbx_list_free() after usage.       <br/>
    */
    @NonNull
    public String[] getLinphoneSpecsList();

    /**
    * Sets the linphone specs list value telling what functionalities the linphone<br/>
    * client supports. <br/>
    * <br/>
    * The said "specs" (specifications) are pair of keyword/version that helps<br/>
    * advertising the level feature supported by liblinphone. An application usually<br/>
    * does not need to set this information, that is automatically assigned at {@link Core}<br/>
    * start. Setting this is mainly for internal tests of backward compatibility. <br/>
    * @param specs The list of string specs to set.    <br/>
    */
    public void setLinphoneSpecsList(@Nullable String[] specs);

    /**
    * Return the list of loaded plugins. <br/>
    * <br/>
    * @return the list of loaded plugins    <br/>
    */
    @NonNull
    public String[] getLoadedPlugins();

    /**
    * Special function to check if the local network permission has been granted by<br/>
    * the user (useful for iOS). <br/>
    * <br/>
    * The test performed by this function may popup the local network permission<br/>
    * dialog, for that reason it could be a good idea to check it twice to conclude<br/>
    * that the user has deny the permission. <br/>
    * @return true if local permission request is granted, false otherwise. <br/>
    */
    public boolean isLocalPermissionEnabled();

    /**
    * Gets the url of the server where to upload the collected log files. <br/>
    * <br/>
    * @return The url of the server where to upload the collected log files.   <br/>
    */
    @Nullable
    public String getLogCollectionUploadServerUrl();

    /**
    * Sets the url of the server where to upload the collected log files. <br/>
    * <br/>
    * @param serverUrl The url of the server where to upload the collected log files.<br/>
    *   <br/>
    */
    public void setLogCollectionUploadServerUrl(@Nullable String serverUrl);

    /**
    * Gets the maximum number of call logs retrieved when using {@link #getCallLogs}<br/>
    * or {@link Account#getCallLogs}. <br/>
    * <br/>
    * @return the maximum number of call logs that will be returned. -1 will return<br/>
    * them all. <br/>
    */
    public int getMaxCallLogs();

    /**
    * Sets the maximum number of call logs to retrieve when using {@link #getCallLogs}<br/>
    * or {@link Account#getCallLogs}. <br/>
    * <br/>
    * @param max the maximum number of call logs, use -1 to get them all. <br/>
    */
    public void setMaxCallLogs(int max);

    /**
    * Gets the maximum number of simultaneous calls Linphone core can manage at a<br/>
    * time. <br/>
    * <br/>
    * All new call above this limit are declined with a busy answer <br/>
    * @return maximum number of simultaneous calls <br/>
    */
    public int getMaxCalls();

    /**
    * Sets the maximum number of simultaneous calls Linphone core can manage at a<br/>
    * time. <br/>
    * <br/>
    * All new call above this limit are declined with a busy answer <br/>
    * @param max number of simultaneous calls <br/>
    */
    public void setMaxCalls(int max);

    /**
    * Gets the size under which incoming files in chat messages will be downloaded<br/>
    * automatically. <br/>
    * <br/>
    * @return The size in bytes, -1 if autodownload feature is disabled, 0 to<br/>
    * download them all no matter the size <br/>
    */
    public int getMaxSizeForAutoDownloadIncomingFiles();

    /**
    * Sets the size under which incoming files in chat messages will be downloaded<br/>
    * automatically. <br/>
    * <br/>
    * @param size The size in bytes, -1 to disable the autodownload feature, 0 to<br/>
    * download them all no matter the size <br/>
    */
    public void setMaxSizeForAutoDownloadIncomingFiles(int size);

    /**
    * Gets the name of the currently assigned sound device for media. <br/>
    * <br/>
    * @return The name of the currently assigned sound device for capture.   <br/>
    */
    @Nullable
    public String getMediaDevice();

    /**
    * Sets the sound device used for media. <br/>
    * <br/>
    * @param devid The device name as returned by linphone_core_get_sound_devices   <br/>
    * @return 0 <br/>
    */
    public int setMediaDevice(@Nullable String devid);

    /**
    * Gets the media encryption type being used for RTP packets. <br/>
    * <br/>
    * @return The {@link MediaEncryption} policy being used. <br/>
    */
    public MediaEncryption getMediaEncryption();

    /**
    * Chooses the media encryption type to be used for RTP packets. <br/>
    * <br/>
    * @param menc The media encryption policy to be used. <br/>
    * @return 0 if successful, any other value otherwise. <br/>
    */
    public int setMediaEncryption(MediaEncryption menc);

    /**
    * Defines whether the configured media encryption is mandatory, if it is and the<br/>
    * negotation cannot result in the desired media encryption then the call will<br/>
    * fail. <br/>
    * <br/>
    * If not an INVITE will be resent with encryption disabled. <br/>
    * @param mandatory true to set it mandatory; false otherwise. <br/>
    */
    public void setMediaEncryptionMandatory(boolean mandatory);

    /**
    * This method is called by the application to notify the linphone core library<br/>
    * when the media (RTP) network is reachable. <br/>
    * <br/>
    * This is for advanced usage, when SIP and RTP layers are required to use<br/>
    * different interfaces. Most applications just need {@link #setNetworkReachable}.<br/>
    * @param reachable true if network is reachable, false otherwise <br/>
    */
    public void setMediaNetworkReachable(boolean reachable);

    /**
    * This function returns the media resource mode for this core. <br/>
    * <br/>
    * @return The media resource mode <br/>
    */
    public MediaResourceMode getMediaResourceMode();

    /**
    * Sets the media resources mode. <br/>
    * <br/>
    * Value values are: unique and shared. When the mode is set to unique, then only<br/>
    * one call in the state StreamsRunning is allowed. While accepting a call, the<br/>
    * core will try to free media resource used by the current call. If it is<br/>
    * unsuccessful, then the call is not accepted. If mode is set to shared, then the<br/>
    * media resources of the current call (if any) are not emptied when taking a new<br/>
    * call. If the user whishes to free them, he/she is responsible to call<br/>
    * linphone_core_preempt_sound_resources himself/herself <br/>
    * @param mode the chosen mode <br/>
    */
    public void setMediaResourceMode(MediaResourceMode mode);

    /**
    * Returns the duration of the timer that delays the sending of chat messages. <br/>
    * <br/>
    * @return the duration of the timer in seconds <br/>
    */
    public int getMessageSendingDelay();

    /**
    * It sets the duration of the timer that starts just after the SUBSCRIBE is sent<br/>
    * to delay the sending of chat messages in group chats. <br/>
    * <br/>
    * @param duration the duration of the timer in seconds. <br/>
    * warning: it is only useful to set this property if<br/>
    * linphone_core_send_message_after_notify_enabled returns false <br/>
    */
    public void setMessageSendingDelay(int duration);

    /**
    * Tells whether the microphone is enabled. <br/>
    * <br/>
    * @return true if the microphone is enabled, false if disabled. <br/>
    */
    public boolean isMicEnabled();

    /**
    * Enables or disables the microphone. <br/>
    * <br/>
    * This effectively enable or disable microphone (mute) for currently the running<br/>
    * call or conference if any, as well as it applies to future currently running<br/>
    * calls or conferences. <br/>
    * @param enable true to enable the microphone, false to disable it. <br/>
    */
    public void setMicEnabled(boolean enable);

    /**
    * Get microphone gain in db. <br/>
    * <br/>
    * @return The current microphone gain <br/>
    */
    public float getMicGainDb();

    /**
    * Allow to control microphone level: gain in db. <br/>
    * <br/>
    * @param level The new microphone level <br/>
    */
    public void setMicGainDb(float level);

    /**
    * Gets the number of missed calls. <br/>
    * <br/>
    * Once checked, this counter can be reset with {@link #resetMissedCallsCount}. <br/>
    * @return The number of missed calls. <br/>
    */
    public int getMissedCallsCount();

    /**
    * Returns the maximum transmission unit size in bytes. <br/>
    * <br/>
    */
    public int getMtu();

    /**
    * Sets the maximum transmission unit size in bytes. <br/>
    * <br/>
    * This information is useful for sending RTP packets. Default value is 1500. <br/>
    * @param mtu The MTU in bytes <br/>
    */
    public void setMtu(int mtu);

    /**
    * Deprecated. <br/>
    * <br/>
    * Get the public IP address of NAT being used. <br/>
    * @return The public IP address of NAT being used.   <br/>
    * @deprecated 12/10/2022 Use {@link #getNatPolicy}<br/>
    */
    @Deprecated
    @Nullable
    public String getNatAddress();

    /**
    * Deprecated. <br/>
    * <br/>
    * This function was used to force a given IP address to appear in SDP.<br/>
    * Unfortunately, this cannot work as explained by<br/>
    * https://www.rfc-editor.org/rfc/rfc5389#section-2 . <br/>
    * @param addr The public IP address of NAT to use.   <br/>
    * @deprecated 12/10/2022 Use {@link #setNatPolicy}<br/>
    */
    @Deprecated
    public void setNatAddress(@Nullable String addr);

    /**
    * Get The policy that is used to pass through NATs/firewalls. <br/>
    * <br/>
    * It may be overridden by a NAT policy for a specific proxy config. <br/>
    * @return {@link NatPolicy} object in use.  <br/>
    * see: {@link AccountParams#getNatPolicy} <br/>
    */
    @Nullable
    public NatPolicy getNatPolicy();

    /**
    * Set the policy to use to pass through NATs/firewalls. <br/>
    * <br/>
    * It may be overridden by a NAT policy for a specific proxy config. <br/>
    * @param policy {@link NatPolicy} object  <br/>
    * see: {@link AccountParams#setNatPolicy} <br/>
    */
    public void setNatPolicy(@Nullable NatPolicy policy);

    /**
    * Get the native window handle of the video preview window. <br/>
    * <br/>
    * see {@link #setNativeVideoWindowId} for details about window_id<br/>
    * There is a special case for Qt : {@link #getNativePreviewWindowId} returns a<br/>
    * #QQuickFramebufferObject::Renderer. Note : Qt blocks GUI thread when calling<br/>
    * createRenderer(), so it is safe to call linphone functions there if needed.<br/>
    * @return The native window handle of the video preview window.   <br/>
    */
    @Nullable
    public Object getNativePreviewWindowId();

    /**
    * Set the native window id where the preview video (local camera) is to be<br/>
    * displayed. <br/>
    * <br/>
    * This has to be used in conjunction with {@link #usePreviewWindow}. see {@link #setNativeVideoWindowId}<br/>
    * for general details about window_id<br/>
    * On Android : #org.linphone.mediastream.video.capture.CaptureTextureView is used<br/>
    * for {@link #setNativePreviewWindowId}. It is inherited from #TextureView and<br/>
    * takes care of rotating the captured image from the camera and scale it to keep<br/>
    * it's ratio.<br/>
    * @param windowId The native window id where the preview video is to be<br/>
    * displayed.   <br/>
    */
    public void setNativePreviewWindowId(@Nullable Object windowId);

    /**
    * Returns whether the native ringing is enabled or not. <br/>
    * <br/>
    * This property is meaningful for Android platform only. When set to true, the<br/>
    * incoming call's ring tone is played by a Android MediaPlayer object playing the<br/>
    * phone's default ringtone, and manages vibrator as well. When set to false, the<br/>
    * incoming call's ring tone is played using liblinphone's internal ring tone<br/>
    * player, that is generic for all platforms. <br/>
    * @return True if we use the native ringing, false otherwise <br/>
    */
    public boolean isNativeRingingEnabled();

    /**
    * Sets whether to use the platform-dependent ringing. <br/>
    * <br/>
    * This property is meaningful for Android platform only. When set to true, the<br/>
    * incoming call's ring tone is played by a Android MediaPlayer object playing the<br/>
    * phone's default ringtone, and manages vibrator as well. When set to false, the<br/>
    * incoming call's ring tone is played using liblinphone's internal ring tone<br/>
    * player, that is generic for all platforms.<br/>
    * @param enable True to enable native ringing, false otherwise <br/>
    */
    public void setNativeRingingEnabled(boolean enable);

    /**
    * Get the native window handle of the video window. <br/>
    * <br/>
    * see linphone_core_set_native_video_window_id for details about window_id<br/>
    * There is a special case for Qt : {@link #getNativeVideoWindowId} returns a<br/>
    * #QQuickFramebufferObject::Renderer. Note : Qt blocks GUI thread when calling<br/>
    * createRenderer(), so it is safe to call linphone functions there if needed.<br/>
    * @return The native window handle of the video window.   <br/>
    */
    @Nullable
    public Object getNativeVideoWindowId();

    /**
    * Set the native video window id where the video is to be displayed. <br/>
    * <br/>
    * On Desktop platforms(MacOS, Linux, Windows), the display filter is "MSOGL" by<br/>
    * default. That means : If window_id is not set or set to<br/>
    * LINPHONE_VIDEO_DISPLAY_NONE, then the core will not create its own window,<br/>
    * unless the special id LINPHONE_VIDEO_DISPLAY_AUTO is given. This is currently<br/>
    * only supported for Linux X11 (Window type), Windows UWP (SwapChainPanel type)<br/>
    * and Windows Win32 (HWND type).<br/>
    * The C# Wrapper on Windows for UWP takes directly a #SwapChainPanel without<br/>
    * Marshalling. On other platforms, window_id is a #MSOglContextInfo defined in<br/>
    * msogl.h of mediastreamer2 There is a special case for Qt : The "MSQOGL" filter<br/>
    * must be selected by using {@link #setVideoDisplayFilter}. Setting window id is<br/>
    * only used to stop rendering by passing LINPHONE_VIDEO_DISPLAY_NONE. {@link #getNativeVideoWindowId}<br/>
    * returns a #QQuickFramebufferObject::Renderer and {@link #createNativeVideoWindowId}<br/>
    * creates one. After a creation, {@link #setNativeVideoWindowId} must be called<br/>
    * with the new object.<br/>
    * On mobile operating systems, LINPHONE_VIDEO_DISPLAY_AUTO is not supported and<br/>
    * window_id depends of the platform : iOS : It is a UIView. Android : It is a<br/>
    * TextureView.<br/>
    * @param windowId The native window id where the remote video is to be displayed.<br/>
    *   <br/>
    */
    public void setNativeVideoWindowId(@Nullable Object windowId);

    /**
    * This method is called by the application to notify the linphone core library<br/>
    * when network is reachable. <br/>
    * <br/>
    * Calling this method with true trigger linphone to initiate a registration<br/>
    * process for all proxies. Calling this method disables the automatic network<br/>
    * detection mode. It means you must call this method after each network state<br/>
    * changes.<br/>
    * @param reachable true if network is reachable, false otherwise <br/>
    */
    public void setNetworkReachable(boolean reachable);

    /**
    * Gets the value of the no-rtp timeout when the call is on hold. <br/>
    * <br/>
    * When no RTP or RTCP packets have been received for a while when the call is on<br/>
    * hold {@link Core} will consider the call is broken (remote end crashed or<br/>
    * disconnected from the network), and thus will terminate the call. The no-rtp<br/>
    * timeout is the duration above which the call is considered broken. <br/>
    * @return The value of the no-rtp timeout in seconds when the call is on hold <br/>
    */
    public int getNortpOnholdTimeout();

    /**
    * Sets the no-rtp timeout value in seconds when the call is on hold. <br/>
    * <br/>
    * @param seconds The no-rtp timeout value to use in seconds when the call is on<br/>
    * hold<br/>
    * see: linphone_core_get_nortp_on_hold_timeout() for details. <br/>
    */
    public void setNortpOnholdTimeout(int seconds);

    /**
    * Gets the value of the no-rtp timeout. <br/>
    * <br/>
    * When no RTP or RTCP packets have been received for a while {@link Core} will<br/>
    * consider the call is broken (remote end crashed or disconnected from the<br/>
    * network), and thus will terminate the call. The no-rtp timeout is the duration<br/>
    * above which the call is considered broken. <br/>
    * @return The value of the no-rtp timeout in seconds <br/>
    */
    public int getNortpTimeout();

    /**
    * Sets the no-rtp timeout value in seconds. <br/>
    * <br/>
    * @param seconds The no-rtp timeout value to use in seconds<br/>
    * see: {@link #getNortpTimeout} for details. <br/>
    */
    public void setNortpTimeout(int seconds);

    /**
    * Gets the output audio device for the current call. <br/>
    * <br/>
    * @return The output audio device for the current or first call, null if there is<br/>
    * no call.   <br/>
    */
    @Nullable
    public AudioDevice getOutputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as output for all active calls. <br/>
    * <br/>
    * @param audioDevice The {@link AudioDevice}. null does nothing.   <br/>
    */
    public void setOutputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Get the wav file that is played when putting somebody on hold, or when files<br/>
    * are used instead of soundcards (see {@link #setUseFiles}). <br/>
    * <br/>
    * The file is a 16 bit linear wav file. <br/>
    * @return The path to the file that is played when putting somebody on hold.   <br/>
    */
    @Nullable
    public String getPlayFile();

    /**
    * Sets a wav file to be played when putting somebody on hold, or when files are<br/>
    * used instead of soundcards (see {@link #setUseFiles}). <br/>
    * <br/>
    * The file must be a 16 bit linear wav file. <br/>
    * @param file The path to the file to be played when putting somebody on hold.   <br/>
    */
    public void setPlayFile(@Nullable String file);

    /**
    * Gets the name of the currently assigned sound device for playback. <br/>
    * <br/>
    * @return The name of the currently assigned sound device for playback.   <br/>
    * @deprecated 11/09/2024 use {@link #getOutputAudioDevice} or {@link #getDefaultOutputAudioDevice}<br/>
    * instead.<br/>
    */
    @Deprecated
    @Nullable
    public String getPlaybackDevice();

    /**
    * Sets the sound device used for playback. <br/>
    * <br/>
    * @param devid The device name as returned by linphone_core_get_sound_devices   <br/>
    * @return 0 <br/>
    * @deprecated 11/09/2024 use {@link #setOutputAudioDevice} or {@link #setDefaultOutputAudioDevice}<br/>
    * instead.<br/>
    */
    @Deprecated
    public int setPlaybackDevice(@Nullable String devid);

    /**
    * Gets playback gain in db (before entering sound card). <br/>
    * <br/>
    * @return The current playback gain <br/>
    */
    public float getPlaybackGainDb();

    /**
    * Allow to control play level before entering sound card: gain in db. <br/>
    * <br/>
    * @param level The new play level <br/>
    */
    public void setPlaybackGainDb(float level);

    /**
    * Returns the preferred video framerate, previously set by {@link #setPreferredFramerate}<br/>
    * . <br/>
    * <br/>
    * @return frame rate in number of frames per seconds. <br/>
    */
    public float getPreferredFramerate();

    /**
    * Set the preferred frame rate for video. <br/>
    * <br/>
    * Based on the available bandwidth constraints and network conditions, the video<br/>
    * encoder remains free to lower the framerate. There is no warranty that the<br/>
    * preferred frame rate be the actual framerate. used during a call. Default value<br/>
    * is 0, which means "use encoder's default fps value". <br/>
    * @param fps the target frame rate in number of frames per seconds. <br/>
    */
    public void setPreferredFramerate(float fps);

    /**
    * Get the preferred video definition for the stream that is captured and sent to<br/>
    * the remote party. <br/>
    * <br/>
    * @return The preferred {@link VideoDefinition}   <br/>
    */
    @NonNull
    public VideoDefinition getPreferredVideoDefinition();

    /**
    * Set the preferred video definition for the stream that is captured and sent to<br/>
    * the remote party. <br/>
    * <br/>
    * All standard video definitions are accepted on the receive path. <br/>
    * @param videoDefinition {@link VideoDefinition} object   <br/>
    */
    public void setPreferredVideoDefinition(@NonNull VideoDefinition videoDefinition);

    /**
    * Sets the preferred video definition by its name. <br/>
    * <br/>
    * Call {@link Factory#getSupportedVideoDefinitions} to have a list of supported<br/>
    * video definitions.<br/>
    * @param name The name of the definition to set   <br/>
    */
    public void setPreferredVideoDefinitionByName(@NonNull String name);

    /**
    * Gets my presence model. <br/>
    * <br/>
    * @return A {@link PresenceModel} object, or null if no presence model has been<br/>
    * set.   <br/>
    */
    @Nullable
    public PresenceModel getPresenceModel();

    /**
    * Sets my presence model. <br/>
    * <br/>
    * @param presence {@link PresenceModel}   <br/>
    */
    public void setPresenceModel(@Nullable PresenceModel presence);

    /**
    * Get the definition of the captured video. <br/>
    * <br/>
    * @return The captured {@link VideoDefinition} if it was previously set by {@link #setPreviewVideoDefinition}<br/>
    * , otherwise a 0x0 LinphoneVideoDefinition.   <br/>
    * see: {@link #setPreviewVideoDefinition} <br/>
    */
    @Nullable
    public VideoDefinition getPreviewVideoDefinition();

    /**
    * Set the video definition for the captured (preview) video. <br/>
    * <br/>
    * This method is for advanced usage where a video capture must be set<br/>
    * independently of the definition of the stream actually sent through the call.<br/>
    * This allows for example to have the preview window in High Definition even if<br/>
    * due to bandwidth constraint the sent video definition is small. Using this<br/>
    * feature increases the CPU consumption, since a rescaling will be done<br/>
    * internally. <br/>
    * @param videoDefinition {@link VideoDefinition} object   <br/>
    */
    public void setPreviewVideoDefinition(@Nullable VideoDefinition videoDefinition);

    /**
    * <br/>
    * @param name The name of the definition to set   <br/>
    */
    public void setPreviewVideoDefinitionByName(@NonNull String name);

    /**
    * Returns the default identity when no account is used. <br/>
    * <br/>
    * This SIP address usually contains a private ip address, and may not be routable<br/>
    * globally.<br/>
    * @return the primary contact identity   <br/>
    */
    @NonNull
    public String getPrimaryContact();

    /**
    * Sets the local "from" SIP identity used for calls made out of any configured<br/>
    * {@link Account}. <br/>
    * <br/>
    * Not using a SIP account is not recommended.<br/>
    * This data is used in absence of any proxy configuration or when no account<br/>
    * configuration is set. See {@link Account} <br/>
    * @param contact the contact to set   <br/>
    * @return 0 if successful, -1 otherwise <br/>
    */
    public int setPrimaryContact(@NonNull String contact);

    /**
    * Same as {@link #getPrimaryContact} but the result is a {@link Address} object<br/>
    * instead of a string. <br/>
    * <br/>
    * @return a {@link Address} object.     <br/>
    */
    @Nullable
    public Address getPrimaryContactAddress();

    /**
    * Same as {@link #getPrimaryContact} but the result is a {@link Address} object<br/>
    * instead of const char *. <br/>
    * <br/>
    * @return a {@link Address} object.    <br/>
    * @deprecated 22/10/2018 Use {@link #createPrimaryContactParsed} instead. <br/>
    */
    @Deprecated
    @Nullable
    public Address getPrimaryContactParsed();

    /**
    * Get provisioning URI. <br/>
    * <br/>
    * @return the provisioning URI.   <br/>
    */
    @Nullable
    public String getProvisioningUri();

    /**
    * Sets the URI where to download xml configuration file at startup. <br/>
    * <br/>
    * http://, https:// and file:// uris are supported. This can also be set from<br/>
    * configuration file or factory config file, from [misc] section, item<br/>
    * "config-uri". Calling this function does not load the configuration. It will<br/>
    * write the value into configuration so that configuration from URI will take<br/>
    * place during next {@link #start} invocation. The format the xml file is briefly<br/>
    * documented here:<br/>
    * https://wiki.linphone.org/xwiki/wiki/public/view/Lib/Features/Remote%20Provisioning/ <br/>
    * @param uri the uri to use in order to obtain the configuration. Passing null<br/>
    * will disable remote provisioning.   <br/>
    * @return -1 if uri could not be parsed, 0 otherwise. Note that this does not<br/>
    * check validity of URI endpoint nor scheme and download may still fail. <br/>
    */
    public int setProvisioningUri(@Nullable String uri);

    /**
    * Returns an unmodifiable list of entered proxy configurations. <br/>
    * <br/>
    * @return A list of {@link ProxyConfig}.    <br/>
    * @deprecated 04/09/2024 Use {@link #getAccountList} <br/>
    */
    @Deprecated
    @NonNull
    public ProxyConfig[] getProxyConfigList();

    /**
    * Returns the push incoming call timeout See {@link #setPushIncomingCallTimeout}<br/>
    * for details. <br/>
    * <br/>
    * @return The current push incoming call timeout in seconds <br/>
    */
    public int getPushIncomingCallTimeout();

    /**
    * Configures the minimum interval between a push notification and the<br/>
    * corresponding incoming INVITE. <br/>
    * <br/>
    * If exceeded, Linphone Call is transitioned to CallError and further incoming<br/>
    * invite associated to this push is declined if any. <br/>
    * @param seconds The new timeout in seconds <br/>
    */
    public void setPushIncomingCallTimeout(int seconds);

    /**
    * Gets the push notification configuration object if it exists. <br/>
    * <br/>
    * @return the {@link PushNotificationConfig} if it exists, null otherwise.   <br/>
    */
    @Nullable
    public PushNotificationConfig getPushNotificationConfig();

    /**
    * Gets whether push notifications are enabled or not (Android & iOS only). <br/>
    * <br/>
    * If not, the app will have to handle all the push-related settings for each<br/>
    * accounts <br/>
    * @return true if push notifications are enabled, false otherwise <br/>
    */
    public boolean isPushNotificationEnabled();

    /**
    * Enables or disables push notifications on Android & iOS. <br/>
    * <br/>
    * If enabled, it will try to get the push token add configure each account with<br/>
    * push_notification_allowed set to true with push parameters. IOS: will also<br/>
    * instanciate a PushRegistry, so make sure that your app does not instanciate one<br/>
    * too or there will be a conflict. <br/>
    * @param enable true to enable push notifications, false to disable <br/>
    */
    public void setPushNotificationEnabled(boolean enable);

    /**
    * Tells whether QRCode is enabled in the preview. <br/>
    * <br/>
    * @return A boolean value telling whether QRCode is enabled in the preview. <br/>
    */
    public boolean isQrcodeVideoPreviewEnabled();

    /**
    * Controls QRCode scanning enablement. <br/>
    * <br/>
    * When enabled, several QRCodes can be decoded. The recognized QR code are<br/>
    * notified through the LinphoneCoreCbs interface (see<br/>
    * linphone_core_cbs_set_qrcode_found) <br/>
    * @param enable A boolean value telling whether to enable QRCode in the preview. <br/>
    */
    public void setQrcodeVideoPreviewEnabled(boolean enable);

    /**
    * Gets if realtime text is enabled or not (RFC4103). <br/>
    * <br/>
    * @return true if realtime text is enabled, false otherwise <br/>
    */
    public boolean isRealtimeTextEnabled();

    /**
    * Gets keep alive interval of real time text (RFC4103). <br/>
    * <br/>
    * @return keep alive interval of real time text. <br/>
    */
    public int getRealtimeTextKeepaliveInterval();

    /**
    * Set keep alive interval for real time text (RFC4103). <br/>
    * <br/>
    * @param interval The keep alive interval of real time text, 25000 by default. <br/>
    */
    public void setRealtimeTextKeepaliveInterval(int interval);

    /**
    * Gets if the record aware feature is enabled or not. <br/>
    * <br/>
    * @return true if the record aware feature is enabled, false otherwise. <br/>
    */
    public boolean isRecordAwareEnabled();

    /**
    * Enables the record-aware feature that will warn other users when doing<br/>
    * recording during a call. <br/>
    * <br/>
    * See @LinphoneCallCbs for being notified when a call is being recorded. <br/>
    * @param enable true to activate the record aware feature, false to disable it. <br/>
    */
    public void setRecordAwareEnabled(boolean enable);

    /**
    * Get the wav file where incoming stream is recorded, when files are used instead<br/>
    * of soundcards (see {@link #setUseFiles}). <br/>
    * <br/>
    * This feature is different from call recording ({@link CallParams#setRecordFile}<br/>
    * ) The file is a 16 bit linear wav file. <br/>
    * @return The path to the file where incoming stream is recorded.   <br/>
    */
    @Nullable
    public String getRecordFile();

    /**
    * Sets a wav file where incoming stream is to be recorded, when files are used<br/>
    * instead of soundcards (see {@link #setUseFiles}). <br/>
    * <br/>
    * This feature is different from call recording ({@link CallParams#setRecordFile}<br/>
    * ) The file will be a 16 bit linear wav file. <br/>
    * @param file The path to the file where incoming stream is to be recorded.   <br/>
    */
    public void setRecordFile(@Nullable String file);

    /**
    * Gets if accounts will wait for network to be connected before trying to<br/>
    * REGISTER or not. <br/>
    * <br/>
    * @return true if accounts will wait for internet connection before trying to<br/>
    * REGISTER, false otherwise. <br/>
    */
    public boolean getRegisterOnlyWhenNetworkIsUp();

    /**
    * Sets if accounts will wait for network to be connected before trying to<br/>
    * REGISTER. <br/>
    * <br/>
    * @param registerOnlyWhenNetworkIsUp true to wait for an internet connection<br/>
    * before trying to REGISTER, false to do it no matter the network state. <br/>
    */
    public void setRegisterOnlyWhenNetworkIsUp(boolean registerOnlyWhenNetworkIsUp);

    /**
    * Returns how many attachments are yet to be downloaded. <br/>
    * <br/>
    * @return how many attachments are yet to be downloaded. <br/>
    */
    public int getRemainingDownloadFileCount();

    /**
    * Returns how many attachments are yet to be uploaded. <br/>
    * <br/>
    * @return how many attachments are yet to be uploaded. <br/>
    */
    public int getRemainingUploadFileCount();

    /**
    * Gets the list of currently configured LDAP or CardDAV remote servers used by<br/>
    * {@link MagicSearch}. <br/>
    * <br/>
    * @return the list of {@link RemoteContactDirectory} currently configured, if<br/>
    * any.       <br/>
    */
    @NonNull
    public RemoteContactDirectory[] getRemoteContactDirectories();

    /**
    * Get the ring back tone played to far end during incoming calls. <br/>
    * <br/>
    * @return the path to the remote ring back tone to be played.   <br/>
    */
    @Nullable
    public String getRemoteRingbackTone();

    /**
    * Specify a ring back tone to be played to far end during incoming calls. <br/>
    * <br/>
    * @param ring The path to the remote ring back tone to be played.   <br/>
    */
    public void setRemoteRingbackTone(@Nullable String ring);

    /**
    * Gets whether the use RTCP NACK for reliability of video transmission is enabled<br/>
    * or not. <br/>
    * <br/>
    * Using RTCP NACK feedback is one of the available techniques to help mitigate<br/>
    * the loss of video RTP packets. It gives good results when round trip time is<br/>
    * low. It is disabled by default. <br/>
    * @return A boolean value telling whether NACK usage is enabled or not <br/>
    */
    public boolean isRetransmissionOnNackEnabled();

    /**
    * Sets whether the use RTCP NACK for reliability of video transmission is enabled<br/>
    * or not. <br/>
    * <br/>
    * Using RTCP NACK feedback is one of the available techniques to help mitigate<br/>
    * the loss of video RTP packets. It gives good results when round trip time is<br/>
    * low. It is disabled by default. <br/>
    * @param enable A boolean value telling whether to enable NACK context <br/>
    */
    public void setRetransmissionOnNackEnabled(boolean enable);

    /**
    * Returns the path to the wav file used for ringing. <br/>
    * <br/>
    * @return The path to the wav file used for ringing.   <br/>
    */
    @Nullable
    public String getRing();

    /**
    * Sets the path to a wav file used for ringing. <br/>
    * <br/>
    * The file must be a wav 16bit linear. If null, ringing is disable unless<br/>
    * #linphone_core_get_use_native_ringing() is enabled, in which case we use the<br/>
    * device ringtone. <br/>
    * @param path The path to a wav file to be used for ringing, null to disable or<br/>
    * use device ringing depending on #linphone_core_get_use_native_ringing().   <br/>
    */
    public void setRing(@Nullable String path);

    /**
    * Tells whether the ring play is enabled during an incoming early media call. <br/>
    * <br/>
    */
    public boolean getRingDuringIncomingEarlyMedia();

    /**
    * Enable or disable the ring play during an incoming early media call. <br/>
    * <br/>
    * @param enable A boolean value telling whether to enable ringing during an<br/>
    * incoming early media call. <br/>
    */
    public void setRingDuringIncomingEarlyMedia(boolean enable);

    /**
    * Returns the path to the wav file used for ringing back. <br/>
    * <br/>
    * @return The path to the wav file used for ringing back.   <br/>
    */
    @Nullable
    public String getRingback();

    /**
    * Sets the path to a wav file used for ringing back. <br/>
    * <br/>
    * Ringback means the ring that is heard when it's ringing at the remote party.<br/>
    * The file must be a wav 16bit linear. <br/>
    * @param path The path to a wav file to be used for ringing back.   <br/>
    */
    public void setRingback(@Nullable String path);

    /**
    * Gets the name of the currently assigned sound device for ringing. <br/>
    * <br/>
    * @return The name of the currently assigned sound device for ringing.   <br/>
    */
    @Nullable
    public String getRingerDevice();

    /**
    * Sets the sound device used for ringing. <br/>
    * <br/>
    * @param devid The device name as returned by linphone_core_get_sound_devices   <br/>
    * @return 0 <br/>
    */
    public int setRingerDevice(@Nullable String devid);

    /**
    * Gets the path to a file or folder containing the trusted root CAs (PEM format) <br/>
    * <br/>
    * @return The path to a file or folder containing the trusted root CAs.   <br/>
    */
    @Nullable
    public String getRootCa();

    /**
    * Sets the path to a file or folder containing trusted root CAs (PEM format) <br/>
    * <br/>
    * @param path The path to a file or folder containing trusted root CAs.   <br/>
    */
    public void setRootCa(@Nullable String path);

    /**
    * Sets the trusted root CAs (PEM format) <br/>
    * <br/>
    * @param data The trusted root CAs as a string   <br/>
    */
    public void setRootCaData(@Nullable String data);

    /**
    * Returns whether RTP bundle mode (also known as Media Multiplexing) is enabled. <br/>
    * <br/>
    * See https://datatracker.ietf.org/doc/html/rfc8843 for more information. <br/>
    * @return a boolean indicating the enablement of rtp bundle mode. <br/>
    */
    public boolean isRtpBundleEnabled();

    /**
    * Enables or disables RTP bundle mode (Media Multiplexing). <br/>
    * <br/>
    * See https://datatracker.ietf.org/doc/html/rfc8843 for more information about<br/>
    * the feature. When enabled, liblinphone will try to negociate the use of a<br/>
    * single port for all streams when doing an outgoing call. It automatically<br/>
    * enables rtcp-mux. This feature can also be enabled per-call using {@link CallParams}<br/>
    * . RTP Bundle mode is required for video conferencing. <br/>
    * @param value a boolean to indicate whether the feature is to be enabled. <br/>
    */
    public void setRtpBundleEnabled(boolean value);

    /**
    * Media offer control param for SIP INVITE. <br/>
    * <br/>
    * @return true if INVITE has to be sent whitout SDP. <br/>
    */
    public boolean isSdp200AckEnabled();

    /**
    * Control when media offer is sent in SIP INVITE. <br/>
    * <br/>
    * Enabling this type of SIP call flow is not recommended. This setting is mainly<br/>
    * for internal testing. <br/>
    * @param enable true if INVITE has to be sent whitout SDP. <br/>
    */
    public void setSdp200AckEnabled(boolean enable);

    /**
    * Tells whether video self view during call is enabled or not. <br/>
    * <br/>
    * @return A boolean value telling whether self view is enabled <br/>
    * see: {@link #enableSelfView} for details. <br/>
    */
    public boolean isSelfViewEnabled();

    /**
    * Enables or disable self view during calls. <br/>
    * <br/>
    * @param enable A boolean value telling whether to enable self view Self-view<br/>
    * refers to having local webcam image inserted in corner of the video window<br/>
    * during calls. This function works at any time, including during calls.<br/>
    * @deprecated 04/09/2024 Prefer using {@link #setNativePreviewWindowId} to assign<br/>
    * a view to render the local image. <br/>
    */
    @Deprecated
    public void setSelfViewEnabled(boolean enable);

    /**
    * Returns enablement of sending chat messages on group chats after receiving the<br/>
    * NOTIFY full state. <br/>
    * <br/>
    * @return true if the core waits for the NOTIFY full statet before sending<br/>
    * messages to group chats, false otherwise. <br/>
    */
    public boolean isSendMessageAfterNotifyEnabled();

    /**
    * Enable sending of chat message on group chats only after receiving the NOTIFY<br/>
    * full state If it is disabled, as it is the default value, message will be sent<br/>
    * after the delay set by linphone_core_get_message_sending_delay <br/>
    * <br/>
    * @param enabled true if enabled, false otherwise. <br/>
    */
    public void setSendMessageAfterNotifyEnabled(boolean enabled);

    /**
    * Enables whether or not to hide sender name in forwarded message. <br/>
    * <br/>
    * @param enable whether or not to enable the feature <br/>
    */
    public void setSenderNameHiddenInForwardMessageEnabled(boolean enable);

    /**
    * Check if the Session Timers feature is enabled. <br/>
    * <br/>
    * @return true if session timers are enabled, false otherwise <br/>
    */
    public boolean isSessionExpiresEnabled();

    /**
    * Enable the Session Timers support. <br/>
    * <br/>
    * @param enabled Enable or disable it <br/>
    */
    public void setSessionExpiresEnabled(boolean enabled);

    /**
    * Returns the session expires min value, 90 by default. <br/>
    * <br/>
    * @return The minSE value <br/>
    */
    public int getSessionExpiresMinValue();

    /**
    * Sets the session expires minSE value, forced to a minimum of 90 by default. <br/>
    * <br/>
    * @param min The minSE value <br/>
    */
    public void setSessionExpiresMinValue(int min);

    /**
    * Returns the session expires refresher value. <br/>
    * <br/>
    * @return The {@link SessionExpiresRefresher} configuration refresher value <br/>
    */
    public SessionExpiresRefresher getSessionExpiresRefresherValue();

    /**
    * Sets the session expires refresher value. <br/>
    * <br/>
    * @param refresher The {@link SessionExpiresRefresher} configuration value <br/>
    */
    public void setSessionExpiresRefresherValue(SessionExpiresRefresher refresher);

    /**
    * Returns the session expires value. <br/>
    * <br/>
    * @return The session timer expire value <br/>
    */
    public int getSessionExpiresValue();

    /**
    * Sets the session expires value, 0 by default. <br/>
    * <br/>
    * @param expires The session expires value <br/>
    */
    public void setSessionExpiresValue(int expires);

    /**
    * Gets the DSCP field for SIP signaling channel. <br/>
    * <br/>
    * The DSCP defines the quality of service in IP packets. <br/>
    * @return The current DSCP value <br/>
    */
    public int getSipDscp();

    /**
    * Sets the DSCP field for SIP signaling channel. <br/>
    * <br/>
    * The DSCP defines the quality of service in IP packets. note: It is usually<br/>
    * useless or a bad idea to try to play with DSCP bits unless having full control<br/>
    * on the network. <br/>
    * warning: Setting the DSCP bits is more or less well supported by operating<br/>
    * systems and sometimes requires to disable IPv6. <br/>
    * @param dscp The DSCP value to set <br/>
    */
    public void setSipDscp(int dscp);

    /**
    * This method is called by the application to notify the linphone core library<br/>
    * when the SIP network is reachable. <br/>
    * <br/>
    * This is for advanced usage, when SIP and RTP layers are required to use<br/>
    * different interfaces. Most applications just need {@link #setNetworkReachable}.<br/>
    * @param reachable true if network is reachable, false otherwise <br/>
    */
    public void setSipNetworkReachable(boolean reachable);

    /**
    * Gets the SIP transport timeout, which represents the maximum time permitted to<br/>
    * establish a connection to a SIP server. <br/>
    * <br/>
    * @return The SIP transport timeout in milliseconds. <br/>
    */
    public int getSipTransportTimeout();

    /**
    * Sets the SIP transport timeout, which represents the maximum time permitted to<br/>
    * establish a connection to a SIP server. <br/>
    * <br/>
    * @param timeoutMs The SIP transport timeout in milliseconds. <br/>
    */
    public void setSipTransportTimeout(int timeoutMs);

    /**
    * Gets the list of the available sound devices. <br/>
    * <br/>
    * @return An unmodifiable array of strings contanining the names of the available<br/>
    * sound devices that is null terminated.      <br/>
    * @deprecated 10/04/2021 Use {@link #getAudioDevices} instead.<br/>
    */
    @Deprecated
    @NonNull
    public String[] getSoundDevicesList();

    /**
    * Gets the crypto suites available to the core. <br/>
    * <br/>
    * @return a comma separated list of supported suites   <br/>
    */
    @NonNull
    public String getSrtpCryptoSuites();

    /**
    * Sets the crypto suites available to the core. <br/>
    * <br/>
    * @param suites comma separated list of supported suites   <br/>
    */
    public void setSrtpCryptoSuites(@NonNull String suites);

    /**
    * Get the path to the image file streamed when "Static picture" is set as the<br/>
    * video device. <br/>
    * <br/>
    * @return The path to the image file streamed when "Static picture" is set as the<br/>
    * video device.   <br/>
    */
    @Nullable
    public String getStaticPicture();

    /**
    * Set the path to the image file to stream when "Static picture" is set as the<br/>
    * video device. <br/>
    * <br/>
    * @param path The path to the image file to use.   <br/>
    */
    public int setStaticPicture(@Nullable String path);

    /**
    * Get the frame rate for static picture. <br/>
    * <br/>
    * @return The frame rate used for static picture. <br/>
    */
    public float getStaticPictureFps();

    /**
    * Set the frame rate for static picture. <br/>
    * <br/>
    * @param fps The new frame rate to use for static picture. <br/>
    */
    public int setStaticPictureFps(float fps);

    /**
    * Get the STUN server address being used. <br/>
    * <br/>
    * @return The STUN server address being used.   <br/>
    * @deprecated 04/09/2024 use {@link #getNatPolicy} or {@link AccountParams#getNatPolicy}<br/>
    * .<br/>
    */
    @Deprecated
    @Nullable
    public String getStunServer();

    /**
    * Set the STUN server address to use when the firewall policy is set to STUN. <br/>
    * <br/>
    * @param server The STUN server address to use.   <br/>
    * @deprecated 04/09/2024 use {@link #setNatPolicy} or {@link AccountParams#setNatPolicy}<br/>
    * .<br/>
    */
    @Deprecated
    public void setStunServer(@Nullable String server);

    /**
    * Returns a list of strings containing the file format types supported for call<br/>
    * recording. <br/>
    * <br/>
    * @return The supported formats, typically 'wav', 'mka', 'mkv', 'smff'.      <br/>
    */
    @NonNull
    public String[] getSupportedFileFormatsList();

    /**
    * Set the SIP supported tags. <br/>
    * <br/>
    * @param tags The SIP feature tags to set   <br/>
    */
    public void setSupportedTag(@Nullable String tags);

    /**
    * Gets the support level of the 100rel attribute. <br/>
    * <br/>
    * @return The 100 rel support level <br/>
    */
    public SupportLevel getTag100RelSupportLevel();

    /**
    * Defines what level of support is provided to the 100rel attribute. <br/>
    * <br/>
    * @param level support level of 100rel <br/>
    */
    public void setTag100RelSupportLevel(SupportLevel level);

    /**
    * Defines whether tcap lines are going to be merged if capability negotiation<br/>
    * (RFC5939) is supported. <br/>
    * <br/>
    * @param merge true to merge tcap lines with consecutive indexes; false<br/>
    * otherwise. <br/>
    */
    public void setTcapLineMergingEnabled(boolean merge);

    /**
    * Checks if tcap lines are going to the merged if the capability negotiation<br/>
    * (RFC5939) is supported or not. <br/>
    * <br/>
    * @return true if tcap lines with consecutive indexes are going to be merged;<br/>
    * false otherwise. <br/>
    */
    public boolean isTcapLinesMergingEnabled();

    /**
    * Returns the list of the available text payload types. <br/>
    * <br/>
    * @return A freshly allocated list of the available payload types.       <br/>
    */
    @NonNull
    public PayloadType[] getTextPayloadTypes();

    /**
    * Redefines the list of the available payload types. <br/>
    * <br/>
    * @param payloadTypes The new list of payload types.    <br/>
    */
    public void setTextPayloadTypes(@Nullable PayloadType[] payloadTypes);

    /**
    * Gets the UDP port used for text streaming. <br/>
    * <br/>
    * @return The UDP port used for text streaming <br/>
    */
    public int getTextPort();

    /**
    * Sets the UDP port used for text streaming. <br/>
    * <br/>
    * A value if -1 will request the system to allocate the local port randomly. This<br/>
    * is recommended in order to avoid firewall warnings. <br/>
    * @param port The UDP port to use for text streaming <br/>
    */
    public void setTextPort(int port);

    /**
    * Get the text port range from which is randomly chosen the UDP port used for<br/>
    * text streaming. <br/>
    * <br/>
    * @return a {@link Range} object     <br/>
    */
    @NonNull
    public Range getTextPortsRange();

    /**
    * Gets the TLS certificate. <br/>
    * <br/>
    * @return the TLS certificate or null if not set yet.   <br/>
    */
    @Nullable
    public String getTlsCert();

    /**
    * Sets a TLS certificate used for TLS authentication The certificate won't be<br/>
    * stored, you have to set it after each {@link Core} startup. <br/>
    * <br/>
    * @param tlsCert the TLS certificate.   <br/>
    */
    public void setTlsCert(@Nullable String tlsCert);

    /**
    * Gets the path to the TLS certificate file. <br/>
    * <br/>
    * @return the TLS certificate path or null if not set yet.   <br/>
    */
    @Nullable
    public String getTlsCertPath();

    /**
    * Sets a TLS certificate path used for TLS authentication The path will be stored<br/>
    * in the rc file and automatically restored on startup. <br/>
    * <br/>
    * @param tlsCertPath path to the TLS certificate.   <br/>
    */
    public void setTlsCertPath(@Nullable String tlsCertPath);

    /**
    * Gets the TLS key. <br/>
    * <br/>
    * @return the TLS key or null if not set yet.   <br/>
    */
    @Nullable
    public String getTlsKey();

    /**
    * Sets a TLS key used for TLS authentication The key won't be stored, you have to<br/>
    * set it after each {@link Core} startup. <br/>
    * <br/>
    * @param tlsKey the TLS key.   <br/>
    */
    public void setTlsKey(@Nullable String tlsKey);

    /**
    * Gets the path to the TLS key file. <br/>
    * <br/>
    * @return the TLS key path or null if not set yet.   <br/>
    */
    @Nullable
    public String getTlsKeyPath();

    /**
    * Sets a TLS key path used for TLS authentication The path will be stored in the<br/>
    * rc file and automatically restored on startup. <br/>
    * <br/>
    * @param tlsKeyPath path to the TLS key.   <br/>
    */
    public void setTlsKeyPath(@Nullable String tlsKeyPath);

    /**
    * Retrieves the port configuration used for each transport (udp, tcp, tls). <br/>
    * <br/>
    * A zero value port for a given transport means the transport is not used. A<br/>
    * value of LC_SIP_TRANSPORT_RANDOM (-1) means the port is to be chosen randomly<br/>
    * by the system. A value of LC_SIP_TRANSPORT_DONTBIND (-2) means that the socket<br/>
    * will not be bound explicitely, in other words liblinphone won't listen for<br/>
    * incoming connections at all. This mode is suitable for a pure client<br/>
    * application (ex: a mobile application). <br/>
    * @return A {@link Transports} structure with the configured ports     <br/>
    */
    @NonNull
    public Transports getTransports();

    /**
    * Sets the ports to be used for each of transport (UDP or TCP) A zero value port<br/>
    * for a given transport means the transport is not used. <br/>
    * <br/>
    * A value of LC_SIP_TRANSPORT_RANDOM (-1) means the port is to be choosen<br/>
    * randomly by the system. A value of LC_SIP_TRANSPORT_DONTBIND (-2) means that<br/>
    * the socket will not be bound explicitely, in other words liblinphone won't<br/>
    * listen for incoming connections at all. This mode is suitable for a pure client<br/>
    * application (ex: a mobile application). <br/>
    * @param transports A #LinphoneSipTransports structure giving the ports to use   <br/>
    * @return 0 <br/>
    */
    public int setTransports(@NonNull Transports transports);

    /**
    * Retrieves the real port number assigned for each sip transport (udp, tcp, tls). <br/>
    * <br/>
    * A zero value means that the transport is not activated. If<br/>
    * LC_SIP_TRANSPORT_RANDOM was passed to linphone_core_set_sip_transports, the<br/>
    * random port choosed by the system is returned. <br/>
    * @return A {@link Transports} structure with the ports being used     <br/>
    */
    @NonNull
    public Transports getTransportsUsed();

    /**
    * Gets tunnel instance if available. <br/>
    * <br/>
    * @return {@link Tunnel} or null if not available.   <br/>
    */
    @Nullable
    public Tunnel getTunnel();

    /**
    * Returns the global unread chat message count. <br/>
    * <br/>
    * @return The global unread chat message count. <br/>
    */
    public int getUnreadChatMessageCount();

    /**
    * Returns the unread chat message count for all active local address. <br/>
    * <br/>
    * (Primary contact + proxy configs.) <br/>
    * @return The unread chat message count. <br/>
    */
    public int getUnreadChatMessageCountFromActiveLocals();

    /**
    * Retrieve the maximum available upload bandwidth. <br/>
    * <br/>
    * This value was set by {@link #setUploadBandwidth}. <br/>
    * @return the upload bandiwdth in kbits/s, 0 for unknown. <br/>
    */
    public int getUploadBandwidth();

    /**
    * Sets maximum available upload bandwidth This is IP bandwidth, in kbit/s. <br/>
    * <br/>
    * This information is used by liblinphone together with remote side available<br/>
    * bandwidth signaled in SDP messages to properly configure audio & video codec's<br/>
    * output bitrate. By default, the download and upload bandwidth are unknowns (set<br/>
    * to zero), in which case adaptive algorithms are run during calls in order to<br/>
    * detect available bandwidth and adapt audio and video bitrate usage. see: {@link #enableAdaptiveRateControl}<br/>
    * .<br/>
    * @param bandwidth the bandwidth in kbits/s, 0 for unknown. <br/>
    */
    public void setUploadBandwidth(int bandwidth);

    /**
    * Gets audio packetization time linphone will send (in absence of requirement<br/>
    * from peer) A value of 0 stands for the current codec default packetization<br/>
    * time. <br/>
    * <br/>
    * @return the upload packetization time set <br/>
    */
    public int getUploadPtime();

    /**
    * Sets audio packetization time linphone will send (in absence of requirement<br/>
    * from peer) A value of 0 stands for the current codec default packetization<br/>
    * time. <br/>
    * <br/>
    * @param ptime the upload packetization time to set <br/>
    */
    public void setUploadPtime(int ptime);

    /**
    * Return the external ip address of router. <br/>
    * <br/>
    * In some cases the uPnP can have an external ip address but not a usable uPnP<br/>
    * (state different of Ok).<br/>
    * @return a null terminated string containing the external ip address. If the the<br/>
    * external ip address is not available return null.   <br/>
    */
    @Nullable
    public String getUpnpExternalIpaddress();

    /**
    * Return the internal state of uPnP. <br/>
    * <br/>
    * @return an LinphoneUpnpState. <br/>
    */
    public UpnpState getUpnpState();

    /**
    * Gets whether linphone is currently streaming audio from and to files, rather<br/>
    * than using the soundcard. <br/>
    * <br/>
    * @return A boolean value representing whether linphone is streaming audio from<br/>
    * and to files or not. <br/>
    */
    public boolean getUseFiles();

    /**
    * Ask the core to stream audio from and to files, instead of using the soundcard. <br/>
    * <br/>
    * @param yesno A boolean value asking to stream audio from and to files or not. <br/>
    */
    public void setUseFiles(boolean yesno);

    /**
    * Indicates whether SIP INFO can be used to send digits. <br/>
    * <br/>
    * @return A boolean value telling whether SIP INFO is used to send digits <br/>
    */
    public boolean getUseInfoForDtmf();

    /**
    * Sets whether SIP INFO method can be used to send digits. <br/>
    * <br/>
    * This non-standard but common practice. <br/>
    * @param useInfo A boolean value telling whether to use SIP INFO to send digits <br/>
    */
    public void setUseInfoForDtmf(boolean useInfo);

    /**
    * Indicates whether RFC2833/RFC4633 can be used to send digits. <br/>
    * <br/>
    * @return A boolean value telling whether RFC2833 is used to send digits <br/>
    */
    public boolean getUseRfc2833ForDtmf();

    /**
    * Sets whether RFC2833 or RFC4633 can be to be used to send digits. <br/>
    * <br/>
    * This is preferred method to reliabily transmit DTMFs codes. There are two<br/>
    * settings relevant to dtmf sending: {@link #setUseRfc2833ForDtmf} and {@link #setUseInfoForDtmf}<br/>
    * ; Resulting in 4 cases:<br/>
    * @param useRfc2833 A boolean value telling whether to use RFC2833 to send digits <br/>
    */
    public void setUseRfc2833ForDtmf(boolean useRfc2833);

    /**
    * Gets the user-agent as a string. <br/>
    * <br/>
    * @return liblinphone's user agent as a string.   <br/>
    */
    @NonNull
    public String getUserAgent();

    /**
    * Get the path to the directory storing the user's certificates. <br/>
    * <br/>
    * @return The path to the directory storing the user's certificates.   <br/>
    */
    @Nullable
    public String getUserCertificatesPath();

    /**
    * Set the path to the directory storing the user's x509 certificates (used by<br/>
    * dtls) <br/>
    * <br/>
    * @param path The path to the directory to use to store the user's certificates. <br/>
    *  <br/>
    */
    public void setUserCertificatesPath(@Nullable String path);

    /**
    * Gets whether the device will vibrate while an incoming call is ringing (Android<br/>
    * only). <br/>
    * <br/>
    * @return true if the device will vibrate (if possible), false otherwise <br/>
    */
    public boolean isVibrationOnIncomingCallEnabled();

    /**
    * Enable vibration will incoming call is ringing (Android only). <br/>
    * <br/>
    * @param enable true to enable the vibration on incoming call, false otherwise <br/>
    */
    public void setVibrationOnIncomingCallEnabled(boolean enable);

    /**
    * Get the default policy for video. <br/>
    * <br/>
    * See {@link #setVideoActivationPolicy} for more details. <br/>
    * @return The currently used video policy   <br/>
    */
    @NonNull
    public VideoActivationPolicy getVideoActivationPolicy();

    /**
    * Sets the default policy for video. <br/>
    * <br/>
    * This policy defines whether:<br/>
    * @param policy The {@link VideoActivationPolicy} to use   <br/>
    */
    public void setVideoActivationPolicy(@NonNull VideoActivationPolicy policy);

    /**
    * Tells whether the video adaptive jitter compensation is enabled. <br/>
    * <br/>
    * @return true if the video adaptive jitter compensation is enabled, false<br/>
    * otherwise. <br/>
    */
    public boolean isVideoAdaptiveJittcompEnabled();

    /**
    * Enables or disables the video adaptive jitter compensation. <br/>
    * <br/>
    * @param enable true to enable the video adaptive jitter compensation, false to<br/>
    * disable it. <br/>
    */
    public void setVideoAdaptiveJittcompEnabled(boolean enable);

    /**
    * Tells whether video capture is enabled. <br/>
    * <br/>
    * @return true if video capture is enabled, false if disabled. <br/>
    */
    public boolean isVideoCaptureEnabled();

    /**
    * Enable or disable video capture. <br/>
    * <br/>
    * This function does not have any effect during calls. It just indicates the<br/>
    * {@link Core} to initiate future calls with video capture or not. <br/>
    * @param enable true to enable video capture, false to disable it. <br/>
    */
    public void setVideoCaptureEnabled(boolean enable);

    /**
    * Gets the current priority policy for video codecs (payload types). <br/>
    * <br/>
    * See {@link CodecPriorityPolicy} for more details. <br/>
    * @return the current {@link CodecPriorityPolicy} <br/>
    */
    public CodecPriorityPolicy getVideoCodecPriorityPolicy();

    /**
    * Sets the priority policy for video codecs (payload types). <br/>
    * <br/>
    * Since version 5.3, the default value is {@link CodecPriorityPolicy#Auto} unless<br/>
    * the core's configuration file describes a list of video payload type to use.<br/>
    * This is to preserve backward compatibility for upgrading applications. See<br/>
    * {@link CodecPriorityPolicy} for more details. <br/>
    * @param policy the {@link CodecPriorityPolicy} to apply <br/>
    */
    public void setVideoCodecPriorityPolicy(CodecPriorityPolicy policy);

    /**
    * Returns the name of the currently active video device. <br/>
    * <br/>
    * @return The name of the currently active video device.   <br/>
    */
    @Nullable
    public String getVideoDevice();

    /**
    * Sets the active video device. <br/>
    * <br/>
    * @param id The name of the video device to use as returned by<br/>
    * linphone_core_get_video_devices   <br/>
    */
    public int setVideoDevice(@Nullable String id);

    /**
    * Gets the list of the available video capture devices. <br/>
    * <br/>
    * @return An unmodifiable array of strings contanining the names of the available<br/>
    * video capture devices that is null terminated.      <br/>
    */
    @NonNull
    public String[] getVideoDevicesList();

    /**
    * Tells whether video display is enabled. <br/>
    * <br/>
    * @return true if video display is enabled, false if disabled. <br/>
    */
    public boolean isVideoDisplayEnabled();

    /**
    * Enable or disable video display. <br/>
    * <br/>
    * This function does not have any effect during calls. It just indicates the<br/>
    * {@link Core} to initiate future calls with video display or not. <br/>
    * @param enable true to enable video display, false to disable it. <br/>
    */
    public void setVideoDisplayEnabled(boolean enable);

    /**
    * Gets the name of the mediastreamer2 engine (filter) used for rendering video. <br/>
    * <br/>
    * @return The currently selected video display filter.   <br/>
    */
    @Nullable
    public String getVideoDisplayFilter();

    /**
    * Sets the name of the mediastreamer2 engine (filter) to be used for rendering<br/>
    * video. <br/>
    * <br/>
    * @param filterName the filter name to use or null to use default.   <br/>
    */
    public void setVideoDisplayFilter(@Nullable String filterName);

    /**
    * Gets the DSCP field for outgoing video streams. <br/>
    * <br/>
    * The DSCP defines the quality of service in IP packets. <br/>
    * @return The current DSCP value <br/>
    */
    public int getVideoDscp();

    /**
    * Sets the DSCP field for outgoing video streams. <br/>
    * <br/>
    * The DSCP defines the quality of service in IP packets. When RTP bundling is<br/>
    * negociated during the call (see {@link #enableRtpBundle}), the video packets<br/>
    * are sent through the audio RTP/UDP connection, which leaves the video dscp<br/>
    * setting wihtout effect. note: It is usually useless or a bad idea to try to<br/>
    * play with DSCP bits unless having full control on the network. <br/>
    * warning: Setting the DSCP bits is more or less well supported by operating<br/>
    * systems and sometimes requires to disable IPv6. <br/>
    * @param dscp The DSCP value to set <br/>
    */
    public void setVideoDscp(int dscp);

    /**
    * Returns true if either capture or display is enabled, false otherwise. <br/>
    * <br/>
    * same as ( {@link #videoCaptureEnabled} | {@link #videoDisplayEnabled} )<br/>
    * @return true if either capture or display is enabled, false otherwise. <br/>
    */
    public boolean isVideoEnabled();

    /**
    * Returns the nominal video jitter buffer size in milliseconds. <br/>
    * <br/>
    * @return The nominal video jitter buffer size in milliseconds <br/>
    */
    public int getVideoJittcomp();

    /**
    * Sets the nominal video jitter buffer size in milliseconds. <br/>
    * <br/>
    * The value takes effect immediately for all running and pending calls, if any. A<br/>
    * value of 0 disables the jitter buffer.<br/>
    * @param milliseconds the jitter buffer size in milliseconds <br/>
    */
    public void setVideoJittcomp(int milliseconds);

    /**
    * Use to get multicast address to be used for video stream. <br/>
    * <br/>
    * @return an ipv4/6 multicast address, or default value.   <br/>
    */
    @Nullable
    public String getVideoMulticastAddr();

    /**
    * Use to set multicast address to be used for video stream. <br/>
    * <br/>
    * @param ip an ipv4/6 multicast address.   <br/>
    * @return 0 in case of success <br/>
    */
    public int setVideoMulticastAddr(@Nullable String ip);

    /**
    * Use to get multicast state of video stream. <br/>
    * <br/>
    * @return true if subsequent calls will propose multicast ip set by {@link #setVideoMulticastAddr}<br/>
    */
    public boolean isVideoMulticastEnabled();

    /**
    * Use to enable multicast rtp for video stream. <br/>
    * <br/>
    * If enabled, outgoing calls put a multicast address from {@link #getVideoMulticastAddr}<br/>
    * into video cline. In case of outgoing call video stream is sent to this<br/>
    * multicast address. For incoming calls behavior is unchanged. <br/>
    * @param yesno if yes, subsequent outgoing calls will propose multicast ip set by<br/>
    * {@link #setVideoMulticastAddr} <br/>
    */
    public void setVideoMulticastEnabled(boolean yesno);

    /**
    * Use to get multicast ttl to be used for video stream. <br/>
    * <br/>
    * @return a time to leave value <br/>
    */
    public int getVideoMulticastTtl();

    /**
    * Use to set multicast ttl to be used for video stream. <br/>
    * <br/>
    * @param ttl value or -1 if not used. [0..255] default value is 1 <br/>
    * @return 0 in case of success <br/>
    */
    public int setVideoMulticastTtl(int ttl);

    /**
    * Returns the list of the available video payload types (codecs). <br/>
    * <br/>
    * @return A freshly allocated list of the available payload types.       <br/>
    */
    @NonNull
    public PayloadType[] getVideoPayloadTypes();

    /**
    * Redefines the list of the available video payload types (codecs). <br/>
    * <br/>
    * Calling this function if the video codec priority policy is<br/>
    * LinphoneCodecPriorityPolicyAuto turns video codec priority policy to basic<br/>
    * scheme, since application is not supposed to control the order of video codecs<br/>
    * when LinphoneCodecPriorityPolicyAuto is selected, by definition. see: {@link #setVideoCodecPriorityPolicy}<br/>
    * @param payloadTypes The new list of codecs. The core does not take ownership on<br/>
    * it.    <br/>
    */
    public void setVideoPayloadTypes(@Nullable PayloadType[] payloadTypes);

    /**
    * Gets the UDP port used for video streaming. <br/>
    * <br/>
    * @return The UDP port used for video streaming <br/>
    */
    public int getVideoPort();

    /**
    * Sets the UDP port used for video streaming. <br/>
    * <br/>
    * A value of -1 will request the system to allocate the local port randomly. This<br/>
    * is recommended in order to avoid firewall warnings. <br/>
    * @param port The UDP port to use for video streaming <br/>
    */
    public void setVideoPort(int port);

    /**
    * Get the video port range from which is randomly chosen the UDP port used for<br/>
    * video streaming. <br/>
    * <br/>
    * @return a {@link Range} object     <br/>
    */
    @NonNull
    public Range getVideoPortsRange();

    /**
    * Get the video preset used for video calls. <br/>
    * <br/>
    * @return The name of the video preset used for video calls (can be null if the<br/>
    * default video preset is used).    <br/>
    */
    @Nullable
    public String getVideoPreset();

    /**
    * Set the video preset to be used for video calls. <br/>
    * <br/>
    * @param preset The name of the video preset to be used (can be null to use the<br/>
    * default video preset).   <br/>
    */
    public void setVideoPreset(@Nullable String preset);

    /**
    * Tells whether video preview is enabled. <br/>
    * <br/>
    * @return A boolean value telling whether video preview is enabled <br/>
    */
    public boolean isVideoPreviewEnabled();

    /**
    * Controls video preview enablement. <br/>
    * <br/>
    * @param enable A boolean value telling whether the video preview is to be shown<br/>
    * Video preview refers to the action of displaying the local webcam image to the<br/>
    * user while not in call. <br/>
    */
    public void setVideoPreviewEnabled(boolean enable);

    /**
    * Enable or disable video source reuse when switching from preview to actual<br/>
    * video call. <br/>
    * <br/>
    * This source reuse is useful when you always display the preview, even before<br/>
    * calls are initiated. By keeping the video source for the transition to a real<br/>
    * video call, you will smooth out the source close/reopen cycle.<br/>
    * This function does not have any effect during calls. It just indicates the<br/>
    * {@link Core} to initiate future calls with video source reuse or not. Also, at<br/>
    * the end of a video call, the source will be closed whatsoever for now. <br/>
    * @param enable true to enable video source reuse. false to disable it for<br/>
    * subsequent calls. <br/>
    */
    public void setVideoSourceReuseEnabled(boolean enable);

    /**
    * Tells whether Wifi only mode is enabled or not. <br/>
    * <br/>
    * warning: Only works for Android platform. <br/>
    * @return A boolean value telling whether Wifi only mode is enabled or not <br/>
    */
    public boolean isWifiOnlyEnabled();

    /**
    * Turns Wifi only mode on or off. <br/>
    * <br/>
    * If enabled, app won't register when active network isn't WiFi or Ethernet.<br/>
    * warning: Only works for Android platform. <br/>
    * @param enable A boolean value telling whether to enable IPv6 support <br/>
    */
    public void setWifiOnlyEnabled(boolean enable);

    /**
    * Checks if RTP port is set to 0 when a stream is inactive. <br/>
    * <br/>
    * @return true if the RTP port is set to 0 if the stream direction is inactive;<br/>
    * false otherwise. <br/>
    */
    public boolean isZeroRtpPortForStreamInactiveEnabled();

    /**
    * Defines whether RTP port is set to 0 when a stream is inactive. <br/>
    * <br/>
    * @param enable true to set the RTP port to 0 if the stream direction is<br/>
    * inactive; false otherwise. <br/>
    */
    public void setZeroRtpPortForStreamInactiveEnabled(boolean enable);

    /**
    * Return the list of the available ZRTP key agreement algorithns. <br/>
    * <br/>
    * @return A freshly allocated list of the available algorithms. The list must be<br/>
    * destroyed with bctbx_list_free() after usage. The elements of the list haven't<br/>
    * to be unref.      <br/>
    */
    @NonNull
    public ZrtpKeyAgreement[] getZrtpAvailableKeyAgreementList();

    /**
    * Checks if the ZRTP go clear is enabled or not. <br/>
    * <br/>
    * @return true if ZTRP go clear is enabled; false otherwise. <br/>
    */
    public boolean isZrtpGoClearEnabled();

    /**
    * Defines whether ZRTP go clear is enabled. <br/>
    * <br/>
    * @param enabled true to enable ZRTP go clear; false otherwise. <br/>
    */
    public void setZrtpGoClearEnabled(boolean enabled);

    /**
    * Return the ordonated list of the ZRTP key agreement algorithns currently<br/>
    * configured. <br/>
    * <br/>
    * @return A freshly allocated list of the available algorithms. The list must be<br/>
    * destroyed with bctbx_list_free() after usage. The elements of the list haven't<br/>
    * to be unref.      <br/>
    */
    @NonNull
    public ZrtpKeyAgreement[] getZrtpKeyAgreementList();

    /**
    * Redefine the list of prefered ZRTP key agreement algorithms. <br/>
    * <br/>
    * @param keyAgreements The new list of key agreements algorithms, in order of<br/>
    * preference. The core does not take ownership on it. The setting accepts a<br/>
    * maximum of 7 algorithms, if the list is longer, only the first 7 available<br/>
    * algorithms are selected    <br/>
    */
    public void setZrtpKeyAgreementSuites(@Nullable ZrtpKeyAgreement[] keyAgreements);

    /**
    * Gets the path to the file storing the zrtp secrets cache. <br/>
    * <br/>
    * @return The path to the file storing the zrtp secrets cache.   <br/>
    */
    @Nullable
    public String getZrtpSecretsFile();

    /**
    * Sets the path to the file storing the zrtp secrets cache. <br/>
    * <br/>
    * @param file The path to the file to use to store the zrtp secrets cache.   <br/>
    */
    public void setZrtpSecretsFile(@Nullable String file);

    /**
    * This method is used to abort a user authentication request initiated by {@link Core}<br/>
    * from the authentication_requested callback of {@link CoreListener}. <br/>
    * <br/>
    * note: this function currently does not take into account the 'info' parameter.<br/>
    * All pending authentication requests are aborted. <br/>
    * @param info the {@link AuthInfo} for which to abort authentication   <br/>
    */
    public void abortAuthentication(@Nullable AuthInfo info);

    /**
    * Special function to indicate if the audio session is activated. <br/>
    * <br/>
    * Must be called when ProviderDelegate of the callkit notifies that the audio<br/>
    * session is activated or deactivated. <br/>
    * @param activated true to activate the audio session, false to disable it. <br/>
    */
    public void activateAudioSession(boolean activated);

    /**
    * Adds an account. <br/>
    * <br/>
    * This will start registration on the proxy, if registration is enabled. <br/>
    * @param account the {@link Account} to add   <br/>
    * @return 0 if successful, -1 otherwise <br/>
    */
    public int addAccount(@NonNull Account account);

    /**
    * Adds all calls into the conference. <br/>
    * <br/>
    * If no conference is running a new internal conference context is created and<br/>
    * all current calls are added to it. <br/>
    * @return 0 if succeeded. Negative number if failed <br/>
    * warning: This function guarantees that the local endpoint is added to the<br/>
    * conference. <br/>
    * @deprecated 23/01/2025 Use {@link Conference#inviteParticipants} instead. <br/>
    */
    @Deprecated
    public int addAllToConference();

    /**
    * Adds authentication information to the {@link Core}. <br/>
    * <br/>
    * These nformation will be used during all SIP or HTTP transactions that require<br/>
    * authentication. <br/>
    * @param info The {@link AuthInfo} to add.   <br/>
    */
    public void addAuthInfo(@NonNull AuthInfo info);

    /**
    * Add support for the specified content type. <br/>
    * <br/>
    * It is the application responsibility to handle it correctly afterwards. <br/>
    * @param contentType The content type to add support for   <br/>
    */
    public void addContentTypeSupport(@NonNull String contentType);

    /**
    * Add a friend list. <br/>
    * <br/>
    * @param list {@link FriendList} object   <br/>
    */
    public void addFriendList(@NonNull FriendList list);

    /**
    * Add or update a LDAP server and save it to the configuration. <br/>
    * <br/>
    * @param ldap The LDAP to add/update.   <br/>
    * @deprecated 18/11/2024 use {@link #addRemoteContactDirectory} instead. <br/>
    */
    @Deprecated
    public void addLdap(@NonNull Ldap ldap);

    /**
    * Add the given linphone specs to the list of functionalities the linphone client<br/>
    * supports. <br/>
    * <br/>
    * see: {@link #setLinphoneSpecsList} <br/>
    * @param spec The spec to add   <br/>
    */
    public void addLinphoneSpec(@NonNull String spec);

    /**
    * Add an extra header for retrieving the remote provisioning (check {@link #setProvisioningUri}<br/>
    * ). <br/>
    * <br/>
    * This can also be set from configuration file or factory config file, from[misc]<br/>
    * section, item "config-uri-headers_X" where X is the index of the header<br/>
    * starting by 0. <br/>
    * @param headerName the header to use when downloading the configuration.   <br/>
    * @param value the value to use when downloading the configuration.   <br/>
    */
    public void addProvisioningHeader(@NonNull String headerName, @NonNull String value);

    /**
    * Add a proxy configuration. <br/>
    * <br/>
    * This will start registration on the proxy, if registration is enabled. <br/>
    * @param config the {@link ProxyConfig} to add   <br/>
    * @return 0 if successful, -1 otherwise <br/>
    * @deprecated 04/09/2024 Use {@link #addAccount} <br/>
    */
    @Deprecated
    public int addProxyConfig(@NonNull ProxyConfig config);

    /**
    * Adds a {@link RemoteContactDirectory} object previously created to the Core, to<br/>
    * be used later by {@link MagicSearch} to query contacts using either LDAP or<br/>
    * CardDAV. <br/>
    * <br/>
    * @param remoteContactDirectory the newly created {@link RemoteContactDirectory}<br/>
    * to add.   <br/>
    */
    public void addRemoteContactDirectory(@NonNull RemoteContactDirectory remoteContactDirectory);

    /**
    * This function controls signaling features supported by the core. <br/>
    * <br/>
    * They are typically included in a SIP Supported header. <br/>
    * @param tag The feature tag name   <br/>
    */
    public void addSupportedTag(@NonNull String tag);

    /**
    * Adds a participant to the conference. <br/>
    * <br/>
    * If no conference is going on a new internal conference context is created and<br/>
    * the participant is added to it. <br/>
    * @param call The current call with the participant to add   <br/>
    * @return 0 if succeeded. Negative number if failed <br/>
    * @deprecated 23/01/2025 Use {@link Conference#addParticipant} instead. <br/>
    */
    @Deprecated
    public int addToConference(@NonNull Call call);

    /**
    * Special function to indicate if the audio route is changed. <br/>
    * <br/>
    * Must be called in the callback of AVAudioSessionRouteChangeNotification. <br/>
    * @deprecated 07/01/2020 now handled in the linphone SDK directly <br/>
    */
    @Deprecated
    public void audioRouteChanged();

    /**
    * Check whether ringing of calls is disabled. <br/>
    * <br/>
    * @return true if call ringing is disabled <br/>
    */
    public boolean callRingingDisabled();

    /**
    * Gets the default ephemeral message mode. <br/>
    * <br/>
    * @return the default ephemeral message mode {@link ChatRoom#EphemeralMode} <br/>
    */
    public ChatRoom.EphemeralMode chatRoomGetDefaultEphemeralMode();

    /**
    * Sets the default ephemeral message mode. <br/>
    * <br/>
    * @param mode default ephemeral message mode {@link ChatRoom#EphemeralMode} <br/>
    */
    public void chatRoomSetDefaultEphemeralMode(ChatRoom.EphemeralMode mode);

    /**
    * Asynchronously checks if a new version of the application is available from a<br/>
    * well-known http server URI given by {@link Core} 's configuration. <br/>
    * <br/>
    * The result of the check is given through the {@link CoreListener} interface,<br/>
    * see linphone_core_cbs_set_version_update_check_result_received. The http URI<br/>
    * has to be given in [misc] section as key 'version_check_url_root'. The<br/>
    * subdirectory is appended to this root URI, per platform, and a "VERSION" file<br/>
    * is fetched. For example:<br/>
    */
    public void checkForUpdate(String currentVersion);

    /**
    * Erases all accounts from config. <br/>
    * <br/>
    */
    public void clearAccounts();

    /**
    * Clears all authentication information. <br/>
    * <br/>
    */
    public void clearAllAuthInfo();

    /**
    * Erases the call log list. <br/>
    * <br/>
    */
    public void clearCallLogs();

    /**
    * Erases all LDAP from the configuration. <br/>
    * <br/>
    * @deprecated 18/11/2024 use {@link #removeRemoteContactDirectory} instead.<br/>
    */
    @Deprecated
    public void clearLdaps();

    /**
    * Clear all headers that were added with {@link #addProvisioningHeader}. <br/>
    * <br/>
    */
    public void clearProvisioningHeaders();

    /**
    * Erase all proxies from config. <br/>
    * <br/>
    * @deprecated 04/09/2024 Use {@link #clearAccounts} <br/>
    */
    @Deprecated
    public void clearProxyConfig();

    /**
    * Forces a flush of the config to disk. <br/>
    * <br/>
    * @return 0 if successful, -1 otherwise <br/>
    */
    public int configSync();

    /**
    * Special function to configure audio session with default settings. <br/>
    * <br/>
    * Must be called in ProviderDelegate's callbacks when answer an incoming call and<br/>
    * start an outgoing call. <br/>
    */
    public void configureAudioSession();

    /**
    * Creates an account using given parameters, see {@link #createAccountParams}. <br/>
    * <br/>
    * Once created, the account must be added to the {@link Core} in order to be used<br/>
    * for registration, calls, messages etc. Use {@link #addAccount} to add it to the<br/>
    * {@link Core}. <br/>
    * @param params {@link AccountParams} object   <br/>
    * @return {@link Account} with default values set   <br/>
    */
    @NonNull
    public Account createAccount(@NonNull AccountParams params);

    /**
    * Create a {@link AccountCreator} and set Linphone Request callbacks. <br/>
    * <br/>
    * @param xmlrpcUrl The URL to the XML-RPC server.   <br/>
    * @return The new {@link AccountCreator} object.  <br/>
    * @deprecated 04/09/2024 : The {@link AccountCreator} interface is replaced by<br/>
    * the {@link AccountManagerServices} interface. <br/>
    */
    @Deprecated
    @NonNull
    public AccountCreator createAccountCreator(@Nullable String xmlrpcUrl);

    /**
    * Creates a {@link AccountManagerServices}. <br/>
    * <br/>
    * @return The new {@link AccountManagerServices} object.   <br/>
    */
    @NonNull
    public AccountManagerServices createAccountManagerServices();

    /**
    * Create an account params using default values from Linphone core. <br/>
    * <br/>
    * @return {@link AccountParams} with default values set   <br/>
    */
    @NonNull
    public AccountParams createAccountParams();

    /**
    * Creates a {@link Address} object by parsing the user supplied address, given as<br/>
    * a string. <br/>
    * <br/>
    * @param address String containing the user supplied address   <br/>
    * @return The created {@link Address} object   <br/>
    * @deprecated 04/06/2024 use {@link Factory#createAddress}.<br/>
    */
    @Deprecated
    @Nullable
    public Address createAddress(@Nullable String address);

    /**
    * Creates a fake {@link CallLog}. <br/>
    * <br/>
    * @param from {@link Address} of caller   <br/>
    * @param to {@link Address} of callee   <br/>
    * @param dir {@link Call#Dir} of call <br/>
    * @param duration call length in seconds <br/>
    * @param startTime timestamp of call start time <br/>
    * @param connectedTime timestamp of call connection <br/>
    * @param status {@link Call#Status} of call <br/>
    * @param videoEnabled whether video was enabled or not for this call <br/>
    * @param quality call quality <br/>
    * @return a {@link CallLog} object   <br/>
    */
    @NonNull
    public CallLog createCallLog(@NonNull Address from, @NonNull Address to, Call.Dir dir, int duration, long startTime, long connectedTime, Call.Status status, boolean videoEnabled, float quality);

    /**
    * Creates a {@link CallParams} suitable for {@link #inviteWithParams}, {@link Call#acceptWithParams}<br/>
    * , {@link Call#acceptEarlyMediaWithParams}, {@link Call#update} or<br/>
    * linphone_call_accept_update_with_params(). <br/>
    * <br/>
    * The parameters are initialized according to the current {@link Core}<br/>
    * configuration and the current state of the call if any. In order to create a<br/>
    * {@link CallParams} for an already created call, the call argument must not be<br/>
    * null. <br/>
    * @param call {@link Call} for which the parameters are to be built, or null in<br/>
    * the case where the parameters are to be used for a new outgoing call.   <br/>
    * @return A new {@link CallParams} object.   <br/>
    */
    @Nullable
    public CallParams createCallParams(@Nullable Call call);

    /**
    * Creates a new CardDAV server params object that may be used later by {@link MagicSearch}<br/>
    * to query contacts. <br/>
    * <br/>
    * @return a new {@link CardDavParams} object to configure, and then use it to<br/>
    * create a {@link RemoteContactDirectory} using {@link #createCardDavRemoteContactDirectory}<br/>
    * .   <br/>
    */
    @NonNull
    public CardDavParams createCardDavParams();

    /**
    * Creates a new CardDAV server params object that may be used later by {@link MagicSearch}<br/>
    * to query contacts. <br/>
    * <br/>
    * @param params the {@link CardDavParams} to configure this remote contact<br/>
    * directory.   <br/>
    * @return a new {@link RemoteContactDirectory} object to configure, and then add<br/>
    * using {@link #addRemoteContactDirectory}.   <br/>
    */
    @NonNull
    public RemoteContactDirectory createCardDavRemoteContactDirectory(@NonNull CardDavParams params);

    /**
    * Create a SIP conference scheduler that can be used to create client conferences<br/>
    * for now or later and then send conference info as an ICS through chat. <br/>
    * <br/>
    * A CCMPConferenceScheduler creates a conference on a server by using the CCMP<br/>
    * protocol <br/>
    * @param account The {@link Account} to use in the {@link ConferenceScheduler}.   <br/>
    * @return A pointer on the freshly created {@link ConferenceScheduler}.   <br/>
    */
    @NonNull
    public ConferenceScheduler createCcmpConferenceScheduler(@Nullable Account account);

    /**
    * Create a chat room. <br/>
    * <br/>
    * @param params The chat room creation parameters {@link ConferenceParams}   <br/>
    * @param participants The initial list of participants of the chat room.    <br/>
    * @return The newly created chat room (can be an existing one if backend is<br/>
    * Basic) or null.   <br/>
    */
    @Nullable
    public ChatRoom createChatRoom(@NonNull ConferenceParams params, @NonNull Address[] participants);

    /**
    * Create a chat room. <br/>
    * <br/>
    * @param params The chat room creation parameters {@link ChatRoomParams}   <br/>
    * @param localAddr {@link Address} representing the local proxy configuration to<br/>
    * use for the chat room creation    <br/>
    * @param subject The subject of the group chat room   <br/>
    * @param participants The initial list of participants of the chat room    <br/>
    * @return The newly created chat room.   <br/>
    * @deprecated 02/07/2020, use {@link #createChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom createChatRoom(@NonNull ChatRoomParams params, @NonNull Address localAddr, @NonNull String subject, @NonNull Address[] participants);

    /**
    * Create a chat room. <br/>
    * <br/>
    * @param params The chat room creation parameters {@link ChatRoomParams}   <br/>
    * @param subject The subject of the group chat room   <br/>
    * @param participants The initial list of participants of the chat room.    <br/>
    * @return The newly created chat room.   <br/>
    * @deprecated 02/07/2020, use {@link #createChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom createChatRoom(@NonNull ChatRoomParams params, @NonNull String subject, @NonNull Address[] participants);

    /**
    * <br/>
    * @param subject The subject of the group chat room   <br/>
    * @param participants The initial list of participants of the chat room.    <br/>
    * @return The newly created chat room.   <br/>
    * @deprecated 02/07/2020, use {@link #createChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom createChatRoom(@NonNull String subject, @NonNull Address[] participants);

    /**
    * <br/>
    * @param params The chat room creation parameters {@link ChatRoomParams}   <br/>
    * @param localAddr {@link Address} representing the local proxy configuration to<br/>
    * use for the chat room creation    <br/>
    * @param participant {@link Address} representing the initial participant to add<br/>
    * to the chat room   <br/>
    * @return The newly created chat room.   <br/>
    * @deprecated 02/07/2020, use {@link #createChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom createChatRoom(@NonNull ChatRoomParams params, @NonNull Address localAddr, @NonNull Address participant);

    /**
    * <br/>
    * @param participant {@link Address} representing the initial participant to add<br/>
    * to the chat room   <br/>
    * @return The newly created chat room.   <br/>
    * @deprecated 02/07/2020, use {@link #createChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom createChatRoom(@NonNull Address participant);

    /**
    * Create a chat room. <br/>
    * <br/>
    * @param params The chat room creation parameters {@link ChatRoomParams}   <br/>
    * @param localAddr {@link Address} of a local {@link Account} identity or null   <br/>
    * @param participants The initial list of participants of the chat room.    <br/>
    * @return The newly created chat room (can be an existing one if backend is<br/>
    * Basic) or null.   <br/>
    * @deprecated 22/10/2024, use {@link #createChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom createChatRoom(@NonNull ChatRoomParams params, @Nullable Address localAddr, @NonNull Address[] participants);

    /**
    * Create a client-side group chat room. <br/>
    * <br/>
    * When calling this function the chat room is only created at the client-side and<br/>
    * is empty. You need to call {@link ChatRoom#addParticipants} to create at the<br/>
    * server side and add participants to it. Also, the created chat room will not be<br/>
    * a one-to-one chat room even if {@link ChatRoom#addParticipants} is called with<br/>
    * only one participant.<br/>
    * @param subject The subject of the group chat room   <br/>
    * @param fallback Boolean value telling whether we should plan on being able to<br/>
    * fallback to a basic chat room if the client-side group chat room creation fails <br/>
    * @return The newly created client-side group chat room.   <br/>
    * @deprecated 02/07/2020, use {@link #createChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom createClientGroupChatRoom(@NonNull String subject, boolean fallback);

    /**
    * Create a client-side group chat room. <br/>
    * <br/>
    * When calling this function the chat room is only created at the client-side and<br/>
    * is empty. You need to call {@link ChatRoom#addParticipants} to create at the<br/>
    * server side and add participants to it. Also, the created chat room will not be<br/>
    * a one-to-one chat room even if {@link ChatRoom#addParticipants} is called with<br/>
    * only one participant.<br/>
    * @param subject The subject of the group chat room   <br/>
    * @param fallback Boolean value telling whether we should plan on being able to<br/>
    * fallback to a basic chat room if the client-side group chat room creation fails <br/>
    * @param encrypted Boolean value telling whether we should apply encryption or<br/>
    * not on chat messages sent and received on this room. <br/>
    * @return The newly created client-side group chat room.   <br/>
    * @deprecated 02/07/2020, use {@link #createChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom createClientGroupChatRoom(@NonNull String subject, boolean fallback, boolean encrypted);

    /**
    * Creates some default conference parameters for instanciating a conference with<br/>
    * {@link #createConferenceWithParams}. <br/>
    * <br/>
    * @param conference {@link Conference} for which the parameters are to be build,<br/>
    * or null in the case where the parameters are to be used for a new conference.   <br/>
    * @return a {@link ConferenceParams} object.   <br/>
    */
    @NonNull
    public ConferenceParams createConferenceParams(@Nullable Conference conference);

    /**
    * Create a conference scheduler that can be used to schedule conferences on a<br/>
    * client conference service and then send conference information invitation as an<br/>
    * ICS object through chat. <br/>
    * <br/>
    * @return A pointer on the freshly created {@link ConferenceScheduler}.   <br/>
    * @deprecated 23/07/2024 Use {@link #createConferenceScheduler} or {@link #createConferenceSchedulerWithType}<br/>
    * instead. <br/>
    */
    @Deprecated
    @NonNull
    public ConferenceScheduler createConferenceScheduler();

    /**
    * Create a conference scheduler that can be used to create client conferences for<br/>
    * now or later and then send conference info as an ICS through chat. <br/>
    * <br/>
    * A SipConferenceScheduler is created if the {@link Account} has not defined the<br/>
    * URL of the CCMP server, other it will create a CCMPConferenceServer <br/>
    * @param account The {@link Account} to use in the {@link ConferenceScheduler}.   <br/>
    * @return A pointer on the freshly created {@link ConferenceScheduler}.   <br/>
    */
    @NonNull
    public ConferenceScheduler createConferenceScheduler(@Nullable Account account);

    /**
    * Create a conference scheduler that can be used to create client conferences for<br/>
    * now or later and then send conference info as an ICS through chat by specifying<br/>
    * its type. <br/>
    * <br/>
    * @param account The {@link Account} to use in the {@link ConferenceScheduler}.   <br/>
    * @param schedulingType The type of the {@link ConferenceScheduler}. <br/>
    * @return A pointer on the freshly created {@link ConferenceScheduler}.   <br/>
    */
    @NonNull
    public ConferenceScheduler createConferenceSchedulerWithType(@Nullable Account account, ConferenceScheduler.Type schedulingType);

    /**
    * Create a conference. <br/>
    * <br/>
    * Local or client conference is determinated from the 'conference_type' variable<br/>
    * in the 'misc' section of the configuration, or by the factory address<br/>
    * parameter. See {@link ConferenceParams#setConferenceFactoryAddress} for more<br/>
    * details. <br/>
    * @param params Parameters of the conference. See {@link ConferenceParams}.   <br/>
    * @return A pointer on the freshly created conference {@link Conference}. That<br/>
    * object will be automatically freed by the core after calling {@link #terminateConference}<br/>
    * .   <br/>
    * warning: To guarantee the backward comatibility, this method will assign the<br/>
    * created conference to the conference context held by the core. Nonetheless<br/>
    * starting from release 5.4, the conference context will be override at every<br/>
    * conference created by calling this method <br/>
    */
    @Nullable
    public Conference createConferenceWithParams(@NonNull ConferenceParams params);

    /**
    * Create a {@link Config} object from a user config file. <br/>
    * <br/>
    * @param filename The filename of the config file to read to fill the<br/>
    * instantiated {@link Config}   <br/>
    * @return a {@link Config} object.   <br/>
    */
    @NonNull
    public Config createConfig(@Nullable String filename);

    /**
    * Creates a content with default values from Linphone core. <br/>
    * <br/>
    * @return {@link Content} object with default values set   <br/>
    */
    @NonNull
    public Content createContent();

    /**
    * Create a database conference scheduler that can be used to create client<br/>
    * conferences for now or later and then send conference info as an ICS through<br/>
    * chat. <br/>
    * <br/>
    * The DBConferenceScheduler only creates a conference info to be stored in the<br/>
    * database of the linphone core <br/>
    * @param account The {@link Account} to use in the {@link ConferenceScheduler}.   <br/>
    * @return A pointer on the freshly created {@link ConferenceScheduler}.   <br/>
    */
    @NonNull
    public ConferenceScheduler createDbConferenceScheduler(@Nullable Account account);

    /**
    * Creates and returns the default chat room parameters. <br/>
    * <br/>
    * @return A {@link ChatRoomParams} object   <br/>
    */
    @NonNull
    public ChatRoomParams createDefaultChatRoomParams();

    /**
    * Gets a {@link EktInfo} from an XML body. <br/>
    * <br/>
    * @param xmlBody the string containing the XML body   <br/>
    * @return The {@link EktInfo}   <br/>
    */
    @Nullable
    public EktInfo createEktInfoFromXml(@NonNull String xmlBody);

    /**
    * Creates an empty LinphoneFriend. <br/>
    * <br/>
    * @return The created {@link Friend} object   <br/>
    */
    @NonNull
    public Friend createFriend();

    /**
    * Creates a {@link Friend} from ai {@link Vcard}. <br/>
    * <br/>
    * @param vcard a {@link Vcard} object   <br/>
    * @return A new {@link Friend} object which has its vCard attribute initialized<br/>
    * from the given vCard, accessible using {@link Friend#getVcard}.   <br/>
    */
    @Nullable
    public Friend createFriendFromVcard(@NonNull Vcard vcard);

    /**
    * Creates a new empty {@link FriendList} object. <br/>
    * <br/>
    * @return A new {@link FriendList} object.   <br/>
    */
    @NonNull
    public FriendList createFriendList();

    /**
    * Creates a {@link Friend} from the given address. <br/>
    * <br/>
    * @param address A string containing the address to create the {@link Friend}<br/>
    * from   <br/>
    * @return The created {@link Friend} object.   <br/>
    */
    @Nullable
    public Friend createFriendWithAddress(@NonNull String address);

    /**
    * Creates an empty info message. <br/>
    * <br/>
    * @return a new LinphoneInfoMessage.  <br/>
    * The info message can later be filled with information using {@link InfoMessage#addHeader}<br/>
    * or {@link InfoMessage#setContent}, and finally sent with {@link Call#sendInfoMessage}<br/>
    * . <br/>
    */
    @NonNull
    public InfoMessage createInfoMessage();

    /**
    * Creates an empty LDAP search. <br/>
    * <br/>
    * {@link Ldap#setParams} must be call to save the parameters in the configuration<br/>
    * file.<br/>
    * @return {@link Ldap} with default values set     <br/>
    * @deprecated 18/11/2024 use {@link #createLdapRemoteContactDirectory} instead. <br/>
    */
    @Deprecated
    @NonNull
    public Ldap createLdap();

    /**
    * Create a LDAP params using default values from Linphone core. <br/>
    * <br/>
    * Check #linphone_ldap_params to update values. In order to add a new LDAP<br/>
    * configuration to {@link MagicSearch}, these parameters must be passed to<br/>
    * linphone_core_create_ldap_with_params. Or, use {@link Ldap#setParams}.<br/>
    * @return {@link LdapParams} with default values set.     <br/>
    */
    @NonNull
    public LdapParams createLdapParams();

    /**
    * Creates a new CardDAV server params object that may be used later by {@link MagicSearch}<br/>
    * to query contacts. <br/>
    * <br/>
    * @param params the {@link LdapParams} to configure this remote contact<br/>
    * directory.   <br/>
    * @return a new {@link RemoteContactDirectory} object to configure, and then add<br/>
    * using {@link #addRemoteContactDirectory}.   <br/>
    */
    @NonNull
    public RemoteContactDirectory createLdapRemoteContactDirectory(@NonNull LdapParams params);

    /**
    * Creates a LDAP search using given parameters and store them in the<br/>
    * configuration file. <br/>
    * <br/>
    * @param params {@link LdapParams} object   <br/>
    * @return {@link Ldap} with default values set     <br/>
    * @deprecated 18/11/2024 use {@link #createLdapRemoteContactDirectory} instead. <br/>
    */
    @Deprecated
    @NonNull
    public Ldap createLdapWithParams(@NonNull LdapParams params);

    /**
    * Creates a media file player, that can be used to play audio and video to the<br/>
    * user, outside of any call or conference. <br/>
    * <br/>
    * See {@link #getSupportedFileFormatsList} for supported multimedia file types. <br/>
    * @param soundCardName Playback sound card. If null, the ringer sound card set in<br/>
    * {@link Core} will be used    <br/>
    * @param videoDisplayName Video display. If null, the video display set in {@link Core}<br/>
    * will be used   <br/>
    * @param windowId Id of the drawing window. See {@link #setNativeVideoWindowId}<br/>
    * for a discussion about supported native video window types.   <br/>
    * @return A pointer on the new instance. null if failed.   <br/>
    */
    @Nullable
    public Player createLocalPlayer(@Nullable String soundCardName, @Nullable String videoDisplayName, @Nullable Object windowId);

    /**
    * Creates a {@link MagicSearch} object. <br/>
    * <br/>
    * @return The created {@link MagicSearch} object   <br/>
    */
    @NonNull
    public MagicSearch createMagicSearch();

    /**
    * Create a new {@link NatPolicy} object with every policies being disabled. <br/>
    * <br/>
    * @return A new {@link NatPolicy} object.   <br/>
    */
    @NonNull
    public NatPolicy createNatPolicy();

    /**
    * Create a Window ID for the video preview window. <br/>
    * <br/>
    * Available for MSQOGL and MSOGL. see {@link #setNativeVideoWindowId} for details<br/>
    * about window_id<br/>
    * MSQOgl can be used for the creation. {@link #createNativePreviewWindowId}<br/>
    * returns a #QQuickFramebufferObject::Renderer. This object must be returned by<br/>
    * your QQuickFramebufferObject::createRenderer() overload for Qt.<br/>
    * linphone_core_set_native_preview_window_id_2() must be called with this object<br/>
    * after the creation. Note : Qt blocks GUI thread when calling createRenderer(),<br/>
    * so it is safe to call linphone functions there if needed.<br/>
    * A context can be used to prevent Linphone from allocating the container<br/>
    * (#MSOglContextInfo for MSOGL). null if not used.<br/>
    * @param context preallocated Window ID (Used only for MSOGL)   <br/>
    * @return The created Window ID.   <br/>
    */
    @Nullable
    public Object createNativePreviewWindowId(@Nullable Object context);

    /**
    * Create a native window handle for the video preview window. <br/>
    * <br/>
    * see {@link #createNativePreviewWindowId} for details<br/>
    * @return The native window handle of the video preview window.   <br/>
    */
    @Nullable
    public Object createNativePreviewWindowId();

    /**
    * Create a Window ID from the current call. <br/>
    * <br/>
    * Available for MSQOGL and MSOGL. see {@link #setNativeVideoWindowId} for details<br/>
    * about window_id<br/>
    * When MSQOgl can be used for the creation: {@link #createNativeVideoWindowId}<br/>
    * returns a #QQuickFramebufferObject::Renderer. This object must be returned by<br/>
    * your QQuickFramebufferObject::createRenderer() overload for Qt. {@link #setNativeVideoWindowId}<br/>
    * must be called with this object after the creation. Note : Qt blocks GUI thread<br/>
    * when calling createRenderer(), so it is safe to call linphone functions there<br/>
    * if needed.<br/>
    * A context can be used to prevent Linphone from allocating the container<br/>
    * (#MSOglContextInfo for MSOGL). null if not used.<br/>
    * @param context preallocated Window ID (Used only for MSOGL)   <br/>
    * @return The created Window ID   <br/>
    */
    @Nullable
    public Object createNativeVideoWindowId(@Nullable Object context);

    /**
    * Create a native window handle for the video window from the current call. <br/>
    * <br/>
    * see {@link #createNativeVideoWindowId} for details<br/>
    * @return The native window handle of the video window.   <br/>
    */
    @Nullable
    public Object createNativeVideoWindowId();

    /**
    * Creates an out-of-dialog notification, specifying the destination resource, the<br/>
    * event name. <br/>
    * <br/>
    * The notification can be send with {@link Event#notify}. <br/>
    * @param resource the destination resource   <br/>
    * @param event the event name   <br/>
    * @return a {@link Event} holding the context of the notification.   <br/>
    */
    @NonNull
    public Event createNotify(@NonNull Address resource, @NonNull String event);

    /**
    * Creates a publish context for a one-shot publish. <br/>
    * <br/>
    * After being created, the publish must be sent using {@link Event#sendPublish}.<br/>
    * The {@link Event} is automatically terminated when the publish transaction is<br/>
    * finished, either with success or failure. The application must not call {@link Event#terminate}<br/>
    * for such one-shot publish. <br/>
    * @param resource the resource uri for the event   <br/>
    * @param event the event name   <br/>
    * @return the {@link Event} holding the context of the publish.   <br/>
    */
    @NonNull
    public Event createOneShotPublish(@NonNull Address resource, @NonNull String event);

    /**
    * Creates a {@link PresenceActivity} with the given type and description. <br/>
    * <br/>
    * @param acttype The {@link PresenceActivity#Type} to set for the activity. <br/>
    * @param description An additional description of the activity to set for the<br/>
    * activity. Can be null if no additional description is to be added.   <br/>
    * @return The created {@link PresenceActivity} object.   <br/>
    */
    @NonNull
    public PresenceActivity createPresenceActivity(PresenceActivity.Type acttype, @Nullable String description);

    /**
    * Creates a default LinphonePresenceModel. <br/>
    * <br/>
    * @return The created {@link PresenceModel} object.   <br/>
    */
    @NonNull
    public PresenceModel createPresenceModel();

    /**
    * Creates a {@link PresenceModel} with the given activity type and activity<br/>
    * description. <br/>
    * <br/>
    * @param acttype The {@link PresenceActivity#Type} to set for the activity of the<br/>
    * created model. <br/>
    * @param description An additional description of the activity to set for the<br/>
    * activity. Can be null if no additional description is to be added.   <br/>
    * @return The created {@link PresenceModel} object.   <br/>
    */
    @NonNull
    public PresenceModel createPresenceModelWithActivity(PresenceActivity.Type acttype, @Nullable String description);

    /**
    * Creates a {@link PresenceModel} with the given activity type, activity<br/>
    * description, note content and note language. <br/>
    * <br/>
    * @param acttype The {@link PresenceActivity#Type} to set for the activity of the<br/>
    * created model. <br/>
    * @param description An additional description of the activity to set for the<br/>
    * activity. Can be null if no additional description is to be added.   <br/>
    * @param note The content of the note to be added to the created model.   <br/>
    * @param lang The language of the note to be added to the created model.   <br/>
    * @return The created {@link PresenceModel} object.   <br/>
    */
    @NonNull
    public PresenceModel createPresenceModelWithActivityAndNote(PresenceActivity.Type acttype, @Nullable String description, @NonNull String note, @Nullable String lang);

    /**
    * Creates a {@link PresenceNote} with the given content and language. <br/>
    * <br/>
    * @param content The content of the note to be created.   <br/>
    * @param lang The language of the note to be created.   <br/>
    * @return The created {@link PresenceNote} object.   <br/>
    */
    @NonNull
    public PresenceNote createPresenceNote(@NonNull String content, @Nullable String lang);

    /**
    * Creates a {@link PresencePerson} with the given id. <br/>
    * <br/>
    * @param id The id of the person to be created.   <br/>
    * @return The created {@link PresencePerson} object.   <br/>
    */
    @NonNull
    public PresencePerson createPresencePerson(@NonNull String id);

    /**
    * Creates a {@link PresenceService} with the given id, basic status and contact. <br/>
    * <br/>
    * @param id The id of the service to be created.   <br/>
    * @param basicStatus The basic status of the service to be created. <br/>
    * @param contact A string containing a contact information corresponding to the<br/>
    * service to be created.   <br/>
    * @return The created {@link PresenceService} object.   <br/>
    */
    @NonNull
    public PresenceService createPresenceService(@NonNull String id, PresenceBasicStatus basicStatus, @NonNull String contact);

    /**
    * Same as {@link #getPrimaryContact} but the result is a {@link Address} object<br/>
    * instead of const char *. <br/>
    * <br/>
    * @return a {@link Address} object.  <br/>
    * @deprecated prefer using {@link #getPrimaryContactAddress} <br/>
    */
    @Deprecated
    @Nullable
    public Address createPrimaryContactParsed();

    /**
    * Create a proxy config with default values from Linphone core. <br/>
    * <br/>
    * @return {@link ProxyConfig} with default values set   <br/>
    * @deprecated 04/09/2024 Use {@link #createAccount} <br/>
    */
    @Deprecated
    @NonNull
    public ProxyConfig createProxyConfig();

    /**
    * Creates a publish context for an event state. <br/>
    * <br/>
    * After being created, the publish must be sent using {@link Event#sendPublish}.<br/>
    * After expiry, the publication is refreshed unless it is terminated before. <br/>
    * @param resource the resource uri for the event   <br/>
    * @param event the event name   <br/>
    * @param expires the lifetime of event being published, -1 if no associated<br/>
    * duration, in which case it will not be refreshed. <br/>
    * @return the {@link Event} holding the context of the publish.   <br/>
    */
    @NonNull
    public Event createPublish(@NonNull Address resource, @NonNull String event, int expires);

    /**
    * Creates an independant media file recorder, that can be used to record user's<br/>
    * voice or video outside of any call or conference. <br/>
    * <br/>
    * See {@link #getSupportedFileFormatsList} for supported multimedia file types. <br/>
    * @param params The {@link RecorderParams} that will contains all recorder<br/>
    * parameters.   <br/>
    * @return A pointer on the new instance. null if failed.   <br/>
    */
    @NonNull
    public Recorder createRecorder(@NonNull RecorderParams params);

    /**
    * Creates an object that holds recording parameters. <br/>
    * <br/>
    * see: {@link #createRecorder} <br/>
    * @return A pointer on the newly created instance of {@link RecorderParams}   <br/>
    */
    @NonNull
    public RecorderParams createRecorderParams();

    /**
    * Create a SIP conference scheduler that can be used to create client conferences<br/>
    * for now or later and then send conference info as an ICS through chat. <br/>
    * <br/>
    * A SipConferenceScheduler creates a conference on a server by using a SIP dialog <br/>
    * @param account The {@link Account} to use in the {@link ConferenceScheduler}.   <br/>
    * @return A pointer on the freshly created {@link ConferenceScheduler}.   <br/>
    */
    @NonNull
    public ConferenceScheduler createSipConferenceScheduler(@Nullable Account account);

    /**
    * Creates an outgoing subscription, specifying the destination resource, the<br/>
    * event name, and an optional content body. <br/>
    * <br/>
    * If accepted, the subscription runs for a finite period, but is automatically<br/>
    * renewed if not terminated before. Unlike {@link #subscribe} the subscription<br/>
    * isn't sent immediately. It will be send when calling {@link Event#sendSubscribe}<br/>
    * . <br/>
    * @param resource the destination resource   <br/>
    * @param event the event name   <br/>
    * @param expires the whished duration of the subscription <br/>
    * @return a {@link Event} holding the context of the created subcription.   <br/>
    */
    @NonNull
    public Event createSubscribe(@NonNull Address resource, @NonNull String event, int expires);

    /**
    * Creates an outgoing subscription, specifying the destination resource, the<br/>
    * event name, and an optional content body. <br/>
    * <br/>
    * If accepted, the subscription runs for a finite period, but is automatically<br/>
    * renewed if not terminated before. Unlike {@link #subscribe} the subscription<br/>
    * isn't sent immediately. It will be send when calling {@link Event#sendSubscribe}<br/>
    * . <br/>
    * @param resource the destination resource   <br/>
    * @param proxy the proxy configuration to use   <br/>
    * @param event the event name   <br/>
    * @param expires the whished duration of the subscription <br/>
    * @return a {@link Event} holding the context of the created subcription.   <br/>
    */
    @NonNull
    public Event createSubscribe(@NonNull Address resource, @NonNull ProxyConfig proxy, @NonNull String event, int expires);

    /**
    * Gets an XML body. <br/>
    * <br/>
    * @param ektInfo the {@link EktInfo}   <br/>
    * @return The XML body     <br/>
    * @deprecated 06/02/2025 use {@link #createXmlFromEktInfo}.<br/>
    */
    @Deprecated
    @Nullable
    public String createXmlFromEktInfo(@NonNull EktInfo ektInfo);

    /**
    * Gets an XML body using a specific account. <br/>
    * <br/>
    * @param ektInfo the {@link EktInfo}   <br/>
    * @param account the {@link Account} associated with the conference   <br/>
    * @return The XML body     <br/>
    */
    @Nullable
    public String createXmlFromEktInfo(@NonNull EktInfo ektInfo, @Nullable Account account);

    /**
    * Create a {@link XmlRpcSession} for a given url. <br/>
    * <br/>
    * @param url The URL to the XML-RPC server. Must be NON null.   <br/>
    * @return The new {@link XmlRpcSession} object.   <br/>
    */
    @NonNull
    public XmlRpcSession createXmlRpcSession(@NonNull String url);

    /**
    * Removes a chatroom including all message history from the LinphoneCore. <br/>
    * <br/>
    * @param chatRoom A {@link ChatRoom} object   <br/>
    */
    public void deleteChatRoom(@NonNull ChatRoom chatRoom);

    /**
    * Deletes a conference information from DB. <br/>
    * <br/>
    * @param conferenceInfo the {@link ConferenceInfo} to delete.   <br/>
    */
    public void deleteConferenceInformation(@NonNull ConferenceInfo conferenceInfo);

    /**
    * Sets device_token when application<br/>
    * didRegisterForRemoteNotificationsWithDeviceToken (IOS only). <br/>
    * <br/>
    * @param deviceToken format (NSData *).   <br/>
    */
    public void didRegisterForRemotePush(@Nullable Object deviceToken);

    /**
    * Sets device_token when application<br/>
    * didRegisterForRemoteNotificationsWithDeviceToken (IOS only). <br/>
    * <br/>
    * @param deviceTokenStr string extracted from the Data objectf received in<br/>
    * didRegisterForRemoteNotificationsWithDeviceToken ios function. Append ":remote"<br/>
    * after data formating..   <br/>
    */
    public void didRegisterForRemotePushWithStringifiedToken(@Nullable String deviceTokenStr);

    /**
    * Enables or disables call ringing. <br/>
    * <br/>
    * This value is taken into account from next time call parameters are created.<br/>
    * This feature can also be enabled per-call using {@link CallParams}. <br/>
    * @param yesno a boolean to indicate whether the feature is to be disabled. <br/>
    */
    public void disableCallRinging(boolean yesno);

    /**
    * Inconditionnaly disables incoming chat messages. <br/>
    * <br/>
    * @param denyReason the deny reason ({@link Reason#None} has no effect). <br/>
    */
    public void disableChat(Reason denyReason);

    /**
    * Enables reception of incoming chat messages. <br/>
    * <br/>
    * By default it is enabled but it can be disabled with {@link #disableChat}. <br/>
    */
    public void enableChat();

    /**
    * Call this method when you receive a push notification (if you handle push<br/>
    * notifications manually). <br/>
    * <br/>
    * It will ensure the proxy configs are correctly registered to the proxy server,<br/>
    * so the call or the message will be correctly delivered. <br/>
    * @deprecated 09/03/2022 See {@link #processPushNotification} instead. <br/>
    */
    @Deprecated
    public void ensureRegistered();

    /**
    * This method is called by the application to notify the linphone core library<br/>
    * when it enters background mode. <br/>
    * <br/>
    */
    public void enterBackground();

    /**
    * Joins the local participant to the running conference. <br/>
    * <br/>
    * @return 0 if succeeded. Negative number if failed <br/>
    * @deprecated 09/03/2021 Use {@link Conference#enter} instead. <br/>
    */
    @Deprecated
    public int enterConference();

    /**
    * This method is called by the application to notify the linphone core library<br/>
    * when it enters foreground mode. <br/>
    * <br/>
    */
    public void enterForeground();

    /**
    * Returns whether a specific file format is supported. <br/>
    * <br/>
    * see: linphone_core_get_supported_file_formats <br/>
    * @param fmt The format extension (wav, mkv).   <br/>
    * @return true if the file format is supported, false otherwise <br/>
    */
    public boolean fileFormatSupported(@NonNull String fmt);

    /**
    * Finds authentication info matching realm, username, domain criteria. <br/>
    * <br/>
    * First of all, (realm,username) pair are searched. If multiple results (which<br/>
    * should not happen because realm are supposed to be unique), then domain is<br/>
    * added to the search. <br/>
    * @param realm the authentication 'realm' (optional)   <br/>
    * @param username the SIP username to be authenticated (mandatory)   <br/>
    * @param sipDomain the SIP domain name (optional)   <br/>
    * @return a {@link AuthInfo} if found.   <br/>
    */
    @Nullable
    public AuthInfo findAuthInfo(@Nullable String realm, @NonNull String username, @Nullable String sipDomain);

    /**
    * Search from the list of current calls if a remote address match uri. <br/>
    * <br/>
    * @param uri which should match call remote uri   <br/>
    * @return {@link Call} or null if no match is found.   <br/>
    * @deprecated 27/10/2020. Use {@link #getCallByRemoteAddress2} instead. <br/>
    */
    @Deprecated
    @Nullable
    public Call findCallFromUri(@NonNull String uri);

    /**
    * Gets the call log matching the call id, or null if can't be found. <br/>
    * <br/>
    * @param callId Call id of the call log to find   <br/>
    * @param limit Search limit of the most recent call logs to find   <br/>
    * @return A call log matching the call id if any.     <br/>
    */
    @Nullable
    public CallLog findCallLog(@NonNull String callId, @NonNull int limit);

    /**
    * Gets the call log matching the call id, or null if can't be found. <br/>
    * <br/>
    * @param callId Call id of the call log to find   <br/>
    * @return A call log matching the call id if any.     <br/>
    */
    @Nullable
    public CallLog findCallLogFromCallId(@NonNull String callId);

    /**
    * Find a chat room. <br/>
    * <br/>
    * No reference is transferred to the application. The {@link Core} keeps a<br/>
    * reference on the chat room. <br/>
    * @param peerAddr a linphone address.   <br/>
    * @param localAddr a linphone address.   <br/>
    * @return {@link ChatRoom} where messaging can take place.   <br/>
    * @deprecated 02/07/2020, use {@link #searchChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom findChatRoom(@NonNull Address peerAddr, @NonNull Address localAddr);

    /**
    * Retrieve the conference information linked to the provided URI if any. <br/>
    * <br/>
    * @param uri Uri of the conference as provided by the CCMP server backend.   <br/>
    * @return The {@link ConferenceInfo} found if any, null otherwise.     <br/>
    */
    @Nullable
    public ConferenceInfo findConferenceInformationFromCcmpUri(@NonNull String uri);

    /**
    * Retrieve the conference information linked to the provided URI if any. <br/>
    * <br/>
    * @param uri {@link Address} of the uri.   <br/>
    * @return The {@link ConferenceInfo} found if any, null otherwise.     <br/>
    */
    @Nullable
    public ConferenceInfo findConferenceInformationFromUri(@NonNull Address uri);

    /**
    * Retrieves a list of {@link Address} sort and filter. <br/>
    * <br/>
    * @param filter Chars used for the filter*   <br/>
    * @param sipOnly Only sip address or not <br/>
    * @return A list of filtered {@link Address} + the {@link Address} created with<br/>
    * the filter.     <br/>
    */
    @NonNull
    public Address[] findContactsByChar(@NonNull String filter, boolean sipOnly);

    /**
    * Searches a {@link Friend} by its address. <br/>
    * <br/>
    * @param address The {@link Address} to use to search the friend.   <br/>
    * @return The {@link Friend} object corresponding to the given address or null if<br/>
    * not found.   <br/>
    */
    @Nullable
    public Friend findFriend(@NonNull Address address);

    /**
    * Searches a {@link Friend} by its phone number. <br/>
    * <br/>
    * @param phoneNumber The phone number to use to search the friend.   <br/>
    * @return The {@link Friend} object corresponding to the given phone number or<br/>
    * null if not found.   <br/>
    */
    @Nullable
    public Friend findFriendByPhoneNumber(@NonNull String phoneNumber);

    /**
    * Searches all {@link Friend} matching an address. <br/>
    * <br/>
    * @param address The address to use to search the friends.   <br/>
    * @return A list of {@link Friend} corresponding to the given address.       <br/>
    */
    @NonNull
    public Friend[] findFriends(@NonNull Address address);

    /**
    * Find a one to one chat room. <br/>
    * <br/>
    * No reference is transferred to the application. The {@link Core} keeps a<br/>
    * reference on the chat room. <br/>
    * @param localAddr a linphone address.   <br/>
    * @param participantAddr a linphone address.   <br/>
    * @param encrypted whether to look for an encrypted chat room or not <br/>
    * @return {@link ChatRoom} where messaging can take place.   <br/>
    * @deprecated 02/07/2020, use {@link #searchChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom findOneToOneChatRoom(@NonNull Address localAddr, @NonNull Address participantAddr, boolean encrypted);

    /**
    * Search for a {@link Account} by it's idkey. <br/>
    * <br/>
    * @param idkey An arbitrary idkey string associated to an account.   <br/>
    * @return the {@link Account} object for the given idkey value, or null if none<br/>
    * found   <br/>
    */
    @Nullable
    public Account getAccountByIdkey(@Nullable String idkey);

    /**
    * Gets the call by its SIP callid. <br/>
    * <br/>
    * @param callId of call   <br/>
    * @return call {@link Call}, return null if there is no call find.   <br/>
    */
    @Nullable
    public Call getCallByCallid(@NonNull String callId);

    /**
    * Get the call with the remote_address specified. <br/>
    * <br/>
    * @param remoteAddress The remote address of the call that we want to get   <br/>
    * @return The call if it has been found, null otherwise.  <br/>
    * @deprecated 08/07/2020 use {@link #getCallByRemoteAddress2} instead <br/>
    */
    @Deprecated
    @Nullable
    public Call getCallByRemoteAddress(@NonNull String remoteAddress);

    /**
    * Get the call with the specified {@link Address}. <br/>
    * <br/>
    * @param remoteAddress the {@link Address} for which the call remote address must<br/>
    * match   <br/>
    * @return the {@link Call} of the call if found.   <br/>
    */
    @Nullable
    public Call getCallByRemoteAddress2(@NonNull Address remoteAddress);

    /**
    * Gets the list of call logs (past calls). <br/>
    * <br/>
    * At the contrary of linphone_core_get_call_logs, it is your responsibility to<br/>
    * unref the logs and free this list once you are done using it. Requires<br/>
    * ENABLE_DB_STORAGE to work. <br/>
    * @param peerAddress The remote {@link Address} object.   <br/>
    * @param localAddress The local {@link Address} object   <br/>
    * @return A list of {@link CallLog}.      <br/>
    */
    @NonNull
    public CallLog[] getCallHistory(@NonNull Address peerAddress, @NonNull Address localAddress);

    /**
    * Get a chat room whose peer is the supplied address. <br/>
    * <br/>
    * If it does not exist yet, it will be created as a basic chat room. No reference<br/>
    * is transferred to the application. The {@link Core} keeps a reference on the<br/>
    * chat room. warning: This method is prone to errors, use {@link #searchChatRoom}<br/>
    * instead <br/>
    * @param addr a linphone address.   <br/>
    * @return {@link ChatRoom} where messaging can take place.   <br/>
    * @deprecated 02/07/2020, use {@link #searchChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom getChatRoom(@NonNull Address addr);

    /**
    * Get a chat room. <br/>
    * <br/>
    * If it does not exist yet, it will be created as a basic chat room. No reference<br/>
    * is transferred to the application. The {@link Core} keeps a reference on the<br/>
    * chat room. warning: This method is prone to errors, use {@link #searchChatRoom}<br/>
    * instead <br/>
    * @param peerAddr a linphone address.   <br/>
    * @param localAddr a linphone address.   <br/>
    * @return {@link ChatRoom} where messaging can take place.   <br/>
    * @deprecated 02/07/2020, use {@link #searchChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom getChatRoom(@NonNull Address peerAddr, @NonNull Address localAddr);

    /**
    * Get a chat room for messaging from a sip uri like sip:joe@sip.linphone.org. <br/>
    * <br/>
    * If it does not exist yet, it will be created as a basic chat room. No reference<br/>
    * is transferred to the application. The {@link Core} keeps a reference on the<br/>
    * chat room. warning: This method is prone to errors, use {@link #searchChatRoom}<br/>
    * instead <br/>
    * @param to The destination address for messages.   <br/>
    * @return {@link ChatRoom} where messaging can take place.   <br/>
    * @deprecated 02/07/2020, use {@link #searchChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom getChatRoomFromUri(@NonNull String to);

    /**
    * Retrieve the list of conference information on DB after a certain time. <br/>
    * <br/>
    * @param time Time to retrieve conference info. <br/>
    * @return The list of conference infos .     <br/>
    */
    @NonNull
    public ConferenceInfo[] getConferenceInformationListAfterTime(long time);

    /**
    * Retrieve the list of conference information on DB where the address passed as<br/>
    * argument is either the organizer or a participant. <br/>
    * <br/>
    * @param uri {@link Address} of the participant.   <br/>
    * @return The list of conference infos  where the address passed as argument is<br/>
    * either the organizer or a participant.     <br/>
    */
    @NonNull
    public ConferenceInfo[] getConferenceInformationsWithParticipant(@NonNull Address uri);

    /**
    * Searches a {@link Friend} by its reference key. <br/>
    * <br/>
    * @param key The reference key to use to search the friend.   <br/>
    * @return The {@link Friend} object corresponding to the given reference key.   <br/>
    */
    @Nullable
    public Friend getFriendByRefKey(@NonNull String key);

    /**
    * Retrieves the list of {@link Friend} from the core that has the given display<br/>
    * name. <br/>
    * <br/>
    * @param name the name of the list   <br/>
    * @return the first {@link FriendList} object or null.   <br/>
    */
    @Nullable
    public FriendList getFriendListByName(@NonNull String name);

    /**
    * Get payload type from mime type and clock rate. <br/>
    * <br/>
    * This function searches in audio and video codecs for the given payload type<br/>
    * name and clockrate. <br/>
    * @param type payload mime type (I.E "speex", "pcmu", "h264")   <br/>
    * @param rate can be LINPHONE_FIND_PAYLOAD_IGNORE_RATE (-1) <br/>
    * @param channels number of channels, can be<br/>
    * LINPHONE_FIND_PAYLOAD_IGNORE_CHANNELS (-1) <br/>
    * @return Returns null if not found. If a {@link PayloadType} is returned, it<br/>
    * must be released with linphone_payload_type_unref after using it.     <br/>
    */
    @Nullable
    public PayloadType getPayloadType(@NonNull String type, int rate, int channels);

    /**
    * Searches for a {@link ProxyConfig} by it's idkey. <br/>
    * <br/>
    * @param idkey An arbitrary idkey string associated to a proxy configuration <br/>
    * @return the {@link ProxyConfig} object for the given idkey value, or null if<br/>
    * none found   <br/>
    * @deprecated 04/09/2024 Use {@link #getAccountByIdkey} <br/>
    */
    @Deprecated
    @Nullable
    public ProxyConfig getProxyConfigByIdkey(String idkey);

    /**
    * Get the zrtp sas validation status for a peer uri. <br/>
    * <br/>
    * Once the SAS has been validated or rejected, the status will never return to<br/>
    * Unknown (unless you delete your cache) <br/>
    * @param addr the peer uri  <br/>
    * @return - LinphoneZrtpPeerStatusUnknown: this uri is not present in cache OR<br/>
    * during calls with the active device, SAS never was validated or rejected<br/>
    */
    public ZrtpPeerStatus getZrtpStatus(@NonNull String addr);

    /**
    * Check whether the device has a hardware echo canceller. <br/>
    * <br/>
    * @return true if it does, false otherwise <br/>
    */
    public boolean hasBuiltinEchoCanceller();

    /**
    * Check whether the device is flagged has crappy opengl. <br/>
    * <br/>
    * @return true if crappy opengl flag is set, false otherwise <br/>
    */
    public boolean hasCrappyOpengl();

    /**
    * Tells whether there is a call running. <br/>
    * <br/>
    * @return A boolean value telling whether a call is currently running or not <br/>
    */
    public boolean inCall();

    /**
    * Constructs a {@link Address} from the given string if possible. <br/>
    * <br/>
    * In case of just a username, characters will be unescaped. If a phone number is<br/>
    * detected, it will be flattened. sip: or sips: prefix will be added if not<br/>
    * present. Finally, @domain will be added if not present using default proxy<br/>
    * config. see: {@link ProxyConfig#normalizeSipUri} for documentation. <br/>
    * @param url the url to parse   <br/>
    * @return the {@link Address} matching the url or null in case of failure.    <br/>
    * @deprecated on 18/07/2022, use {@link #interpretUrl} instead. <br/>
    */
    @Deprecated
    @Nullable
    public Address interpretUrl(@NonNull String url);

    /**
    * Constructs a {@link Address} from the given string if possible. <br/>
    * <br/>
    * In case of just a username, characters will be unescaped. If a phone number is<br/>
    * detected, it will be flattened. sip: or sips: prefix will be added if not<br/>
    * present. Finally, @domain will be added if not present using the default<br/>
    * #Account. see: {@link Account#normalizeSipUri} for a similar function. <br/>
    * @param url the url to parse   <br/>
    * @param applyInternationalPrefix whether or not to try to format url as phone<br/>
    * number using default account prefix if it set (and if url is a number). <br/>
    * @return the {@link Address} matching the url or null in case of failure.     <br/>
    */
    @Nullable
    public Address interpretUrl(@NonNull String url, boolean applyInternationalPrefix);

    /**
    * Initiates an outgoing call. <br/>
    * <br/>
    * The application doesn't own a reference to the returned LinphoneCall object.<br/>
    * Use linphone_call_ref to safely keep the LinphoneCall pointer valid within your<br/>
    * application.<br/>
    * @param url The destination of the call (sip address, or phone number).   <br/>
    * @return A {@link Call} object or null in case of failure.   <br/>
    */
    @Nullable
    public Call invite(@NonNull String url);

    /**
    * Initiates an outgoing call given a destination {@link Address} The {@link Address}<br/>
    * can be constructed directly using {@link Factory#createAddress}, or created by<br/>
    * {@link #interpretUrl}. <br/>
    * <br/>
    * In C, the application doesn't own a reference to the returned {@link Call}<br/>
    * object. Use linphone_call_ref to safely keep the {@link Call} pointer valid<br/>
    * within your application. <br/>
    * @param addr The destination of the call (sip address).   <br/>
    * @return A {@link Call} object or null in case of failure.   <br/>
    */
    @Nullable
    public Call inviteAddress(@NonNull Address addr);

    /**
    * Initiates an outgoing call given a destination {@link Address} The {@link Address}<br/>
    * can be constructed directly using {@link Factory#createAddress}, or created by<br/>
    * {@link #interpretUrl}. <br/>
    * <br/>
    * In C, the application doesn't own a reference to the returned {@link Call}<br/>
    * object. Use linphone_call_ref to safely keep the {@link Call} pointer valid<br/>
    * within your application. If the {@link Account} is not specified in parameters,<br/>
    * the caller's account will be automatically selected by finding what is the best<br/>
    * to reach the destination of the call. <br/>
    * @param addr The destination of the call (sip address).   <br/>
    * @param params Call parameters   <br/>
    * @return A {@link Call} object or null in case of failure.   <br/>
    */
    @Nullable
    public Call inviteAddressWithParams(@NonNull Address addr, @NonNull CallParams params);

    /**
    * Initiates an outgoing call given a destination {@link Address} The {@link Address}<br/>
    * can be constructed directly using {@link Factory#createAddress}, or created by<br/>
    * {@link #interpretUrl}. <br/>
    * <br/>
    * In C, the application doesn't own a reference to the returned {@link Call}<br/>
    * object. Use linphone_call_ref to safely keep the {@link Call} pointer valid<br/>
    * within your application. If the {@link Account} is not specified in parameters,<br/>
    * the caller's account will be automatically selected by finding what is the best<br/>
    * to reach the destination of the call. <br/>
    * @param addr The destination of the call (sip address).   <br/>
    * @param params Call parameters   <br/>
    * @param subject Subject of the call, UTF-8 encoded   <br/>
    * @param content Body of the SIP INVITE   <br/>
    * @return A {@link Call} object or null in case of failure.   <br/>
    */
    @Nullable
    public Call inviteAddressWithParams(@NonNull Address addr, @NonNull CallParams params, @Nullable String subject, @Nullable Content content);

    /**
    * Initiates an outgoing call according to supplied call parameters In C, the<br/>
    * application doesn't own a reference to the returned {@link Call} object. <br/>
    * <br/>
    * Use linphone_call_ref to safely keep the {@link Call} pointer valid within your<br/>
    * application. <br/>
    * @param url The destination of the call (sip address, or phone number).   <br/>
    * @param params the {@link CallParams} call parameters   <br/>
    * @return A {@link Call} object or null in case of failure.   <br/>
    */
    @Nullable
    public Call inviteWithParams(@NonNull String url, @NonNull CallParams params);

    /**
    * Tells whether a content type is supported. <br/>
    * <br/>
    * @param contentType The content type to check   <br/>
    * @return A boolean value telling whether the specified content type is supported<br/>
    * or not. <br/>
    */
    public boolean isContentTypeSupported(@NonNull String contentType);

    /**
    * Checks if given media encryption is supported. <br/>
    * <br/>
    * @param menc The media encryption policy to be used. <br/>
    * @return true if the media encryption is supported, false otherwise <br/>
    */
    public boolean isMediaEncryptionSupported(MediaEncryption menc);

    /**
    * Checks if the given media filter is loaded and usable. <br/>
    * <br/>
    * This is for advanced users of the library, mainly to expose mediastreamer video<br/>
    * filter status. <br/>
    * @param filtername the filter name   <br/>
    * @return true if the filter is loaded and usable, false otherwise <br/>
    */
    public boolean isMediaFilterSupported(@NonNull String filtername);

    /**
    * Tells whether a plugin is loaded or not. <br/>
    * <br/>
    * @param name name of the plugin   <br/>
    * @return A boolean value telling whether the plugin has been loaded <br/>
    */
    public boolean isPluginLoaded(@NonNull String name);

    /**
    * Main loop integration. <br/>
    * <br/>
    * Unless auto-iterate mode is provided ( see {@link #enableAutoIterate} ), it is<br/>
    * crucial that your application calls {@link #iterate} repeatedly.<br/>
    * {@link #iterate} performs various backgrounds tasks:<br/>
    */
    public void iterate();

    /**
    * End of group contacts. <br/>
    * <br/>
    * Tells if LDAP is available <br/>
    * @return true if LDAP is available, false otherwise <br/>
    */
    public boolean ldapAvailable();

    /**
    * Makes the local participant leave the running conference. <br/>
    * <br/>
    * @return 0 if succeeded. Negative number if failed <br/>
    * @deprecated 09/03/2021 Use {@link Conference#leave} instead. <br/>
    */
    @Deprecated
    public int leaveConference();

    /**
    * Tells if LIME X3DH is available. <br/>
    * <br/>
    */
    public boolean limeX3DhAvailable();

    /**
    * Update current config with the content of a xml config file. <br/>
    * <br/>
    * @param xmlUri the path to the xml file   <br/>
    */
    public void loadConfigFromXml(@NonNull String xmlUri);

    /**
    * Checks if a media encryption type is supported. <br/>
    * <br/>
    * @param menc {@link MediaEncryption} <br/>
    * @return whether a media encryption scheme is supported by the {@link Core}<br/>
    * engine <br/>
    */
    public boolean mediaEncryptionSupported(MediaEncryption menc);

    /**
    * Migrates the call logs from the linphonerc to the database if not done yet. <br/>
    * <br/>
    */
    public void migrateLogsFromRcToDb();

    /**
    * Notifies all friends that have subscribed. <br/>
    * <br/>
    * @param presence {@link PresenceModel} to notify   <br/>
    */
    public void notifyAllFriends(@NonNull PresenceModel presence);

    /**
    * Notifies the upper layer that a presence status has been received by calling<br/>
    * the appropriate callback if one has been set. <br/>
    * <br/>
    * This method is for advanced usage, where customization of the liblinphone's<br/>
    * internal behavior is required. <br/>
    * @param linphoneFriend the {@link Friend} whose presence information has been<br/>
    * received.   <br/>
    */
    public void notifyNotifyPresenceReceived(@NonNull Friend linphoneFriend);

    /**
    * Notifies the upper layer that a presence model change has been received for the<br/>
    * uri or telephone number given as a parameter, by calling the appropriate<br/>
    * callback if one has been set. <br/>
    * <br/>
    * This method is for advanced usage, where customization of the liblinphone's<br/>
    * internal behavior is required. <br/>
    * @param linphoneFriend the {@link Friend} whose presence information has been<br/>
    * received.   <br/>
    * @param uriOrTel telephone number or sip uri   <br/>
    * @param presenceModel the {@link PresenceModel} that has been modified   <br/>
    */
    public void notifyNotifyPresenceReceivedForUriOrTel(@NonNull Friend linphoneFriend, @NonNull String uriOrTel, @NonNull PresenceModel presenceModel);

    /**
    * Pauses all currently running calls. <br/>
    * <br/>
    * @return 0 <br/>
    */
    public int pauseAllCalls();

    /**
    * Plays a dtmf sound to the local user. <br/>
    * <br/>
    * @param dtmf DTMF to play ['0'..'16'] | '#' | '#' <br/>
    * @param durationMs Duration in ms, -1 means play until next further call to<br/>
    * {@link #stopDtmf} <br/>
    */
    public void playDtmf(char dtmf, int durationMs);

    /**
    * Plays an audio file to the local user. <br/>
    * <br/>
    * This function works at any time, during calls, or when no calls are running. It<br/>
    * doesn't request the underlying audio system to support multiple playback<br/>
    * streams. <br/>
    * @param audiofile The path to an audio file in wav PCM 16 bit format   <br/>
    * @return 0 on success, -1 on error <br/>
    */
    public int playLocal(@NonNull String audiofile);

    /**
    * Empties sound resources to allow a new call to be accepted. <br/>
    * <br/>
    * This function is autyomatically called by the core if the media resource mode<br/>
    * is set to unique. <br/>
    * @return An integer returning the exit value. If it is 0, sound resources have<br/>
    * been emptied. Otherwise, sound resources are busy and cannot be freed<br/>
    * immediately. <br/>
    */
    public int preemptSoundResources();

    /**
    * Call generic OpenGL render for a given core. <br/>
    * <br/>
    */
    public void previewOglRender();

    /**
    * Call this method when you receive a push notification (if you handle push<br/>
    * notifications manually). <br/>
    * <br/>
    * It will ensure the proxy configs are correctly registered to the proxy server,<br/>
    * so the call or the message will be correctly delivered. <br/>
    * @param callId the Call-ID of the MESSAGE or INVITE for which the push was<br/>
    * received and to wait for.   <br/>
    */
    public void processPushNotification(@Nullable String callId);

    /**
    * Publishes an event state. <br/>
    * <br/>
    * This first create a {@link Event} with {@link #createPublish} and calls {@link Event#sendPublish}<br/>
    * to actually send it. After expiry, the publication is refreshed unless it is<br/>
    * terminated before. <br/>
    * @param resource the resource uri for the event   <br/>
    * @param event the event name   <br/>
    * @param expires the lifetime of event being published, -1 if no associated<br/>
    * duration, in which case it will not be refreshed. <br/>
    * @param body the actual published data   <br/>
    * @return the {@link Event} holding the context of the publish.   <br/>
    */
    @Nullable
    public Event publish(@NonNull Address resource, @NonNull String event, int expires, @NonNull Content body);

    /**
    * Forces registration refresh to be initiated upon next iterate. <br/>
    * <br/>
    */
    public void refreshRegisters();

    /**
    * Black list a friend. <br/>
    * <br/>
    * same as {@link Friend#setIncSubscribePolicy} with {@link SubscribePolicy#SPDeny}<br/>
    * policy; <br/>
    * @param linphoneFriend {@link Friend} to reject   <br/>
    */
    public void rejectSubscriber(@NonNull Friend linphoneFriend);

    /**
    * Reload mediastreamer2 plugins from specified directory. <br/>
    * <br/>
    * @param path the path from where plugins are to be loaded, pass null to use<br/>
    * default (compile-time determined) plugin directory.   <br/>
    */
    public void reloadMsPlugins(@Nullable String path);

    /**
    * Update detection of sound devices. <br/>
    * <br/>
    * Use this function when the application is notified of USB plug events, so that<br/>
    * list of available hardwares for sound playback and capture is updated. <br/>
    */
    public void reloadSoundDevices();

    /**
    * Update detection of camera devices. <br/>
    * <br/>
    * Use this function when the application is notified of USB plug events, so that<br/>
    * list of available hardwares for video capture is updated. <br/>
    */
    public void reloadVideoDevices();

    /**
    * Removes an account. <br/>
    * <br/>
    * {@link Core} will then automatically unregister and place the account on a<br/>
    * deleted list. For that reason, a removed account does NOT need to be freed. <br/>
    * @param account the {@link Account} to remove   <br/>
    */
    public void removeAccount(@NonNull Account account);

    /**
    * Removes an authentication information object. <br/>
    * <br/>
    * @param info The {@link AuthInfo} to remove.   <br/>
    */
    public void removeAuthInfo(@NonNull AuthInfo info);

    /**
    * Removes a specific call log from call history list. <br/>
    * <br/>
    * This function destroys the call log object. It must not be accessed anymore by<br/>
    * the application after calling this function. <br/>
    * @param callLog {@link CallLog} object to remove.   <br/>
    */
    public void removeCallLog(@NonNull CallLog callLog);

    /**
    * Remove support for the specified content type. <br/>
    * <br/>
    * It is the application responsibility to handle it correctly afterwards. <br/>
    * @param contentType The content type to remove support for   <br/>
    */
    public void removeContentTypeSupport(@NonNull String contentType);

    /**
    * Removes a friend list. <br/>
    * <br/>
    * @param list {@link FriendList} object   <br/>
    */
    public void removeFriendList(@NonNull FriendList list);

    /**
    * Removes a call from the conference. <br/>
    * <br/>
    * @param call a call that has been previously merged into the conference.  <br/>
    * After removing the remote participant belonging to the supplied call, the call<br/>
    * becomes a normal call in paused state. If one single remote participant is left<br/>
    * alone together with the local user in the conference after the removal, then<br/>
    * the conference is automatically transformed into a simple call in<br/>
    * StreamsRunning state. The conference's resources are then automatically<br/>
    * destroyed.<br/>
    * In other words, unless {@link #leaveConference} is explicitly called, the last<br/>
    * remote participant of a conference is automatically put in a simple call in<br/>
    * running state.<br/>
    * @return 0 if successful, -1 otherwise. <br/>
    * @deprecated 23/01/2025 Use {@link Conference#removeParticipant} instead. <br/>
    */
    @Deprecated
    public int removeFromConference(@NonNull Call call);

    /**
    * Remove a LDAP from the configuration. <br/>
    * <br/>
    * @param ldap The LDAP to remove.   <br/>
    * @deprecated 18/11/2024 use {@link #removeRemoteContactDirectory} instead. <br/>
    */
    @Deprecated
    public void removeLdap(@NonNull Ldap ldap);

    /**
    * Remove the given linphone specs from the list of functionalities the linphone<br/>
    * client supports. <br/>
    * <br/>
    * see: {@link #setLinphoneSpecsList} <br/>
    * @param spec The spec to remove   <br/>
    */
    public void removeLinphoneSpec(@NonNull String spec);

    /**
    * Removes a proxy configuration. <br/>
    * <br/>
    * {@link Core} will then automatically unregister and place the proxy<br/>
    * configuration on a deleted list. For that reason, a removed proxy does NOT need<br/>
    * to be freed. <br/>
    * @param config the {@link ProxyConfig} to remove   <br/>
    * @deprecated 04/09/2024 Use {@link #removeAccount} <br/>
    */
    @Deprecated
    public void removeProxyConfig(@NonNull ProxyConfig config);

    /**
    * Removes a {@link RemoteContactDirectory} object previously added to the Core. <br/>
    * <br/>
    * @param remoteContactDirectory the {@link RemoteContactDirectory} to remove.   <br/>
    */
    public void removeRemoteContactDirectory(@NonNull RemoteContactDirectory remoteContactDirectory);

    /**
    * Remove a supported tag. <br/>
    * <br/>
    * @param tag The tag to remove  <br/>
    * see: {@link #addSupportedTag} <br/>
    */
    public void removeSupportedTag(@NonNull String tag);

    /**
    * Clears all state resulting from a previous echo canceller calibration<br/>
    * procedure, which restores default policy and settings for echo cancellation. <br/>
    * <br/>
    * see: {@link #enableEchoCancellation} and {@link #startEchoCancellerCalibration} <br/>
    */
    public void resetEchoCancellationCalibration();

    /**
    * Resets the counter of missed calls. <br/>
    * <br/>
    */
    public void resetMissedCallsCount();

    /**
    * Find a chat room. <br/>
    * <br/>
    * @param params The chat room parameters to match {@link ChatRoomParams} or null <br/>
    *  <br/>
    * @param localAddr {@link Address} of a local {@link Account} identity or null   <br/>
    * @param remoteAddr {@link Address} to search for or null   <br/>
    * @param participants The participants that must be present in the chat room to<br/>
    * find.     <br/>
    * @return A matching chat room or null if none matches.   <br/>
    * @deprecated 22/10/2024, use {@link #searchChatRoom} instead<br/>
    */
    @Deprecated
    @Nullable
    public ChatRoom searchChatRoom(@Nullable ChatRoomParams params, @Nullable Address localAddr, @Nullable Address remoteAddr, @Nullable Address[] participants);

    /**
    * Find a chat room. <br/>
    * <br/>
    * @param params The chat room parameters to match {@link ChatRoomParams} or null <br/>
    *  <br/>
    * @param localAddr {@link Address} of a local {@link Account} identity or null   <br/>
    * @param remoteAddr {@link Address} to search for or null   <br/>
    * @param participants The participants that must be present in the chat room to<br/>
    * find.     <br/>
    * @return A matching chat room or null if none matches.   <br/>
    */
    @Nullable
    public ChatRoom searchChatRoom(@Nullable ConferenceParams params, @Nullable Address localAddr, @Nullable Address remoteAddr, @Nullable Address[] participants);

    /**
    * Find a chat room by its identifier. <br/>
    * <br/>
    * @param identifier The chat room identifier   <br/>
    * @return A matching chat room or null if none matches.   <br/>
    */
    @Nullable
    public ChatRoom searchChatRoomByIdentifier(@NonNull String identifier);

    /**
    * Find a conference. <br/>
    * <br/>
    * @param params The conference parameters to match {@link ConferenceParams} or<br/>
    * null   <br/>
    * @param localAddr {@link Address} representing the local proxy configuration or<br/>
    * null   <br/>
    * @param remoteAddr {@link Address} to search for or null   <br/>
    * @param participants The participants that must be present in the chat room to<br/>
    * find     <br/>
    * @return A pointer on {@link Conference} satisfying the non-null function<br/>
    * arguments or null if none matches   <br/>
    */
    @Nullable
    public Conference searchConference(@Nullable ConferenceParams params, @Nullable Address localAddr, @Nullable Address remoteAddr, @Nullable Address[] participants);

    /**
    * Finds a conference. <br/>
    * <br/>
    * @param conferenceAddr {@link Address} representing the conference address   <br/>
    * @return A pointer on {@link Conference} whose conference address is the one<br/>
    * provided as argument or null if none matches   <br/>
    */
    @Nullable
    public Conference searchConference(@NonNull Address conferenceAddr);

    /**
    * Find a conference by its identifier. <br/>
    * <br/>
    * @param identifier The conference identifier   <br/>
    * @return A matching conference or null if none matches.   <br/>
    */
    @Nullable
    public Conference searchConferenceByIdentifier(@NonNull String identifier);

    /**
    * Sets the UDP port range from which to randomly select the port used for audio<br/>
    * streaming. <br/>
    * <br/>
    * @param minPort The lower bound of the audio port range to use <br/>
    * @param maxPort The upper bound of the audio port range to use <br/>
    */
    public void setAudioPortRange(int minPort, int maxPort);

    /**
    * Set the rectangle where the decoder will search a QRCode. <br/>
    * <br/>
    * @param x axis <br/>
    * @param y axis <br/>
    * @param w width <br/>
    * @param h height <br/>
    */
    public void setQrcodeDecodeRect(int x, int y, int w, int h);

    /**
    * Set the refresh window. <br/>
    * <br/>
    * During this window, belle-sip schedules the refreshes of the sip messages <br/>
    * @param minValue lower bound of the refresh window <br/>
    * @param maxValue upper bound of the refresh window <br/>
    * warning: The refresh window must be set before starting the core <br/>
    */
    public void setRefreshWindow(int minValue, int maxValue);

    /**
    * Sets the UDP port range from which to randomly select the port used for text<br/>
    * streaming. <br/>
    * <br/>
    * @param minPort The lower bound of the text port range to use <br/>
    * @param maxPort The upper bound of the text port range to use <br/>
    */
    public void setTextPortRange(int minPort, int maxPort);

    /**
    * Assign an audio file to be played as a specific tone id. <br/>
    * <br/>
    * This function typically allows to customize telephony tones per country.<br/>
    * If you want to disable a tone, set a path to a non-existent file. To disable<br/>
    * all tones, use {@link #enableCallToneIndications} or set the tone_indications<br/>
    * to 0 in the [misc] section of your linphonerc. <br/>
    * @param toneId the #LinphoneToneId <br/>
    * @param audiofile a wav file to be played or null to use the default (generated)<br/>
    * one.   <br/>
    */
    public void setTone(ToneID toneId, @Nullable String audiofile);

    /**
    * Set the user agent string used in SIP messages. <br/>
    * <br/>
    * Set the user agent string used in SIP messages as "[ua_name]/[version]". No<br/>
    * slash character will be printed if null is given to "version". If null is given<br/>
    * to "ua_name" and "version" both, the User-agent header will be empty.<br/>
    * This function should be called just after linphone_factory_create_core ideally. <br/>
    * @param name Name of the user agent.   <br/>
    * @param version Version of the user agent.   <br/>
    */
    public void setUserAgent(@Nullable String name, @Nullable String version);

    /**
    * Sets the UDP port range from which to randomly select the port used for video<br/>
    * streaming. <br/>
    * <br/>
    * @param minPort The lower bound of the video port range to use <br/>
    * @param maxPort The upper bound of the video port range to use <br/>
    */
    public void setVideoPortRange(int minPort, int maxPort);

    /**
    * Tells whether a specified sound device can capture sound. <br/>
    * <br/>
    * @param device the device name as returned by linphone_core_get_sound_devices   <br/>
    * @return A boolean value telling whether the specified sound device can capture<br/>
    * sound <br/>
    * @deprecated 08/07/2020 use {@link AudioDevice} API instead()<br/>
    */
    @Deprecated
    public boolean soundDeviceCanCapture(@NonNull String device);

    /**
    * Tells whether a specified sound device can play sound. <br/>
    * <br/>
    * @param device the device name as returned by linphone_core_get_sound_devices   <br/>
    * @return A boolean value telling whether the specified sound device can play<br/>
    * sound <br/>
    * @deprecated 08/07/2020 use {@link AudioDevice} API instead()<br/>
    */
    @Deprecated
    public boolean soundDeviceCanPlayback(@NonNull String device);

    /**
    * Checks if a call will need the sound resources in near future (typically an<br/>
    * outgoing call that is awaiting response). <br/>
    * <br/>
    * In liblinphone, it is not possible to have two independant calls using sound<br/>
    * device or camera at the same time. In order to prevent this situation, an<br/>
    * application can use {@link #soundResourcesLocked} to know whether it is<br/>
    * possible at a given time to start a new outgoing call. When the function<br/>
    * returns true, an application should not allow the user to start an outgoing<br/>
    * call. <br/>
    * @return A boolean value telling whether a call will need the sound resources in<br/>
    * near future <br/>
    */
    public boolean soundResourcesLocked();

    /**
    * Starts a {@link Core} object after it has been instantiated and not<br/>
    * automatically started. <br/>
    * <br/>
    * Also re-initialize a {@link Core} object that has been stopped using {@link #stop}<br/>
    * . Must be called only if {@link GlobalState} is either Ready of Off. State will<br/>
    * changed to Startup, Configuring and then On.<br/>
    * @return 0: success, -1: global failure, -2: could not connect database <br/>
    */
    public int start();

    /**
    * Starts an echo calibration of the sound devices, in order to find adequate<br/>
    * settings for the echo canceler automatically. <br/>
    * <br/>
    * @return LinphoneStatus whether calibration has started or not. <br/>
    */
    public int startEchoCancellerCalibration();

    /**
    * Start the simulation of call to test the latency with an external device. <br/>
    * <br/>
    * @param rate Sound sample rate. <br/>
    * @return -1 in case of failure, 1 otherwise. <br/>
    */
    public int startEchoTester(int rate);

    /**
    * Stops a {@link Core} object after it has been instantiated and started. <br/>
    * <br/>
    * If stopped, it can be started again using {@link #start}. Must be called only<br/>
    * if {@link GlobalState} is either On. State will changed to Shutdown and then<br/>
    * Off. This function may block to perform SIP server unregistration. Using {@link #stopAsync}<br/>
    * is preferred.<br/>
    * warning: This function must never be called from within an event notification<br/>
    * triggered by Liblinphone. <br/>
    */
    public void stop();

    /**
    * Asynchronously stops a {@link Core} object after it has been instantiated and<br/>
    * started. <br/>
    * <br/>
    * State changes to Shutdown then {@link #iterate} must be called to allow the<br/>
    * Core to end asynchronous tasks (terminate call, etc.). When all tasks are<br/>
    * finished, State will change to Off. Must be called only if {@link GlobalState}<br/>
    * is On. When {@link GlobalState} is Off {@link Core} can be started again using<br/>
    * {@link #start}.<br/>
    * warning: This function must never be called from within an event notification<br/>
    * triggered by Liblinphone. <br/>
    */
    public void stopAsync();

    /**
    * Stops playing a dtmf started by {@link #playDtmf}. <br/>
    * <br/>
    */
    public void stopDtmf();

    /**
    * Stop the simulation of call. <br/>
    * <br/>
    */
    public int stopEchoTester();

    /**
    * Whenever the liblinphone is playing a ring to advertise an incoming call or<br/>
    * ringback of an outgoing call, this function stops the ringing. <br/>
    * <br/>
    * Typical use is to stop ringing when the user requests to ignore the call. <br/>
    */
    public void stopRinging();

    /**
    * Creates and send an outgoing subscription, specifying the destination resource,<br/>
    * the event name, and an optional content body. <br/>
    * <br/>
    * If accepted, the subscription runs for a finite period, but is automatically<br/>
    * renewed if not terminated before. <br/>
    * @param resource the destination resource   <br/>
    * @param event the event name   <br/>
    * @param expires the whished duration of the subscription <br/>
    * @param body an optional body, may be null.   <br/>
    * @return a {@link Event} holding the context of the created subcription.   <br/>
    */
    @NonNull
    public Event subscribe(@NonNull Address resource, @NonNull String event, int expires, @Nullable Content body);

    /**
    * Takes a photo of currently from capture device and write it into a jpeg file. <br/>
    * <br/>
    * Note that the snapshot is asynchronous, an application shall not assume that<br/>
    * the file is created when the function returns.<br/>
    * @param file a path where to write the jpeg content.   <br/>
    * @return 0 if successful, -1 otherwise (typically if jpeg format is not<br/>
    * supported). <br/>
    */
    public int takePreviewSnapshot(@NonNull String file);

    /**
    * Terminates all the calls. <br/>
    * <br/>
    * @return 0 <br/>
    */
    public int terminateAllCalls();

    /**
    * Terminates the running conference. <br/>
    * <br/>
    * If it is a local conference, all calls inside it will become back separate<br/>
    * calls and will be put in #LinphoneCallPaused state. If it is a conference<br/>
    * involving a focus server, all calls inside the conference will be terminated. <br/>
    * @return 0 if succeeded. Negative number if failed <br/>
    * @deprecated 23/01/2025 Use {@link Conference#terminate} instead. <br/>
    */
    @Deprecated
    public int terminateConference();

    /**
    * Uploads the log collection to the configured server url. <br/>
    * <br/>
    */
    public void uploadLogCollection();

    /**
    * Tells the core to use a separate window for local camera preview video, instead<br/>
    * of inserting local view within the remote video window. <br/>
    * <br/>
    * @param yesno true to use a separate window, false to insert the preview in the<br/>
    * remote video window. <br/>
    */
    public void usePreviewWindow(boolean yesno);

    /**
    * Specify whether the tls server certificate must be verified when connecting to<br/>
    * a SIP/TLS server. <br/>
    * <br/>
    * @param yesno A boolean value telling whether the tls server certificate must be<br/>
    * verified <br/>
    */
    public void verifyServerCertificates(boolean yesno);

    /**
    * Specify whether the tls server certificate common name must be verified when<br/>
    * connecting to a SIP/TLS server. <br/>
    * <br/>
    * @param yesno A boolean value telling whether the tls server certificate common<br/>
    * name must be verified <br/>
    */
    public void verifyServerCn(boolean yesno);

    /**
    * Test if video is supported. <br/>
    * <br/>
    * @return true if the library was built with video support, false otherwise <br/>
    */
    public boolean videoSupported();

    /**
    * Compresses the log collection in a single file. <br/>
    * <br/>
    * @return The path of the compressed log collection file.     <br/>
    */
    @NonNull
    public String compressLogCollection();

    /**
    * Enables the linphone core log collection to upload logs on a server. <br/>
    * <br/>
    * @param state {@link LogCollectionState} value telling whether to enable log<br/>
    * collection or not. <br/>
    */
    public void enableLogCollection(LogCollectionState state);

    /**
    * Gets the max file size in bytes of the files used for log collection. <br/>
    * <br/>
    * @return The max file size in bytes of the files used for log collection.   <br/>
    */
    @NonNull
    public int getLogCollectionMaxFileSize();

    /**
    * Gets the path where the log files will be written for log collection. <br/>
    * <br/>
    * @return The path where the log files will be written.   <br/>
    */
    @NonNull
    public String getLogCollectionPath();

    /**
    * Gets the prefix of the filenames that will be used for log collection. <br/>
    * <br/>
    * @return The prefix of the filenames used for log collection.   <br/>
    */
    @NonNull
    public String getLogCollectionPrefix();

    /**
    * Are PostQuantum algoritms available. <br/>
    * <br/>
    * @return true if Post Quantum algorithms are available false otherwise <br/>
    */
    public boolean getPostQuantumAvailable();

    /**
    * Returns liblinphone's version as a string. <br/>
    * <br/>
    * @return the current version of the {@link Core}   <br/>
    */
    @NonNull
    public String getVersion();

    /**
    * Tells whether the linphone core log collection is enabled. <br/>
    * <br/>
    * @return The {@link LogCollectionState} of the {@link Core} log collection. <br/>
    */
    public LogCollectionState logCollectionEnabled();

    /**
    * Resets the log collection by removing the log files. <br/>
    * <br/>
    */
    public void resetLogCollection();

    /**
    * Enables logs serialization (output logs from either the thread that creates the<br/>
    * linphone core or the thread that calls {@link #iterate}). <br/>
    * <br/>
    * Must be called before creating the {@link Core}. <br/>
    */
    public void serializeLogs();

    /**
    * Sets the max file size in bytes of the files used for log collection. <br/>
    * <br/>
    * Warning: this function should only not be used to change size dynamically but<br/>
    * instead only before calling {@link #enableLogCollection}. If you increase max<br/>
    * size on runtime, logs chronological order COULD be broken. <br/>
    * @param size The max file size in bytes of the files used for log collection. <br/>
    */
    public void setLogCollectionMaxFileSize(int size);

    /**
    * Sets the path of a directory where the log files will be written for log<br/>
    * collection. <br/>
    * <br/>
    * When log collection is enabled, the function will close the file with the<br/>
    * current prefix in the old path and it will open the new file with current<br/>
    * prefix in the new path. If you need to change the path and the file at the same<br/>
    * time, then you should deactivate log collection with {@link #enableLogCollection}<br/>
    * before doing modifications. <br/>
    * @param path The path where the log files will be written.   <br/>
    */
    public void setLogCollectionPath(@NonNull String path);

    /**
    * Sets the prefix of the filenames that will be used for log collection. <br/>
    * <br/>
    * When log collection is enabled, the function will close the old file and it<br/>
    * will open the new one in the current path. If you need to change the path and<br/>
    * the file at the same time, then you should deactivate log collection with<br/>
    * {@link #enableLogCollection} before doing modifications. <br/>
    * @param prefix The prefix to use for the filenames for log collection.   <br/>
    */
    public void setLogCollectionPrefix(@NonNull String prefix);

    /**
    * True if tunnel extension was compiled. <br/>
    * <br/>
    * @return true if library was built with tunnel, false otherwise <br/>
    */
    public boolean tunnelAvailable();

    /**
    * Return the availability of uPnP. <br/>
    * <br/>
    * @return true if uPnP is available otherwise return false. <br/>
    * warning: UPNP support has been removed, and proved to be useless. <br/>
    */
    public boolean upnpAvailable();

    /**
    * Tells whether VCARD support is builtin. <br/>
    * <br/>
    * @return true if VCARD is supported, false otherwise. <br/>
    */
    public boolean vcardSupported();

    /**
    */
    public void addListener(CoreListener listener);

    /**
    */
    public void removeListener(CoreListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class CoreImpl implements Core {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected CoreImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getAccountCreatorBackend(long nativePtr);
    @Override
    synchronized public AccountCreator.Backend getAccountCreatorBackend()  {
        
        
        return AccountCreator.Backend.fromInt(getAccountCreatorBackend(nativePtr));
    }

    private native void setAccountCreatorBackend(long nativePtr, int backend);
    @Override
    synchronized public void setAccountCreatorBackend(AccountCreator.Backend backend)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccountCreatorBackend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccountCreatorBackend(nativePtr, backend.toInt());
    }

    private native String getAccountCreatorUrl(long nativePtr);
    @Override @Nullable
    synchronized public String getAccountCreatorUrl()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getAccountCreatorUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getAccountCreatorUrl(nativePtr);
    }

    private native void setAccountCreatorUrl(long nativePtr, String url);
    @Override
    synchronized public void setAccountCreatorUrl(@Nullable String url)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccountCreatorUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccountCreatorUrl(nativePtr, url);
    }

    private native Account[] getAccountList(long nativePtr);
    @Override @NonNull
    synchronized public Account[] getAccountList()  {
        
        
        return getAccountList(nativePtr);
    }

    private native String getAdaptiveRateAlgorithm(long nativePtr);
    @Override @NonNull
    synchronized public String getAdaptiveRateAlgorithm()  {
        
        
        return getAdaptiveRateAlgorithm(nativePtr);
    }

    private native void setAdaptiveRateAlgorithm(long nativePtr, String algorithm);
    @Override
    synchronized public void setAdaptiveRateAlgorithm(@NonNull String algorithm)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAdaptiveRateAlgorithm() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAdaptiveRateAlgorithm(nativePtr, algorithm);
    }

    private native boolean isAdaptiveRateControlEnabled(long nativePtr);
    @Override
    synchronized public boolean isAdaptiveRateControlEnabled()  {
        
        
        return isAdaptiveRateControlEnabled(nativePtr);
    }

    private native void setAdaptiveRateControlEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setAdaptiveRateControlEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAdaptiveRateControlEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAdaptiveRateControlEnabled(nativePtr, enabled);
    }

    private native boolean isAgcEnabled(long nativePtr);
    @Override
    synchronized public boolean isAgcEnabled()  {
        
        
        return isAgcEnabled(nativePtr);
    }

    private native void setAgcEnabled(long nativePtr, boolean val);
    @Override
    synchronized public void setAgcEnabled(boolean val)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAgcEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAgcEnabled(nativePtr, val);
    }

    private native boolean isAlertsEnabled(long nativePtr);
    @Override
    synchronized public boolean isAlertsEnabled()  {
        
        
        return isAlertsEnabled(nativePtr);
    }

    private native void setAlertsEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setAlertsEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAlertsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAlertsEnabled(nativePtr, enable);
    }

    private native boolean isAudioAdaptiveJittcompEnabled(long nativePtr);
    @Override
    synchronized public boolean isAudioAdaptiveJittcompEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAudioAdaptiveJittcompEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isAudioAdaptiveJittcompEnabled(nativePtr);
    }

    private native void setAudioAdaptiveJittcompEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setAudioAdaptiveJittcompEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioAdaptiveJittcompEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioAdaptiveJittcompEnabled(nativePtr, enable);
    }

    private native AudioDevice[] getAudioDevices(long nativePtr);
    @Override @NonNull
    synchronized public AudioDevice[] getAudioDevices()  {
        
        
        return getAudioDevices(nativePtr);
    }

    private native int getAudioDscp(long nativePtr);
    @Override
    synchronized public int getAudioDscp()  {
        
        
        return getAudioDscp(nativePtr);
    }

    private native void setAudioDscp(long nativePtr, int dscp);
    @Override
    synchronized public void setAudioDscp(int dscp)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioDscp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioDscp(nativePtr, dscp);
    }

    private native int getAudioJittcomp(long nativePtr);
    @Override
    synchronized public int getAudioJittcomp()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getAudioJittcomp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getAudioJittcomp(nativePtr);
    }

    private native void setAudioJittcomp(long nativePtr, int milliseconds);
    @Override
    synchronized public void setAudioJittcomp(int milliseconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioJittcomp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioJittcomp(nativePtr, milliseconds);
    }

    private native String getAudioMulticastAddr(long nativePtr);
    @Override @Nullable
    synchronized public String getAudioMulticastAddr()  {
        
        
        return getAudioMulticastAddr(nativePtr);
    }

    private native int setAudioMulticastAddr(long nativePtr, String ip);
    @Override
    synchronized public int setAudioMulticastAddr(@Nullable String ip)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioMulticastAddr() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setAudioMulticastAddr(nativePtr, ip);
    }

    private native boolean isAudioMulticastEnabled(long nativePtr);
    @Override
    synchronized public boolean isAudioMulticastEnabled()  {
        
        
        return isAudioMulticastEnabled(nativePtr);
    }

    private native void setAudioMulticastEnabled(long nativePtr, boolean yesno);
    @Override
    synchronized public void setAudioMulticastEnabled(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioMulticastEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioMulticastEnabled(nativePtr, yesno);
    }

    private native int getAudioMulticastTtl(long nativePtr);
    @Override
    synchronized public int getAudioMulticastTtl()  {
        
        
        return getAudioMulticastTtl(nativePtr);
    }

    private native int setAudioMulticastTtl(long nativePtr, int ttl);
    @Override
    synchronized public int setAudioMulticastTtl(int ttl)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioMulticastTtl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setAudioMulticastTtl(nativePtr, ttl);
    }

    private native PayloadType[] getAudioPayloadTypes(long nativePtr);
    @Override @NonNull
    synchronized public PayloadType[] getAudioPayloadTypes()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getAudioPayloadTypes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getAudioPayloadTypes(nativePtr);
    }

    private native void setAudioPayloadTypes(long nativePtr, PayloadType[] payloadTypes);
    @Override
    synchronized public void setAudioPayloadTypes(@Nullable PayloadType[] payloadTypes)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioPayloadTypes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioPayloadTypes(nativePtr, payloadTypes);
    }

    private native int getAudioPort(long nativePtr);
    @Override
    synchronized public int getAudioPort()  {
        
        
        return getAudioPort(nativePtr);
    }

    private native void setAudioPort(long nativePtr, int port);
    @Override
    synchronized public void setAudioPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioPort(nativePtr, port);
    }

    private native Range getAudioPortsRange(long nativePtr);
    @Override @NonNull
    synchronized public Range getAudioPortsRange()  {
        
        
        return (Range)getAudioPortsRange(nativePtr);
    }

    private native AuthInfo[] getAuthInfoList(long nativePtr);
    @Override @NonNull
    synchronized public AuthInfo[] getAuthInfoList()  {
        
        
        return getAuthInfoList(nativePtr);
    }

    private native boolean isAutoDownloadIcalendarsEnabled(long nativePtr);
    @Override
    synchronized public boolean isAutoDownloadIcalendarsEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAutoDownloadIcalendarsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isAutoDownloadIcalendarsEnabled(nativePtr);
    }

    private native void setAutoDownloadIcalendarsEnabled(long nativePtr, boolean autoDownloadIcalendars);
    @Override
    synchronized public void setAutoDownloadIcalendarsEnabled(boolean autoDownloadIcalendars)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAutoDownloadIcalendarsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAutoDownloadIcalendarsEnabled(nativePtr, autoDownloadIcalendars);
    }

    private native boolean isAutoDownloadVoiceRecordingsEnabled(long nativePtr);
    @Override
    synchronized public boolean isAutoDownloadVoiceRecordingsEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAutoDownloadVoiceRecordingsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isAutoDownloadVoiceRecordingsEnabled(nativePtr);
    }

    private native void setAutoDownloadVoiceRecordingsEnabled(long nativePtr, boolean autoDownloadVoiceRecordings);
    @Override
    synchronized public void setAutoDownloadVoiceRecordingsEnabled(boolean autoDownloadVoiceRecordings)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAutoDownloadVoiceRecordingsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAutoDownloadVoiceRecordingsEnabled(nativePtr, autoDownloadVoiceRecordings);
    }

    private native int getAutoIterateBackgroundSchedule(long nativePtr);
    @Override
    synchronized public int getAutoIterateBackgroundSchedule()  {
        
        
        return getAutoIterateBackgroundSchedule(nativePtr);
    }

    private native void setAutoIterateBackgroundSchedule(long nativePtr, int schedule);
    @Override
    synchronized public void setAutoIterateBackgroundSchedule(int schedule)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAutoIterateBackgroundSchedule() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAutoIterateBackgroundSchedule(nativePtr, schedule);
    }

    private native boolean isAutoIterateEnabled(long nativePtr);
    @Override
    synchronized public boolean isAutoIterateEnabled()  {
        
        
        return isAutoIterateEnabled(nativePtr);
    }

    private native void setAutoIterateEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setAutoIterateEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAutoIterateEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAutoIterateEnabled(nativePtr, enable);
    }

    private native int getAutoIterateForegroundSchedule(long nativePtr);
    @Override
    synchronized public int getAutoIterateForegroundSchedule()  {
        
        
        return getAutoIterateForegroundSchedule(nativePtr);
    }

    private native void setAutoIterateForegroundSchedule(long nativePtr, int schedule);
    @Override
    synchronized public void setAutoIterateForegroundSchedule(int schedule)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAutoIterateForegroundSchedule() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAutoIterateForegroundSchedule(nativePtr, schedule);
    }

    private native boolean isAutoSendRingingEnabled(long nativePtr);
    @Override
    synchronized public boolean isAutoSendRingingEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAutoSendRingingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isAutoSendRingingEnabled(nativePtr);
    }

    private native void setAutoSendRingingEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setAutoSendRingingEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAutoSendRingingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAutoSendRingingEnabled(nativePtr, enable);
    }

    private native boolean isAutomaticHttpProxyDetectionEnabled(long nativePtr);
    @Override
    synchronized public boolean isAutomaticHttpProxyDetectionEnabled()  {
        
        
        return isAutomaticHttpProxyDetectionEnabled(nativePtr);
    }

    private native void setAutomaticHttpProxyDetectionEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setAutomaticHttpProxyDetectionEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAutomaticHttpProxyDetectionEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAutomaticHttpProxyDetectionEnabled(nativePtr, enable);
    }

    private native int getAvpfMode(long nativePtr);
    @Override
    synchronized public AVPFMode getAvpfMode()  {
        
        
        return AVPFMode.fromInt(getAvpfMode(nativePtr));
    }

    private native void setAvpfMode(long nativePtr, int mode);
    @Override
    synchronized public void setAvpfMode(AVPFMode mode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAvpfMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAvpfMode(nativePtr, mode.toInt());
    }

    private native int getAvpfRrInterval(long nativePtr);
    @Override
    synchronized public int getAvpfRrInterval()  {
        
        
        return getAvpfRrInterval(nativePtr);
    }

    private native void setAvpfRrInterval(long nativePtr, int interval);
    @Override
    synchronized public void setAvpfRrInterval(int interval)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAvpfRrInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAvpfRrInterval(nativePtr, interval);
    }

    private native boolean isBaudotEnabled(long nativePtr);
    @Override
    synchronized public boolean isBaudotEnabled()  {
        
        
        return isBaudotEnabled(nativePtr);
    }

    private native void setBaudotEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setBaudotEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBaudotEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBaudotEnabled(nativePtr, enabled);
    }

    private native CallLog[] getCallLogs(long nativePtr);
    @Override @NonNull
    synchronized public CallLog[] getCallLogs()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCallLogs() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCallLogs(nativePtr);
    }

    private native String getCallLogsDatabasePath(long nativePtr);
    @Override @Nullable
    synchronized public String getCallLogsDatabasePath()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCallLogsDatabasePath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCallLogsDatabasePath(nativePtr);
    }

    private native void setCallLogsDatabasePath(long nativePtr, String path);
    @Override
    synchronized public void setCallLogsDatabasePath(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCallLogsDatabasePath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCallLogsDatabasePath(nativePtr, path);
    }

    private native boolean isCallToneIndicationsEnabled(long nativePtr);
    @Override
    synchronized public boolean isCallToneIndicationsEnabled()  {
        
        
        return isCallToneIndicationsEnabled(nativePtr);
    }

    private native void setCallToneIndicationsEnabled(long nativePtr, boolean yesno);
    @Override
    synchronized public void setCallToneIndicationsEnabled(boolean yesno)  {
        
        
        setCallToneIndicationsEnabled(nativePtr, yesno);
    }

    private native boolean isCallkitEnabled(long nativePtr);
    @Override
    synchronized public boolean isCallkitEnabled()  {
        
        
        return isCallkitEnabled(nativePtr);
    }

    private native void setCallkitEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setCallkitEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCallkitEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCallkitEnabled(nativePtr, enabled);
    }

    private native Call[] getCalls(long nativePtr);
    @Override @NonNull
    synchronized public Call[] getCalls()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCalls() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCalls(nativePtr);
    }

    private native int getCallsNb(long nativePtr);
    @Override
    synchronized public int getCallsNb()  {
        
        
        return getCallsNb(nativePtr);
    }

    private native int getCameraSensorRotation(long nativePtr);
    @Override
    synchronized public int getCameraSensorRotation()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCameraSensorRotation() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCameraSensorRotation(nativePtr);
    }

    private native int getCameraWhitebalance(long nativePtr);
    @Override
    synchronized public int getCameraWhitebalance()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCameraWhitebalance() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCameraWhitebalance(nativePtr);
    }

    private native int setCameraWhitebalance(long nativePtr, int whitebalance);
    @Override
    synchronized public int setCameraWhitebalance(int whitebalance)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCameraWhitebalance() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setCameraWhitebalance(nativePtr, whitebalance);
    }

    private native boolean isCapabilityNegociationEnabled(long nativePtr);
    @Override
    synchronized public boolean isCapabilityNegociationEnabled()  {
        
        
        return isCapabilityNegociationEnabled(nativePtr);
    }

    private native void setCapabilityNegociationEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setCapabilityNegociationEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCapabilityNegociationEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCapabilityNegociationEnabled(nativePtr, enable);
    }

    private native boolean isCapabilityNegotiationReinviteEnabled(long nativePtr);
    @Override
    synchronized public boolean isCapabilityNegotiationReinviteEnabled()  {
        
        
        return isCapabilityNegotiationReinviteEnabled(nativePtr);
    }

    private native void setCapabilityNegotiationReinviteEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setCapabilityNegotiationReinviteEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCapabilityNegotiationReinviteEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCapabilityNegotiationReinviteEnabled(nativePtr, enable);
    }

    private native String getCaptureDevice(long nativePtr);
    @Override @Nullable
    synchronized public String getCaptureDevice()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCaptureDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCaptureDevice(nativePtr);
    }

    private native int setCaptureDevice(long nativePtr, String devid);
    @Override
    synchronized public int setCaptureDevice(@Nullable String devid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCaptureDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setCaptureDevice(nativePtr, devid);
    }

    private native boolean isCfgLinesMergingEnabled(long nativePtr);
    @Override
    synchronized public boolean isCfgLinesMergingEnabled()  {
        
        
        return isCfgLinesMergingEnabled(nativePtr);
    }

    private native void setCfgLinesMergingEnabled(long nativePtr, boolean merge);
    @Override
    synchronized public void setCfgLinesMergingEnabled(boolean merge)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCfgLinesMergingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCfgLinesMergingEnabled(nativePtr, merge);
    }

    private native boolean isChatEnabled(long nativePtr);
    @Override
    synchronized public boolean isChatEnabled()  {
        
        
        return isChatEnabled(nativePtr);
    }

    private native boolean getChatMessagesAggregationEnabled(long nativePtr);
    @Override
    synchronized public boolean getChatMessagesAggregationEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getChatMessagesAggregationEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getChatMessagesAggregationEnabled(nativePtr);
    }

    private native void setChatMessagesAggregationEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setChatMessagesAggregationEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setChatMessagesAggregationEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setChatMessagesAggregationEnabled(nativePtr, enabled);
    }

    private native ChatRoom[] getChatRooms(long nativePtr);
    @Override @NonNull
    synchronized public ChatRoom[] getChatRooms()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getChatRooms() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getChatRooms(nativePtr);
    }

    private native long getConferenceAvailabilityBeforeStart(long nativePtr);
    @Override
    synchronized public long getConferenceAvailabilityBeforeStart()  {
        
        
        return getConferenceAvailabilityBeforeStart(nativePtr);
    }

    private native void setConferenceAvailabilityBeforeStart(long nativePtr, long seconds);
    @Override
    synchronized public void setConferenceAvailabilityBeforeStart(long seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceAvailabilityBeforeStart() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceAvailabilityBeforeStart(nativePtr, seconds);
    }

    private native long getConferenceCleanupPeriod(long nativePtr);
    @Override
    synchronized public long getConferenceCleanupPeriod()  {
        
        
        return getConferenceCleanupPeriod(nativePtr);
    }

    private native void setConferenceCleanupPeriod(long nativePtr, long seconds);
    @Override
    synchronized public void setConferenceCleanupPeriod(long seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceCleanupPeriod() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceCleanupPeriod(nativePtr, seconds);
    }

    private native long getConferenceExpirePeriod(long nativePtr);
    @Override
    synchronized public long getConferenceExpirePeriod()  {
        
        
        return getConferenceExpirePeriod(nativePtr);
    }

    private native void setConferenceExpirePeriod(long nativePtr, long seconds);
    @Override
    synchronized public void setConferenceExpirePeriod(long seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceExpirePeriod() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceExpirePeriod(nativePtr, seconds);
    }

    private native boolean isConferenceIcsInMessageBodyEnabled(long nativePtr);
    @Override
    synchronized public boolean isConferenceIcsInMessageBodyEnabled()  {
        
        
        return isConferenceIcsInMessageBodyEnabled(nativePtr);
    }

    private native void setConferenceIcsInMessageBodyEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setConferenceIcsInMessageBodyEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceIcsInMessageBodyEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceIcsInMessageBodyEnabled(nativePtr, enable);
    }

    private native ConferenceInfo[] getConferenceInformationList(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceInfo[] getConferenceInformationList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getConferenceInformationList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getConferenceInformationList(nativePtr);
    }

    private native float getConferenceLocalInputVolume(long nativePtr);
    @Override
    synchronized public float getConferenceLocalInputVolume()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getConferenceLocalInputVolume() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getConferenceLocalInputVolume(nativePtr);
    }

    private native int getConferenceMaxThumbnails(long nativePtr);
    @Override
    synchronized public int getConferenceMaxThumbnails()  {
        
        
        return getConferenceMaxThumbnails(nativePtr);
    }

    private native void setConferenceMaxThumbnails(long nativePtr, int max);
    @Override
    synchronized public void setConferenceMaxThumbnails(int max)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceMaxThumbnails() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceMaxThumbnails(nativePtr, max);
    }

    private native int getConferenceParticipantListType(long nativePtr);
    @Override
    synchronized public Conference.ParticipantListType getConferenceParticipantListType()  {
        
        
        return Conference.ParticipantListType.fromInt(getConferenceParticipantListType(nativePtr));
    }

    private native void setConferenceParticipantListType(long nativePtr, int type);
    @Override
    synchronized public void setConferenceParticipantListType(Conference.ParticipantListType type)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceParticipantListType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceParticipantListType(nativePtr, type.toInt());
    }

    private native boolean isConferenceServerEnabled(long nativePtr);
    @Override
    synchronized public boolean isConferenceServerEnabled()  {
        
        
        return isConferenceServerEnabled(nativePtr);
    }

    private native void setConferenceServerEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setConferenceServerEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceServerEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceServerEnabled(nativePtr, enable);
    }

    private native Config getConfig(long nativePtr);
    @Override @NonNull
    synchronized public Config getConfig()  {
        
        
        return (Config)getConfig(nativePtr);
    }

    private native int getConsolidatedPresence(long nativePtr);
    @Override
    synchronized public ConsolidatedPresence getConsolidatedPresence()  {
        
        
        return ConsolidatedPresence.fromInt(getConsolidatedPresence(nativePtr));
    }

    private native void setConsolidatedPresence(long nativePtr, int presence);
    @Override
    synchronized public void setConsolidatedPresence(ConsolidatedPresence presence)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConsolidatedPresence() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConsolidatedPresence(nativePtr, presence.toInt());
    }

    private native Call getCurrentCall(long nativePtr);
    @Override @Nullable
    synchronized public Call getCurrentCall()  {
        
        
        return (Call)getCurrentCall(nativePtr);
    }

    private native Address getCurrentCallRemoteAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getCurrentCallRemoteAddress()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCurrentCallRemoteAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)getCurrentCallRemoteAddress(nativePtr);
    }

    private native VideoDefinition getCurrentPreviewVideoDefinition(long nativePtr);
    @Override @NonNull
    synchronized public VideoDefinition getCurrentPreviewVideoDefinition()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCurrentPreviewVideoDefinition() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (VideoDefinition)getCurrentPreviewVideoDefinition(nativePtr);
    }

    private native boolean isDatabaseEnabled(long nativePtr);
    @Override
    synchronized public boolean isDatabaseEnabled()  {
        
        
        return isDatabaseEnabled(nativePtr);
    }

    private native void setDatabaseEnabled(long nativePtr, boolean value);
    @Override
    synchronized public void setDatabaseEnabled(boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDatabaseEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDatabaseEnabled(nativePtr, value);
    }

    private native Account getDefaultAccount(long nativePtr);
    @Override @Nullable
    synchronized public Account getDefaultAccount()  {
        
        
        return (Account)getDefaultAccount(nativePtr);
    }

    private native void setDefaultAccount(long nativePtr, Account account);
    @Override
    synchronized public void setDefaultAccount(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDefaultAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDefaultAccount(nativePtr, account);
    }

    private native int getDefaultConferenceLayout(long nativePtr);
    @Override
    synchronized public Conference.Layout getDefaultConferenceLayout()  {
        
        
        return Conference.Layout.fromInt(getDefaultConferenceLayout(nativePtr));
    }

    private native void setDefaultConferenceLayout(long nativePtr, int value);
    @Override
    synchronized public void setDefaultConferenceLayout(Conference.Layout value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDefaultConferenceLayout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDefaultConferenceLayout(nativePtr, value.toInt());
    }

    private native long getDefaultEphemeralLifetime(long nativePtr);
    @Override
    synchronized public long getDefaultEphemeralLifetime()  {
        
        
        return getDefaultEphemeralLifetime(nativePtr);
    }

    private native void setDefaultEphemeralLifetime(long nativePtr, long value);
    @Override
    synchronized public void setDefaultEphemeralLifetime(long value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDefaultEphemeralLifetime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDefaultEphemeralLifetime(nativePtr, value);
    }

    private native FriendList getDefaultFriendList(long nativePtr);
    @Override @Nullable
    synchronized public FriendList getDefaultFriendList()  {
        
        
        return (FriendList)getDefaultFriendList(nativePtr);
    }

    private native AudioDevice getDefaultInputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getDefaultInputAudioDevice()  {
        
        
        return (AudioDevice)getDefaultInputAudioDevice(nativePtr);
    }

    private native void setDefaultInputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setDefaultInputAudioDevice(@Nullable AudioDevice audioDevice)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDefaultInputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDefaultInputAudioDevice(nativePtr, audioDevice);
    }

    private native AudioDevice getDefaultOutputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getDefaultOutputAudioDevice()  {
        
        
        return (AudioDevice)getDefaultOutputAudioDevice(nativePtr);
    }

    private native void setDefaultOutputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setDefaultOutputAudioDevice(@Nullable AudioDevice audioDevice)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDefaultOutputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDefaultOutputAudioDevice(nativePtr, audioDevice);
    }

    private native ProxyConfig getDefaultProxyConfig(long nativePtr);
    @Override @Nullable
    synchronized public ProxyConfig getDefaultProxyConfig()  {
        
        
        return (ProxyConfig)getDefaultProxyConfig(nativePtr);
    }

    private native void setDefaultProxyConfig(long nativePtr, ProxyConfig config);
    @Override
    synchronized public void setDefaultProxyConfig(@Nullable ProxyConfig config)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDefaultProxyConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDefaultProxyConfig(nativePtr, config);
    }

    private native String getDefaultVideoDisplayFilter(long nativePtr);
    @Override @NonNull
    synchronized public String getDefaultVideoDisplayFilter()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDefaultVideoDisplayFilter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDefaultVideoDisplayFilter(nativePtr);
    }

    private native int getDelayedTimeout(long nativePtr);
    @Override
    synchronized public int getDelayedTimeout()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDelayedTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDelayedTimeout(nativePtr);
    }

    private native void setDelayedTimeout(long nativePtr, int seconds);
    @Override
    synchronized public void setDelayedTimeout(int seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDelayedTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDelayedTimeout(nativePtr, seconds);
    }

    private native int getDeviceRotation(long nativePtr);
    @Override
    synchronized public int getDeviceRotation()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDeviceRotation() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDeviceRotation(nativePtr);
    }

    private native void setDeviceRotation(long nativePtr, int rotation);
    @Override
    synchronized public void setDeviceRotation(int rotation)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDeviceRotation() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDeviceRotation(nativePtr, rotation);
    }

    private native DigestAuthenticationPolicy getDigestAuthenticationPolicy(long nativePtr);
    @Override @NonNull
    synchronized public DigestAuthenticationPolicy getDigestAuthenticationPolicy()  {
        
        
        return (DigestAuthenticationPolicy)getDigestAuthenticationPolicy(nativePtr);
    }

    private native void setDigestAuthenticationPolicy(long nativePtr, DigestAuthenticationPolicy policy);
    @Override
    synchronized public void setDigestAuthenticationPolicy(@NonNull DigestAuthenticationPolicy policy)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDigestAuthenticationPolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDigestAuthenticationPolicy(nativePtr, policy);
    }

    private native boolean getDisableRecordOnMute(long nativePtr);
    @Override
    synchronized public boolean getDisableRecordOnMute()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDisableRecordOnMute() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDisableRecordOnMute(nativePtr);
    }

    private native void setDisableRecordOnMute(long nativePtr, boolean disable);
    @Override
    synchronized public void setDisableRecordOnMute(boolean disable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDisableRecordOnMute() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDisableRecordOnMute(nativePtr, disable);
    }

    private native boolean isDnsSearchEnabled(long nativePtr);
    @Override
    synchronized public boolean isDnsSearchEnabled()  {
        
        
        return isDnsSearchEnabled(nativePtr);
    }

    private native void setDnsSearchEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setDnsSearchEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDnsSearchEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDnsSearchEnabled(nativePtr, enable);
    }

    private native void setDnsServers(long nativePtr, String[] servers);
    @Override
    synchronized public void setDnsServers(@Nullable String[] servers)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDnsServers() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDnsServers(nativePtr, servers);
    }

    private native void setDnsServersApp(long nativePtr, String[] servers);
    @Override
    synchronized public void setDnsServersApp(@Nullable String[] servers)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDnsServersApp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDnsServersApp(nativePtr, servers);
    }

    private native boolean getDnsSetByApp(long nativePtr);
    @Override
    synchronized public boolean getDnsSetByApp()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDnsSetByApp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDnsSetByApp(nativePtr);
    }

    private native boolean isDnsSrvEnabled(long nativePtr);
    @Override
    synchronized public boolean isDnsSrvEnabled()  {
        
        
        return isDnsSrvEnabled(nativePtr);
    }

    private native void setDnsSrvEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setDnsSrvEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDnsSrvEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDnsSrvEnabled(nativePtr, enable);
    }

    private native int getDownloadBandwidth(long nativePtr);
    @Override
    synchronized public int getDownloadBandwidth()  {
        
        
        return getDownloadBandwidth(nativePtr);
    }

    private native void setDownloadBandwidth(long nativePtr, int bandwidth);
    @Override
    synchronized public void setDownloadBandwidth(int bandwidth)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDownloadBandwidth() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDownloadBandwidth(nativePtr, bandwidth);
    }

    private native int getDownloadPtime(long nativePtr);
    @Override
    synchronized public int getDownloadPtime()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDownloadPtime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDownloadPtime(nativePtr);
    }

    private native void setDownloadPtime(long nativePtr, int ptime);
    @Override
    synchronized public void setDownloadPtime(int ptime)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDownloadPtime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDownloadPtime(nativePtr, ptime);
    }

    private native int getEchoCancellationCalibration(long nativePtr);
    @Override
    synchronized public int getEchoCancellationCalibration()  {
        
        
        return getEchoCancellationCalibration(nativePtr);
    }

    private native boolean isEchoCancellationEnabled(long nativePtr);
    @Override
    synchronized public boolean isEchoCancellationEnabled()  {
        
        
        return isEchoCancellationEnabled(nativePtr);
    }

    private native void setEchoCancellationEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setEchoCancellationEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEchoCancellationEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEchoCancellationEnabled(nativePtr, enable);
    }

    private native String getEchoCancellerFilterName(long nativePtr);
    @Override @Nullable
    synchronized public String getEchoCancellerFilterName()  {
        
        
        return getEchoCancellerFilterName(nativePtr);
    }

    private native void setEchoCancellerFilterName(long nativePtr, String filtername);
    @Override
    synchronized public void setEchoCancellerFilterName(@Nullable String filtername)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEchoCancellerFilterName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEchoCancellerFilterName(nativePtr, filtername);
    }

    private native boolean isEchoLimiterEnabled(long nativePtr);
    @Override
    synchronized public boolean isEchoLimiterEnabled()  {
        
        
        return isEchoLimiterEnabled(nativePtr);
    }

    private native void setEchoLimiterEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setEchoLimiterEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEchoLimiterEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEchoLimiterEnabled(nativePtr, enable);
    }

    private native void setEktPluginLoaded(long nativePtr, boolean ektPluginLoaded);
    @Override
    synchronized public void setEktPluginLoaded(boolean ektPluginLoaded)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEktPluginLoaded() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEktPluginLoaded(nativePtr, ektPluginLoaded);
    }

    private native boolean isEmptyChatroomsDeletionEnabled(long nativePtr);
    @Override
    synchronized public boolean isEmptyChatroomsDeletionEnabled()  {
        
        
        return isEmptyChatroomsDeletionEnabled(nativePtr);
    }

    private native void setEmptyChatroomsDeletionEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setEmptyChatroomsDeletionEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEmptyChatroomsDeletionEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEmptyChatroomsDeletionEnabled(nativePtr, enable);
    }

    private native void setEnableSipUpdate(long nativePtr, int value);
    @Override
    synchronized public void setEnableSipUpdate(int value)  {
        
        
        setEnableSipUpdate(nativePtr, value);
    }

    private native void setExpectedBandwidth(long nativePtr, int bandwidth);
    @Override
    synchronized public void setExpectedBandwidth(int bandwidth)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setExpectedBandwidth() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setExpectedBandwidth(nativePtr, bandwidth);
    }

    private native AudioDevice[] getExtendedAudioDevices(long nativePtr);
    @Override @NonNull
    synchronized public AudioDevice[] getExtendedAudioDevices()  {
        
        
        return getExtendedAudioDevices(nativePtr);
    }

    private native boolean isFecEnabled(long nativePtr);
    @Override
    synchronized public boolean isFecEnabled()  {
        
        
        return isFecEnabled(nativePtr);
    }

    private native void setFecEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setFecEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFecEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFecEnabled(nativePtr, enable);
    }

    private native String getFileTransferServer(long nativePtr);
    @Override @Nullable
    synchronized public String getFileTransferServer()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getFileTransferServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getFileTransferServer(nativePtr);
    }

    private native void setFileTransferServer(long nativePtr, String serverUrl);
    @Override
    synchronized public void setFileTransferServer(@Nullable String serverUrl)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFileTransferServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFileTransferServer(nativePtr, serverUrl);
    }

    private native boolean isForcedIceRelayEnabled(long nativePtr);
    @Override
    synchronized public boolean isForcedIceRelayEnabled()  {
        
        
        return isForcedIceRelayEnabled(nativePtr);
    }

    private native void setForcedIceRelayEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setForcedIceRelayEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setForcedIceRelayEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setForcedIceRelayEnabled(nativePtr, enable);
    }

    private native boolean isFriendListSubscriptionEnabled(long nativePtr);
    @Override
    synchronized public boolean isFriendListSubscriptionEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isFriendListSubscriptionEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isFriendListSubscriptionEnabled(nativePtr);
    }

    private native void setFriendListSubscriptionEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setFriendListSubscriptionEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFriendListSubscriptionEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFriendListSubscriptionEnabled(nativePtr, enable);
    }

    private native String getFriendsDatabasePath(long nativePtr);
    @Override @Nullable
    synchronized public String getFriendsDatabasePath()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getFriendsDatabasePath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getFriendsDatabasePath(nativePtr);
    }

    private native void setFriendsDatabasePath(long nativePtr, String path);
    @Override
    synchronized public void setFriendsDatabasePath(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFriendsDatabasePath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFriendsDatabasePath(nativePtr, path);
    }

    private native FriendList[] getFriendsLists(long nativePtr);
    @Override @NonNull
    synchronized public FriendList[] getFriendsLists()  {
        
        
        return getFriendsLists(nativePtr);
    }

    private native ConferenceInfo[] getFutureConferenceInformationList(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceInfo[] getFutureConferenceInformationList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getFutureConferenceInformationList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getFutureConferenceInformationList(nativePtr);
    }

    private native boolean isGenericComfortNoiseEnabled(long nativePtr);
    @Override
    synchronized public boolean isGenericComfortNoiseEnabled()  {
        
        
        return isGenericComfortNoiseEnabled(nativePtr);
    }

    private native void setGenericComfortNoiseEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setGenericComfortNoiseEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setGenericComfortNoiseEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setGenericComfortNoiseEnabled(nativePtr, enabled);
    }

    private native int getGlobalState(long nativePtr);
    @Override @NonNull
    synchronized public GlobalState getGlobalState()  {
        
        
        return GlobalState.fromInt(getGlobalState(nativePtr));
    }

    private native boolean isGruuInConferenceAddressEnabled(long nativePtr);
    @Override
    synchronized public boolean isGruuInConferenceAddressEnabled()  {
        
        
        return isGruuInConferenceAddressEnabled(nativePtr);
    }

    private native void setGruuInConferenceAddressEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setGruuInConferenceAddressEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setGruuInConferenceAddressEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setGruuInConferenceAddressEnabled(nativePtr, enabled);
    }

    private native boolean getGuessHostname(long nativePtr);
    @Override
    synchronized public boolean getGuessHostname()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getGuessHostname() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getGuessHostname(nativePtr);
    }

    private native void setGuessHostname(long nativePtr, boolean enable);
    @Override
    synchronized public void setGuessHostname(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setGuessHostname() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setGuessHostname(nativePtr, enable);
    }

    private native String getHttpProxyHost(long nativePtr);
    @Override @Nullable
    synchronized public String getHttpProxyHost()  {
        
        
        return getHttpProxyHost(nativePtr);
    }

    private native void setHttpProxyHost(long nativePtr, String host);
    @Override
    synchronized public void setHttpProxyHost(@Nullable String host)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHttpProxyHost() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHttpProxyHost(nativePtr, host);
    }

    private native int getHttpProxyPort(long nativePtr);
    @Override
    synchronized public int getHttpProxyPort()  {
        
        
        return getHttpProxyPort(nativePtr);
    }

    private native void setHttpProxyPort(long nativePtr, int port);
    @Override
    synchronized public void setHttpProxyPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHttpProxyPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHttpProxyPort(nativePtr, port);
    }

    private native String getIdentity(long nativePtr);
    @Override @NonNull
    synchronized public String getIdentity()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getIdentity() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getIdentity(nativePtr);
    }

    private native ImNotifPolicy getImNotifPolicy(long nativePtr);
    @Override @Nullable
    synchronized public ImNotifPolicy getImNotifPolicy()  {
        
        
        return (ImNotifPolicy)getImNotifPolicy(nativePtr);
    }

    private native long getImdnResendPeriod(long nativePtr);
    @Override
    synchronized public long getImdnResendPeriod()  {
        
        
        return getImdnResendPeriod(nativePtr);
    }

    private native void setImdnResendPeriod(long nativePtr, long seconds);
    @Override
    synchronized public void setImdnResendPeriod(long seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setImdnResendPeriod() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setImdnResendPeriod(nativePtr, seconds);
    }

    private native int getImdnToEverybodyThreshold(long nativePtr);
    @Override
    synchronized public int getImdnToEverybodyThreshold()  {
        
        
        return getImdnToEverybodyThreshold(nativePtr);
    }

    private native void setImdnToEverybodyThreshold(long nativePtr, int threshold);
    @Override
    synchronized public void setImdnToEverybodyThreshold(int threshold)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setImdnToEverybodyThreshold() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setImdnToEverybodyThreshold(nativePtr, threshold);
    }

    private native int getInCallTimeout(long nativePtr);
    @Override
    synchronized public int getInCallTimeout()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getInCallTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getInCallTimeout(nativePtr);
    }

    private native void setInCallTimeout(long nativePtr, int seconds);
    @Override
    synchronized public void setInCallTimeout(int seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInCallTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInCallTimeout(nativePtr, seconds);
    }

    private native int getIncTimeout(long nativePtr);
    @Override
    synchronized public int getIncTimeout()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getIncTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getIncTimeout(nativePtr);
    }

    private native void setIncTimeout(long nativePtr, int seconds);
    @Override
    synchronized public void setIncTimeout(int seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIncTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setIncTimeout(nativePtr, seconds);
    }

    private native AudioDevice getInputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getInputAudioDevice()  {
        
        
        return (AudioDevice)getInputAudioDevice(nativePtr);
    }

    private native void setInputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setInputAudioDevice(@Nullable AudioDevice audioDevice)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInputAudioDevice(nativePtr, audioDevice);
    }

    private native boolean isIpv6Enabled(long nativePtr);
    @Override
    synchronized public boolean isIpv6Enabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isIpv6Enabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isIpv6Enabled(nativePtr);
    }

    private native void setIpv6Enabled6(long nativePtr, boolean enable);
    @Override
    synchronized public void setIpv6Enabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIpv6Enabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setIpv6Enabled6(nativePtr, enable);
    }

    private native boolean isEchoCancellerCalibrationRequired(long nativePtr);
    @Override
    synchronized public boolean isEchoCancellerCalibrationRequired()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isEchoCancellerCalibrationRequired() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isEchoCancellerCalibrationRequired(nativePtr);
    }

    private native boolean isEktPluginLoaded(long nativePtr);
    @Override
    synchronized public boolean isEktPluginLoaded()  {
        
        
        return isEktPluginLoaded(nativePtr);
    }

    private native boolean isInBackground(long nativePtr);
    @Override
    synchronized public boolean isInBackground()  {
        
        
        return isInBackground(nativePtr);
    }

    private native boolean isInConference(long nativePtr);
    @Override
    synchronized public boolean isInConference()  {
        
        
        return isInConference(nativePtr);
    }

    private native boolean isIncomingInvitePending(long nativePtr);
    @Override
    synchronized public boolean isIncomingInvitePending()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isIncomingInvitePending() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isIncomingInvitePending(nativePtr);
    }

    private native boolean isMediaEncryptionMandatory(long nativePtr);
    @Override
    synchronized public boolean isMediaEncryptionMandatory()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isMediaEncryptionMandatory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isMediaEncryptionMandatory(nativePtr);
    }

    private native boolean isNetworkReachable(long nativePtr);
    @Override
    synchronized public boolean isNetworkReachable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isNetworkReachable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isNetworkReachable(nativePtr);
    }

    private native boolean isPushNotificationAvailable(long nativePtr);
    @Override
    synchronized public boolean isPushNotificationAvailable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isPushNotificationAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isPushNotificationAvailable(nativePtr);
    }

    private native boolean isSenderNameHiddenInForwardMessage(long nativePtr);
    @Override
    synchronized public boolean isSenderNameHiddenInForwardMessage()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isSenderNameHiddenInForwardMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isSenderNameHiddenInForwardMessage(nativePtr);
    }

    private native boolean isVerifyServerCertificates(long nativePtr);
    @Override
    synchronized public boolean isVerifyServerCertificates()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isVerifyServerCertificates() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isVerifyServerCertificates(nativePtr);
    }

    private native boolean isVerifyServerCn(long nativePtr);
    @Override
    synchronized public boolean isVerifyServerCn()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isVerifyServerCn() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isVerifyServerCn(nativePtr);
    }

    private native boolean isKeepAliveEnabled(long nativePtr);
    @Override
    synchronized public boolean isKeepAliveEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isKeepAliveEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isKeepAliveEnabled(nativePtr);
    }

    private native void setKeepAliveEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setKeepAliveEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setKeepAliveEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setKeepAliveEnabled(nativePtr, enable);
    }

    private native String getLabel(long nativePtr);
    @Override
    synchronized public String getLabel()  {
        
        
        return getLabel(nativePtr);
    }

    private native void setLabel(long nativePtr, String label);
    @Override
    synchronized public void setLabel(String label)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLabel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLabel(nativePtr, label);
    }

    private native CallLog getLastOutgoingCallLog(long nativePtr);
    @Override @Nullable
    synchronized public CallLog getLastOutgoingCallLog()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLastOutgoingCallLog() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallLog)getLastOutgoingCallLog(nativePtr);
    }

    private native Ldap[] getLdapList(long nativePtr);
    @Override @NonNull
    synchronized public Ldap[] getLdapList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLdapList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLdapList(nativePtr);
    }

    private native boolean isLimeX3DhEnabled(long nativePtr);
    @Override
    synchronized public boolean isLimeX3DhEnabled()  {
        
        
        return isLimeX3DhEnabled(nativePtr);
    }

    private native void setLimeX3DhEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setLimeX3DhEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLimeX3DhEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLimeX3DhEnabled(nativePtr, enable);
    }

    private native String getLimeX3DhServerUrl(long nativePtr);
    @Override @Nullable
    synchronized public String getLimeX3DhServerUrl()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLimeX3DhServerUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLimeX3DhServerUrl(nativePtr);
    }

    private native void setLimeX3DhServerUrl(long nativePtr, String url);
    @Override
    synchronized public void setLimeX3DhServerUrl(@Nullable String url)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLimeX3DhServerUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLimeX3DhServerUrl(nativePtr, url);
    }

    private native String[] getLinphoneSpecsList(long nativePtr);
    @Override @NonNull
    synchronized public String[] getLinphoneSpecsList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLinphoneSpecsList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLinphoneSpecsList(nativePtr);
    }

    private native void setLinphoneSpecsList(long nativePtr, String[] specs);
    @Override
    synchronized public void setLinphoneSpecsList(@Nullable String[] specs)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLinphoneSpecsList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLinphoneSpecsList(nativePtr, specs);
    }

    private native String[] getLoadedPlugins(long nativePtr);
    @Override @NonNull
    synchronized public String[] getLoadedPlugins()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLoadedPlugins() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLoadedPlugins(nativePtr);
    }

    private native boolean isLocalPermissionEnabled(long nativePtr);
    @Override
    synchronized public boolean isLocalPermissionEnabled()  {
        
        
        return isLocalPermissionEnabled(nativePtr);
    }

    private native String getLogCollectionUploadServerUrl(long nativePtr);
    @Override @Nullable
    synchronized public String getLogCollectionUploadServerUrl()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLogCollectionUploadServerUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLogCollectionUploadServerUrl(nativePtr);
    }

    private native void setLogCollectionUploadServerUrl(long nativePtr, String serverUrl);
    @Override
    synchronized public void setLogCollectionUploadServerUrl(@Nullable String serverUrl)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLogCollectionUploadServerUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLogCollectionUploadServerUrl(nativePtr, serverUrl);
    }

    private native int getMaxCallLogs(long nativePtr);
    @Override
    synchronized public int getMaxCallLogs()  {
        
        
        return getMaxCallLogs(nativePtr);
    }

    private native void setMaxCallLogs(long nativePtr, int max);
    @Override
    synchronized public void setMaxCallLogs(int max)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMaxCallLogs() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMaxCallLogs(nativePtr, max);
    }

    private native int getMaxCalls(long nativePtr);
    @Override
    synchronized public int getMaxCalls()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getMaxCalls() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getMaxCalls(nativePtr);
    }

    private native void setMaxCalls(long nativePtr, int max);
    @Override
    synchronized public void setMaxCalls(int max)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMaxCalls() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMaxCalls(nativePtr, max);
    }

    private native int getMaxSizeForAutoDownloadIncomingFiles(long nativePtr);
    @Override
    synchronized public int getMaxSizeForAutoDownloadIncomingFiles()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getMaxSizeForAutoDownloadIncomingFiles() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getMaxSizeForAutoDownloadIncomingFiles(nativePtr);
    }

    private native void setMaxSizeForAutoDownloadIncomingFiles(long nativePtr, int size);
    @Override
    synchronized public void setMaxSizeForAutoDownloadIncomingFiles(int size)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMaxSizeForAutoDownloadIncomingFiles() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMaxSizeForAutoDownloadIncomingFiles(nativePtr, size);
    }

    private native String getMediaDevice(long nativePtr);
    @Override @Nullable
    synchronized public String getMediaDevice()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getMediaDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getMediaDevice(nativePtr);
    }

    private native int setMediaDevice(long nativePtr, String devid);
    @Override
    synchronized public int setMediaDevice(@Nullable String devid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMediaDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setMediaDevice(nativePtr, devid);
    }

    private native int getMediaEncryption(long nativePtr);
    @Override
    synchronized public MediaEncryption getMediaEncryption()  {
        
        
        return MediaEncryption.fromInt(getMediaEncryption(nativePtr));
    }

    private native int setMediaEncryption(long nativePtr, int menc);
    @Override
    synchronized public int setMediaEncryption(MediaEncryption menc)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMediaEncryption() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setMediaEncryption(nativePtr, menc.toInt());
    }

    private native void setMediaEncryptionMandatory(long nativePtr, boolean mandatory);
    @Override
    synchronized public void setMediaEncryptionMandatory(boolean mandatory)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMediaEncryptionMandatory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMediaEncryptionMandatory(nativePtr, mandatory);
    }

    private native void setMediaNetworkReachable(long nativePtr, boolean reachable);
    @Override
    synchronized public void setMediaNetworkReachable(boolean reachable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMediaNetworkReachable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMediaNetworkReachable(nativePtr, reachable);
    }

    private native int getMediaResourceMode(long nativePtr);
    @Override
    synchronized public MediaResourceMode getMediaResourceMode()  {
        
        
        return MediaResourceMode.fromInt(getMediaResourceMode(nativePtr));
    }

    private native void setMediaResourceMode(long nativePtr, int mode);
    @Override
    synchronized public void setMediaResourceMode(MediaResourceMode mode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMediaResourceMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMediaResourceMode(nativePtr, mode.toInt());
    }

    private native int getMessageSendingDelay(long nativePtr);
    @Override
    synchronized public int getMessageSendingDelay()  {
        
        
        return getMessageSendingDelay(nativePtr);
    }

    private native void setMessageSendingDelay(long nativePtr, int duration);
    @Override
    synchronized public void setMessageSendingDelay(int duration)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMessageSendingDelay() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMessageSendingDelay(nativePtr, duration);
    }

    private native boolean isMicEnabled(long nativePtr);
    @Override
    synchronized public boolean isMicEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isMicEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isMicEnabled(nativePtr);
    }

    private native void setMicEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setMicEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMicEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMicEnabled(nativePtr, enable);
    }

    private native float getMicGainDb(long nativePtr);
    @Override
    synchronized public float getMicGainDb()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getMicGainDb() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getMicGainDb(nativePtr);
    }

    private native void setMicGainDb(long nativePtr, float level);
    @Override
    synchronized public void setMicGainDb(float level)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMicGainDb() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMicGainDb(nativePtr, level);
    }

    private native int getMissedCallsCount(long nativePtr);
    @Override
    synchronized public int getMissedCallsCount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getMissedCallsCount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getMissedCallsCount(nativePtr);
    }

    private native int getMtu(long nativePtr);
    @Override
    synchronized public int getMtu()  {
        
        
        return getMtu(nativePtr);
    }

    private native void setMtu(long nativePtr, int mtu);
    @Override
    synchronized public void setMtu(int mtu)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMtu() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMtu(nativePtr, mtu);
    }

    private native String getNatAddress(long nativePtr);
    @Override @Nullable
    synchronized public String getNatAddress()  {
        
        
        return getNatAddress(nativePtr);
    }

    private native void setNatAddress(long nativePtr, String addr);
    @Override
    synchronized public void setNatAddress(@Nullable String addr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNatAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNatAddress(nativePtr, addr);
    }

    private native NatPolicy getNatPolicy(long nativePtr);
    @Override @Nullable
    synchronized public NatPolicy getNatPolicy()  {
        
        
        return (NatPolicy)getNatPolicy(nativePtr);
    }

    private native void setNatPolicy(long nativePtr, NatPolicy policy);
    @Override
    synchronized public void setNatPolicy(@Nullable NatPolicy policy)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNatPolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNatPolicy(nativePtr, policy);
    }

    private native Object getNativePreviewWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object getNativePreviewWindowId()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getNativePreviewWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getNativePreviewWindowId(nativePtr);
    }

    private native void setNativePreviewWindowId(long nativePtr, Object windowId);
    @Override
    synchronized public void setNativePreviewWindowId(@Nullable Object windowId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNativePreviewWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNativePreviewWindowId(nativePtr, windowId);
    }

    private native boolean isNativeRingingEnabled(long nativePtr);
    @Override
    synchronized public boolean isNativeRingingEnabled()  {
        
        
        return isNativeRingingEnabled(nativePtr);
    }

    private native void setNativeRingingEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setNativeRingingEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNativeRingingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNativeRingingEnabled(nativePtr, enable);
    }

    private native Object getNativeVideoWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object getNativeVideoWindowId()  {
        
        
        return getNativeVideoWindowId(nativePtr);
    }

    private native void setNativeVideoWindowId(long nativePtr, Object windowId);
    @Override
    synchronized public void setNativeVideoWindowId(@Nullable Object windowId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNativeVideoWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNativeVideoWindowId(nativePtr, windowId);
    }

    private native void setNetworkReachable(long nativePtr, boolean reachable);
    @Override
    synchronized public void setNetworkReachable(boolean reachable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNetworkReachable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNetworkReachable(nativePtr, reachable);
    }

    private native int getNortpOnholdTimeout(long nativePtr);
    @Override
    synchronized public int getNortpOnholdTimeout()  {
        
        
        return getNortpOnholdTimeout(nativePtr);
    }

    private native void setNortpOnholdTimeout(long nativePtr, int seconds);
    @Override
    synchronized public void setNortpOnholdTimeout(int seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNortpOnholdTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNortpOnholdTimeout(nativePtr, seconds);
    }

    private native int getNortpTimeout(long nativePtr);
    @Override
    synchronized public int getNortpTimeout()  {
        
        
        return getNortpTimeout(nativePtr);
    }

    private native void setNortpTimeout(long nativePtr, int seconds);
    @Override
    synchronized public void setNortpTimeout(int seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNortpTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNortpTimeout(nativePtr, seconds);
    }

    private native AudioDevice getOutputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getOutputAudioDevice()  {
        
        
        return (AudioDevice)getOutputAudioDevice(nativePtr);
    }

    private native void setOutputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setOutputAudioDevice(@Nullable AudioDevice audioDevice)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOutputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOutputAudioDevice(nativePtr, audioDevice);
    }

    private native String getPlayFile(long nativePtr);
    @Override @Nullable
    synchronized public String getPlayFile()  {
        
        
        return getPlayFile(nativePtr);
    }

    private native void setPlayFile(long nativePtr, String file);
    @Override
    synchronized public void setPlayFile(@Nullable String file)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPlayFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPlayFile(nativePtr, file);
    }

    private native String getPlaybackDevice(long nativePtr);
    @Override @Nullable
    synchronized public String getPlaybackDevice()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPlaybackDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getPlaybackDevice(nativePtr);
    }

    private native int setPlaybackDevice(long nativePtr, String devid);
    @Override
    synchronized public int setPlaybackDevice(@Nullable String devid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPlaybackDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setPlaybackDevice(nativePtr, devid);
    }

    private native float getPlaybackGainDb(long nativePtr);
    @Override
    synchronized public float getPlaybackGainDb()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPlaybackGainDb() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getPlaybackGainDb(nativePtr);
    }

    private native void setPlaybackGainDb(long nativePtr, float level);
    @Override
    synchronized public void setPlaybackGainDb(float level)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPlaybackGainDb() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPlaybackGainDb(nativePtr, level);
    }

    private native float getPreferredFramerate(long nativePtr);
    @Override
    synchronized public float getPreferredFramerate()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPreferredFramerate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getPreferredFramerate(nativePtr);
    }

    private native void setPreferredFramerate(long nativePtr, float fps);
    @Override
    synchronized public void setPreferredFramerate(float fps)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPreferredFramerate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPreferredFramerate(nativePtr, fps);
    }

    private native VideoDefinition getPreferredVideoDefinition(long nativePtr);
    @Override @NonNull
    synchronized public VideoDefinition getPreferredVideoDefinition()  {
        
        
        return (VideoDefinition)getPreferredVideoDefinition(nativePtr);
    }

    private native void setPreferredVideoDefinition(long nativePtr, VideoDefinition videoDefinition);
    @Override
    synchronized public void setPreferredVideoDefinition(@NonNull VideoDefinition videoDefinition)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPreferredVideoDefinition() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPreferredVideoDefinition(nativePtr, videoDefinition);
    }

    private native void setPreferredVideoDefinitionByName(long nativePtr, String name);
    @Override
    synchronized public void setPreferredVideoDefinitionByName(@NonNull String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPreferredVideoDefinitionByName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPreferredVideoDefinitionByName(nativePtr, name);
    }

    private native PresenceModel getPresenceModel(long nativePtr);
    @Override @Nullable
    synchronized public PresenceModel getPresenceModel()  {
        
        
        return (PresenceModel)getPresenceModel(nativePtr);
    }

    private native void setPresenceModel(long nativePtr, PresenceModel presence);
    @Override
    synchronized public void setPresenceModel(@Nullable PresenceModel presence)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPresenceModel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPresenceModel(nativePtr, presence);
    }

    private native VideoDefinition getPreviewVideoDefinition(long nativePtr);
    @Override @Nullable
    synchronized public VideoDefinition getPreviewVideoDefinition()  {
        
        
        return (VideoDefinition)getPreviewVideoDefinition(nativePtr);
    }

    private native void setPreviewVideoDefinition(long nativePtr, VideoDefinition videoDefinition);
    @Override
    synchronized public void setPreviewVideoDefinition(@Nullable VideoDefinition videoDefinition)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPreviewVideoDefinition() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPreviewVideoDefinition(nativePtr, videoDefinition);
    }

    private native void setPreviewVideoDefinitionByName(long nativePtr, String name);
    @Override
    synchronized public void setPreviewVideoDefinitionByName(@NonNull String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPreviewVideoDefinitionByName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPreviewVideoDefinitionByName(nativePtr, name);
    }

    private native String getPrimaryContact(long nativePtr);
    @Override @NonNull
    synchronized public String getPrimaryContact()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPrimaryContact() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getPrimaryContact(nativePtr);
    }

    private native int setPrimaryContact(long nativePtr, String contact);
    @Override
    synchronized public int setPrimaryContact(@NonNull String contact)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPrimaryContact() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setPrimaryContact(nativePtr, contact);
    }

    private native Address getPrimaryContactAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getPrimaryContactAddress()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPrimaryContactAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)getPrimaryContactAddress(nativePtr);
    }

    private native Address getPrimaryContactParsed(long nativePtr);
    @Override @Nullable
    synchronized public Address getPrimaryContactParsed()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPrimaryContactParsed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)getPrimaryContactParsed(nativePtr);
    }

    private native String getProvisioningUri(long nativePtr);
    @Override @Nullable
    synchronized public String getProvisioningUri()  {
        
        
        return getProvisioningUri(nativePtr);
    }

    private native int setProvisioningUri(long nativePtr, String uri);
    @Override
    synchronized public int setProvisioningUri(@Nullable String uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setProvisioningUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setProvisioningUri(nativePtr, uri);
    }

    private native ProxyConfig[] getProxyConfigList(long nativePtr);
    @Override @NonNull
    synchronized public ProxyConfig[] getProxyConfigList()  {
        
        
        return getProxyConfigList(nativePtr);
    }

    private native int getPushIncomingCallTimeout(long nativePtr);
    @Override
    synchronized public int getPushIncomingCallTimeout()  {
        
        
        return getPushIncomingCallTimeout(nativePtr);
    }

    private native void setPushIncomingCallTimeout(long nativePtr, int seconds);
    @Override
    synchronized public void setPushIncomingCallTimeout(int seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPushIncomingCallTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPushIncomingCallTimeout(nativePtr, seconds);
    }

    private native PushNotificationConfig getPushNotificationConfig(long nativePtr);
    @Override @Nullable
    synchronized public PushNotificationConfig getPushNotificationConfig()  {
        
        
        return (PushNotificationConfig)getPushNotificationConfig(nativePtr);
    }

    private native boolean isPushNotificationEnabled(long nativePtr);
    @Override
    synchronized public boolean isPushNotificationEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isPushNotificationEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isPushNotificationEnabled(nativePtr);
    }

    private native void setPushNotificationEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setPushNotificationEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPushNotificationEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPushNotificationEnabled(nativePtr, enable);
    }

    private native boolean isQrcodeVideoPreviewEnabled(long nativePtr);
    @Override
    synchronized public boolean isQrcodeVideoPreviewEnabled()  {
        
        
        return isQrcodeVideoPreviewEnabled(nativePtr);
    }

    private native void setQrcodeVideoPreviewEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setQrcodeVideoPreviewEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setQrcodeVideoPreviewEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setQrcodeVideoPreviewEnabled(nativePtr, enable);
    }

    private native boolean isRealtimeTextEnabled(long nativePtr);
    @Override
    synchronized public boolean isRealtimeTextEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isRealtimeTextEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isRealtimeTextEnabled(nativePtr);
    }

    private native int getRealtimeTextKeepaliveInterval(long nativePtr);
    @Override
    synchronized public int getRealtimeTextKeepaliveInterval()  {
        
        
        return getRealtimeTextKeepaliveInterval(nativePtr);
    }

    private native void setRealtimeTextKeepaliveInterval(long nativePtr, int interval);
    @Override
    synchronized public void setRealtimeTextKeepaliveInterval(int interval)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRealtimeTextKeepaliveInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRealtimeTextKeepaliveInterval(nativePtr, interval);
    }

    private native boolean isRecordAwareEnabled(long nativePtr);
    @Override
    synchronized public boolean isRecordAwareEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isRecordAwareEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isRecordAwareEnabled(nativePtr);
    }

    private native void setRecordAwareEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setRecordAwareEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRecordAwareEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRecordAwareEnabled(nativePtr, enable);
    }

    private native String getRecordFile(long nativePtr);
    @Override @Nullable
    synchronized public String getRecordFile()  {
        
        
        return getRecordFile(nativePtr);
    }

    private native void setRecordFile(long nativePtr, String file);
    @Override
    synchronized public void setRecordFile(@Nullable String file)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRecordFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRecordFile(nativePtr, file);
    }

    private native boolean getRegisterOnlyWhenNetworkIsUp(long nativePtr);
    @Override
    synchronized public boolean getRegisterOnlyWhenNetworkIsUp()  {
        
        
        return getRegisterOnlyWhenNetworkIsUp(nativePtr);
    }

    private native void setRegisterOnlyWhenNetworkIsUp(long nativePtr, boolean registerOnlyWhenNetworkIsUp);
    @Override
    synchronized public void setRegisterOnlyWhenNetworkIsUp(boolean registerOnlyWhenNetworkIsUp)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRegisterOnlyWhenNetworkIsUp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRegisterOnlyWhenNetworkIsUp(nativePtr, registerOnlyWhenNetworkIsUp);
    }

    private native int getRemainingDownloadFileCount(long nativePtr);
    @Override
    synchronized public int getRemainingDownloadFileCount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRemainingDownloadFileCount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getRemainingDownloadFileCount(nativePtr);
    }

    private native int getRemainingUploadFileCount(long nativePtr);
    @Override
    synchronized public int getRemainingUploadFileCount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRemainingUploadFileCount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getRemainingUploadFileCount(nativePtr);
    }

    private native RemoteContactDirectory[] getRemoteContactDirectories(long nativePtr);
    @Override @NonNull
    synchronized public RemoteContactDirectory[] getRemoteContactDirectories()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRemoteContactDirectories() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getRemoteContactDirectories(nativePtr);
    }

    private native String getRemoteRingbackTone(long nativePtr);
    @Override @Nullable
    synchronized public String getRemoteRingbackTone()  {
        
        
        return getRemoteRingbackTone(nativePtr);
    }

    private native void setRemoteRingbackTone(long nativePtr, String ring);
    @Override
    synchronized public void setRemoteRingbackTone(@Nullable String ring)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRemoteRingbackTone() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRemoteRingbackTone(nativePtr, ring);
    }

    private native boolean isRetransmissionOnNackEnabled(long nativePtr);
    @Override
    synchronized public boolean isRetransmissionOnNackEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isRetransmissionOnNackEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isRetransmissionOnNackEnabled(nativePtr);
    }

    private native void setRetransmissionOnNackEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setRetransmissionOnNackEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRetransmissionOnNackEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRetransmissionOnNackEnabled(nativePtr, enable);
    }

    private native String getRing(long nativePtr);
    @Override @Nullable
    synchronized public String getRing()  {
        
        
        return getRing(nativePtr);
    }

    private native void setRing(long nativePtr, String path);
    @Override
    synchronized public void setRing(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRing() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRing(nativePtr, path);
    }

    private native boolean getRingDuringIncomingEarlyMedia(long nativePtr);
    @Override
    synchronized public boolean getRingDuringIncomingEarlyMedia()  {
        
        
        return getRingDuringIncomingEarlyMedia(nativePtr);
    }

    private native void setRingDuringIncomingEarlyMedia(long nativePtr, boolean enable);
    @Override
    synchronized public void setRingDuringIncomingEarlyMedia(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRingDuringIncomingEarlyMedia() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRingDuringIncomingEarlyMedia(nativePtr, enable);
    }

    private native String getRingback(long nativePtr);
    @Override @Nullable
    synchronized public String getRingback()  {
        
        
        return getRingback(nativePtr);
    }

    private native void setRingback(long nativePtr, String path);
    @Override
    synchronized public void setRingback(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRingback() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRingback(nativePtr, path);
    }

    private native String getRingerDevice(long nativePtr);
    @Override @Nullable
    synchronized public String getRingerDevice()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRingerDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getRingerDevice(nativePtr);
    }

    private native int setRingerDevice(long nativePtr, String devid);
    @Override
    synchronized public int setRingerDevice(@Nullable String devid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRingerDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setRingerDevice(nativePtr, devid);
    }

    private native String getRootCa(long nativePtr);
    @Override @Nullable
    synchronized public String getRootCa()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRootCa() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getRootCa(nativePtr);
    }

    private native void setRootCa(long nativePtr, String path);
    @Override
    synchronized public void setRootCa(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRootCa() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRootCa(nativePtr, path);
    }

    private native void setRootCaData(long nativePtr, String data);
    @Override
    synchronized public void setRootCaData(@Nullable String data)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRootCaData() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRootCaData(nativePtr, data);
    }

    private native boolean isRtpBundleEnabled(long nativePtr);
    @Override
    synchronized public boolean isRtpBundleEnabled()  {
        
        
        return isRtpBundleEnabled(nativePtr);
    }

    private native void setRtpBundleEnabled(long nativePtr, boolean value);
    @Override
    synchronized public void setRtpBundleEnabled(boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRtpBundleEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRtpBundleEnabled(nativePtr, value);
    }

    private native boolean isSdp200AckEnabled(long nativePtr);
    @Override
    synchronized public boolean isSdp200AckEnabled()  {
        
        
        return isSdp200AckEnabled(nativePtr);
    }

    private native void setSdp200AckEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setSdp200AckEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSdp200AckEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSdp200AckEnabled(nativePtr, enable);
    }

    private native boolean isSelfViewEnabled(long nativePtr);
    @Override
    synchronized public boolean isSelfViewEnabled()  {
        
        
        return isSelfViewEnabled(nativePtr);
    }

    private native void setSelfViewEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setSelfViewEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSelfViewEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSelfViewEnabled(nativePtr, enable);
    }

    private native boolean isSendMessageAfterNotifyEnabled(long nativePtr);
    @Override
    synchronized public boolean isSendMessageAfterNotifyEnabled()  {
        
        
        return isSendMessageAfterNotifyEnabled(nativePtr);
    }

    private native void setSendMessageAfterNotifyEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setSendMessageAfterNotifyEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSendMessageAfterNotifyEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSendMessageAfterNotifyEnabled(nativePtr, enabled);
    }

    private native void setSenderNameHiddenInForwardMessageEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setSenderNameHiddenInForwardMessageEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSenderNameHiddenInForwardMessageEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSenderNameHiddenInForwardMessageEnabled(nativePtr, enable);
    }

    private native boolean isSessionExpiresEnabled(long nativePtr);
    @Override
    synchronized public boolean isSessionExpiresEnabled()  {
        
        
        return isSessionExpiresEnabled(nativePtr);
    }

    private native void setSessionExpiresEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setSessionExpiresEnabled(boolean enabled)  {
        
        
        setSessionExpiresEnabled(nativePtr, enabled);
    }

    private native int getSessionExpiresMinValue(long nativePtr);
    @Override
    synchronized public int getSessionExpiresMinValue()  {
        
        
        return getSessionExpiresMinValue(nativePtr);
    }

    private native void setSessionExpiresMinValue(long nativePtr, int min);
    @Override
    synchronized public void setSessionExpiresMinValue(int min)  {
        
        
        setSessionExpiresMinValue(nativePtr, min);
    }

    private native int getSessionExpiresRefresherValue(long nativePtr);
    @Override
    synchronized public SessionExpiresRefresher getSessionExpiresRefresherValue()  {
        
        
        return SessionExpiresRefresher.fromInt(getSessionExpiresRefresherValue(nativePtr));
    }

    private native void setSessionExpiresRefresherValue(long nativePtr, int refresher);
    @Override
    synchronized public void setSessionExpiresRefresherValue(SessionExpiresRefresher refresher)  {
        
        
        setSessionExpiresRefresherValue(nativePtr, refresher.toInt());
    }

    private native int getSessionExpiresValue(long nativePtr);
    @Override
    synchronized public int getSessionExpiresValue()  {
        
        
        return getSessionExpiresValue(nativePtr);
    }

    private native void setSessionExpiresValue(long nativePtr, int expires);
    @Override
    synchronized public void setSessionExpiresValue(int expires)  {
        
        
        setSessionExpiresValue(nativePtr, expires);
    }

    private native int getSipDscp(long nativePtr);
    @Override
    synchronized public int getSipDscp()  {
        
        
        return getSipDscp(nativePtr);
    }

    private native void setSipDscp(long nativePtr, int dscp);
    @Override
    synchronized public void setSipDscp(int dscp)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSipDscp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSipDscp(nativePtr, dscp);
    }

    private native void setSipNetworkReachable(long nativePtr, boolean reachable);
    @Override
    synchronized public void setSipNetworkReachable(boolean reachable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSipNetworkReachable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSipNetworkReachable(nativePtr, reachable);
    }

    private native int getSipTransportTimeout(long nativePtr);
    @Override
    synchronized public int getSipTransportTimeout()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSipTransportTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getSipTransportTimeout(nativePtr);
    }

    private native void setSipTransportTimeout(long nativePtr, int timeoutMs);
    @Override
    synchronized public void setSipTransportTimeout(int timeoutMs)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSipTransportTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSipTransportTimeout(nativePtr, timeoutMs);
    }

    private native String[] getSoundDevicesList(long nativePtr);
    @Override @NonNull
    synchronized public String[] getSoundDevicesList()  {
        
        
        return getSoundDevicesList(nativePtr);
    }

    private native String getSrtpCryptoSuites(long nativePtr);
    @Override @NonNull
    synchronized public String getSrtpCryptoSuites()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSrtpCryptoSuites() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getSrtpCryptoSuites(nativePtr);
    }

    private native void setSrtpCryptoSuites(long nativePtr, String suites);
    @Override
    synchronized public void setSrtpCryptoSuites(@NonNull String suites)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSrtpCryptoSuites() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSrtpCryptoSuites(nativePtr, suites);
    }

    private native String getStaticPicture(long nativePtr);
    @Override @Nullable
    synchronized public String getStaticPicture()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getStaticPicture() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getStaticPicture(nativePtr);
    }

    private native int setStaticPicture(long nativePtr, String path);
    @Override
    synchronized public int setStaticPicture(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStaticPicture() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setStaticPicture(nativePtr, path);
    }

    private native float getStaticPictureFps(long nativePtr);
    @Override
    synchronized public float getStaticPictureFps()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getStaticPictureFps() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getStaticPictureFps(nativePtr);
    }

    private native int setStaticPictureFps(long nativePtr, float fps);
    @Override
    synchronized public int setStaticPictureFps(float fps)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStaticPictureFps() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setStaticPictureFps(nativePtr, fps);
    }

    private native String getStunServer(long nativePtr);
    @Override @Nullable
    synchronized public String getStunServer()  {
        
        
        return getStunServer(nativePtr);
    }

    private native void setStunServer(long nativePtr, String server);
    @Override
    synchronized public void setStunServer(@Nullable String server)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStunServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStunServer(nativePtr, server);
    }

    private native String[] getSupportedFileFormatsList(long nativePtr);
    @Override @NonNull
    synchronized public String[] getSupportedFileFormatsList()  {
        
        
        return getSupportedFileFormatsList(nativePtr);
    }

    private native void setSupportedTag(long nativePtr, String tags);
    @Override
    synchronized public void setSupportedTag(@Nullable String tags)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSupportedTag() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSupportedTag(nativePtr, tags);
    }

    private native int getTag100RelSupportLevel(long nativePtr);
    @Override
    synchronized public SupportLevel getTag100RelSupportLevel()  {
        
        
        return SupportLevel.fromInt(getTag100RelSupportLevel(nativePtr));
    }

    private native void setTag100RelSupportLevel(long nativePtr, int level);
    @Override
    synchronized public void setTag100RelSupportLevel(SupportLevel level)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTag100RelSupportLevel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTag100RelSupportLevel(nativePtr, level.toInt());
    }

    private native void setTcapLineMergingEnabled(long nativePtr, boolean merge);
    @Override
    synchronized public void setTcapLineMergingEnabled(boolean merge)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTcapLineMergingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTcapLineMergingEnabled(nativePtr, merge);
    }

    private native boolean isTcapLinesMergingEnabled(long nativePtr);
    @Override
    synchronized public boolean isTcapLinesMergingEnabled()  {
        
        
        return isTcapLinesMergingEnabled(nativePtr);
    }

    private native PayloadType[] getTextPayloadTypes(long nativePtr);
    @Override @NonNull
    synchronized public PayloadType[] getTextPayloadTypes()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getTextPayloadTypes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getTextPayloadTypes(nativePtr);
    }

    private native void setTextPayloadTypes(long nativePtr, PayloadType[] payloadTypes);
    @Override
    synchronized public void setTextPayloadTypes(@Nullable PayloadType[] payloadTypes)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTextPayloadTypes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTextPayloadTypes(nativePtr, payloadTypes);
    }

    private native int getTextPort(long nativePtr);
    @Override
    synchronized public int getTextPort()  {
        
        
        return getTextPort(nativePtr);
    }

    private native void setTextPort(long nativePtr, int port);
    @Override
    synchronized public void setTextPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTextPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTextPort(nativePtr, port);
    }

    private native Range getTextPortsRange(long nativePtr);
    @Override @NonNull
    synchronized public Range getTextPortsRange()  {
        
        
        return (Range)getTextPortsRange(nativePtr);
    }

    private native String getTlsCert(long nativePtr);
    @Override @Nullable
    synchronized public String getTlsCert()  {
        
        
        return getTlsCert(nativePtr);
    }

    private native void setTlsCert(long nativePtr, String tlsCert);
    @Override
    synchronized public void setTlsCert(@Nullable String tlsCert)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsCert() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsCert(nativePtr, tlsCert);
    }

    private native String getTlsCertPath(long nativePtr);
    @Override @Nullable
    synchronized public String getTlsCertPath()  {
        
        
        return getTlsCertPath(nativePtr);
    }

    private native void setTlsCertPath(long nativePtr, String tlsCertPath);
    @Override
    synchronized public void setTlsCertPath(@Nullable String tlsCertPath)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsCertPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsCertPath(nativePtr, tlsCertPath);
    }

    private native String getTlsKey(long nativePtr);
    @Override @Nullable
    synchronized public String getTlsKey()  {
        
        
        return getTlsKey(nativePtr);
    }

    private native void setTlsKey(long nativePtr, String tlsKey);
    @Override
    synchronized public void setTlsKey(@Nullable String tlsKey)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsKey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsKey(nativePtr, tlsKey);
    }

    private native String getTlsKeyPath(long nativePtr);
    @Override @Nullable
    synchronized public String getTlsKeyPath()  {
        
        
        return getTlsKeyPath(nativePtr);
    }

    private native void setTlsKeyPath(long nativePtr, String tlsKeyPath);
    @Override
    synchronized public void setTlsKeyPath(@Nullable String tlsKeyPath)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsKeyPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsKeyPath(nativePtr, tlsKeyPath);
    }

    private native Transports getTransports(long nativePtr);
    @Override @NonNull
    synchronized public Transports getTransports()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getTransports() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Transports)getTransports(nativePtr);
    }

    private native int setTransports(long nativePtr, Transports transports);
    @Override
    synchronized public int setTransports(@NonNull Transports transports)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTransports() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setTransports(nativePtr, transports);
    }

    private native Transports getTransportsUsed(long nativePtr);
    @Override @NonNull
    synchronized public Transports getTransportsUsed()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getTransportsUsed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Transports)getTransportsUsed(nativePtr);
    }

    private native Tunnel getTunnel(long nativePtr);
    @Override @Nullable
    synchronized public Tunnel getTunnel()  {
        
        
        return (Tunnel)getTunnel(nativePtr);
    }

    private native int getUnreadChatMessageCount(long nativePtr);
    @Override
    synchronized public int getUnreadChatMessageCount()  {
        
        
        return getUnreadChatMessageCount(nativePtr);
    }

    private native int getUnreadChatMessageCountFromActiveLocals(long nativePtr);
    @Override
    synchronized public int getUnreadChatMessageCountFromActiveLocals()  {
        
        
        return getUnreadChatMessageCountFromActiveLocals(nativePtr);
    }

    private native int getUploadBandwidth(long nativePtr);
    @Override
    synchronized public int getUploadBandwidth()  {
        
        
        return getUploadBandwidth(nativePtr);
    }

    private native void setUploadBandwidth(long nativePtr, int bandwidth);
    @Override
    synchronized public void setUploadBandwidth(int bandwidth)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUploadBandwidth() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUploadBandwidth(nativePtr, bandwidth);
    }

    private native int getUploadPtime(long nativePtr);
    @Override
    synchronized public int getUploadPtime()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUploadPtime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUploadPtime(nativePtr);
    }

    private native void setUploadPtime(long nativePtr, int ptime);
    @Override
    synchronized public void setUploadPtime(int ptime)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUploadPtime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUploadPtime(nativePtr, ptime);
    }

    private native String getUpnpExternalIpaddress(long nativePtr);
    @Override @Nullable
    synchronized public String getUpnpExternalIpaddress()  {
        
        
        return getUpnpExternalIpaddress(nativePtr);
    }

    private native int getUpnpState(long nativePtr);
    @Override
    synchronized public UpnpState getUpnpState()  {
        
        
        return UpnpState.fromInt(getUpnpState(nativePtr));
    }

    private native boolean getUseFiles(long nativePtr);
    @Override
    synchronized public boolean getUseFiles()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUseFiles() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUseFiles(nativePtr);
    }

    private native void setUseFiles(long nativePtr, boolean yesno);
    @Override
    synchronized public void setUseFiles(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUseFiles() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUseFiles(nativePtr, yesno);
    }

    private native boolean getUseInfoForDtmf(long nativePtr);
    @Override
    synchronized public boolean getUseInfoForDtmf()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUseInfoForDtmf() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUseInfoForDtmf(nativePtr);
    }

    private native void setUseInfoForDtmf(long nativePtr, boolean useInfo);
    @Override
    synchronized public void setUseInfoForDtmf(boolean useInfo)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUseInfoForDtmf() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUseInfoForDtmf(nativePtr, useInfo);
    }

    private native boolean getUseRfc2833ForDtmf(long nativePtr);
    @Override
    synchronized public boolean getUseRfc2833ForDtmf()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUseRfc2833ForDtmf() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUseRfc2833ForDtmf(nativePtr);
    }

    private native void setUseRfc2833ForDtmf(long nativePtr, boolean useRfc2833);
    @Override
    synchronized public void setUseRfc2833ForDtmf(boolean useRfc2833)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUseRfc2833ForDtmf() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUseRfc2833ForDtmf(nativePtr, useRfc2833);
    }

    private native String getUserAgent(long nativePtr);
    @Override @NonNull
    synchronized public String getUserAgent()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUserAgent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUserAgent(nativePtr);
    }

    private native String getUserCertificatesPath(long nativePtr);
    @Override @Nullable
    synchronized public String getUserCertificatesPath()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUserCertificatesPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUserCertificatesPath(nativePtr);
    }

    private native void setUserCertificatesPath(long nativePtr, String path);
    @Override
    synchronized public void setUserCertificatesPath(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUserCertificatesPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUserCertificatesPath(nativePtr, path);
    }

    private native boolean isVibrationOnIncomingCallEnabled(long nativePtr);
    @Override
    synchronized public boolean isVibrationOnIncomingCallEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isVibrationOnIncomingCallEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isVibrationOnIncomingCallEnabled(nativePtr);
    }

    private native void setVibrationOnIncomingCallEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setVibrationOnIncomingCallEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVibrationOnIncomingCallEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVibrationOnIncomingCallEnabled(nativePtr, enable);
    }

    private native VideoActivationPolicy getVideoActivationPolicy(long nativePtr);
    @Override @NonNull
    synchronized public VideoActivationPolicy getVideoActivationPolicy()  {
        
        
        return (VideoActivationPolicy)getVideoActivationPolicy(nativePtr);
    }

    private native void setVideoActivationPolicy(long nativePtr, VideoActivationPolicy policy);
    @Override
    synchronized public void setVideoActivationPolicy(@NonNull VideoActivationPolicy policy)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoActivationPolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoActivationPolicy(nativePtr, policy);
    }

    private native boolean isVideoAdaptiveJittcompEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoAdaptiveJittcompEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isVideoAdaptiveJittcompEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isVideoAdaptiveJittcompEnabled(nativePtr);
    }

    private native void setVideoAdaptiveJittcompEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setVideoAdaptiveJittcompEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoAdaptiveJittcompEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoAdaptiveJittcompEnabled(nativePtr, enable);
    }

    private native boolean isVideoCaptureEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoCaptureEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isVideoCaptureEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isVideoCaptureEnabled(nativePtr);
    }

    private native void setVideoCaptureEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setVideoCaptureEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoCaptureEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoCaptureEnabled(nativePtr, enable);
    }

    private native int getVideoCodecPriorityPolicy(long nativePtr);
    @Override
    synchronized public CodecPriorityPolicy getVideoCodecPriorityPolicy()  {
        
        
        return CodecPriorityPolicy.fromInt(getVideoCodecPriorityPolicy(nativePtr));
    }

    private native void setVideoCodecPriorityPolicy(long nativePtr, int policy);
    @Override
    synchronized public void setVideoCodecPriorityPolicy(CodecPriorityPolicy policy)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoCodecPriorityPolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoCodecPriorityPolicy(nativePtr, policy.toInt());
    }

    private native String getVideoDevice(long nativePtr);
    @Override @Nullable
    synchronized public String getVideoDevice()  {
        
        
        return getVideoDevice(nativePtr);
    }

    private native int setVideoDevice(long nativePtr, String id);
    @Override
    synchronized public int setVideoDevice(@Nullable String id)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setVideoDevice(nativePtr, id);
    }

    private native String[] getVideoDevicesList(long nativePtr);
    @Override @NonNull
    synchronized public String[] getVideoDevicesList()  {
        
        
        return getVideoDevicesList(nativePtr);
    }

    private native boolean isVideoDisplayEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoDisplayEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isVideoDisplayEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isVideoDisplayEnabled(nativePtr);
    }

    private native void setVideoDisplayEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setVideoDisplayEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoDisplayEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoDisplayEnabled(nativePtr, enable);
    }

    private native String getVideoDisplayFilter(long nativePtr);
    @Override @Nullable
    synchronized public String getVideoDisplayFilter()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getVideoDisplayFilter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getVideoDisplayFilter(nativePtr);
    }

    private native void setVideoDisplayFilter(long nativePtr, String filterName);
    @Override
    synchronized public void setVideoDisplayFilter(@Nullable String filterName)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoDisplayFilter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoDisplayFilter(nativePtr, filterName);
    }

    private native int getVideoDscp(long nativePtr);
    @Override
    synchronized public int getVideoDscp()  {
        
        
        return getVideoDscp(nativePtr);
    }

    private native void setVideoDscp(long nativePtr, int dscp);
    @Override
    synchronized public void setVideoDscp(int dscp)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoDscp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoDscp(nativePtr, dscp);
    }

    private native boolean isVideoEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isVideoEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isVideoEnabled(nativePtr);
    }

    private native int getVideoJittcomp(long nativePtr);
    @Override
    synchronized public int getVideoJittcomp()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getVideoJittcomp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getVideoJittcomp(nativePtr);
    }

    private native void setVideoJittcomp(long nativePtr, int milliseconds);
    @Override
    synchronized public void setVideoJittcomp(int milliseconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoJittcomp() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoJittcomp(nativePtr, milliseconds);
    }

    private native String getVideoMulticastAddr(long nativePtr);
    @Override @Nullable
    synchronized public String getVideoMulticastAddr()  {
        
        
        return getVideoMulticastAddr(nativePtr);
    }

    private native int setVideoMulticastAddr(long nativePtr, String ip);
    @Override
    synchronized public int setVideoMulticastAddr(@Nullable String ip)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoMulticastAddr() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setVideoMulticastAddr(nativePtr, ip);
    }

    private native boolean isVideoMulticastEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoMulticastEnabled()  {
        
        
        return isVideoMulticastEnabled(nativePtr);
    }

    private native void setVideoMulticastEnabled(long nativePtr, boolean yesno);
    @Override
    synchronized public void setVideoMulticastEnabled(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoMulticastEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoMulticastEnabled(nativePtr, yesno);
    }

    private native int getVideoMulticastTtl(long nativePtr);
    @Override
    synchronized public int getVideoMulticastTtl()  {
        
        
        return getVideoMulticastTtl(nativePtr);
    }

    private native int setVideoMulticastTtl(long nativePtr, int ttl);
    @Override
    synchronized public int setVideoMulticastTtl(int ttl)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoMulticastTtl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setVideoMulticastTtl(nativePtr, ttl);
    }

    private native PayloadType[] getVideoPayloadTypes(long nativePtr);
    @Override @NonNull
    synchronized public PayloadType[] getVideoPayloadTypes()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getVideoPayloadTypes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getVideoPayloadTypes(nativePtr);
    }

    private native void setVideoPayloadTypes(long nativePtr, PayloadType[] payloadTypes);
    @Override
    synchronized public void setVideoPayloadTypes(@Nullable PayloadType[] payloadTypes)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoPayloadTypes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoPayloadTypes(nativePtr, payloadTypes);
    }

    private native int getVideoPort(long nativePtr);
    @Override
    synchronized public int getVideoPort()  {
        
        
        return getVideoPort(nativePtr);
    }

    private native void setVideoPort(long nativePtr, int port);
    @Override
    synchronized public void setVideoPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoPort(nativePtr, port);
    }

    private native Range getVideoPortsRange(long nativePtr);
    @Override @NonNull
    synchronized public Range getVideoPortsRange()  {
        
        
        return (Range)getVideoPortsRange(nativePtr);
    }

    private native String getVideoPreset(long nativePtr);
    @Override @Nullable
    synchronized public String getVideoPreset()  {
        
        
        return getVideoPreset(nativePtr);
    }

    private native void setVideoPreset(long nativePtr, String preset);
    @Override
    synchronized public void setVideoPreset(@Nullable String preset)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoPreset() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoPreset(nativePtr, preset);
    }

    private native boolean isVideoPreviewEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoPreviewEnabled()  {
        
        
        return isVideoPreviewEnabled(nativePtr);
    }

    private native void setVideoPreviewEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setVideoPreviewEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoPreviewEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoPreviewEnabled(nativePtr, enable);
    }

    private native void setVideoSourceReuseEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setVideoSourceReuseEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoSourceReuseEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoSourceReuseEnabled(nativePtr, enable);
    }

    private native boolean isWifiOnlyEnabled(long nativePtr);
    @Override
    synchronized public boolean isWifiOnlyEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isWifiOnlyEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isWifiOnlyEnabled(nativePtr);
    }

    private native void setWifiOnlyEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setWifiOnlyEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setWifiOnlyEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setWifiOnlyEnabled(nativePtr, enable);
    }

    private native boolean isZeroRtpPortForStreamInactiveEnabled(long nativePtr);
    @Override
    synchronized public boolean isZeroRtpPortForStreamInactiveEnabled()  {
        
        
        return isZeroRtpPortForStreamInactiveEnabled(nativePtr);
    }

    private native void setZeroRtpPortForStreamInactiveEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setZeroRtpPortForStreamInactiveEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setZeroRtpPortForStreamInactiveEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setZeroRtpPortForStreamInactiveEnabled(nativePtr, enable);
    }

    private native int[] getZrtpAvailableKeyAgreementList(long nativePtr);
    @Override @NonNull
    synchronized public ZrtpKeyAgreement[] getZrtpAvailableKeyAgreementList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getZrtpAvailableKeyAgreementList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return ZrtpKeyAgreement.fromIntArray(getZrtpAvailableKeyAgreementList(nativePtr));
    }

    private native boolean isZrtpGoClearEnabled(long nativePtr);
    @Override
    synchronized public boolean isZrtpGoClearEnabled()  {
        
        
        return isZrtpGoClearEnabled(nativePtr);
    }

    private native void setZrtpGoClearEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setZrtpGoClearEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setZrtpGoClearEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setZrtpGoClearEnabled(nativePtr, enabled);
    }

    private native int[] getZrtpKeyAgreementList(long nativePtr);
    @Override @NonNull
    synchronized public ZrtpKeyAgreement[] getZrtpKeyAgreementList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getZrtpKeyAgreementList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return ZrtpKeyAgreement.fromIntArray(getZrtpKeyAgreementList(nativePtr));
    }

    private native void setZrtpKeyAgreementSuites(long nativePtr, int[] keyAgreements);
    @Override
    synchronized public void setZrtpKeyAgreementSuites(@Nullable ZrtpKeyAgreement[] keyAgreements)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setZrtpKeyAgreementSuites() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setZrtpKeyAgreementSuites(nativePtr, ZrtpKeyAgreement.toIntArray(keyAgreements));
    }

    private native String getZrtpSecretsFile(long nativePtr);
    @Override @Nullable
    synchronized public String getZrtpSecretsFile()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getZrtpSecretsFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getZrtpSecretsFile(nativePtr);
    }

    private native void setZrtpSecretsFile(long nativePtr, String file);
    @Override
    synchronized public void setZrtpSecretsFile(@Nullable String file)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setZrtpSecretsFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setZrtpSecretsFile(nativePtr, file);
    }

    private native void abortAuthentication(long nativePtr, AuthInfo info);
    @Override
    synchronized public void abortAuthentication(@Nullable AuthInfo info)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call abortAuthentication() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        abortAuthentication(nativePtr, info);
    }

    private native void activateAudioSession(long nativePtr, boolean activated);
    @Override
    synchronized public void activateAudioSession(boolean activated)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call activateAudioSession() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        activateAudioSession(nativePtr, activated);
    }

    private native int addAccount(long nativePtr, Account account);
    @Override
    synchronized public int addAccount(@NonNull Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addAccount(nativePtr, account);
    }

    private native int addAllToConference(long nativePtr);
    @Override
    synchronized public int addAllToConference()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addAllToConference() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addAllToConference(nativePtr);
    }

    private native void addAuthInfo(long nativePtr, AuthInfo info);
    @Override
    synchronized public void addAuthInfo(@NonNull AuthInfo info)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addAuthInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addAuthInfo(nativePtr, info);
    }

    private native void addContentTypeSupport(long nativePtr, String contentType);
    @Override
    synchronized public void addContentTypeSupport(@NonNull String contentType)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addContentTypeSupport() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addContentTypeSupport(nativePtr, contentType);
    }

    private native void addFriendList(long nativePtr, FriendList list);
    @Override
    synchronized public void addFriendList(@NonNull FriendList list)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addFriendList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addFriendList(nativePtr, list);
    }

    private native void addLdap(long nativePtr, Ldap ldap);
    @Override
    synchronized public void addLdap(@NonNull Ldap ldap)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addLdap() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addLdap(nativePtr, ldap);
    }

    private native void addLinphoneSpec(long nativePtr, String spec);
    @Override
    synchronized public void addLinphoneSpec(@NonNull String spec)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addLinphoneSpec() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addLinphoneSpec(nativePtr, spec);
    }

    private native void addProvisioningHeader(long nativePtr, String headerName, String value);
    @Override
    synchronized public void addProvisioningHeader(@NonNull String headerName, @NonNull String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addProvisioningHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addProvisioningHeader(nativePtr, headerName, value);
    }

    private native int addProxyConfig(long nativePtr, ProxyConfig config);
    @Override
    synchronized public int addProxyConfig(@NonNull ProxyConfig config)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addProxyConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addProxyConfig(nativePtr, config);
    }

    private native void addRemoteContactDirectory(long nativePtr, RemoteContactDirectory remoteContactDirectory);
    @Override
    synchronized public void addRemoteContactDirectory(@NonNull RemoteContactDirectory remoteContactDirectory)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addRemoteContactDirectory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addRemoteContactDirectory(nativePtr, remoteContactDirectory);
    }

    private native void addSupportedTag(long nativePtr, String tag);
    @Override
    synchronized public void addSupportedTag(@NonNull String tag)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addSupportedTag() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addSupportedTag(nativePtr, tag);
    }

    private native int addToConference(long nativePtr, Call call);
    @Override
    synchronized public int addToConference(@NonNull Call call)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addToConference() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addToConference(nativePtr, call);
    }

    private native void audioRouteChanged(long nativePtr);
    @Override
    synchronized public void audioRouteChanged()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call audioRouteChanged() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        audioRouteChanged(nativePtr);
    }

    private native boolean callRingingDisabled(long nativePtr);
    @Override
    synchronized public boolean callRingingDisabled()  {
        
        
        return callRingingDisabled(nativePtr);
    }

    private native int chatRoomGetDefaultEphemeralMode(long nativePtr);
    @Override
    synchronized public ChatRoom.EphemeralMode chatRoomGetDefaultEphemeralMode()  {
        
        
        return ChatRoom.EphemeralMode.fromInt(chatRoomGetDefaultEphemeralMode(nativePtr));
    }

    private native void chatRoomSetDefaultEphemeralMode(long nativePtr, int mode);
    @Override
    synchronized public void chatRoomSetDefaultEphemeralMode(ChatRoom.EphemeralMode mode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call chatRoomSetDefaultEphemeralMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        chatRoomSetDefaultEphemeralMode(nativePtr, mode.toInt());
    }

    private native void checkForUpdate(long nativePtr, String currentVersion);
    @Override
    synchronized public void checkForUpdate(String currentVersion)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call checkForUpdate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        checkForUpdate(nativePtr, currentVersion);
    }

    private native void clearAccounts(long nativePtr);
    @Override
    synchronized public void clearAccounts()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearAccounts() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearAccounts(nativePtr);
    }

    private native void clearAllAuthInfo(long nativePtr);
    @Override
    synchronized public void clearAllAuthInfo()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearAllAuthInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearAllAuthInfo(nativePtr);
    }

    private native void clearCallLogs(long nativePtr);
    @Override
    synchronized public void clearCallLogs()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearCallLogs() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearCallLogs(nativePtr);
    }

    private native void clearLdaps(long nativePtr);
    @Override
    synchronized public void clearLdaps()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearLdaps() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearLdaps(nativePtr);
    }

    private native void clearProvisioningHeaders(long nativePtr);
    @Override
    synchronized public void clearProvisioningHeaders()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearProvisioningHeaders() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearProvisioningHeaders(nativePtr);
    }

    private native void clearProxyConfig(long nativePtr);
    @Override
    synchronized public void clearProxyConfig()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearProxyConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearProxyConfig(nativePtr);
    }

    private native int configSync(long nativePtr);
    @Override
    synchronized public int configSync()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call configSync() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return configSync(nativePtr);
    }

    private native void configureAudioSession(long nativePtr);
    @Override
    synchronized public void configureAudioSession()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call configureAudioSession() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        configureAudioSession(nativePtr);
    }

    private native Account createAccount(long nativePtr, AccountParams params);
    @Override @NonNull
    synchronized public Account createAccount(@NonNull AccountParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Account)createAccount(nativePtr, params);
    }

    private native AccountCreator createAccountCreator(long nativePtr, String xmlrpcUrl);
    @Override @NonNull
    synchronized public AccountCreator createAccountCreator(@Nullable String xmlrpcUrl)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createAccountCreator() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountCreator)createAccountCreator(nativePtr, xmlrpcUrl);
    }

    private native AccountManagerServices createAccountManagerServices(long nativePtr);
    @Override @NonNull
    synchronized public AccountManagerServices createAccountManagerServices()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createAccountManagerServices() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServices)createAccountManagerServices(nativePtr);
    }

    private native AccountParams createAccountParams(long nativePtr);
    @Override @NonNull
    synchronized public AccountParams createAccountParams()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createAccountParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountParams)createAccountParams(nativePtr);
    }

    private native Address createAddress(long nativePtr, String address);
    @Override @Nullable
    synchronized public Address createAddress(@Nullable String address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)createAddress(nativePtr, address);
    }

    private native CallLog createCallLog(long nativePtr, Address from, Address to, int dir, int duration, long startTime, long connectedTime, int status, boolean videoEnabled, float quality);
    @Override @NonNull
    synchronized public CallLog createCallLog(@NonNull Address from, @NonNull Address to, Call.Dir dir, int duration, long startTime, long connectedTime, Call.Status status, boolean videoEnabled, float quality)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createCallLog() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallLog)createCallLog(nativePtr, from, to, dir.toInt(), duration, startTime, connectedTime, status.toInt(), videoEnabled, quality);
    }

    private native CallParams createCallParams(long nativePtr, Call call);
    @Override @Nullable
    synchronized public CallParams createCallParams(@Nullable Call call)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createCallParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallParams)createCallParams(nativePtr, call);
    }

    private native CardDavParams createCardDavParams(long nativePtr);
    @Override @NonNull
    synchronized public CardDavParams createCardDavParams()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createCardDavParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CardDavParams)createCardDavParams(nativePtr);
    }

    private native RemoteContactDirectory createCardDavRemoteContactDirectory(long nativePtr, CardDavParams params);
    @Override @NonNull
    synchronized public RemoteContactDirectory createCardDavRemoteContactDirectory(@NonNull CardDavParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createCardDavRemoteContactDirectory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (RemoteContactDirectory)createCardDavRemoteContactDirectory(nativePtr, params);
    }

    private native ConferenceScheduler createCcmpConferenceScheduler(long nativePtr, Account account);
    @Override @NonNull
    synchronized public ConferenceScheduler createCcmpConferenceScheduler(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createCcmpConferenceScheduler() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceScheduler)createCcmpConferenceScheduler(nativePtr, account);
    }

    private native ChatRoom createChatRoom7(long nativePtr, ConferenceParams params, Address[] participants);
    @Override @Nullable
    synchronized public ChatRoom createChatRoom(@NonNull ConferenceParams params, @NonNull Address[] participants)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createChatRoom7(nativePtr, params, participants);
    }

    private native ChatRoom createChatRoom(long nativePtr, ChatRoomParams params, Address localAddr, String subject, Address[] participants);
    @Override @Nullable
    synchronized public ChatRoom createChatRoom(@NonNull ChatRoomParams params, @NonNull Address localAddr, @NonNull String subject, @NonNull Address[] participants)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createChatRoom(nativePtr, params, localAddr, subject, participants);
    }

    private native ChatRoom createChatRoom2(long nativePtr, ChatRoomParams params, String subject, Address[] participants);
    @Override @Nullable
    synchronized public ChatRoom createChatRoom(@NonNull ChatRoomParams params, @NonNull String subject, @NonNull Address[] participants)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createChatRoom2(nativePtr, params, subject, participants);
    }

    private native ChatRoom createChatRoom3(long nativePtr, String subject, Address[] participants);
    @Override @Nullable
    synchronized public ChatRoom createChatRoom(@NonNull String subject, @NonNull Address[] participants)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createChatRoom3(nativePtr, subject, participants);
    }

    private native ChatRoom createChatRoom4(long nativePtr, ChatRoomParams params, Address localAddr, Address participant);
    @Override @Nullable
    synchronized public ChatRoom createChatRoom(@NonNull ChatRoomParams params, @NonNull Address localAddr, @NonNull Address participant)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createChatRoom4(nativePtr, params, localAddr, participant);
    }

    private native ChatRoom createChatRoom5(long nativePtr, Address participant);
    @Override @Nullable
    synchronized public ChatRoom createChatRoom(@NonNull Address participant)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createChatRoom5(nativePtr, participant);
    }

    private native ChatRoom createChatRoom6(long nativePtr, ChatRoomParams params, Address localAddr, Address[] participants);
    @Override @Nullable
    synchronized public ChatRoom createChatRoom(@NonNull ChatRoomParams params, @Nullable Address localAddr, @NonNull Address[] participants)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createChatRoom6(nativePtr, params, localAddr, participants);
    }

    private native ChatRoom createClientGroupChatRoom(long nativePtr, String subject, boolean fallback);
    @Override @Nullable
    synchronized public ChatRoom createClientGroupChatRoom(@NonNull String subject, boolean fallback)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createClientGroupChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createClientGroupChatRoom(nativePtr, subject, fallback);
    }

    private native ChatRoom createClientGroupChatRoom2(long nativePtr, String subject, boolean fallback, boolean encrypted);
    @Override @Nullable
    synchronized public ChatRoom createClientGroupChatRoom(@NonNull String subject, boolean fallback, boolean encrypted)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createClientGroupChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)createClientGroupChatRoom2(nativePtr, subject, fallback, encrypted);
    }

    private native ConferenceParams createConferenceParams2(long nativePtr, Conference conference);
    @Override @NonNull
    synchronized public ConferenceParams createConferenceParams(@Nullable Conference conference)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConferenceParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceParams)createConferenceParams2(nativePtr, conference);
    }

    private native ConferenceScheduler createConferenceScheduler(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceScheduler createConferenceScheduler()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConferenceScheduler() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceScheduler)createConferenceScheduler(nativePtr);
    }

    private native ConferenceScheduler createConferenceScheduler2(long nativePtr, Account account);
    @Override @NonNull
    synchronized public ConferenceScheduler createConferenceScheduler(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConferenceScheduler() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceScheduler)createConferenceScheduler2(nativePtr, account);
    }

    private native ConferenceScheduler createConferenceSchedulerWithType(long nativePtr, Account account, int schedulingType);
    @Override @NonNull
    synchronized public ConferenceScheduler createConferenceSchedulerWithType(@Nullable Account account, ConferenceScheduler.Type schedulingType)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConferenceSchedulerWithType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceScheduler)createConferenceSchedulerWithType(nativePtr, account, schedulingType.toInt());
    }

    private native Conference createConferenceWithParams(long nativePtr, ConferenceParams params);
    @Override @Nullable
    synchronized public Conference createConferenceWithParams(@NonNull ConferenceParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConferenceWithParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Conference)createConferenceWithParams(nativePtr, params);
    }

    private native Config createConfig(long nativePtr, String filename);
    @Override @NonNull
    synchronized public Config createConfig(@Nullable String filename)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Config)createConfig(nativePtr, filename);
    }

    private native Content createContent(long nativePtr);
    @Override @NonNull
    synchronized public Content createContent()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Content)createContent(nativePtr);
    }

    private native ConferenceScheduler createDbConferenceScheduler(long nativePtr, Account account);
    @Override @NonNull
    synchronized public ConferenceScheduler createDbConferenceScheduler(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createDbConferenceScheduler() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceScheduler)createDbConferenceScheduler(nativePtr, account);
    }

    private native ChatRoomParams createDefaultChatRoomParams(long nativePtr);
    @Override @NonNull
    synchronized public ChatRoomParams createDefaultChatRoomParams()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createDefaultChatRoomParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoomParams)createDefaultChatRoomParams(nativePtr);
    }

    private native EktInfo createEktInfoFromXml(long nativePtr, String xmlBody);
    @Override @Nullable
    synchronized public EktInfo createEktInfoFromXml(@NonNull String xmlBody)  {
        
        
        return (EktInfo)createEktInfoFromXml(nativePtr, xmlBody);
    }

    private native Friend createFriend(long nativePtr);
    @Override @NonNull
    synchronized public Friend createFriend()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createFriend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Friend)createFriend(nativePtr);
    }

    private native Friend createFriendFromVcard(long nativePtr, Vcard vcard);
    @Override @Nullable
    synchronized public Friend createFriendFromVcard(@NonNull Vcard vcard)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createFriendFromVcard() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Friend)createFriendFromVcard(nativePtr, vcard);
    }

    private native FriendList createFriendList(long nativePtr);
    @Override @NonNull
    synchronized public FriendList createFriendList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createFriendList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (FriendList)createFriendList(nativePtr);
    }

    private native Friend createFriendWithAddress(long nativePtr, String address);
    @Override @Nullable
    synchronized public Friend createFriendWithAddress(@NonNull String address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createFriendWithAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Friend)createFriendWithAddress(nativePtr, address);
    }

    private native InfoMessage createInfoMessage(long nativePtr);
    @Override @NonNull
    synchronized public InfoMessage createInfoMessage()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createInfoMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (InfoMessage)createInfoMessage(nativePtr);
    }

    private native Ldap createLdap(long nativePtr);
    @Override @NonNull
    synchronized public Ldap createLdap()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createLdap() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Ldap)createLdap(nativePtr);
    }

    private native LdapParams createLdapParams(long nativePtr);
    @Override @NonNull
    synchronized public LdapParams createLdapParams()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createLdapParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (LdapParams)createLdapParams(nativePtr);
    }

    private native RemoteContactDirectory createLdapRemoteContactDirectory(long nativePtr, LdapParams params);
    @Override @NonNull
    synchronized public RemoteContactDirectory createLdapRemoteContactDirectory(@NonNull LdapParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createLdapRemoteContactDirectory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (RemoteContactDirectory)createLdapRemoteContactDirectory(nativePtr, params);
    }

    private native Ldap createLdapWithParams(long nativePtr, LdapParams params);
    @Override @NonNull
    synchronized public Ldap createLdapWithParams(@NonNull LdapParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createLdapWithParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Ldap)createLdapWithParams(nativePtr, params);
    }

    private native Player createLocalPlayer(long nativePtr, String soundCardName, String videoDisplayName, Object windowId);
    @Override @Nullable
    synchronized public Player createLocalPlayer(@Nullable String soundCardName, @Nullable String videoDisplayName, @Nullable Object windowId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createLocalPlayer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Player)createLocalPlayer(nativePtr, soundCardName, videoDisplayName, windowId);
    }

    private native MagicSearch createMagicSearch(long nativePtr);
    @Override @NonNull
    synchronized public MagicSearch createMagicSearch()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createMagicSearch() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (MagicSearch)createMagicSearch(nativePtr);
    }

    private native NatPolicy createNatPolicy(long nativePtr);
    @Override @NonNull
    synchronized public NatPolicy createNatPolicy()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createNatPolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (NatPolicy)createNatPolicy(nativePtr);
    }

    private native Object createNativePreviewWindowId2(long nativePtr, Object context);
    @Override @Nullable
    synchronized public Object createNativePreviewWindowId(@Nullable Object context)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createNativePreviewWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return createNativePreviewWindowId2(nativePtr, context);
    }

    private native Object createNativePreviewWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object createNativePreviewWindowId()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createNativePreviewWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return createNativePreviewWindowId(nativePtr);
    }

    private native Object createNativeVideoWindowId2(long nativePtr, Object context);
    @Override @Nullable
    synchronized public Object createNativeVideoWindowId(@Nullable Object context)  {
        
        
        return createNativeVideoWindowId2(nativePtr, context);
    }

    private native Object createNativeVideoWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object createNativeVideoWindowId()  {
        
        
        return createNativeVideoWindowId(nativePtr);
    }

    private native Event createNotify(long nativePtr, Address resource, String event);
    @Override @NonNull
    synchronized public Event createNotify(@NonNull Address resource, @NonNull String event)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createNotify() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Event)createNotify(nativePtr, resource, event);
    }

    private native Event createOneShotPublish(long nativePtr, Address resource, String event);
    @Override @NonNull
    synchronized public Event createOneShotPublish(@NonNull Address resource, @NonNull String event)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createOneShotPublish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Event)createOneShotPublish(nativePtr, resource, event);
    }

    private native PresenceActivity createPresenceActivity(long nativePtr, int acttype, String description);
    @Override @NonNull
    synchronized public PresenceActivity createPresenceActivity(PresenceActivity.Type acttype, @Nullable String description)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPresenceActivity() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresenceActivity)createPresenceActivity(nativePtr, acttype.toInt(), description);
    }

    private native PresenceModel createPresenceModel(long nativePtr);
    @Override @NonNull
    synchronized public PresenceModel createPresenceModel()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPresenceModel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresenceModel)createPresenceModel(nativePtr);
    }

    private native PresenceModel createPresenceModelWithActivity(long nativePtr, int acttype, String description);
    @Override @NonNull
    synchronized public PresenceModel createPresenceModelWithActivity(PresenceActivity.Type acttype, @Nullable String description)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPresenceModelWithActivity() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresenceModel)createPresenceModelWithActivity(nativePtr, acttype.toInt(), description);
    }

    private native PresenceModel createPresenceModelWithActivityAndNote(long nativePtr, int acttype, String description, String note, String lang);
    @Override @NonNull
    synchronized public PresenceModel createPresenceModelWithActivityAndNote(PresenceActivity.Type acttype, @Nullable String description, @NonNull String note, @Nullable String lang)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPresenceModelWithActivityAndNote() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresenceModel)createPresenceModelWithActivityAndNote(nativePtr, acttype.toInt(), description, note, lang);
    }

    private native PresenceNote createPresenceNote(long nativePtr, String content, String lang);
    @Override @NonNull
    synchronized public PresenceNote createPresenceNote(@NonNull String content, @Nullable String lang)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPresenceNote() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresenceNote)createPresenceNote(nativePtr, content, lang);
    }

    private native PresencePerson createPresencePerson(long nativePtr, String id);
    @Override @NonNull
    synchronized public PresencePerson createPresencePerson(@NonNull String id)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPresencePerson() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresencePerson)createPresencePerson(nativePtr, id);
    }

    private native PresenceService createPresenceService(long nativePtr, String id, int basicStatus, String contact);
    @Override @NonNull
    synchronized public PresenceService createPresenceService(@NonNull String id, PresenceBasicStatus basicStatus, @NonNull String contact)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPresenceService() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PresenceService)createPresenceService(nativePtr, id, basicStatus.toInt(), contact);
    }

    private native Address createPrimaryContactParsed(long nativePtr);
    @Override @Nullable
    synchronized public Address createPrimaryContactParsed()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPrimaryContactParsed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)createPrimaryContactParsed(nativePtr);
    }

    private native ProxyConfig createProxyConfig(long nativePtr);
    @Override @NonNull
    synchronized public ProxyConfig createProxyConfig()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createProxyConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ProxyConfig)createProxyConfig(nativePtr);
    }

    private native Event createPublish(long nativePtr, Address resource, String event, int expires);
    @Override @NonNull
    synchronized public Event createPublish(@NonNull Address resource, @NonNull String event, int expires)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createPublish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Event)createPublish(nativePtr, resource, event, expires);
    }

    private native Recorder createRecorder(long nativePtr, RecorderParams params);
    @Override @NonNull
    synchronized public Recorder createRecorder(@NonNull RecorderParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createRecorder() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Recorder)createRecorder(nativePtr, params);
    }

    private native RecorderParams createRecorderParams(long nativePtr);
    @Override @NonNull
    synchronized public RecorderParams createRecorderParams()  {
        
        
        return (RecorderParams)createRecorderParams(nativePtr);
    }

    private native ConferenceScheduler createSipConferenceScheduler(long nativePtr, Account account);
    @Override @NonNull
    synchronized public ConferenceScheduler createSipConferenceScheduler(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createSipConferenceScheduler() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceScheduler)createSipConferenceScheduler(nativePtr, account);
    }

    private native Event createSubscribe(long nativePtr, Address resource, String event, int expires);
    @Override @NonNull
    synchronized public Event createSubscribe(@NonNull Address resource, @NonNull String event, int expires)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createSubscribe() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Event)createSubscribe(nativePtr, resource, event, expires);
    }

    private native Event createSubscribe2(long nativePtr, Address resource, ProxyConfig proxy, String event, int expires);
    @Override @NonNull
    synchronized public Event createSubscribe(@NonNull Address resource, @NonNull ProxyConfig proxy, @NonNull String event, int expires)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createSubscribe() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Event)createSubscribe2(nativePtr, resource, proxy, event, expires);
    }

    private native String createXmlFromEktInfo(long nativePtr, EktInfo ektInfo);
    @Override @Nullable
    synchronized public String createXmlFromEktInfo(@NonNull EktInfo ektInfo)  {
        
        
        return createXmlFromEktInfo(nativePtr, ektInfo);
    }

    private native String createXmlFromEktInfo2(long nativePtr, EktInfo ektInfo, Account account);
    @Override @Nullable
    synchronized public String createXmlFromEktInfo(@NonNull EktInfo ektInfo, @Nullable Account account)  {
        
        
        return createXmlFromEktInfo2(nativePtr, ektInfo, account);
    }

    private native XmlRpcSession createXmlRpcSession(long nativePtr, String url);
    @Override @NonNull
    synchronized public XmlRpcSession createXmlRpcSession(@NonNull String url)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createXmlRpcSession() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (XmlRpcSession)createXmlRpcSession(nativePtr, url);
    }

    private native void deleteChatRoom(long nativePtr, ChatRoom chatRoom);
    @Override
    synchronized public void deleteChatRoom(@NonNull ChatRoom chatRoom)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call deleteChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        deleteChatRoom(nativePtr, chatRoom);
    }

    private native void deleteConferenceInformation(long nativePtr, ConferenceInfo conferenceInfo);
    @Override
    synchronized public void deleteConferenceInformation(@NonNull ConferenceInfo conferenceInfo)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call deleteConferenceInformation() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        deleteConferenceInformation(nativePtr, conferenceInfo);
    }

    private native void didRegisterForRemotePush(long nativePtr, Object deviceToken);
    @Override
    synchronized public void didRegisterForRemotePush(@Nullable Object deviceToken)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call didRegisterForRemotePush() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        didRegisterForRemotePush(nativePtr, deviceToken);
    }

    private native void didRegisterForRemotePushWithStringifiedToken(long nativePtr, String deviceTokenStr);
    @Override
    synchronized public void didRegisterForRemotePushWithStringifiedToken(@Nullable String deviceTokenStr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call didRegisterForRemotePushWithStringifiedToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        didRegisterForRemotePushWithStringifiedToken(nativePtr, deviceTokenStr);
    }

    private native void disableCallRinging(long nativePtr, boolean yesno);
    @Override
    synchronized public void disableCallRinging(boolean yesno)  {
        
        
        disableCallRinging(nativePtr, yesno);
    }

    private native void disableChat(long nativePtr, int denyReason);
    @Override
    synchronized public void disableChat(Reason denyReason)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call disableChat() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        disableChat(nativePtr, denyReason.toInt());
    }

    private native void enableChat(long nativePtr);
    @Override
    synchronized public void enableChat()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enableChat() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        enableChat(nativePtr);
    }

    private native void ensureRegistered(long nativePtr);
    @Override
    synchronized public void ensureRegistered()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call ensureRegistered() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        ensureRegistered(nativePtr);
    }

    private native void enterBackground(long nativePtr);
    @Override
    synchronized public void enterBackground()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enterBackground() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        enterBackground(nativePtr);
    }

    private native int enterConference(long nativePtr);
    @Override
    synchronized public int enterConference()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enterConference() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return enterConference(nativePtr);
    }

    private native void enterForeground(long nativePtr);
    @Override
    synchronized public void enterForeground()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enterForeground() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        enterForeground(nativePtr);
    }

    private native boolean fileFormatSupported(long nativePtr, String fmt);
    @Override
    synchronized public boolean fileFormatSupported(@NonNull String fmt)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call fileFormatSupported() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return fileFormatSupported(nativePtr, fmt);
    }

    private native AuthInfo findAuthInfo(long nativePtr, String realm, String username, String sipDomain);
    @Override @Nullable
    synchronized public AuthInfo findAuthInfo(@Nullable String realm, @NonNull String username, @Nullable String sipDomain)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findAuthInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AuthInfo)findAuthInfo(nativePtr, realm, username, sipDomain);
    }

    private native Call findCallFromUri(long nativePtr, String uri);
    @Override @Nullable
    synchronized public Call findCallFromUri(@NonNull String uri)  {
        
        
        return (Call)findCallFromUri(nativePtr, uri);
    }

    private native CallLog findCallLog(long nativePtr, String callId, int limit);
    @Override @Nullable
    synchronized public CallLog findCallLog(@NonNull String callId, @NonNull int limit)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findCallLog() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallLog)findCallLog(nativePtr, callId, limit);
    }

    private native CallLog findCallLogFromCallId(long nativePtr, String callId);
    @Override @Nullable
    synchronized public CallLog findCallLogFromCallId(@NonNull String callId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findCallLogFromCallId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (CallLog)findCallLogFromCallId(nativePtr, callId);
    }

    private native ChatRoom findChatRoom(long nativePtr, Address peerAddr, Address localAddr);
    @Override @Nullable
    synchronized public ChatRoom findChatRoom(@NonNull Address peerAddr, @NonNull Address localAddr)  {
        
        
        return (ChatRoom)findChatRoom(nativePtr, peerAddr, localAddr);
    }

    private native ConferenceInfo findConferenceInformationFromCcmpUri(long nativePtr, String uri);
    @Override @Nullable
    synchronized public ConferenceInfo findConferenceInformationFromCcmpUri(@NonNull String uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findConferenceInformationFromCcmpUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceInfo)findConferenceInformationFromCcmpUri(nativePtr, uri);
    }

    private native ConferenceInfo findConferenceInformationFromUri(long nativePtr, Address uri);
    @Override @Nullable
    synchronized public ConferenceInfo findConferenceInformationFromUri(@NonNull Address uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findConferenceInformationFromUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceInfo)findConferenceInformationFromUri(nativePtr, uri);
    }

    private native Address[] findContactsByChar(long nativePtr, String filter, boolean sipOnly);
    @Override @NonNull
    synchronized public Address[] findContactsByChar(@NonNull String filter, boolean sipOnly)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findContactsByChar() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return findContactsByChar(nativePtr, filter, sipOnly);
    }

    private native Friend findFriend(long nativePtr, Address address);
    @Override @Nullable
    synchronized public Friend findFriend(@NonNull Address address)  {
        
        
        return (Friend)findFriend(nativePtr, address);
    }

    private native Friend findFriendByPhoneNumber(long nativePtr, String phoneNumber);
    @Override @Nullable
    synchronized public Friend findFriendByPhoneNumber(@NonNull String phoneNumber)  {
        
        
        return (Friend)findFriendByPhoneNumber(nativePtr, phoneNumber);
    }

    private native Friend[] findFriends(long nativePtr, Address address);
    @Override @NonNull
    synchronized public Friend[] findFriends(@NonNull Address address)  {
        
        
        return findFriends(nativePtr, address);
    }

    private native ChatRoom findOneToOneChatRoom2(long nativePtr, Address localAddr, Address participantAddr, boolean encrypted);
    @Override @Nullable
    synchronized public ChatRoom findOneToOneChatRoom(@NonNull Address localAddr, @NonNull Address participantAddr, boolean encrypted)  {
        
        
        return (ChatRoom)findOneToOneChatRoom2(nativePtr, localAddr, participantAddr, encrypted);
    }

    private native Account getAccountByIdkey(long nativePtr, String idkey);
    @Override @Nullable
    synchronized public Account getAccountByIdkey(@Nullable String idkey)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getAccountByIdkey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Account)getAccountByIdkey(nativePtr, idkey);
    }

    private native Call getCallByCallid(long nativePtr, String callId);
    @Override @Nullable
    synchronized public Call getCallByCallid(@NonNull String callId)  {
        
        
        return (Call)getCallByCallid(nativePtr, callId);
    }

    private native Call getCallByRemoteAddress(long nativePtr, String remoteAddress);
    @Override @Nullable
    synchronized public Call getCallByRemoteAddress(@NonNull String remoteAddress)  {
        
        
        return (Call)getCallByRemoteAddress(nativePtr, remoteAddress);
    }

    private native Call getCallByRemoteAddress22(long nativePtr, Address remoteAddress);
    @Override @Nullable
    synchronized public Call getCallByRemoteAddress2(@NonNull Address remoteAddress)  {
        
        
        return (Call)getCallByRemoteAddress22(nativePtr, remoteAddress);
    }

    private native CallLog[] getCallHistory2(long nativePtr, Address peerAddress, Address localAddress);
    @Override @NonNull
    synchronized public CallLog[] getCallHistory(@NonNull Address peerAddress, @NonNull Address localAddress)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCallHistory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCallHistory2(nativePtr, peerAddress, localAddress);
    }

    private native ChatRoom getChatRoom(long nativePtr, Address addr);
    @Override @Nullable
    synchronized public ChatRoom getChatRoom(@NonNull Address addr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)getChatRoom(nativePtr, addr);
    }

    private native ChatRoom getChatRoom2(long nativePtr, Address peerAddr, Address localAddr);
    @Override @Nullable
    synchronized public ChatRoom getChatRoom(@NonNull Address peerAddr, @NonNull Address localAddr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)getChatRoom2(nativePtr, peerAddr, localAddr);
    }

    private native ChatRoom getChatRoomFromUri(long nativePtr, String to);
    @Override @Nullable
    synchronized public ChatRoom getChatRoomFromUri(@NonNull String to)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getChatRoomFromUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)getChatRoomFromUri(nativePtr, to);
    }

    private native ConferenceInfo[] getConferenceInformationListAfterTime(long nativePtr, long time);
    @Override @NonNull
    synchronized public ConferenceInfo[] getConferenceInformationListAfterTime(long time)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getConferenceInformationListAfterTime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getConferenceInformationListAfterTime(nativePtr, time);
    }

    private native ConferenceInfo[] getConferenceInformationsWithParticipant(long nativePtr, Address uri);
    @Override @NonNull
    synchronized public ConferenceInfo[] getConferenceInformationsWithParticipant(@NonNull Address uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getConferenceInformationsWithParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getConferenceInformationsWithParticipant(nativePtr, uri);
    }

    private native Friend getFriendByRefKey(long nativePtr, String key);
    @Override @Nullable
    synchronized public Friend getFriendByRefKey(@NonNull String key)  {
        
        
        return (Friend)getFriendByRefKey(nativePtr, key);
    }

    private native FriendList getFriendListByName(long nativePtr, String name);
    @Override @Nullable
    synchronized public FriendList getFriendListByName(@NonNull String name)  {
        
        
        return (FriendList)getFriendListByName(nativePtr, name);
    }

    private native PayloadType getPayloadType(long nativePtr, String type, int rate, int channels);
    @Override @Nullable
    synchronized public PayloadType getPayloadType(@NonNull String type, int rate, int channels)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPayloadType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (PayloadType)getPayloadType(nativePtr, type, rate, channels);
    }

    private native ProxyConfig getProxyConfigByIdkey(long nativePtr, String idkey);
    @Override @Nullable
    synchronized public ProxyConfig getProxyConfigByIdkey(String idkey)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getProxyConfigByIdkey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ProxyConfig)getProxyConfigByIdkey(nativePtr, idkey);
    }

    private native int getZrtpStatus(long nativePtr, String addr);
    @Override
    synchronized public ZrtpPeerStatus getZrtpStatus(@NonNull String addr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getZrtpStatus() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return ZrtpPeerStatus.fromInt(getZrtpStatus(nativePtr, addr));
    }

    private native boolean hasBuiltinEchoCanceller(long nativePtr);
    @Override
    synchronized public boolean hasBuiltinEchoCanceller()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call hasBuiltinEchoCanceller() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return hasBuiltinEchoCanceller(nativePtr);
    }

    private native boolean hasCrappyOpengl(long nativePtr);
    @Override
    synchronized public boolean hasCrappyOpengl()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call hasCrappyOpengl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return hasCrappyOpengl(nativePtr);
    }

    private native boolean inCall(long nativePtr);
    @Override
    synchronized public boolean inCall()  {
        
        
        return inCall(nativePtr);
    }

    private native Address interpretUrl(long nativePtr, String url);
    @Override @Nullable
    synchronized public Address interpretUrl(@NonNull String url)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call interpretUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)interpretUrl(nativePtr, url);
    }

    private native Address interpretUrl2(long nativePtr, String url, boolean applyInternationalPrefix);
    @Override @Nullable
    synchronized public Address interpretUrl(@NonNull String url, boolean applyInternationalPrefix)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call interpretUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)interpretUrl2(nativePtr, url, applyInternationalPrefix);
    }

    private native Call invite(long nativePtr, String url);
    @Override @Nullable
    synchronized public Call invite(@NonNull String url)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call invite() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Call)invite(nativePtr, url);
    }

    private native Call inviteAddress(long nativePtr, Address addr);
    @Override @Nullable
    synchronized public Call inviteAddress(@NonNull Address addr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call inviteAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Call)inviteAddress(nativePtr, addr);
    }

    private native Call inviteAddressWithParams(long nativePtr, Address addr, CallParams params);
    @Override @Nullable
    synchronized public Call inviteAddressWithParams(@NonNull Address addr, @NonNull CallParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call inviteAddressWithParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Call)inviteAddressWithParams(nativePtr, addr, params);
    }

    private native Call inviteAddressWithParams2(long nativePtr, Address addr, CallParams params, String subject, Content content);
    @Override @Nullable
    synchronized public Call inviteAddressWithParams(@NonNull Address addr, @NonNull CallParams params, @Nullable String subject, @Nullable Content content)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call inviteAddressWithParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Call)inviteAddressWithParams2(nativePtr, addr, params, subject, content);
    }

    private native Call inviteWithParams(long nativePtr, String url, CallParams params);
    @Override @Nullable
    synchronized public Call inviteWithParams(@NonNull String url, @NonNull CallParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call inviteWithParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Call)inviteWithParams(nativePtr, url, params);
    }

    private native boolean isContentTypeSupported(long nativePtr, String contentType);
    @Override
    synchronized public boolean isContentTypeSupported(@NonNull String contentType)  {
        
        
        return isContentTypeSupported(nativePtr, contentType);
    }

    private native boolean isMediaEncryptionSupported(long nativePtr, int menc);
    @Override
    synchronized public boolean isMediaEncryptionSupported(MediaEncryption menc)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isMediaEncryptionSupported() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isMediaEncryptionSupported(nativePtr, menc.toInt());
    }

    private native boolean isMediaFilterSupported(long nativePtr, String filtername);
    @Override
    synchronized public boolean isMediaFilterSupported(@NonNull String filtername)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isMediaFilterSupported() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isMediaFilterSupported(nativePtr, filtername);
    }

    private native boolean isPluginLoaded(long nativePtr, String name);
    @Override
    synchronized public boolean isPluginLoaded(@NonNull String name)  {
        
        
        return isPluginLoaded(nativePtr, name);
    }

    private native void iterate(long nativePtr);
    @Override
    synchronized public void iterate()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call iterate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        iterate(nativePtr);
    }

    private native boolean ldapAvailable(long nativePtr);
    @Override
    synchronized public boolean ldapAvailable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call ldapAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return ldapAvailable(nativePtr);
    }

    private native int leaveConference(long nativePtr);
    @Override
    synchronized public int leaveConference()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call leaveConference() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return leaveConference(nativePtr);
    }

    private native boolean limeX3DhAvailable(long nativePtr);
    @Override
    synchronized public boolean limeX3DhAvailable()  {
        
        
        return limeX3DhAvailable(nativePtr);
    }

    private native void loadConfigFromXml(long nativePtr, String xmlUri);
    @Override
    synchronized public void loadConfigFromXml(@NonNull String xmlUri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call loadConfigFromXml() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        loadConfigFromXml(nativePtr, xmlUri);
    }

    private native boolean mediaEncryptionSupported(long nativePtr, int menc);
    @Override
    synchronized public boolean mediaEncryptionSupported(MediaEncryption menc)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call mediaEncryptionSupported() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return mediaEncryptionSupported(nativePtr, menc.toInt());
    }

    private native void migrateLogsFromRcToDb(long nativePtr);
    @Override
    synchronized public void migrateLogsFromRcToDb()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call migrateLogsFromRcToDb() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        migrateLogsFromRcToDb(nativePtr);
    }

    private native void notifyAllFriends(long nativePtr, PresenceModel presence);
    @Override
    synchronized public void notifyAllFriends(@NonNull PresenceModel presence)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call notifyAllFriends() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        notifyAllFriends(nativePtr, presence);
    }

    private native void notifyNotifyPresenceReceived(long nativePtr, Friend linphoneFriend);
    @Override
    synchronized public void notifyNotifyPresenceReceived(@NonNull Friend linphoneFriend)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call notifyNotifyPresenceReceived() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        notifyNotifyPresenceReceived(nativePtr, linphoneFriend);
    }

    private native void notifyNotifyPresenceReceivedForUriOrTel(long nativePtr, Friend linphoneFriend, String uriOrTel, PresenceModel presenceModel);
    @Override
    synchronized public void notifyNotifyPresenceReceivedForUriOrTel(@NonNull Friend linphoneFriend, @NonNull String uriOrTel, @NonNull PresenceModel presenceModel)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call notifyNotifyPresenceReceivedForUriOrTel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        notifyNotifyPresenceReceivedForUriOrTel(nativePtr, linphoneFriend, uriOrTel, presenceModel);
    }

    private native int pauseAllCalls(long nativePtr);
    @Override
    synchronized public int pauseAllCalls()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call pauseAllCalls() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return pauseAllCalls(nativePtr);
    }

    private native void playDtmf(long nativePtr, char dtmf, int durationMs);
    @Override
    synchronized public void playDtmf(char dtmf, int durationMs)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call playDtmf() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        playDtmf(nativePtr, dtmf, durationMs);
    }

    private native int playLocal(long nativePtr, String audiofile);
    @Override
    synchronized public int playLocal(@NonNull String audiofile)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call playLocal() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return playLocal(nativePtr, audiofile);
    }

    private native int preemptSoundResources(long nativePtr);
    @Override
    synchronized public int preemptSoundResources()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call preemptSoundResources() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return preemptSoundResources(nativePtr);
    }

    private native void previewOglRender(long nativePtr);
    @Override
    synchronized public void previewOglRender()  {
        
        
        previewOglRender(nativePtr);
    }

    private native void processPushNotification(long nativePtr, String callId);
    @Override
    synchronized public void processPushNotification(@Nullable String callId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call processPushNotification() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        processPushNotification(nativePtr, callId);
    }

    private native Event publish(long nativePtr, Address resource, String event, int expires, Content body);
    @Override @Nullable
    synchronized public Event publish(@NonNull Address resource, @NonNull String event, int expires, @NonNull Content body)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call publish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Event)publish(nativePtr, resource, event, expires, body);
    }

    private native void refreshRegisters(long nativePtr);
    @Override
    synchronized public void refreshRegisters()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call refreshRegisters() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        refreshRegisters(nativePtr);
    }

    private native void rejectSubscriber(long nativePtr, Friend linphoneFriend);
    @Override
    synchronized public void rejectSubscriber(@NonNull Friend linphoneFriend)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call rejectSubscriber() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        rejectSubscriber(nativePtr, linphoneFriend);
    }

    private native void reloadMsPlugins(long nativePtr, String path);
    @Override
    synchronized public void reloadMsPlugins(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call reloadMsPlugins() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        reloadMsPlugins(nativePtr, path);
    }

    private native void reloadSoundDevices(long nativePtr);
    @Override
    synchronized public void reloadSoundDevices()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call reloadSoundDevices() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        reloadSoundDevices(nativePtr);
    }

    private native void reloadVideoDevices(long nativePtr);
    @Override
    synchronized public void reloadVideoDevices()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call reloadVideoDevices() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        reloadVideoDevices(nativePtr);
    }

    private native void removeAccount(long nativePtr, Account account);
    @Override
    synchronized public void removeAccount(@NonNull Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeAccount(nativePtr, account);
    }

    private native void removeAuthInfo(long nativePtr, AuthInfo info);
    @Override
    synchronized public void removeAuthInfo(@NonNull AuthInfo info)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeAuthInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeAuthInfo(nativePtr, info);
    }

    private native void removeCallLog(long nativePtr, CallLog callLog);
    @Override
    synchronized public void removeCallLog(@NonNull CallLog callLog)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeCallLog() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeCallLog(nativePtr, callLog);
    }

    private native void removeContentTypeSupport(long nativePtr, String contentType);
    @Override
    synchronized public void removeContentTypeSupport(@NonNull String contentType)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeContentTypeSupport() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeContentTypeSupport(nativePtr, contentType);
    }

    private native void removeFriendList(long nativePtr, FriendList list);
    @Override
    synchronized public void removeFriendList(@NonNull FriendList list)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeFriendList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeFriendList(nativePtr, list);
    }

    private native int removeFromConference(long nativePtr, Call call);
    @Override
    synchronized public int removeFromConference(@NonNull Call call)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeFromConference() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return removeFromConference(nativePtr, call);
    }

    private native void removeLdap(long nativePtr, Ldap ldap);
    @Override
    synchronized public void removeLdap(@NonNull Ldap ldap)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeLdap() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeLdap(nativePtr, ldap);
    }

    private native void removeLinphoneSpec(long nativePtr, String spec);
    @Override
    synchronized public void removeLinphoneSpec(@NonNull String spec)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeLinphoneSpec() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeLinphoneSpec(nativePtr, spec);
    }

    private native void removeProxyConfig(long nativePtr, ProxyConfig config);
    @Override
    synchronized public void removeProxyConfig(@NonNull ProxyConfig config)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeProxyConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeProxyConfig(nativePtr, config);
    }

    private native void removeRemoteContactDirectory(long nativePtr, RemoteContactDirectory remoteContactDirectory);
    @Override
    synchronized public void removeRemoteContactDirectory(@NonNull RemoteContactDirectory remoteContactDirectory)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeRemoteContactDirectory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeRemoteContactDirectory(nativePtr, remoteContactDirectory);
    }

    private native void removeSupportedTag(long nativePtr, String tag);
    @Override
    synchronized public void removeSupportedTag(@NonNull String tag)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeSupportedTag() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeSupportedTag(nativePtr, tag);
    }

    private native void resetEchoCancellationCalibration(long nativePtr);
    @Override
    synchronized public void resetEchoCancellationCalibration()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call resetEchoCancellationCalibration() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        resetEchoCancellationCalibration(nativePtr);
    }

    private native void resetMissedCallsCount(long nativePtr);
    @Override
    synchronized public void resetMissedCallsCount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call resetMissedCallsCount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        resetMissedCallsCount(nativePtr);
    }

    private native ChatRoom searchChatRoom(long nativePtr, ChatRoomParams params, Address localAddr, Address remoteAddr, Address[] participants);
    @Override @Nullable
    synchronized public ChatRoom searchChatRoom(@Nullable ChatRoomParams params, @Nullable Address localAddr, @Nullable Address remoteAddr, @Nullable Address[] participants)  {
        
        
        return (ChatRoom)searchChatRoom(nativePtr, params, localAddr, remoteAddr, participants);
    }

    private native ChatRoom searchChatRoom2(long nativePtr, ConferenceParams params, Address localAddr, Address remoteAddr, Address[] participants);
    @Override @Nullable
    synchronized public ChatRoom searchChatRoom(@Nullable ConferenceParams params, @Nullable Address localAddr, @Nullable Address remoteAddr, @Nullable Address[] participants)  {
        
        
        return (ChatRoom)searchChatRoom2(nativePtr, params, localAddr, remoteAddr, participants);
    }

    private native ChatRoom searchChatRoomByIdentifier(long nativePtr, String identifier);
    @Override @Nullable
    synchronized public ChatRoom searchChatRoomByIdentifier(@NonNull String identifier)  {
        
        
        return (ChatRoom)searchChatRoomByIdentifier(nativePtr, identifier);
    }

    private native Conference searchConference(long nativePtr, ConferenceParams params, Address localAddr, Address remoteAddr, Address[] participants);
    @Override @Nullable
    synchronized public Conference searchConference(@Nullable ConferenceParams params, @Nullable Address localAddr, @Nullable Address remoteAddr, @Nullable Address[] participants)  {
        
        
        return (Conference)searchConference(nativePtr, params, localAddr, remoteAddr, participants);
    }

    private native Conference searchConference2(long nativePtr, Address conferenceAddr);
    @Override @Nullable
    synchronized public Conference searchConference(@NonNull Address conferenceAddr)  {
        
        
        return (Conference)searchConference2(nativePtr, conferenceAddr);
    }

    private native Conference searchConferenceByIdentifier(long nativePtr, String identifier);
    @Override @Nullable
    synchronized public Conference searchConferenceByIdentifier(@NonNull String identifier)  {
        
        
        return (Conference)searchConferenceByIdentifier(nativePtr, identifier);
    }

    private native void setAudioPortRange(long nativePtr, int minPort, int maxPort);
    @Override
    synchronized public void setAudioPortRange(int minPort, int maxPort)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioPortRange() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioPortRange(nativePtr, minPort, maxPort);
    }

    private native void setQrcodeDecodeRect(long nativePtr, int x, int y, int w, int h);
    @Override
    synchronized public void setQrcodeDecodeRect(int x, int y, int w, int h)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setQrcodeDecodeRect() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setQrcodeDecodeRect(nativePtr, x, y, w, h);
    }

    private native void setRefreshWindow(long nativePtr, int minValue, int maxValue);
    @Override
    synchronized public void setRefreshWindow(int minValue, int maxValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRefreshWindow() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRefreshWindow(nativePtr, minValue, maxValue);
    }

    private native void setTextPortRange(long nativePtr, int minPort, int maxPort);
    @Override
    synchronized public void setTextPortRange(int minPort, int maxPort)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTextPortRange() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTextPortRange(nativePtr, minPort, maxPort);
    }

    private native void setTone(long nativePtr, int toneId, String audiofile);
    @Override
    synchronized public void setTone(ToneID toneId, @Nullable String audiofile)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTone() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTone(nativePtr, toneId.toInt(), audiofile);
    }

    private native void setUserAgent(long nativePtr, String name, String version);
    @Override
    synchronized public void setUserAgent(@Nullable String name, @Nullable String version)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUserAgent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUserAgent(nativePtr, name, version);
    }

    private native void setVideoPortRange(long nativePtr, int minPort, int maxPort);
    @Override
    synchronized public void setVideoPortRange(int minPort, int maxPort)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoPortRange() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoPortRange(nativePtr, minPort, maxPort);
    }

    private native boolean soundDeviceCanCapture(long nativePtr, String device);
    @Override
    synchronized public boolean soundDeviceCanCapture(@NonNull String device)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call soundDeviceCanCapture() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return soundDeviceCanCapture(nativePtr, device);
    }

    private native boolean soundDeviceCanPlayback(long nativePtr, String device);
    @Override
    synchronized public boolean soundDeviceCanPlayback(@NonNull String device)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call soundDeviceCanPlayback() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return soundDeviceCanPlayback(nativePtr, device);
    }

    private native boolean soundResourcesLocked(long nativePtr);
    @Override
    synchronized public boolean soundResourcesLocked()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call soundResourcesLocked() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return soundResourcesLocked(nativePtr);
    }

    private native int start(long nativePtr);
    @Override
    synchronized public int start()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call start() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return start(nativePtr);
    }

    private native int startEchoCancellerCalibration(long nativePtr);
    @Override
    synchronized public int startEchoCancellerCalibration()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call startEchoCancellerCalibration() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return startEchoCancellerCalibration(nativePtr);
    }

    private native int startEchoTester(long nativePtr, int rate);
    @Override
    synchronized public int startEchoTester(int rate)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call startEchoTester() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return startEchoTester(nativePtr, rate);
    }

    private native void stop(long nativePtr);
    @Override
    synchronized public void stop()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stop() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        stop(nativePtr);
    }

    private native void stopAsync(long nativePtr);
    @Override
    synchronized public void stopAsync()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stopAsync() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        stopAsync(nativePtr);
    }

    private native void stopDtmf(long nativePtr);
    @Override
    synchronized public void stopDtmf()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stopDtmf() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        stopDtmf(nativePtr);
    }

    private native int stopEchoTester(long nativePtr);
    @Override
    synchronized public int stopEchoTester()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stopEchoTester() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return stopEchoTester(nativePtr);
    }

    private native void stopRinging(long nativePtr);
    @Override
    synchronized public void stopRinging()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stopRinging() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        stopRinging(nativePtr);
    }

    private native Event subscribe(long nativePtr, Address resource, String event, int expires, Content body);
    @Override @NonNull
    synchronized public Event subscribe(@NonNull Address resource, @NonNull String event, int expires, @Nullable Content body)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call subscribe() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Event)subscribe(nativePtr, resource, event, expires, body);
    }

    private native int takePreviewSnapshot(long nativePtr, String file);
    @Override
    synchronized public int takePreviewSnapshot(@NonNull String file)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call takePreviewSnapshot() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return takePreviewSnapshot(nativePtr, file);
    }

    private native int terminateAllCalls(long nativePtr);
    @Override
    synchronized public int terminateAllCalls()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call terminateAllCalls() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return terminateAllCalls(nativePtr);
    }

    private native int terminateConference(long nativePtr);
    @Override
    synchronized public int terminateConference()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call terminateConference() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return terminateConference(nativePtr);
    }

    private native void uploadLogCollection(long nativePtr);
    @Override
    synchronized public void uploadLogCollection()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call uploadLogCollection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        uploadLogCollection(nativePtr);
    }

    private native void usePreviewWindow(long nativePtr, boolean yesno);
    @Override
    synchronized public void usePreviewWindow(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call usePreviewWindow() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        usePreviewWindow(nativePtr, yesno);
    }

    private native void verifyServerCertificates(long nativePtr, boolean yesno);
    @Override
    synchronized public void verifyServerCertificates(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call verifyServerCertificates() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        verifyServerCertificates(nativePtr, yesno);
    }

    private native void verifyServerCn(long nativePtr, boolean yesno);
    @Override
    synchronized public void verifyServerCn(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call verifyServerCn() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        verifyServerCn(nativePtr, yesno);
    }

    private native boolean videoSupported(long nativePtr);
    @Override
    synchronized public boolean videoSupported()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call videoSupported() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return videoSupported(nativePtr);
    }

    private native String compressLogCollection(long nativePtr);
    @Override @NonNull
    synchronized public String compressLogCollection()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call compressLogCollection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return compressLogCollection(nativePtr);
    }

    private native void enableLogCollection(long nativePtr, int state);
    @Override
    synchronized public void enableLogCollection(LogCollectionState state)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enableLogCollection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        enableLogCollection(nativePtr, state.toInt());
    }

    private native int getLogCollectionMaxFileSize(long nativePtr);
    @Override @NonNull
    synchronized public int getLogCollectionMaxFileSize()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLogCollectionMaxFileSize() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLogCollectionMaxFileSize(nativePtr);
    }

    private native String getLogCollectionPath(long nativePtr);
    @Override @NonNull
    synchronized public String getLogCollectionPath()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLogCollectionPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLogCollectionPath(nativePtr);
    }

    private native String getLogCollectionPrefix(long nativePtr);
    @Override @NonNull
    synchronized public String getLogCollectionPrefix()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLogCollectionPrefix() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLogCollectionPrefix(nativePtr);
    }

    private native boolean getPostQuantumAvailable(long nativePtr);
    @Override
    synchronized public boolean getPostQuantumAvailable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPostQuantumAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getPostQuantumAvailable(nativePtr);
    }

    private native String getVersion(long nativePtr);
    @Override @NonNull
    synchronized public String getVersion()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getVersion() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getVersion(nativePtr);
    }

    private native int logCollectionEnabled(long nativePtr);
    @Override
    synchronized public LogCollectionState logCollectionEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call logCollectionEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return LogCollectionState.fromInt(logCollectionEnabled(nativePtr));
    }

    private native void resetLogCollection(long nativePtr);
    @Override
    synchronized public void resetLogCollection()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call resetLogCollection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        resetLogCollection(nativePtr);
    }

    private native void serializeLogs(long nativePtr);
    @Override
    synchronized public void serializeLogs()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call serializeLogs() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        serializeLogs(nativePtr);
    }

    private native void setLogCollectionMaxFileSize(long nativePtr, int size);
    @Override
    synchronized public void setLogCollectionMaxFileSize(int size)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLogCollectionMaxFileSize() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLogCollectionMaxFileSize(nativePtr, size);
    }

    private native void setLogCollectionPath(long nativePtr, String path);
    @Override
    synchronized public void setLogCollectionPath(@NonNull String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLogCollectionPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLogCollectionPath(nativePtr, path);
    }

    private native void setLogCollectionPrefix(long nativePtr, String prefix);
    @Override
    synchronized public void setLogCollectionPrefix(@NonNull String prefix)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLogCollectionPrefix() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLogCollectionPrefix(nativePtr, prefix);
    }

    private native boolean tunnelAvailable(long nativePtr);
    @Override
    synchronized public boolean tunnelAvailable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call tunnelAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return tunnelAvailable(nativePtr);
    }

    private native boolean upnpAvailable(long nativePtr);
    @Override
    synchronized public boolean upnpAvailable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call upnpAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return upnpAvailable(nativePtr);
    }

    private native boolean vcardSupported(long nativePtr);
    @Override
    synchronized public boolean vcardSupported()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call vcardSupported() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return vcardSupported(nativePtr);
    }

    private native void addListener(long nativePtr, CoreListener listener);
    @Override
    synchronized public void addListener(CoreListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, CoreListener listener);
    @Override
    synchronized public void removeListener(CoreListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native org.linphone.mediastream.Factory getMediastreamerFactory(long nativePtr);
    public org.linphone.mediastream.Factory getMediastreamerFactory() {
        return getMediastreamerFactory(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
