/*
EventLog.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that represents an event that must be stored in database. <br/>
* <br/>
* For example, all chat related events are wrapped in an {@link EventLog}, and<br/>
* many callbacks use this kind of type as parameter.<br/>
* Use {@link #getType} to get the {@link Type} it refers to, and then you can use<br/>
* one of the accessor methods to get the underlying object, for example {@link #getChatMessage}<br/>
* for a {@link ChatMessage}. <br/>
*/
public interface EventLog {
    public enum SecurityEventType {
        /**
        * Event is not a security event. <br/>
        * <br/>
        */
        None(0),

        /**
        * Chatroom security level downgraded event. <br/>
        * <br/>
        */
        SecurityLevelDowngraded(1),

        /**
        * Participant has exceeded the maximum number of device event. <br/>
        * <br/>
        */
        ParticipantMaxDeviceCountExceeded(2),

        /**
        * Peer device instant messaging encryption identity key has changed event. <br/>
        * <br/>
        */
        EncryptionIdentityKeyChanged(3),

        /**
        * Man in the middle detected event. <br/>
        * <br/>
        */
        ManInTheMiddleDetected(4);

        protected final int mValue;

        private SecurityEventType (int value) {
            mValue = value;
        }

        static public SecurityEventType fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1: return SecurityLevelDowngraded;
            case 2: return ParticipantMaxDeviceCountExceeded;
            case 3: return EncryptionIdentityKeyChanged;
            case 4: return ManInTheMiddleDetected;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for SecurityEventType");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Type {
        /**
        * No defined event. <br/>
        * <br/>
        */
        None(0),

        /**
        * Conference (created) event. <br/>
        * <br/>
        */
        ConferenceCreated(1),

        /**
        * Conference (terminated) event. <br/>
        * <br/>
        */
        ConferenceTerminated(2),

        /**
        * Conference call (start) event. <br/>
        * <br/>
        */
        ConferenceCallStarted(3),

        /**
        * Conference call (connected) event. <br/>
        * <br/>
        */
        ConferenceConnected(21),

        /**
        * Conference call (end) event. <br/>
        * <br/>
        */
        ConferenceCallEnded(4),

        /**
        * Conference chat message event. <br/>
        * <br/>
        */
        ConferenceChatMessage(5),

        /**
        * Conference allowed participant changed event. <br/>
        * <br/>
        */
        ConferenceAllowedParticipantListChanged(28),

        /**
        * Conference participant (added) event. <br/>
        * <br/>
        */
        ConferenceParticipantAdded(6),

        /**
        * Conference participant (removed) event. <br/>
        * <br/>
        */
        ConferenceParticipantRemoved(7),

        /**
        * Conference participant (role unknown) event. <br/>
        * <br/>
        */
        ConferenceParticipantRoleUnknown(25),

        /**
        * Conference participant (role speaker) event. <br/>
        * <br/>
        */
        ConferenceParticipantRoleSpeaker(26),

        /**
        * Conference participant (role listener) event. <br/>
        * <br/>
        */
        ConferenceParticipantRoleListener(27),

        /**
        * Conference participant (set admin) event. <br/>
        * <br/>
        */
        ConferenceParticipantSetAdmin(8),

        /**
        * Conference participant (unset admin) event. <br/>
        * <br/>
        */
        ConferenceParticipantUnsetAdmin(9),

        /**
        * Conference participant device (added) event. <br/>
        * <br/>
        */
        ConferenceParticipantDeviceAdded(10),

        /**
        * Conference participant device (removed) event. <br/>
        * <br/>
        */
        ConferenceParticipantDeviceRemoved(11),

        /**
        * Conference participant device (joining request) event. <br/>
        * <br/>
        */
        ConferenceParticipantDeviceJoiningRequest(29),

        /**
        * Conference participant device (media capability changed) event. <br/>
        * <br/>
        */
        ConferenceParticipantDeviceMediaCapabilityChanged(17),

        /**
        * Conference participant device (media availability changed) event. <br/>
        * <br/>
        */
        ConferenceParticipantDeviceMediaAvailabilityChanged(23),

        /**
        * Conference participant device (left) event. <br/>
        * <br/>
        */
        ConferenceParticipantDeviceStatusChanged(22),

        /**
        * Conference subject event. <br/>
        * <br/>
        */
        ConferenceSubjectChanged(12),

        /**
        * Conference available media event. <br/>
        * <br/>
        */
        ConferenceAvailableMediaChanged(18),

        /**
        * Conference encryption security event. <br/>
        * <br/>
        */
        ConferenceSecurityEvent(13),

        /**
        * Conference ephemeral message (ephemeral message lifetime changed) event. <br/>
        * <br/>
        */
        ConferenceEphemeralMessageLifetimeChanged(14),

        /**
        * Conference ephemeral message (ephemeral message enabled) event. <br/>
        * <br/>
        */
        ConferenceEphemeralMessageEnabled(15),

        /**
        * Conference ephemeral message (ephemeral message disabled) event. <br/>
        * <br/>
        */
        ConferenceEphemeralMessageDisabled(16),

        /**
        * Conference ephemeral message (ephemeral message settings managed by admin)<br/>
        * event. <br/>
        * <br/>
        */
        ConferenceEphemeralMessageManagedByAdmin(19),

        /**
        * Conference ephemeral message (ephemeral message settings managed by<br/>
        * participants) event. <br/>
        * <br/>
        */
        ConferenceEphemeralMessageManagedByParticipants(20),

        /**
        * Reaction event to a chat message. <br/>
        * <br/>
        */
        ConferenceChatMessageReaction(24);

        protected final int mValue;

        private Type (int value) {
            mValue = value;
        }

        static public Type fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1: return ConferenceCreated;
            case 2: return ConferenceTerminated;
            case 3: return ConferenceCallStarted;
            case 21: return ConferenceConnected;
            case 4: return ConferenceCallEnded;
            case 5: return ConferenceChatMessage;
            case 28: return ConferenceAllowedParticipantListChanged;
            case 6: return ConferenceParticipantAdded;
            case 7: return ConferenceParticipantRemoved;
            case 25: return ConferenceParticipantRoleUnknown;
            case 26: return ConferenceParticipantRoleSpeaker;
            case 27: return ConferenceParticipantRoleListener;
            case 8: return ConferenceParticipantSetAdmin;
            case 9: return ConferenceParticipantUnsetAdmin;
            case 10: return ConferenceParticipantDeviceAdded;
            case 11: return ConferenceParticipantDeviceRemoved;
            case 29: return ConferenceParticipantDeviceJoiningRequest;
            case 17: return ConferenceParticipantDeviceMediaCapabilityChanged;
            case 23: return ConferenceParticipantDeviceMediaAvailabilityChanged;
            case 22: return ConferenceParticipantDeviceStatusChanged;
            case 12: return ConferenceSubjectChanged;
            case 18: return ConferenceAvailableMediaChanged;
            case 13: return ConferenceSecurityEvent;
            case 14: return ConferenceEphemeralMessageLifetimeChanged;
            case 15: return ConferenceEphemeralMessageEnabled;
            case 16: return ConferenceEphemeralMessageDisabled;
            case 19: return ConferenceEphemeralMessageManagedByAdmin;
            case 20: return ConferenceEphemeralMessageManagedByParticipants;
            case 24: return ConferenceChatMessageReaction;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Type");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Returns the call log of a conference call event. <br/>
    * <br/>
    * @return The conference {@link CallLog}.   <br/>
    */
    @Nullable
    public CallLog getCallLog();

    /**
    * Returns the chat message of a conference chat message event. <br/>
    * <br/>
    * @return The conference {@link ChatMessage}.   <br/>
    */
    @Nullable
    public ChatMessage getChatMessage();

    /**
    * Returns the conference info of a conference call event. <br/>
    * <br/>
    * @return The conference {@link ConferenceInfo}.   <br/>
    */
    @Nullable
    public ConferenceInfo getConferenceInfo();

    /**
    * Returns the creation time of a event log. <br/>
    * <br/>
    * @return The event creation time <br/>
    */
    public long getCreationTime();

    /**
    * Returns the device address of a conference participant device event. <br/>
    * <br/>
    * @return The conference device {@link Address}.   <br/>
    */
    @Nullable
    public Address getDeviceAddress();

    /**
    * Returns the ephemeral message lifetime of a conference ephemeral message event. <br/>
    * <br/>
    * Ephemeral lifetime means the time before an ephemeral message which has been<br/>
    * viewed gets deleted. <br/>
    * @return The ephemeral message lifetime. <br/>
    */
    public long getEphemeralMessageLifetime();

    /**
    * Returns the local address of a conference event. <br/>
    * <br/>
    * @return The local {@link Address}.   <br/>
    */
    @Nullable
    public Address getLocalAddress();

    /**
    * Returns the notify id of a conference notified event. <br/>
    * <br/>
    * @return The conference notify id. <br/>
    */
    public int getNotifyId();

    /**
    * Returns the participant address of a conference participant event. <br/>
    * <br/>
    * @return The conference participant {@link Address}.   <br/>
    */
    @Nullable
    public Address getParticipantAddress();

    /**
    * Returns the peer address of a conference event. <br/>
    * <br/>
    * @return The peer {@link Address}.   <br/>
    */
    @Nullable
    public Address getPeerAddress();

    /**
    * Returns the faulty device address of a conference security event. <br/>
    * <br/>
    * @return The {@link Address} of the faulty device.   <br/>
    */
    @Nullable
    public Address getSecurityEventFaultyDeviceAddress();

    /**
    * Returns the type of security event. <br/>
    * <br/>
    * @return The {@link SecurityEventType} type. <br/>
    */
    public EventLog.SecurityEventType getSecurityEventType();

    /**
    * Returns the subject of a conference subject event. <br/>
    * <br/>
    * @return The conference subject.   <br/>
    */
    @Nullable
    public String getSubject();

    /**
    * Returns the type of a event log. <br/>
    * <br/>
    * @return The {@link Type} type <br/>
    */
    public EventLog.Type getType();

    /**
    * Delete event log from database. <br/>
    * <br/>
    */
    public void deleteFromDatabase();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class EventLogImpl implements EventLog {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected EventLogImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native CallLog getCallLog(long nativePtr);
    @Override @Nullable
    synchronized public CallLog getCallLog()  {
        
        
        return (CallLog)getCallLog(nativePtr);
    }

    private native ChatMessage getChatMessage(long nativePtr);
    @Override @Nullable
    synchronized public ChatMessage getChatMessage()  {
        
        
        return (ChatMessage)getChatMessage(nativePtr);
    }

    private native ConferenceInfo getConferenceInfo(long nativePtr);
    @Override @Nullable
    synchronized public ConferenceInfo getConferenceInfo()  {
        
        
        return (ConferenceInfo)getConferenceInfo(nativePtr);
    }

    private native long getCreationTime(long nativePtr);
    @Override
    synchronized public long getCreationTime()  {
        
        
        return getCreationTime(nativePtr);
    }

    private native Address getDeviceAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getDeviceAddress()  {
        
        
        return (Address)getDeviceAddress(nativePtr);
    }

    private native long getEphemeralMessageLifetime(long nativePtr);
    @Override
    synchronized public long getEphemeralMessageLifetime()  {
        
        
        return getEphemeralMessageLifetime(nativePtr);
    }

    private native Address getLocalAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getLocalAddress()  {
        
        
        return (Address)getLocalAddress(nativePtr);
    }

    private native int getNotifyId(long nativePtr);
    @Override
    synchronized public int getNotifyId()  {
        
        
        return getNotifyId(nativePtr);
    }

    private native Address getParticipantAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getParticipantAddress()  {
        
        
        return (Address)getParticipantAddress(nativePtr);
    }

    private native Address getPeerAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getPeerAddress()  {
        
        
        return (Address)getPeerAddress(nativePtr);
    }

    private native Address getSecurityEventFaultyDeviceAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getSecurityEventFaultyDeviceAddress()  {
        
        
        return (Address)getSecurityEventFaultyDeviceAddress(nativePtr);
    }

    private native int getSecurityEventType(long nativePtr);
    @Override
    synchronized public EventLog.SecurityEventType getSecurityEventType()  {
        
        
        return EventLog.SecurityEventType.fromInt(getSecurityEventType(nativePtr));
    }

    private native String getSubject(long nativePtr);
    @Override @Nullable
    synchronized public String getSubject()  {
        
        
        return getSubject(nativePtr);
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public EventLog.Type getType()  {
        
        
        return EventLog.Type.fromInt(getType(nativePtr));
    }

    private native void deleteFromDatabase(long nativePtr);
    @Override
    synchronized public void deleteFromDatabase()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call deleteFromDatabase() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        deleteFromDatabase(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
