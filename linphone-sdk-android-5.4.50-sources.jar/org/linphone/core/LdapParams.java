/*
LdapParams.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that is used to set the different parameters of a {@link Ldap}. <br/>
* <br/>
*/
public interface LdapParams {
    /**
    * Get the authentification method. <br/>
    * <br/>
    * Check {@link Ldap#AuthMethod} for authentification values.<br/>
    * @return The {@link Ldap#AuthMethod}. <br/>
    */
    public Ldap.AuthMethod getAuthMethod();

    /**
    * Authentification method. <br/>
    * <br/>
    * Check {@link Ldap#AuthMethod} for authentification values. Default value :<br/>
    * LinphoneLdapAuthMethodSimple<br/>
    * @param authMethod The {@link Ldap#AuthMethod}. <br/>
    */
    public void setAuthMethod(Ldap.AuthMethod authMethod);

    /**
    * Get the BaseObject. <br/>
    * <br/>
    * It is a specification for LDAP Search Scopes that specifies that the Search<br/>
    * Request should only be performed against the entry specified as the search base<br/>
    * DN. No entries above it will be considered. This field is required.<br/>
    * @return The specification.   <br/>
    */
    @NonNull
    public String getBaseObject();

    /**
    * BaseObject is a specification for LDAP Search Scopes that specifies that the<br/>
    * Search Request should only be performed against the entry specified as the<br/>
    * search base DN. <br/>
    * <br/>
    * No entries above it will be considered. This field is required. Default value :<br/>
    * "dc=example,dc=com"<br/>
    * @param baseObject The specification.   <br/>
    */
    public void setBaseObject(@NonNull String baseObject);

    /**
    * Get the Bind DN to use for bindings. <br/>
    * <br/>
    * The bindDN DN is the credential that is used to authenticate against an LDAP.<br/>
    * If empty, the connection will be Anonymous. eg:<br/>
    * cn=ausername,ou=people,dc=bc,dc=com<br/>
    * @return The Bind DN to use for bindings.   <br/>
    */
    @Nullable
    public String getBindDn();

    /**
    * Bind DN to use for bindings. <br/>
    * <br/>
    * The bindDN DN is the credential that is used to authenticate against an LDAP.<br/>
    * If empty, the connection will be Anonymous. eg:<br/>
    * cn=ausername,ou=people,dc=bc,dc=com Default value : "".<br/>
    * @param bindDn The Bind DN to use for bindings.   <br/>
    */
    public void setBindDn(@Nullable String bindDn);

    /**
    * Return the debug verbosity level. <br/>
    * <br/>
    * @return The {@link Ldap#DebugLevel} debug level. <br/>
    */
    public Ldap.DebugLevel getDebugLevel();

    /**
    * The debug verbosity level from internal LDAP API. <br/>
    * <br/>
    * Values are {@link Ldap#DebugLevel} Default value: LinphoneLdapDebugLevelOff<br/>
    * @param level The {@link Ldap#DebugLevel} debug level. <br/>
    */
    public void setDebugLevel(Ldap.DebugLevel level);

    /**
    * Get the delay between each search in milliseconds. <br/>
    * <br/>
    * @return The delay in milliseconds. <br/>
    */
    public int getDelay();

    /**
    * Delay between each search in milliseconds Default value : 500. <br/>
    * <br/>
    * @param delay The timeout in milliseconds. <br/>
    */
    public void setDelay(int delay);

    /**
    * Return if the configuration is enabled. <br/>
    * <br/>
    * @return Enable or not the LDAP configuration. <br/>
    */
    public boolean getEnabled();

    /**
    * If this config is enabled. <br/>
    * <br/>
    * Default value : false.<br/>
    * @param enable Enable or not the LDAP configuration. <br/>
    */
    public void setEnabled(boolean enable);

    /**
    * Get the search is based on this filter to search contacts. <br/>
    * <br/>
    * @return The filter to use.   <br/>
    */
    @Nullable
    public String getFilter();

    /**
    * The search is based on this filter to search contacts. <br/>
    * <br/>
    * Default value : "(sn=*%s*)".<br/>
    * @param filter The filter to use.   <br/>
    */
    public void setFilter(@Nullable String filter);

    /**
    * Get the max results when requesting searches. <br/>
    * <br/>
    * 0 means the results aren't limited (but magic search limitation may apply).<br/>
    * @return The max results when requesting searches. <br/>
    * @deprecated 18/11/2024 use {@link RemoteContactDirectory#getLimit} instead. <br/>
    */
    @Deprecated
    public int getMaxResults();

    /**
    * The max results when requesting searches. <br/>
    * <br/>
    * Default value : 5. This value fit for standard cases where only first results<br/>
    * are needed. Also, it avoids latency on each searchs. Set this value to 0 to<br/>
    * have an unlimited search (but magic search limitation may apply).<br/>
    * @param maxResults The max results when requesting searches. <br/>
    * @deprecated 18/11/2024 use {@link RemoteContactDirectory#setLimit} instead. <br/>
    */
    @Deprecated
    public void setMaxResults(int maxResults);

    /**
    * Get the minimum characters needed for doing a search on LDAP servers. <br/>
    * <br/>
    * @return The minimum characters needed by a search. <br/>
    * @deprecated 18/11/2024 use {@link RemoteContactDirectory#getMinCharacters}<br/>
    * instead. <br/>
    */
    @Deprecated
    public int getMinChars();

    /**
    * The minimum characters needed for doing a search on LDAP servers. <br/>
    * <br/>
    * Default value : 0.<br/>
    * @param minChars The minimum characters needed by a search. <br/>
    * @deprecated 18/11/2024 use {@link RemoteContactDirectory#setMinCharacters}<br/>
    * instead. <br/>
    */
    @Deprecated
    public void setMinChars(int minChars);

    /**
    * Get the list of LDAP attributes to check for the contact name, separated by a<br/>
    * comma and the first being the highest priority. <br/>
    * <br/>
    * @return The comma separated attributes for the search.   <br/>
    */
    @Nullable
    public String getNameAttribute();

    /**
    * List of LDAP attributes to check for the contact name, separated by a comma and<br/>
    * the first being the highest priority. <br/>
    * <br/>
    * Default value : "sn". <br/>
    * @param nameAttribute The comma separated attributes for the search.   <br/>
    */
    public void setNameAttribute(@Nullable String nameAttribute);

    /**
    * Get the password to pass to server when binding. <br/>
    * <br/>
    * @return The password to pass to server when binding.   <br/>
    */
    @Nullable
    public String getPassword();

    /**
    * The password to pass to server when binding. <br/>
    * <br/>
    * Default value : "".<br/>
    * @param password The password to pass to server when binding.   <br/>
    */
    public void setPassword(@Nullable String password);

    /**
    * Handle the DNS resolution using liblinphone's own resolver, which allows to use<br/>
    * DNS SRV records. <br/>
    * <br/>
    * @return whether liblinphone'own DNS resolver is used. <br/>
    */
    public boolean isSalEnabled();

    /**
    * Handle the DNS resolution using liblinphone's own resolver, which allows to use<br/>
    * DNS SRV records. <br/>
    * <br/>
    * Default value : true.<br/>
    * @param enable Enable or not the use of own DNS resolver. <br/>
    */
    public void setSalEnabled(boolean enable);

    /**
    * Get the LDAP Server. <br/>
    * <br/>
    * @return LDAP Server address.   <br/>
    * @deprecated 18/11/2024 use {@link RemoteContactDirectory#getServerUrl} instead. <br/>
    */
    @Deprecated
    @NonNull
    public String getServer();

    /**
    * LDAP Server. <br/>
    * <br/>
    * eg: ldap:/// for a localhost server or ldap://ldap.example.org/ Default value:<br/>
    * "ldap:///". This field is required.<br/>
    * You must use 'ldap' scheme. 'ldaps' for LDAP over SSL is non-standardized and<br/>
    * deprecated.<br/>
    * @param server LDAP Server address.   <br/>
    * @deprecated 18/11/2024 use {@link RemoteContactDirectory#setServerUrl} instead. <br/>
    */
    @Deprecated
    public void setServer(@NonNull String server);

    /**
    * Return whether the tls server certificate must be verified when connecting to a<br/>
    * LDAP server. <br/>
    * <br/>
    * @return The TLS verification mode from {@link Ldap#CertVerificationMode} <br/>
    */
    public Ldap.CertVerificationMode getServerCertificatesVerificationMode();

    /**
    * Specify whether the tls server certificate must be verified when connecting to<br/>
    * a LDAP server. <br/>
    * <br/>
    * Values are {@link Ldap#CertVerificationMode} Default value :<br/>
    * LinphoneLdapCertVerificationDefault (auto)<br/>
    * @param verifyServerCertificates The TLS verification mode from {@link Ldap#CertVerificationMode}<br/>
    */
    public void setServerCertificatesVerificationMode(Ldap.CertVerificationMode verifyServerCertificates);

    /**
    * Get the attributes to build the SIP username in address of Friend. <br/>
    * <br/>
    * Attributes are separated by a comma.<br/>
    * @return The comma separated attributes for building Friend.   <br/>
    */
    @Nullable
    public String getSipAttribute();

    /**
    * Check these attributes to build the SIP username in address of Friend. <br/>
    * <br/>
    * Attributes are separated by a comma. Default value :<br/>
    * "mobile,telephoneNumber,homePhone,sn".<br/>
    * @param sipAttribute The comma separated attributes for building Friend.   <br/>
    */
    public void setSipAttribute(@Nullable String sipAttribute);

    /**
    * Get the domain to the sip address(sip:username@domain). <br/>
    * <br/>
    * @return The SIP domain for the friend.   <br/>
    */
    @Nullable
    public String getSipDomain();

    /**
    * Add the domain to the sip address(sip:username@domain). <br/>
    * <br/>
    * By default or if it is empty, the domain will be specify while searching on the<br/>
    * current proxy account. Default value : "".<br/>
    * @param sipDomain The SIP domain for the friend.   <br/>
    */
    public void setSipDomain(@Nullable String sipDomain);

    /**
    * Get the timeout for requests in seconds. <br/>
    * <br/>
    * @return The timeout in seconds. <br/>
    * @deprecated 18/11/2024 use {@link RemoteContactDirectory#getTimeout} instead. <br/>
    */
    @Deprecated
    public int getTimeout();

    /**
    * Timeout for requests in seconds. <br/>
    * <br/>
    * It limits the time for searchs and the value is passed to Ldap with<br/>
    * LDAP_OPT_NETWORK_TIMEOUT. Default value : 5.<br/>
    * @param timeout The timeout in seconds. <br/>
    * @deprecated 18/11/2024 use {@link RemoteContactDirectory#setTimeout} instead. <br/>
    */
    @Deprecated
    public void setTimeout(int timeout);

    /**
    * Get the timeout for TLS connection in milliseconds. <br/>
    * <br/>
    * @return The timeout in milliseconds. <br/>
    */
    public int getTimeoutTlsMs();

    /**
    * Timeout for TLS connection in milliseconds. <br/>
    * <br/>
    * Default value : 1000.<br/>
    * @param timeout The timeout in milliseconds. <br/>
    */
    public void setTimeoutTlsMs(int timeout);

    /**
    * Return if transactions are encrypted by LDAP over TLS(StartTLS). <br/>
    * <br/>
    * You must use \'ldap\' scheme. \'ldaps\' for LDAP over SSL is non-standardized<br/>
    * and deprecated. StartTLS in an extension to the LDAP protocol which uses the<br/>
    * TLS protocol to encrypt communication. It works by establishing a normal - i.e.<br/>
    * unsecured - connection with the LDAP server before a handshake negotiation<br/>
    * between the server and the web services is carried out. Here, the server sends<br/>
    * its certificate to prove its identity before the secure connection is<br/>
    * established.<br/>
    * @return Enable or not the use of TLS. <br/>
    */
    public boolean isTlsEnabled();

    /**
    * Encrypt transactions by LDAP over TLS(StartTLS). <br/>
    * <br/>
    * You must use 'ldap' scheme. 'ldaps' for LDAP over SSL is non-standardized and<br/>
    * deprecated. StartTLS in an extension to the LDAP protocol which uses the TLS<br/>
    * protocol to encrypt communication. It works by establishing a normal - i.e.<br/>
    * unsecured - connection with the LDAP server before a handshake negotiation<br/>
    * between the server and the web services is carried out. Here, the server sends<br/>
    * its certificate to prove its identity before the secure connection is<br/>
    * established. Default value : true.<br/>
    * @param enable Enable or not the use of TLS. <br/>
    */
    public void setTlsEnabled(boolean enable);

    /**
    * Check parameters and return what are wrong. <br/>
    * <br/>
    * @return The {@link Ldap#Check} values. LinphoneLdapCheckOk if everything is ok. <br/>
    */
    public int check();

    /**
    * Instantiate a new {@link LdapParams} with values from source. <br/>
    * <br/>
    * @return The newly created {@link LdapParams} object.   <br/>
    */
    @NonNull
    public LdapParams clone();

    /**
    * Get the value from field. <br/>
    * <br/>
    * @param key The key string.   <br/>
    * @return The Value associated to the key.   <br/>
    */
    @Nullable
    public String getCustomValue(@NonNull String key);

    /**
    * Set custom field. <br/>
    * <br/>
    * @param key The key string.   <br/>
    * @param value The value string.   <br/>
    */
    public void setCustomValue(@NonNull String key, @Nullable String value);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class LdapParamsImpl implements LdapParams {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected LdapParamsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getAuthMethod(long nativePtr);
    @Override
    synchronized public Ldap.AuthMethod getAuthMethod()  {
        
        
        return Ldap.AuthMethod.fromInt(getAuthMethod(nativePtr));
    }

    private native void setAuthMethod(long nativePtr, int authMethod);
    @Override
    synchronized public void setAuthMethod(Ldap.AuthMethod authMethod)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAuthMethod() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAuthMethod(nativePtr, authMethod.toInt());
    }

    private native String getBaseObject(long nativePtr);
    @Override @NonNull
    synchronized public String getBaseObject()  {
        
        
        return getBaseObject(nativePtr);
    }

    private native void setBaseObject(long nativePtr, String baseObject);
    @Override
    synchronized public void setBaseObject(@NonNull String baseObject)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBaseObject() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBaseObject(nativePtr, baseObject);
    }

    private native String getBindDn(long nativePtr);
    @Override @Nullable
    synchronized public String getBindDn()  {
        
        
        return getBindDn(nativePtr);
    }

    private native void setBindDn(long nativePtr, String bindDn);
    @Override
    synchronized public void setBindDn(@Nullable String bindDn)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBindDn() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBindDn(nativePtr, bindDn);
    }

    private native int getDebugLevel(long nativePtr);
    @Override
    synchronized public Ldap.DebugLevel getDebugLevel()  {
        
        
        return Ldap.DebugLevel.fromInt(getDebugLevel(nativePtr));
    }

    private native void setDebugLevel(long nativePtr, int level);
    @Override
    synchronized public void setDebugLevel(Ldap.DebugLevel level)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDebugLevel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDebugLevel(nativePtr, level.toInt());
    }

    private native int getDelay(long nativePtr);
    @Override
    synchronized public int getDelay()  {
        
        
        return getDelay(nativePtr);
    }

    private native void setDelay(long nativePtr, int delay);
    @Override
    synchronized public void setDelay(int delay)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDelay() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDelay(nativePtr, delay);
    }

    private native boolean getEnabled(long nativePtr);
    @Override
    synchronized public boolean getEnabled()  {
        
        
        return getEnabled(nativePtr);
    }

    private native void setEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEnabled(nativePtr, enable);
    }

    private native String getFilter(long nativePtr);
    @Override @Nullable
    synchronized public String getFilter()  {
        
        
        return getFilter(nativePtr);
    }

    private native void setFilter(long nativePtr, String filter);
    @Override
    synchronized public void setFilter(@Nullable String filter)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFilter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFilter(nativePtr, filter);
    }

    private native int getMaxResults(long nativePtr);
    @Override
    synchronized public int getMaxResults()  {
        
        
        return getMaxResults(nativePtr);
    }

    private native void setMaxResults(long nativePtr, int maxResults);
    @Override
    synchronized public void setMaxResults(int maxResults)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMaxResults() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMaxResults(nativePtr, maxResults);
    }

    private native int getMinChars(long nativePtr);
    @Override
    synchronized public int getMinChars()  {
        
        
        return getMinChars(nativePtr);
    }

    private native void setMinChars(long nativePtr, int minChars);
    @Override
    synchronized public void setMinChars(int minChars)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMinChars() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMinChars(nativePtr, minChars);
    }

    private native String getNameAttribute(long nativePtr);
    @Override @Nullable
    synchronized public String getNameAttribute()  {
        
        
        return getNameAttribute(nativePtr);
    }

    private native void setNameAttribute(long nativePtr, String nameAttribute);
    @Override
    synchronized public void setNameAttribute(@Nullable String nameAttribute)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNameAttribute() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNameAttribute(nativePtr, nameAttribute);
    }

    private native String getPassword(long nativePtr);
    @Override @Nullable
    synchronized public String getPassword()  {
        
        
        return getPassword(nativePtr);
    }

    private native void setPassword(long nativePtr, String password);
    @Override
    synchronized public void setPassword(@Nullable String password)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPassword() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPassword(nativePtr, password);
    }

    private native boolean isSalEnabled(long nativePtr);
    @Override
    synchronized public boolean isSalEnabled()  {
        
        
        return isSalEnabled(nativePtr);
    }

    private native void setSalEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setSalEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSalEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSalEnabled(nativePtr, enable);
    }

    private native String getServer(long nativePtr);
    @Override @NonNull
    synchronized public String getServer()  {
        
        
        return getServer(nativePtr);
    }

    private native void setServer(long nativePtr, String server);
    @Override
    synchronized public void setServer(@NonNull String server)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setServer(nativePtr, server);
    }

    private native int getServerCertificatesVerificationMode(long nativePtr);
    @Override
    synchronized public Ldap.CertVerificationMode getServerCertificatesVerificationMode()  {
        
        
        return Ldap.CertVerificationMode.fromInt(getServerCertificatesVerificationMode(nativePtr));
    }

    private native void setServerCertificatesVerificationMode(long nativePtr, int verifyServerCertificates);
    @Override
    synchronized public void setServerCertificatesVerificationMode(Ldap.CertVerificationMode verifyServerCertificates)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setServerCertificatesVerificationMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setServerCertificatesVerificationMode(nativePtr, verifyServerCertificates.toInt());
    }

    private native String getSipAttribute(long nativePtr);
    @Override @Nullable
    synchronized public String getSipAttribute()  {
        
        
        return getSipAttribute(nativePtr);
    }

    private native void setSipAttribute(long nativePtr, String sipAttribute);
    @Override
    synchronized public void setSipAttribute(@Nullable String sipAttribute)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSipAttribute() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSipAttribute(nativePtr, sipAttribute);
    }

    private native String getSipDomain(long nativePtr);
    @Override @Nullable
    synchronized public String getSipDomain()  {
        
        
        return getSipDomain(nativePtr);
    }

    private native void setSipDomain(long nativePtr, String sipDomain);
    @Override
    synchronized public void setSipDomain(@Nullable String sipDomain)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSipDomain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSipDomain(nativePtr, sipDomain);
    }

    private native int getTimeout(long nativePtr);
    @Override
    synchronized public int getTimeout()  {
        
        
        return getTimeout(nativePtr);
    }

    private native void setTimeout(long nativePtr, int timeout);
    @Override
    synchronized public void setTimeout(int timeout)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTimeout(nativePtr, timeout);
    }

    private native int getTimeoutTlsMs(long nativePtr);
    @Override
    synchronized public int getTimeoutTlsMs()  {
        
        
        return getTimeoutTlsMs(nativePtr);
    }

    private native void setTimeoutTlsMs(long nativePtr, int timeout);
    @Override
    synchronized public void setTimeoutTlsMs(int timeout)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTimeoutTlsMs() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTimeoutTlsMs(nativePtr, timeout);
    }

    private native boolean isTlsEnabled(long nativePtr);
    @Override
    synchronized public boolean isTlsEnabled()  {
        
        
        return isTlsEnabled(nativePtr);
    }

    private native void setTlsEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setTlsEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsEnabled(nativePtr, enable);
    }

    private native int check(long nativePtr);
    @Override
    synchronized public int check()  {
        
        
        return check(nativePtr);
    }

    private native LdapParams clone(long nativePtr);
    @Override @NonNull
    synchronized public LdapParams clone()  {
        
        
        return (LdapParams)clone(nativePtr);
    }

    private native String getCustomValue(long nativePtr, String key);
    @Override @Nullable
    synchronized public String getCustomValue(@NonNull String key)  {
        
        
        return getCustomValue(nativePtr, key);
    }

    private native void setCustomValue(long nativePtr, String key, String value);
    @Override
    synchronized public void setCustomValue(@NonNull String key, @Nullable String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCustomValue() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCustomValue(nativePtr, key, value);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
