/*
SessionExpiresRefresher.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Session Timers refresher. <br/>
* <br/>
*/
public enum SessionExpiresRefresher {
    /**
    * <br/>
    */
    Unspecified(0),

    /**
    * <br/>
    */
    UAS(1),

    /**
    * <br/>
    */
    UAC(2);

    protected final int mValue;

    private SessionExpiresRefresher (int value) {
        mValue = value;
    }

    static public SessionExpiresRefresher fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Unspecified;
        case 1: return UAS;
        case 2: return UAC;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for SessionExpiresRefresher");
        }
    }
    
    static protected SessionExpiresRefresher[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        SessionExpiresRefresher[] enumArray = new SessionExpiresRefresher[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = SessionExpiresRefresher.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(SessionExpiresRefresher[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
