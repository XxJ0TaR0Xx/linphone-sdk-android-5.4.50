/*
ConferenceSchedulerListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Callbacks of {@link ConferenceScheduler} object. <br/>
* <br/>
*/
public interface ConferenceSchedulerListener {
    /**
    * Callback for notifying when a registration state has changed for the conference<br/>
    * scheduler. <br/>
    * <br/>
    * @param conferenceScheduler LinphoneConferenceScheduler object whose state has<br/>
    * changed.   <br/>
    * @param state The current LinphoneConferenceSchedulerState. <br/>
    */
    public void onStateChanged(@NonNull ConferenceScheduler conferenceScheduler, ConferenceScheduler.State state);

    /**
    * Callback for notifying when conference invitations have been sent. <br/>
    * <br/>
    * In case of error for some participants, their addresses will be given as<br/>
    * parameter. <br/>
    * @param conferenceScheduler {@link ConferenceScheduler} object whose state has<br/>
    * changed.   <br/>
    * @param failedInvitations a list of addresses for which invitation couldn't be<br/>
    * sent.     <br/>
    */
    public void onInvitationsSent(@NonNull ConferenceScheduler conferenceScheduler, @Nullable Address[] failedInvitations);

}