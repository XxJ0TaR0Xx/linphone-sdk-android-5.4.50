/*
Content.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* This object holds data that can be embedded in a signaling message or IM<br/>
* message. <br/>
* <br/>
* Use {@link Core#createContent} to create it, and then you should set at least<br/>
* it's type and subtype and fill the buffer with your data.<br/>
* A {@link Content} can be multipart (contain other contents), have file<br/>
* information (name, path, size), be encrypted, have custom headers, etc... <br/>
*/
public interface Content {
    /**
    * Get the content data buffer, usually a string. <br/>
    * <br/>
    * @return The content data buffer.   <br/>
    */
    @NonNull
    public byte[] getBuffer();

    /**
    * Returns the creation timestamp if this content is a FileContent (received or<br/>
    * sent by chat). <br/>
    * <br/>
    * @return The timestamp at which this content was created if available, -1<br/>
    * otherwise. <br/>
    */
    public long getCreationTimestamp();

    /**
    * Get the disposition of the Content, for example "recipient-list". <br/>
    * <br/>
    * @return The disposition of the Content.   <br/>
    */
    @Nullable
    public String getDisposition();

    /**
    * Set the disposition of the Content, for example "recipient-list". <br/>
    * <br/>
    * @param disposition The disposition of the Content.   <br/>
    */
    public void setDisposition(@Nullable String disposition);

    /**
    * Get the encoding of the data buffer, for example "gzip". <br/>
    * <br/>
    * @return The encoding of the data buffer.   <br/>
    */
    @Nullable
    public String getEncoding();

    /**
    * Set the encoding of the data buffer, for example "gzip". <br/>
    * <br/>
    * @param encoding The encoding of the data buffer.   <br/>
    */
    public void setEncoding(@Nullable String encoding);

    /**
    * Gets the file duration in seconds, if information is available. <br/>
    * <br/>
    * @return The duration of the file in milliseconds or -1 if information isn't<br/>
    * available. <br/>
    */
    public int getFileDuration();

    /**
    * Get the file transfer filepath set for this content (replace<br/>
    * linphone_chat_message_get_file_transfer_filepath). <br/>
    * <br/>
    * @return The file path set for this content if it has been set, null otherwise. <br/>
    *  <br/>
    */
    @Nullable
    public String getFilePath();

    /**
    * Set the file transfer filepath for this content (replace<br/>
    * linphone_chat_message_set_file_transfer_filepath). <br/>
    * <br/>
    * @param filePath the file transfer filepath.   <br/>
    */
    public void setFilePath(@Nullable String filePath);

    /**
    * Get the file size if content is either a FileContent or a FileTransferContent. <br/>
    * <br/>
    * @return The represented file size. <br/>
    */
    public int getFileSize();

    /**
    * Tells whether or not this content contains a file. <br/>
    * <br/>
    * @return true if this content contains a file, false otherwise. <br/>
    */
    public boolean isFile();

    /**
    * Tells whether or not this content contains an encrypted file. <br/>
    * <br/>
    * @return True is this content contains a file and this file is encrypted, false<br/>
    * otherwise. <br/>
    */
    public boolean isFileEncrypted();

    /**
    * Tells whether or not this content is a file transfer. <br/>
    * <br/>
    * @return true if this content is a file transfer, false otherwise. <br/>
    */
    public boolean isFileTransfer();

    /**
    * Tells whether or not this content contains an icalendar by checking it's<br/>
    * content type. <br/>
    * <br/>
    * @return true if this content type is 'text/calendar;conference-event=yes',<br/>
    * false otherwise. <br/>
    */
    public boolean isIcalendar();

    /**
    * Tell whether a content is a multipart content. <br/>
    * <br/>
    * @return A boolean value telling whether the content is multipart or not. <br/>
    */
    public boolean isMultipart();

    /**
    * Tells whether or not this content contains text. <br/>
    * <br/>
    * @return true if this content contains plain text, false otherwise. <br/>
    */
    public boolean isText();

    /**
    * Tells whether or not this content contains a voice recording by checking it's<br/>
    * content type. <br/>
    * <br/>
    * @return true if this content type is 'audio/wav;voice-recording=yes', false<br/>
    * otherwise. <br/>
    */
    public boolean isVoiceRecording();

    /**
    * Get the key associated with a RCS file transfer message if encrypted. <br/>
    * <br/>
    * @return The key to encrypt/decrypt the file associated to this content.   <br/>
    */
    @Nullable
    public String getKey();

    /**
    * Get the size of key associated with a RCS file transfer message if encrypted. <br/>
    * <br/>
    * @return The key size in bytes <br/>
    */
    public int getKeySize();

    /**
    * Get the name associated with a RCS file transfer message. <br/>
    * <br/>
    * It is used to store the original filename of the file to be downloaded from<br/>
    * server. <br/>
    * @return The name of the content.   <br/>
    */
    @Nullable
    public String getName();

    /**
    * Set the name associated with a RCS file transfer message. <br/>
    * <br/>
    * It is used to store the original filename of the file to be downloaded from<br/>
    * server. <br/>
    * @param name The name of the content.   <br/>
    */
    public void setName(@Nullable String name);

    /**
    * Get all the parts from a multipart content. <br/>
    * <br/>
    * @return A  object holding the part if found, null otherwise.     <br/>
    */
    @NonNull
    public Content[] getParts();

    /**
    * Generates a temporary plain copy of the file and returns its paths The caller<br/>
    * is responsible to then delete this temporary copy and the returned string. <br/>
    * <br/>
    * @return The file path set for this content if it has been set, null otherwise. <br/>
    *  <br/>
    * @deprecated 2022-01-07. Use {@link #exportPlainFile} instead. <br/>
    */
    @Deprecated
    public String getPlainFilePath();

    /**
    * Returns the chat message id for which this content is related to, if any. <br/>
    * <br/>
    * @return The chat message ID if this content is related to a chat message, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public String getRelatedChatMessageId();

    /**
    * Get the content data buffer size, excluding null character despite null<br/>
    * character is always set for convenience. <br/>
    * <br/>
    * @return The content data buffer size. <br/>
    */
    public int getSize();

    /**
    * Set the content data size, excluding null character despite null character is<br/>
    * always set for convenience. <br/>
    * <br/>
    * @param size The content data buffer size. <br/>
    */
    public void setSize(int size);

    /**
    * Get the string content data buffer. <br/>
    * <br/>
    * @return The string content data buffer.   <br/>
    * @deprecated 2020-07-01. Use {@link #getUtf8Text} instead. <br/>
    */
    @Deprecated
    @NonNull
    public String getStringBuffer();

    /**
    * Set the string content data buffer. <br/>
    * <br/>
    * @param buffer The string content data buffer in UTF8.   <br/>
    * @deprecated 2020-07-01. Use {@link #setUtf8Text} instead. <br/>
    */
    @Deprecated
    public void setStringBuffer(@NonNull String buffer);

    /**
    * Get the mime subtype of the content data. <br/>
    * <br/>
    * @return The mime subtype of the content data, for example "html".   <br/>
    */
    @NonNull
    public String getSubtype();

    /**
    * Set the mime subtype of the content data. <br/>
    * <br/>
    * @param subtype The mime subtype of the content data, for example "html".   <br/>
    */
    public void setSubtype(@NonNull String subtype);

    /**
    * Get the mime type of the content data. <br/>
    * <br/>
    * @return The mime type of the content data, for example "application".   <br/>
    */
    @NonNull
    public String getType();

    /**
    * Set the mime type of the content data. <br/>
    * <br/>
    * @param type The mime type of the content data, for example "application".   <br/>
    */
    public void setType(@NonNull String type);

    /**
    * Get the string content data buffer. <br/>
    * <br/>
    * Introduced in 01/07/2020 <br/>
    * @return The string content data buffer in UTF8.   <br/>
    */
    @Nullable
    public String getUtf8Text();

    /**
    * Get the string content data buffer. <br/>
    * <br/>
    * Introduced in 01/07/2020 <br/>
    * @param buffer The string content data buffer in UTF8.   <br/>
    */
    public void setUtf8Text(@Nullable String buffer);

    /**
    * Adds a parameter to the ContentType header. <br/>
    * <br/>
    * @param name the name of the parameter to add.   <br/>
    * @param value the value of the parameter to add.   <br/>
    */
    public void addContentTypeParameter(@NonNull String name, @Nullable String value);

    /**
    * Adds a custom header in a content. <br/>
    * <br/>
    * @param headerName The name of the header to add.   <br/>
    * @param headerValue The value of the header to add.   <br/>
    */
    public void addCustomHeader(@NonNull String headerName, @NonNull String headerValue);

    /**
    * Generates a temporary plain copy of the file and returns its paths The caller<br/>
    * is responsible to then delete this temporary copy and the returned string. <br/>
    * <br/>
    * @return The file path set for this content if it has been set, null otherwise. <br/>
    *  <br/>
    */
    public String exportPlainFile();

    /**
    * Find a part from a multipart content looking for a part header with a specified<br/>
    * value. <br/>
    * <br/>
    * @param headerName The name of the header to look for.   <br/>
    * @param headerValue The value of the header to look for.   <br/>
    * @return A {@link Content} object object the part if found, null otherwise.   <br/>
    */
    @Nullable
    public Content findPartByHeader(@NonNull String headerName, @NonNull String headerValue);

    /**
    * Get a custom header value of a content. <br/>
    * <br/>
    * @param headerName The name of the header to get the value from.   <br/>
    * @return The value of the header if found, null otherwise.   <br/>
    */
    @Nullable
    public String getCustomHeader(@NonNull String headerName);

    /**
    * Get a part from a multipart content according to its index. <br/>
    * <br/>
    * @param index The index of the part to get. <br/>
    * @return A {@link Content} object holding the part if found, null otherwise.   <br/>
    */
    @Nullable
    public Content getPart(int index);

    /**
    * Set the content data buffer, usually a string. <br/>
    * <br/>
    * @param buffer The content data buffer.   <br/>
    * @param size The size of the content data buffer. <br/>
    */
    public void setBuffer(@NonNull byte[] buffer, int size);

    /**
    * Set the key associated with a RCS file transfer message if encrypted. <br/>
    * <br/>
    * @param key The key to be used to encrypt/decrypt file associated to this<br/>
    * content.   <br/>
    * @param keyLength The lengh of the key. <br/>
    */
    public void setKey(@NonNull String key, int keyLength);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ContentImpl implements Content {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ContentImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native byte[] getBuffer(long nativePtr);
    @Override @NonNull
    synchronized public byte[] getBuffer()  {
        
        
        return getBuffer(nativePtr);
    }

    private native long getCreationTimestamp(long nativePtr);
    @Override
    synchronized public long getCreationTimestamp()  {
        
        
        return getCreationTimestamp(nativePtr);
    }

    private native String getDisposition(long nativePtr);
    @Override @Nullable
    synchronized public String getDisposition()  {
        
        
        return getDisposition(nativePtr);
    }

    private native void setDisposition(long nativePtr, String disposition);
    @Override
    synchronized public void setDisposition(@Nullable String disposition)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDisposition() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDisposition(nativePtr, disposition);
    }

    private native String getEncoding(long nativePtr);
    @Override @Nullable
    synchronized public String getEncoding()  {
        
        
        return getEncoding(nativePtr);
    }

    private native void setEncoding(long nativePtr, String encoding);
    @Override
    synchronized public void setEncoding(@Nullable String encoding)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEncoding() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEncoding(nativePtr, encoding);
    }

    private native int getFileDuration(long nativePtr);
    @Override
    synchronized public int getFileDuration()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getFileDuration() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getFileDuration(nativePtr);
    }

    private native String getFilePath(long nativePtr);
    @Override @Nullable
    synchronized public String getFilePath()  {
        
        
        return getFilePath(nativePtr);
    }

    private native void setFilePath(long nativePtr, String filePath);
    @Override
    synchronized public void setFilePath(@Nullable String filePath)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFilePath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFilePath(nativePtr, filePath);
    }

    private native int getFileSize(long nativePtr);
    @Override
    synchronized public int getFileSize()  {
        
        
        return getFileSize(nativePtr);
    }

    private native boolean isFile(long nativePtr);
    @Override
    synchronized public boolean isFile()  {
        
        
        return isFile(nativePtr);
    }

    private native boolean isFileEncrypted(long nativePtr);
    @Override
    synchronized public boolean isFileEncrypted()  {
        
        
        return isFileEncrypted(nativePtr);
    }

    private native boolean isFileTransfer(long nativePtr);
    @Override
    synchronized public boolean isFileTransfer()  {
        
        
        return isFileTransfer(nativePtr);
    }

    private native boolean isIcalendar(long nativePtr);
    @Override
    synchronized public boolean isIcalendar()  {
        
        
        return isIcalendar(nativePtr);
    }

    private native boolean isMultipart(long nativePtr);
    @Override
    synchronized public boolean isMultipart()  {
        
        
        return isMultipart(nativePtr);
    }

    private native boolean isText(long nativePtr);
    @Override
    synchronized public boolean isText()  {
        
        
        return isText(nativePtr);
    }

    private native boolean isVoiceRecording(long nativePtr);
    @Override
    synchronized public boolean isVoiceRecording()  {
        
        
        return isVoiceRecording(nativePtr);
    }

    private native String getKey(long nativePtr);
    @Override @Nullable
    synchronized public String getKey()  {
        
        
        return getKey(nativePtr);
    }

    private native int getKeySize(long nativePtr);
    @Override
    synchronized public int getKeySize()  {
        
        
        return getKeySize(nativePtr);
    }

    private native String getName(long nativePtr);
    @Override @Nullable
    synchronized public String getName()  {
        
        
        return getName(nativePtr);
    }

    private native void setName(long nativePtr, String name);
    @Override
    synchronized public void setName(@Nullable String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setName(nativePtr, name);
    }

    private native Content[] getParts(long nativePtr);
    @Override @NonNull
    synchronized public Content[] getParts()  {
        
        
        return getParts(nativePtr);
    }

    private native String getPlainFilePath(long nativePtr);
    @Override
    synchronized public String getPlainFilePath()  {
        
        
        return getPlainFilePath(nativePtr);
    }

    private native String getRelatedChatMessageId(long nativePtr);
    @Override @Nullable
    synchronized public String getRelatedChatMessageId()  {
        
        
        return getRelatedChatMessageId(nativePtr);
    }

    private native int getSize(long nativePtr);
    @Override
    synchronized public int getSize()  {
        
        
        return getSize(nativePtr);
    }

    private native void setSize(long nativePtr, int size);
    @Override
    synchronized public void setSize(int size)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSize() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSize(nativePtr, size);
    }

    private native String getStringBuffer(long nativePtr);
    @Override @NonNull
    synchronized public String getStringBuffer()  {
        
        
        return getStringBuffer(nativePtr);
    }

    private native void setStringBuffer(long nativePtr, String buffer);
    @Override
    synchronized public void setStringBuffer(@NonNull String buffer)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStringBuffer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStringBuffer(nativePtr, buffer);
    }

    private native String getSubtype(long nativePtr);
    @Override @NonNull
    synchronized public String getSubtype()  {
        
        
        return getSubtype(nativePtr);
    }

    private native void setSubtype(long nativePtr, String subtype);
    @Override
    synchronized public void setSubtype(@NonNull String subtype)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubtype() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubtype(nativePtr, subtype);
    }

    private native String getType(long nativePtr);
    @Override @NonNull
    synchronized public String getType()  {
        
        
        return getType(nativePtr);
    }

    private native void setType(long nativePtr, String type);
    @Override
    synchronized public void setType(@NonNull String type)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setType(nativePtr, type);
    }

    private native String getUtf8Text(long nativePtr);
    @Override @Nullable
    synchronized public String getUtf8Text()  {
        
        
        return getUtf8Text(nativePtr);
    }

    private native void setUtf8Text(long nativePtr, String buffer);
    @Override
    synchronized public void setUtf8Text(@Nullable String buffer)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUtf8Text() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUtf8Text(nativePtr, buffer);
    }

    private native void addContentTypeParameter(long nativePtr, String name, String value);
    @Override
    synchronized public void addContentTypeParameter(@NonNull String name, @Nullable String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addContentTypeParameter() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addContentTypeParameter(nativePtr, name, value);
    }

    private native void addCustomHeader(long nativePtr, String headerName, String headerValue);
    @Override
    synchronized public void addCustomHeader(@NonNull String headerName, @NonNull String headerValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomHeader(nativePtr, headerName, headerValue);
    }

    private native String exportPlainFile(long nativePtr);
    @Override
    synchronized public String exportPlainFile()  {
        
        
        return exportPlainFile(nativePtr);
    }

    private native Content findPartByHeader(long nativePtr, String headerName, String headerValue);
    @Override @Nullable
    synchronized public Content findPartByHeader(@NonNull String headerName, @NonNull String headerValue)  {
        
        
        return (Content)findPartByHeader(nativePtr, headerName, headerValue);
    }

    private native String getCustomHeader(long nativePtr, String headerName);
    @Override @Nullable
    synchronized public String getCustomHeader(@NonNull String headerName)  {
        
        
        return getCustomHeader(nativePtr, headerName);
    }

    private native Content getPart(long nativePtr, int index);
    @Override @Nullable
    synchronized public Content getPart(int index)  {
        
        
        return (Content)getPart(nativePtr, index);
    }

    private native void setBuffer(long nativePtr, byte[] buffer, int size);
    @Override
    synchronized public void setBuffer(@NonNull byte[] buffer, int size)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBuffer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBuffer(nativePtr, buffer, size);
    }

    private native void setKey(long nativePtr, String key, int keyLength);
    @Override
    synchronized public void setKey(@NonNull String key, int keyLength)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setKey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setKey(nativePtr, key, keyLength);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
