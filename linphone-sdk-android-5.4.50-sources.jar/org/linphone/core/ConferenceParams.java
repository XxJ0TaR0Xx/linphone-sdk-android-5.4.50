/*
ConferenceParams.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object defining parameters for a {@link Conference}. <br/>
* <br/>
* Can be created by calling function {@link Core#createConferenceParams}. <br/>
*/
public interface ConferenceParams {
    /**
    * Returns the account for the conference. <br/>
    * <br/>
    * @return a pointer to the account or null if it is not set.   <br/>
    */
    @Nullable
    public Account getAccount();

    /**
    * Sets the account for the conference. <br/>
    * <br/>
    * @param account a pointer to the account.   <br/>
    * warning: The account can only be changed upon creation of a conference when<br/>
    * calling linphone_core_create_conference_with_params <br/>
    */
    public void setAccount(@Nullable Account account);

    /**
    * Check whether audio capabilities are enabled. <br/>
    * <br/>
    * @return true if the conference supports audio capabilities, false otherwise <br/>
    */
    public boolean isAudioEnabled();

    /**
    * Enable audio capabilities. <br/>
    * <br/>
    * @param enable If true, audio will be enabled during conference <br/>
    */
    public void setAudioEnabled(boolean enable);

    /**
    * Check whether chat capabilities are enabled. <br/>
    * <br/>
    * @return true if the conference supports chat capabilities, false otherwise <br/>
    */
    public boolean isChatEnabled();

    /**
    * Enable chat capabilities. <br/>
    * <br/>
    * @param enable If true, chat is enabled during conference <br/>
    */
    public void setChatEnabled(boolean enable);

    /**
    * Get the chat parameters. <br/>
    * <br/>
    * @return the chat parameters if chat capabilities are on, null otherwise   <br/>
    */
    @Nullable
    public ChatParams getChatParams();

    /**
    * Get the conference factory address of the conference that has been set. <br/>
    * <br/>
    * @return the factory address conference description.   <br/>
    */
    @Nullable
    public Address getConferenceFactoryAddress();

    /**
    * Set the conference factory address of the conference. <br/>
    * <br/>
    * By default when creating a new conference, the factory address will come from<br/>
    * the current proxy configuration. If null then the conference will be local else<br/>
    * it will be a client conference. <br/>
    * @param address the conference factory address.   <br/>
    */
    public void setConferenceFactoryAddress(@Nullable Address address);

    /**
    * Get conference description (utf8). <br/>
    * <br/>
    * @return the conference description.   <br/>
    */
    @Nullable
    public String getDescriptionUtf8();

    /**
    * Set the description of the conference (utf8) <br/>
    * <br/>
    * @param description the conference description.   <br/>
    */
    public void setDescriptionUtf8(@Nullable String description);

    /**
    * Get the group chat status of the text capabilities of the conference associated<br/>
    * with the given parameters. <br/>
    * <br/>
    * @return true if group chat is enabled, false if one-to-one <br/>
    */
    public boolean isGroupEnabled();

    /**
    * Enables or disables group chat for the text capabilities of the conference<br/>
    * associated with the given parameters. <br/>
    * <br/>
    * @param group true to enable group chat, false to disable (resulting in<br/>
    * one-to-one text capabilities of the conference) <br/>
    */
    public void setGroupEnabled(boolean group);

    /**
    * Set the conference as hidden. <br/>
    * <br/>
    * This means that the contact address will not have any conference releated<br/>
    * attribute such as isfocus, the conference ID and the admin status. <br/>
    * @param hidden Boolean that states whether the conference is hidden or not <br/>
    */
    public void setHidden(boolean hidden);

    /**
    * Get the value of the hidden flag. <br/>
    * <br/>
    * @return whether the conference is hidden or not <br/>
    */
    public boolean isHidden();

    /**
    * Returns whether the given parameters are valid or not. <br/>
    * <br/>
    * @return true if the given parameters are valid, false otherwise <br/>
    */
    public boolean isValid();

    /**
    * Returns whether local participant has to enter the conference. <br/>
    * <br/>
    * @return true if local participant is by default part of the conference, false<br/>
    * otherwise <br/>
    */
    public boolean isLocalParticipantEnabled();

    /**
    * Enable local participant to enter the conference. <br/>
    * <br/>
    * The local participant is the one driving the local {@link Core}. It uses the<br/>
    * local sound devices. The default value is true. Setting to false is mostly<br/>
    * helpful when using liblinphone on a server application. <br/>
    * @param enable true if local participant is automatically added to the<br/>
    * conference, false otherwise <br/>
    */
    public void setLocalParticipantEnabled(boolean enable);

    /**
    * Returns whether conference can have only one participant. <br/>
    * <br/>
    * @return true if the conference can have only one participant, false otherwise <br/>
    */
    public boolean isOneParticipantConferenceEnabled();

    /**
    * Enable conference with one participant. <br/>
    * <br/>
    * @param enable true if conference can have only one participant, false otherwise <br/>
    */
    public void setOneParticipantConferenceEnabled(boolean enable);

    /**
    * Get the participant list type. <br/>
    * <br/>
    * @return participant list type {@link Conference#ParticipantListType}. <br/>
    */
    public Conference.ParticipantListType getParticipantListType();

    /**
    * Set the participant list type. <br/>
    * <br/>
    * @param type Participant list type {@link Conference#ParticipantListType}. This<br/>
    * allows to restrict the access to the conference to a selected set of<br/>
    * participants <br/>
    */
    public void setParticipantListType(Conference.ParticipantListType type);

    /**
    * Returns the proxy configuration for the conference. <br/>
    * <br/>
    * @return a pointer to the proxy configuration or null if it is not set.   <br/>
    * @deprecated 11/01/2022 Use {@link #getAccount} instead. <br/>
    */
    @Deprecated
    @Nullable
    public ProxyConfig getProxyCfg();

    /**
    * Retrieve the desired security level of the conference. <br/>
    * <br/>
    * @return The desired security level of the conference. <br/>
    */
    public Conference.SecurityLevel getSecurityLevel();

    /**
    * Set the desired security level of the conference. <br/>
    * <br/>
    * @param securityLevel The desired security level of the conference. <br/>
    */
    public void setSecurityLevel(Conference.SecurityLevel securityLevel);

    /**
    * Get the conference subject. <br/>
    * <br/>
    * @return conference subject.   <br/>
    */
    @Nullable
    public String getSubject();

    /**
    * Set the conference subject. <br/>
    * <br/>
    * @param subject conference subject   <br/>
    */
    public void setSubject(@Nullable String subject);

    /**
    * Get the conference subject as an UTF-8 string. <br/>
    * <br/>
    * @return conference subject.   <br/>
    */
    @Nullable
    public String getSubjectUtf8();

    /**
    * Set the conference subject as an UTF8 string. <br/>
    * <br/>
    * @param subject conference subject   <br/>
    */
    public void setSubjectUtf8(@Nullable String subject);

    /**
    * Check whether video capabilities are enabled. <br/>
    * <br/>
    * @return true if the conference supports video capabilities, false otherwise <br/>
    */
    public boolean isVideoEnabled();

    /**
    * Enable video capabilities. <br/>
    * <br/>
    * @param enable If true, video will be enabled during conference <br/>
    */
    public void setVideoEnabled(boolean enable);

    /**
    * Clone a {@link ConferenceParams}. <br/>
    * <br/>
    * @return An allocated {@link ConferenceParams} with the same parameters than<br/>
    * params   <br/>
    */
    @NonNull
    public ConferenceParams clone();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ConferenceParamsImpl implements ConferenceParams {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ConferenceParamsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Account getAccount(long nativePtr);
    @Override @Nullable
    synchronized public Account getAccount()  {
        
        
        return (Account)getAccount(nativePtr);
    }

    private native void setAccount(long nativePtr, Account account);
    @Override
    synchronized public void setAccount(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccount(nativePtr, account);
    }

    private native boolean isAudioEnabled(long nativePtr);
    @Override
    synchronized public boolean isAudioEnabled()  {
        
        
        return isAudioEnabled(nativePtr);
    }

    private native void setAudioEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setAudioEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioEnabled(nativePtr, enable);
    }

    private native boolean isChatEnabled(long nativePtr);
    @Override
    synchronized public boolean isChatEnabled()  {
        
        
        return isChatEnabled(nativePtr);
    }

    private native void setChatEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setChatEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setChatEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setChatEnabled(nativePtr, enable);
    }

    private native ChatParams getChatParams(long nativePtr);
    @Override @Nullable
    synchronized public ChatParams getChatParams()  {
        
        
        return (ChatParams)getChatParams(nativePtr);
    }

    private native Address getConferenceFactoryAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getConferenceFactoryAddress()  {
        
        
        return (Address)getConferenceFactoryAddress(nativePtr);
    }

    private native void setConferenceFactoryAddress(long nativePtr, Address address);
    @Override
    synchronized public void setConferenceFactoryAddress(@Nullable Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceFactoryAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceFactoryAddress(nativePtr, address);
    }

    private native String getDescriptionUtf88(long nativePtr);
    @Override @Nullable
    synchronized public String getDescriptionUtf8()  {
        
        
        return getDescriptionUtf88(nativePtr);
    }

    private native void setDescriptionUtf88(long nativePtr, String description);
    @Override
    synchronized public void setDescriptionUtf8(@Nullable String description)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDescriptionUtf8() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDescriptionUtf88(nativePtr, description);
    }

    private native boolean isGroupEnabled(long nativePtr);
    @Override
    synchronized public boolean isGroupEnabled()  {
        
        
        return isGroupEnabled(nativePtr);
    }

    private native void setGroupEnabled(long nativePtr, boolean group);
    @Override
    synchronized public void setGroupEnabled(boolean group)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setGroupEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setGroupEnabled(nativePtr, group);
    }

    private native void setHidden(long nativePtr, boolean hidden);
    @Override
    synchronized public void setHidden(boolean hidden)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHidden() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHidden(nativePtr, hidden);
    }

    private native boolean isHidden(long nativePtr);
    @Override
    synchronized public boolean isHidden()  {
        
        
        return isHidden(nativePtr);
    }

    private native boolean isValid(long nativePtr);
    @Override
    synchronized public boolean isValid()  {
        
        
        return isValid(nativePtr);
    }

    private native boolean isLocalParticipantEnabled(long nativePtr);
    @Override
    synchronized public boolean isLocalParticipantEnabled()  {
        
        
        return isLocalParticipantEnabled(nativePtr);
    }

    private native void setLocalParticipantEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setLocalParticipantEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLocalParticipantEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLocalParticipantEnabled(nativePtr, enable);
    }

    private native boolean isOneParticipantConferenceEnabled(long nativePtr);
    @Override
    synchronized public boolean isOneParticipantConferenceEnabled()  {
        
        
        return isOneParticipantConferenceEnabled(nativePtr);
    }

    private native void setOneParticipantConferenceEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setOneParticipantConferenceEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOneParticipantConferenceEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOneParticipantConferenceEnabled(nativePtr, enable);
    }

    private native int getParticipantListType(long nativePtr);
    @Override
    synchronized public Conference.ParticipantListType getParticipantListType()  {
        
        
        return Conference.ParticipantListType.fromInt(getParticipantListType(nativePtr));
    }

    private native void setParticipantListType(long nativePtr, int type);
    @Override
    synchronized public void setParticipantListType(Conference.ParticipantListType type)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParticipantListType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParticipantListType(nativePtr, type.toInt());
    }

    private native ProxyConfig getProxyCfg(long nativePtr);
    @Override @Nullable
    synchronized public ProxyConfig getProxyCfg()  {
        
        
        return (ProxyConfig)getProxyCfg(nativePtr);
    }

    private native int getSecurityLevel(long nativePtr);
    @Override
    synchronized public Conference.SecurityLevel getSecurityLevel()  {
        
        
        return Conference.SecurityLevel.fromInt(getSecurityLevel(nativePtr));
    }

    private native void setSecurityLevel(long nativePtr, int securityLevel);
    @Override
    synchronized public void setSecurityLevel(Conference.SecurityLevel securityLevel)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSecurityLevel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSecurityLevel(nativePtr, securityLevel.toInt());
    }

    private native String getSubject(long nativePtr);
    @Override @Nullable
    synchronized public String getSubject()  {
        
        
        return getSubject(nativePtr);
    }

    private native void setSubject(long nativePtr, String subject);
    @Override
    synchronized public void setSubject(@Nullable String subject)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubject() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubject(nativePtr, subject);
    }

    private native String getSubjectUtf88(long nativePtr);
    @Override @Nullable
    synchronized public String getSubjectUtf8()  {
        
        
        return getSubjectUtf88(nativePtr);
    }

    private native void setSubjectUtf88(long nativePtr, String subject);
    @Override
    synchronized public void setSubjectUtf8(@Nullable String subject)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubjectUtf8() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubjectUtf88(nativePtr, subject);
    }

    private native boolean isVideoEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoEnabled()  {
        
        
        return isVideoEnabled(nativePtr);
    }

    private native void setVideoEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setVideoEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoEnabled(nativePtr, enable);
    }

    private native ConferenceParams clone(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceParams clone()  {
        
        
        return (ConferenceParams)clone(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
