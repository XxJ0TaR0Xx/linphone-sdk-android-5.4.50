/*
ParticipantDeviceListenerStub.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

public class ParticipantDeviceListenerStub implements ParticipantDeviceListener {
    @Override
    public void onIsSpeakingChanged(@NonNull ParticipantDevice participantDevice, boolean isSpeaking) {
        // Auto-generated method stub
    }

    @Override
    public void onIsMuted(@NonNull ParticipantDevice participantDevice, boolean isMuted) {
        // Auto-generated method stub
    }

    @Override
    public void onScreenSharingChanged(@NonNull ParticipantDevice participantDevice, boolean isScreenSharing) {
        // Auto-generated method stub
    }

    @Override
    public void onStateChanged(@NonNull ParticipantDevice participantDevice, ParticipantDevice.State state) {
        // Auto-generated method stub
    }

    @Override
    public void onStreamCapabilityChanged(@NonNull ParticipantDevice participantDevice, MediaDirection direction, StreamType streamType) {
        // Auto-generated method stub
    }

    @Override
    public void onThumbnailStreamCapabilityChanged(@NonNull ParticipantDevice participantDevice, MediaDirection direction) {
        // Auto-generated method stub
    }

    @Override
    public void onStreamAvailabilityChanged(@NonNull ParticipantDevice participantDevice, boolean available, StreamType streamType) {
        // Auto-generated method stub
    }

    @Override
    public void onThumbnailStreamAvailabilityChanged(@NonNull ParticipantDevice participantDevice, boolean available) {
        // Auto-generated method stub
    }

    @Override
    public void onVideoDisplayErrorOccurred(@NonNull ParticipantDevice participantDevice, int errorCode) {
        // Auto-generated method stub
    }

}