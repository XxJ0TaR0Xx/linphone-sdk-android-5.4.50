/*
CallParams.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* An object containing various parameters of a {@link Call}. <br/>
* <br/>
* You can specify your params while answering an incoming call using {@link Call#acceptWithParams}<br/>
* or while initiating an outgoing call with {@link Core#inviteAddressWithParams}.<br/>
* This object can be created using {@link Core#createCallParams}, using null for<br/>
* the call pointer if you plan to use it for an outgoing call.<br/>
* For each call, three {@link CallParams} are available: yours, your<br/>
* correspondent's and the one that describe the current state of the call that is<br/>
* the result of the negociation between the previous two. For example, you might<br/>
* enable a certain feature in your call param but this feature can be denied in<br/>
* the remote's configuration, hence the difference.<br/>
* see: {@link Call#getCurrentParams}, {@link Call#getRemoteParams} and {@link Call#getParams}<br/>
* . <br/>
*/
public interface CallParams {
    /**
    * Get the {@link Account} that is used for the call. <br/>
    * <br/>
    * @return The selected {@link Account} for the call, or null if none has been<br/>
    * selected.   <br/>
    */
    @Nullable
    public Account getAccount();

    /**
    * Set the {@link Account} to use for the call. <br/>
    * <br/>
    * @param account The {@link Account} to use, or null if none has been selected.<br/>
    * The {@link CallParams} keeps a reference to it and removes the previous one, if<br/>
    * any.   <br/>
    */
    public void setAccount(@Nullable Account account);

    /**
    * Refine bandwidth settings for this call by setting a bandwidth limit for audio<br/>
    * streams. <br/>
    * <br/>
    * As a consequence, codecs whose bitrates are not compatible with this limit<br/>
    * won't be used. <br/>
    * @param bandwidth The audio bandwidth limit to set in kbit/s. <br/>
    */
    public void setAudioBandwidthLimit(int bandwidth);

    /**
    * Get the audio stream direction. <br/>
    * <br/>
    * @return The audio stream {@link MediaDirection} associated with the call<br/>
    * params. <br/>
    */
    public MediaDirection getAudioDirection();

    /**
    * Set the audio stream direction. <br/>
    * <br/>
    * @param direction The audio stream {@link MediaDirection} associated with this<br/>
    * call params. <br/>
    */
    public void setAudioDirection(MediaDirection direction);

    /**
    * Tell whether audio is enabled or not. <br/>
    * <br/>
    * @return A boolean value telling whether audio is enabled or not. <br/>
    */
    public boolean isAudioEnabled();

    /**
    * Enable audio stream. <br/>
    * <br/>
    * @param enabled A boolean value telling whether to enable audio or not. <br/>
    */
    public void setAudioEnabled(boolean enabled);

    /**
    * Use to get multicast state of audio stream. <br/>
    * <br/>
    * @return true if subsequent calls will propose multicast ip set by {@link Core#setAudioMulticastAddr}<br/>
    */
    public boolean isAudioMulticastEnabled();

    /**
    * Use to enable multicast rtp for audio stream. <br/>
    * <br/>
    */
    public void setAudioMulticastEnabled(boolean yesno);

    /**
    * Whether or not the feedback extension will be used for AVP. <br/>
    * <br/>
    * @return true if AVPF is enabled, false otherwise <br/>
    */
    public boolean isAvpfEnabled();

    /**
    * Toggle feedback extension for AVP. <br/>
    * <br/>
    * @param enable wether or not AVPF should be enabled <br/>
    */
    public void setAvpfEnabled(boolean enable);

    /**
    * Tell whether camera is enabled or not. <br/>
    * <br/>
    * The value returned by this function has a different meaning whether it is from<br/>
    * local or remote parameters. The former states the will of the user to use the<br/>
    * camera of his/her device. On the other hand, the latter is just a guess to know<br/>
    * whether the remote party enabled its camera or not. For example, while the call<br/>
    * is part of a conference a core will understand that the remote party disabled<br/>
    * its camera if the thumbnail stream's direction is inactive. <br/>
    * @return A boolean value telling whether camera is enabled or not. <br/>
    */
    public boolean isCameraEnabled();

    /**
    * Enable camera stream. <br/>
    * <br/>
    * @param enabled A boolean value telling whether to enable camera or not. <br/>
    */
    public void setCameraEnabled(boolean enabled);

    /**
    * Check if the capability negotiation (RFC5939) reINVITE is enabled or not. <br/>
    * <br/>
    * @return true if capability negotiation reINVITE is enabled; false otherwise. <br/>
    */
    public boolean isCapabilityNegotiationReinviteEnabled();

    /**
    * Define whether capability negotiation (RFC5939) reINVITE is enabled. <br/>
    * <br/>
    * @param enable true to enable capability negotiation reINVITE; false otherwise. <br/>
    */
    public void setCapabilityNegotiationReinviteEnabled(boolean enable);

    /**
    * Indicates whether capability negotiations (RFC5939) is enabled. <br/>
    * <br/>
    * @return a boolean indicating the enablement of capability negotiations. <br/>
    */
    public boolean isCapabilityNegotiationsEnabled();

    /**
    * Enable capability negotiations (RFC5939). <br/>
    * <br/>
    * @param enabled A boolean value telling whether to enable capability<br/>
    * negotiations or not. <br/>
    */
    public void setCapabilityNegotiationsEnabled(boolean enabled);

    /**
    * Enable merging of cfg lines with consecutive indexes if capability negotiations<br/>
    * (RFC5939) is enabled. <br/>
    * <br/>
    * @param enabled A boolean value telling whether to merge pcfg and acfg lines <br/>
    */
    public void setCfgLinesMergingEnabled(boolean enabled);

    /**
    * Set video layout for conference. <br/>
    * <br/>
    * @return Preferred {@link Conference#Layout} to use at the start of a conference <br/>
    */
    public Conference.Layout getConferenceVideoLayout();

    /**
    * Set video layout for conference. <br/>
    * <br/>
    * @param layout {@link Conference#Layout} to use as default when creating a<br/>
    * conference <br/>
    */
    public void setConferenceVideoLayout(Conference.Layout layout);

    /**
    * Gets a list of {@link Content} set if exists. <br/>
    * <br/>
    * @return A list of {@link Content} set if exists, null otherwise.      <br/>
    */
    @NonNull
    public Content[] getCustomContents();

    /**
    * Indicate whether sending of early media was enabled. <br/>
    * <br/>
    * @return A boolean value telling whether sending of early media was enabled. <br/>
    */
    public boolean isEarlyMediaSendingEnabled();

    /**
    * Enable sending of real early media (during outgoing calls). <br/>
    * <br/>
    * @param enabled A boolean value telling whether to enable early media sending or<br/>
    * not. <br/>
    */
    public void setEarlyMediaSendingEnabled(boolean enabled);

    /**
    * Tell whether FEC is enabled or not. <br/>
    * <br/>
    * The FEC is enbaled whether a FEC stream is found. <br/>
    * @return A boolean value telling whether FEC is enabled or not. <br/>
    */
    public boolean isFecEnabled();

    /**
    * Get the from header in the CallParams. <br/>
    * <br/>
    * @return The content of the from header, may be null.   <br/>
    */
    @Nullable
    public String getFromHeader();

    /**
    * Force the from header of a call when instanciating it (if set, it precludes the<br/>
    * search in proxy and primary contact) <br/>
    * <br/>
    * @param fromValue The value of the forced from, null to delete it.   <br/>
    */
    public void setFromHeader(@Nullable String fromValue);

    /**
    * Gets the default input audio device for a call that will be created using this<br/>
    * call params. <br/>
    * <br/>
    * warning: This method only concerns the call creation, it doesn't reflect the<br/>
    * currently used input audio device of the call. Instead use {@link Call#getInputAudioDevice}<br/>
    * when call has been created. <br/>
    * @return the {@link AudioDevice} that will be used by default as input when the<br/>
    * call will be created   <br/>
    */
    @Nullable
    public AudioDevice getInputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as default input for a call to be created<br/>
    * later. <br/>
    * <br/>
    * warning: This method won't have any effect once the call has been created!<br/>
    * Instead use {@link Call#setInputAudioDevice} when call has been created. <br/>
    * @param audioDevice The {@link AudioDevice}. null does nothing.   <br/>
    */
    public void setInputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Indicates whether the call is being recorded. <br/>
    * <br/>
    * @return true if the call is being recorded, false otherwise. <br/>
    */
    public boolean isRecording();

    /**
    * Check if call parameters are valid. <br/>
    * <br/>
    * @return true if the parameters are valid; false otherwise. <br/>
    */
    public boolean isValid();

    /**
    * Tell whether the call is part of the locally managed conference. <br/>
    * <br/>
    * warning: If a conference server is used to manage conferences, that function<br/>
    * does not return true even if the conference is running. If you want to test<br/>
    * whether the conference is running, you should test whether<br/>
    * linphone_core_get_conference() return a non-null pointer. <br/>
    * @return A boolean value telling whether the call is part of the locally managed<br/>
    * conference. <br/>
    */
    public boolean getLocalConferenceMode();

    /**
    * Tell whether the call has been configured in low bandwidth mode or not. <br/>
    * <br/>
    * This mode can be automatically discovered thanks to a stun server when<br/>
    * activate_edge_workarounds=1 in section [net] of configuration file. An<br/>
    * application that would have reliable way to know network capacity may not use<br/>
    * activate_edge_workarounds=1 but instead manually configure low bandwidth mode<br/>
    * with {@link #enableLowBandwidth}. When enabled, this param may transform a call<br/>
    * request with video in audio only mode. <br/>
    * @return A boolean value telling whether the low bandwidth mode has been<br/>
    * configured/detected. <br/>
    */
    public boolean isLowBandwidthEnabled();

    /**
    * Indicate low bandwith mode. <br/>
    * <br/>
    * Configuring a call to low bandwidth mode will result in the core to activate<br/>
    * several settings for the call in order to ensure that bitrate usage is lowered<br/>
    * to the minimum possible. Typically, ptime (packetization time) will be<br/>
    * increased, audio codec's output bitrate will be targetted to 20kbit/s provided<br/>
    * that it is achievable by the codec selected after SDP handshake. Video is<br/>
    * automatically disabled. <br/>
    * @param enabled A boolean value telling whether to activate the low bandwidth<br/>
    * mode or not. <br/>
    */
    public void setLowBandwidthEnabled(boolean enabled);

    /**
    * Get the kind of media encryption selected for the call. <br/>
    * <br/>
    * @return The kind of {@link MediaEncryption} selected for the call. <br/>
    */
    public MediaEncryption getMediaEncryption();

    /**
    * Set requested media encryption for a call. <br/>
    * <br/>
    * @param encryption The {@link MediaEncryption} to use for the call. <br/>
    */
    public void setMediaEncryption(MediaEncryption encryption);

    /**
    * Tells whether the microphone will be enabled when the call will be created. <br/>
    * <br/>
    * warning: This method only concerns the call creation, it doesn't reflect the<br/>
    * actual microphone status during a call. Instead use {@link Call#getMicrophoneMuted}<br/>
    * when call has been created. <br/>
    * @return true if the microphone will be enabled, false if disabled. <br/>
    */
    public boolean isMicEnabled();

    /**
    * Enable or disable the microphone at the call creation. <br/>
    * <br/>
    * warning: This method won't have any effect once the call has been created!<br/>
    * Instead use {@link Call#setMicrophoneMuted} when call has been created. <br/>
    * @param enable true to enable the microphone, false to disable it. <br/>
    */
    public void setMicEnabled(boolean enable);

    /**
    * Gets the default output audio device for a call that will be created using this<br/>
    * call params. <br/>
    * <br/>
    * warning: This method only concerns the call creation, it doesn't reflect the<br/>
    * currently used output audio device of the call. Instead use {@link Call#getOutputAudioDevice}<br/>
    * when call has been created. <br/>
    * @return the {@link AudioDevice} that will be used by default as output when the<br/>
    * call will be created   <br/>
    */
    @Nullable
    public AudioDevice getOutputAudioDevice();

    /**
    * Sets the given {@link AudioDevice} as default output for a call to be created<br/>
    * later. <br/>
    * <br/>
    * warning: This method won't have any effect once the call has been created!<br/>
    * Instead use {@link Call#setOutputAudioDevice} when call has been created. <br/>
    * @param audioDevice The {@link AudioDevice}. null does nothing.   <br/>
    */
    public void setOutputAudioDevice(@Nullable AudioDevice audioDevice);

    /**
    * Get requested level of privacy for the call. <br/>
    * <br/>
    * @return The LinphonePrivacyMask used for the call. <br/>
    */
    public int getPrivacy();

    /**
    * Set requested level of privacy for the call. <br/>
    * <br/>
    * @param privacy The LinphonePrivacyMask to used for the call. <br/>
    */
    public void setPrivacy(int privacy);

    /**
    * Get the {@link ProxyConfig} that is used for the call. <br/>
    * <br/>
    * @return The selected {@link ProxyConfig} for the call, or null if none has been<br/>
    * selected.   <br/>
    * @deprecated 28/02/2021 Use {@link #getAccount} instead. <br/>
    */
    @Deprecated
    @Nullable
    public ProxyConfig getProxyConfig();

    /**
    * Set the {@link ProxyConfig} to use for the call. <br/>
    * <br/>
    * @param proxyConfig The {@link ProxyConfig} to use, or null if none has been<br/>
    * selected. The {@link CallParams} keep a reference on it and remove the older if<br/>
    * it exists.   <br/>
    * @deprecated 28/02/2021 Use {@link #setAccount} instead. <br/>
    */
    @Deprecated
    public void setProxyConfig(@Nullable ProxyConfig proxyConfig);

    /**
    * Use to get real time text following rfc4103. <br/>
    * <br/>
    * @return returns true if call rtt is activated. <br/>
    */
    public boolean isRealtimeTextEnabled();

    /**
    * Use to enable real time text following rfc4103. <br/>
    * <br/>
    * If enabled, outgoing calls put a m=text line in SDP offer . <br/>
    * @param yesno if yes, subsequent outgoing calls will propose rtt <br/>
    * @return 0 <br/>
    */
    public int setRealtimeTextEnabled(boolean yesno);

    /**
    * Use to get keep alive interval of real time text following rfc4103. <br/>
    * <br/>
    * @return returns keep alive interval of real time text. <br/>
    */
    public int getRealtimeTextKeepaliveInterval();

    /**
    * Use to set keep alive interval for real time text following rfc4103. <br/>
    * <br/>
    * @param interval The keep alive interval for real time text, 25000 by default. <br/>
    */
    public void setRealtimeTextKeepaliveInterval(int interval);

    /**
    * Get the framerate of the video that is received. <br/>
    * <br/>
    * @return The actual received framerate in frames per seconds, 0 if not<br/>
    * available. <br/>
    */
    public float getReceivedFramerate();

    /**
    * Get the definition of the received video. <br/>
    * <br/>
    * @return The received {@link VideoDefinition} or null.   <br/>
    */
    @Nullable
    public VideoDefinition getReceivedVideoDefinition();

    /**
    * Get the path for the audio recording of the call. <br/>
    * <br/>
    * @return The path to the audio recording of the call or null.   <br/>
    */
    @Nullable
    public String getRecordFile();

    /**
    * Enable recording of the call. <br/>
    * <br/>
    * This function must be used before the call parameters are assigned to the call.<br/>
    * The call recording can be started and paused after the call is established with<br/>
    * {@link Call#startRecording} and linphone_call_pause_recording(). <br/>
    * @param path A string containing the path and filename of the file where<br/>
    * audio/video streams are to be written. The filename must have an extension that<br/>
    * maps to any of the supported file formats listed in {@link MediaFileFormat}<br/>
    * enum.    <br/>
    */
    public void setRecordFile(@Nullable String path);

    /**
    * Indicates whether RTP bundle mode (also known as Media Multiplexing) is<br/>
    * enabled. <br/>
    * <br/>
    * See https://datatracker.ietf.org/doc/html/rfc8843 for more information. <br/>
    * @return a boolean indicating the enablement of rtp bundle mode. <br/>
    */
    public boolean isRtpBundleEnabled();

    /**
    * Enables or disables RTP bundle mode (Media Multiplexing). <br/>
    * <br/>
    * See https://datatracker.ietf.org/doc/html/rfc8843 for more information about<br/>
    * the feature. When enabled, liblinphone will try to negociate the use of a<br/>
    * single port for all streams. It automatically enables rtcp-mux. <br/>
    * @param value a boolean to indicate whether the feature is to be enabled. <br/>
    * @deprecated This property can no longer be controlled via {@link CallParams}.<br/>
    * Use {@link AccountParams#enableRtpBundle}.<br/>
    */
    @Deprecated
    public void setRtpBundleEnabled(boolean value);

    /**
    * Get the RTP profile being used. <br/>
    * <br/>
    * @return The RTP profile.   <br/>
    */
    @NonNull
    public String getRtpProfile();

    /**
    * Tell whether screen sharing is enabled or not. <br/>
    * <br/>
    * @return A boolean value telling whether screen sharing is enabled or not. <br/>
    */
    public boolean isScreenSharingEnabled();

    /**
    * Enable screen sharing stream. <br/>
    * <br/>
    * @param enabled A boolean value telling whether to enable screen sharing or not. <br/>
    */
    public void setScreenSharingEnabled(boolean enabled);

    /**
    * Get the framerate of the video that is sent. <br/>
    * <br/>
    * @return The actual sent framerate in frames per seconds, 0 if not available. <br/>
    */
    public float getSentFramerate();

    /**
    * Get the definition of the sent video. <br/>
    * <br/>
    * @return The sent {@link VideoDefinition} or null.   <br/>
    */
    @Nullable
    public VideoDefinition getSentVideoDefinition();

    /**
    * Get the session name of the media session (ie in SDP). <br/>
    * <br/>
    * Subject from the SIP message can be retrieved using {@link #getCustomHeader}<br/>
    * and is different. <br/>
    * @return The session name of the media session or null.   <br/>
    */
    @Nullable
    public String getSessionName();

    /**
    * Set the session name of the media session (ie in SDP). <br/>
    * <br/>
    * Subject from the SIP message (which is different) can be set using<br/>
    * linphone_call_params_set_custom_header(). <br/>
    * @param name The session name to be used.   <br/>
    */
    public void setSessionName(@Nullable String name);

    /**
    * Returns the list of enable srtp suite in the call (enforced only if SDES is the<br/>
    * selected encryption mode) <br/>
    * <br/>
    * @return a list of srtp suite enabled in a given call    <br/>
    */
    @NonNull
    public SrtpSuite[] getSrtpSuites();

    /**
    * Sets the list of srtp suite enabled(enforced only when SDES is the encryption<br/>
    * mode) <br/>
    * <br/>
    * @param srtpSuites list with the list of SRTP encryption suites enabled in a<br/>
    * given call     <br/>
    */
    public void setSrtpSuites(@NonNull SrtpSuite[] srtpSuites);

    /**
    * Enable merging of tcap lines with consecutive indexes if capability<br/>
    * negotiations (RFC5939) is enabled. <br/>
    * <br/>
    * @param enabled A boolean value telling whether to merge tcap lines <br/>
    */
    public void setTcapLineMergingEnabled(boolean enabled);

    /**
    * Check if tone indications are enabled. <br/>
    * <br/>
    * @return true if tone indications are enabled; false otherwise. <br/>
    */
    public boolean isToneIndicationsEnabled();

    /**
    * Define whether tone indications are enabled. <br/>
    * <br/>
    * @param enable true to enable tone indications; false otherwise. <br/>
    */
    public void setToneIndicationsEnabled(boolean enable);

    /**
    * Get the audio payload type that has been selected by a call. <br/>
    * <br/>
    * @return The selected {@link PayloadType}. null is returned if no audio payload<br/>
    * type has been selected by the call.    <br/>
    */
    @Nullable
    public PayloadType getUsedAudioPayloadType();

    /**
    * Get the text payload type that has been selected by a call. <br/>
    * <br/>
    * @return The selected {@link PayloadType}. null is returned if no text payload<br/>
    * type has been selected by the call.    <br/>
    */
    @Nullable
    public PayloadType getUsedTextPayloadType();

    /**
    * Get the video payload type that has been selected by a call. <br/>
    * <br/>
    * @return The selected {@link PayloadType}. null is returned if no video payload<br/>
    * type has been selected by the call.    <br/>
    */
    @Nullable
    public PayloadType getUsedVideoPayloadType();

    /**
    * Get the video stream direction. <br/>
    * <br/>
    * @return The video stream {@link MediaDirection} associated with the call<br/>
    * params. <br/>
    */
    public MediaDirection getVideoDirection();

    /**
    * Set the video stream direction. <br/>
    * <br/>
    * @param direction The video stream {@link MediaDirection} associated with this<br/>
    * call params. <br/>
    */
    public void setVideoDirection(MediaDirection direction);

    /**
    * Tell whether video is enabled or not. <br/>
    * <br/>
    * @return A boolean value telling whether video is enabled or not. <br/>
    */
    public boolean isVideoEnabled();

    /**
    * Enable video stream. <br/>
    * <br/>
    * @param enabled A boolean value telling whether to enable video or not. <br/>
    */
    public void setVideoEnabled(boolean enabled);

    /**
    * Use to get multicast state of video stream. <br/>
    * <br/>
    * @return true if subsequent calls will propose multicast ip set by {@link Core#setVideoMulticastAddr}<br/>
    */
    public boolean isVideoMulticastEnabled();

    /**
    * Use to enable multicast rtp for video stream. <br/>
    * <br/>
    * If enabled, outgoing calls put a multicast address from {@link Core#getVideoMulticastAddr}<br/>
    * into video cline. In case of outgoing call video stream is sent to this<br/>
    * multicast address.  For incoming calls behavior is unchanged. <br/>
    * @param yesno if yes, subsequent outgoing calls will propose multicast ip set by<br/>
    * {@link Core#setVideoMulticastAddr} <br/>
    */
    public void setVideoMulticastEnabled(boolean yesno);

    /**
    * Adds a {@link Content} to be added to the INVITE SDP. <br/>
    * <br/>
    * @param content The {@link Content} to be added.   <br/>
    */
    public void addCustomContent(@NonNull Content content);

    /**
    * Add a custom SIP header in the INVITE for a call. <br/>
    * <br/>
    * @param headerName The name of the header to add.   <br/>
    * @param headerValue The content of the header to add.   <br/>
    */
    public void addCustomHeader(@NonNull String headerName, @Nullable String headerValue);

    /**
    * Add a custom attribute related to all the streams in the SDP exchanged within<br/>
    * SIP messages during a call. <br/>
    * <br/>
    * @param attributeName The name of the attribute to add.   <br/>
    * @param attributeValue The content value of the attribute to add.   <br/>
    */
    public void addCustomSdpAttribute(@NonNull String attributeName, @Nullable String attributeValue);

    /**
    * Add a custom attribute related to a specific stream in the SDP exchanged within<br/>
    * SIP messages during a call. <br/>
    * <br/>
    * @param type The type of the stream to add a custom SDP attribute to. <br/>
    * @param attributeName The name of the attribute to add.   <br/>
    * @param attributeValue The content value of the attribute to add.   <br/>
    */
    public void addCustomSdpMediaAttribute(StreamType type, @NonNull String attributeName, @Nullable String attributeValue);

    /**
    * Indicates whether cfg lines with consecutive indexes are going to be merged or<br/>
    * not if capability negotiations (RFC5939) is enabled. <br/>
    * <br/>
    * @return a boolean indicating the enablement of pcfg and acfg line merging <br/>
    */
    public boolean cfgLinesMerged();

    /**
    * Clear the custom SDP attributes related to all the streams in the SDP exchanged<br/>
    * within SIP messages during a call. <br/>
    * <br/>
    */
    public void clearCustomSdpAttributes();

    /**
    * Clear the custom SDP attributes related to a specific stream in the SDP<br/>
    * exchanged within SIP messages during a call. <br/>
    * <br/>
    * @param type The type of the stream to clear the custom SDP attributes from. <br/>
    */
    public void clearCustomSdpMediaAttributes(StreamType type);

    /**
    * Copy an existing {@link CallParams} object to a new {@link CallParams} object. <br/>
    * <br/>
    * {@link #copy} is error-prone, leading to inconsistent parameters being passed<br/>
    * to {@link Core#inviteAddressWithParams} or {@link Call#acceptWithParams}.<br/>
    * @deprecated use exclusively {@link Core#createCallParams} to create {@link CallParams}<br/>
    * object. <br/>
    * @return A copy of the {@link CallParams} object.     <br/>
    */
    @Deprecated
    @NonNull
    public CallParams copy();

    /**
    * Define whether ringing is disabled. <br/>
    * <br/>
    * @param disable true to disable ringing; false otherwise. <br/>
    */
    public void disableRinging(boolean disable);

    /**
    * Get a custom SIP header. <br/>
    * <br/>
    * @param headerName The name of the header to get.   <br/>
    * @return The content of the header or null if not found.   <br/>
    */
    @Nullable
    public String getCustomHeader(@NonNull String headerName);

    /**
    * Get a custom SDP attribute that is related to all the streams. <br/>
    * <br/>
    * @param attributeName The name of the attribute to get.   <br/>
    * @return The content value of the attribute or null if not found.   <br/>
    */
    @Nullable
    public String getCustomSdpAttribute(@NonNull String attributeName);

    /**
    * Get a custom SDP attribute that is related to a specific stream. <br/>
    * <br/>
    * @param type The type of the stream to add a custom SDP attribute to. <br/>
    * @param attributeName The name of the attribute to get.   <br/>
    * @return The content value of the attribute or null if not found.   <br/>
    */
    @Nullable
    public String getCustomSdpMediaAttribute(StreamType type, @NonNull String attributeName);

    /**
    * Returns true if a custom SDP attribute that is related to all the streams is<br/>
    * present. <br/>
    * <br/>
    * @param attributeName The name of the attribute to get.   <br/>
    * @return Whether the attribute is present. <br/>
    */
    public boolean hasCustomSdpAttribute(@NonNull String attributeName);

    /**
    * Indicates whether a custom SDP attribute that is related to a specific stream<br/>
    * is present or not. <br/>
    * <br/>
    * @param type The type of the stream to add a custom SDP attribute to. <br/>
    * @param attributeName The name of the attribute to get.   <br/>
    * @return Whether the attribute is present. <br/>
    */
    public boolean hasCustomSdpMediaAttribute(StreamType type, @NonNull String attributeName);

    /**
    * Returns the encryption is supported. <br/>
    * <br/>
    * @param encryption The {@link MediaEncryption} to check whether is supported <br/>
    * @return a boolean indicating whether the encryption is supported <br/>
    */
    public boolean isMediaEncryptionSupported(MediaEncryption encryption);

    /**
    * Check if ringing is disabled. <br/>
    * <br/>
    * @return true if ringing is disabled; false otherwise. <br/>
    */
    public boolean ringingDisabled();

    /**
    * Indicates whether tcap lines with consecutive indexes are going to be merged or<br/>
    * not if capability negotiations (RFC5939) is enabled. <br/>
    * <br/>
    * @return a boolean indicating the enablement of tcap line merging <br/>
    */
    public boolean tcapLinesMerged();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class CallParamsImpl implements CallParams {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected CallParamsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Account getAccount(long nativePtr);
    @Override @Nullable
    synchronized public Account getAccount()  {
        
        
        return (Account)getAccount(nativePtr);
    }

    private native void setAccount(long nativePtr, Account account);
    @Override
    synchronized public void setAccount(@Nullable Account account)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccount(nativePtr, account);
    }

    private native void setAudioBandwidthLimit(long nativePtr, int bandwidth);
    @Override
    synchronized public void setAudioBandwidthLimit(int bandwidth)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioBandwidthLimit() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioBandwidthLimit(nativePtr, bandwidth);
    }

    private native int getAudioDirection(long nativePtr);
    @Override
    synchronized public MediaDirection getAudioDirection()  {
        
        
        return MediaDirection.fromInt(getAudioDirection(nativePtr));
    }

    private native void setAudioDirection(long nativePtr, int direction);
    @Override
    synchronized public void setAudioDirection(MediaDirection direction)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioDirection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioDirection(nativePtr, direction.toInt());
    }

    private native boolean isAudioEnabled(long nativePtr);
    @Override
    synchronized public boolean isAudioEnabled()  {
        
        
        return isAudioEnabled(nativePtr);
    }

    private native void setAudioEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setAudioEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioEnabled(nativePtr, enabled);
    }

    private native boolean isAudioMulticastEnabled(long nativePtr);
    @Override
    synchronized public boolean isAudioMulticastEnabled()  {
        
        
        return isAudioMulticastEnabled(nativePtr);
    }

    private native void setAudioMulticastEnabled(long nativePtr, boolean yesno);
    @Override
    synchronized public void setAudioMulticastEnabled(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioMulticastEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioMulticastEnabled(nativePtr, yesno);
    }

    private native boolean isAvpfEnabled(long nativePtr);
    @Override
    synchronized public boolean isAvpfEnabled()  {
        
        
        return isAvpfEnabled(nativePtr);
    }

    private native void setAvpfEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setAvpfEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAvpfEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAvpfEnabled(nativePtr, enable);
    }

    private native boolean isCameraEnabled(long nativePtr);
    @Override
    synchronized public boolean isCameraEnabled()  {
        
        
        return isCameraEnabled(nativePtr);
    }

    private native void setCameraEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setCameraEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCameraEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCameraEnabled(nativePtr, enabled);
    }

    private native boolean isCapabilityNegotiationReinviteEnabled(long nativePtr);
    @Override
    synchronized public boolean isCapabilityNegotiationReinviteEnabled()  {
        
        
        return isCapabilityNegotiationReinviteEnabled(nativePtr);
    }

    private native void setCapabilityNegotiationReinviteEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setCapabilityNegotiationReinviteEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCapabilityNegotiationReinviteEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCapabilityNegotiationReinviteEnabled(nativePtr, enable);
    }

    private native boolean isCapabilityNegotiationsEnabled(long nativePtr);
    @Override
    synchronized public boolean isCapabilityNegotiationsEnabled()  {
        
        
        return isCapabilityNegotiationsEnabled(nativePtr);
    }

    private native void setCapabilityNegotiationsEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setCapabilityNegotiationsEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCapabilityNegotiationsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCapabilityNegotiationsEnabled(nativePtr, enabled);
    }

    private native void setCfgLinesMergingEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setCfgLinesMergingEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCfgLinesMergingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCfgLinesMergingEnabled(nativePtr, enabled);
    }

    private native int getConferenceVideoLayout(long nativePtr);
    @Override
    synchronized public Conference.Layout getConferenceVideoLayout()  {
        
        
        return Conference.Layout.fromInt(getConferenceVideoLayout(nativePtr));
    }

    private native void setConferenceVideoLayout(long nativePtr, int layout);
    @Override
    synchronized public void setConferenceVideoLayout(Conference.Layout layout)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceVideoLayout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceVideoLayout(nativePtr, layout.toInt());
    }

    private native Content[] getCustomContents(long nativePtr);
    @Override @NonNull
    synchronized public Content[] getCustomContents()  {
        
        
        return getCustomContents(nativePtr);
    }

    private native boolean isEarlyMediaSendingEnabled(long nativePtr);
    @Override
    synchronized public boolean isEarlyMediaSendingEnabled()  {
        
        
        return isEarlyMediaSendingEnabled(nativePtr);
    }

    private native void setEarlyMediaSendingEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setEarlyMediaSendingEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEarlyMediaSendingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEarlyMediaSendingEnabled(nativePtr, enabled);
    }

    private native boolean isFecEnabled(long nativePtr);
    @Override
    synchronized public boolean isFecEnabled()  {
        
        
        return isFecEnabled(nativePtr);
    }

    private native String getFromHeader(long nativePtr);
    @Override @Nullable
    synchronized public String getFromHeader()  {
        
        
        return getFromHeader(nativePtr);
    }

    private native void setFromHeader(long nativePtr, String fromValue);
    @Override
    synchronized public void setFromHeader(@Nullable String fromValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFromHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFromHeader(nativePtr, fromValue);
    }

    private native AudioDevice getInputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getInputAudioDevice()  {
        
        
        return (AudioDevice)getInputAudioDevice(nativePtr);
    }

    private native void setInputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setInputAudioDevice(@Nullable AudioDevice audioDevice)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInputAudioDevice(nativePtr, audioDevice);
    }

    private native boolean isRecording(long nativePtr);
    @Override
    synchronized public boolean isRecording()  {
        
        
        return isRecording(nativePtr);
    }

    private native boolean isValid(long nativePtr);
    @Override
    synchronized public boolean isValid()  {
        
        
        return isValid(nativePtr);
    }

    private native boolean getLocalConferenceMode(long nativePtr);
    @Override
    synchronized public boolean getLocalConferenceMode()  {
        
        
        return getLocalConferenceMode(nativePtr);
    }

    private native boolean isLowBandwidthEnabled(long nativePtr);
    @Override
    synchronized public boolean isLowBandwidthEnabled()  {
        
        
        return isLowBandwidthEnabled(nativePtr);
    }

    private native void setLowBandwidthEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setLowBandwidthEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLowBandwidthEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLowBandwidthEnabled(nativePtr, enabled);
    }

    private native int getMediaEncryption(long nativePtr);
    @Override
    synchronized public MediaEncryption getMediaEncryption()  {
        
        
        return MediaEncryption.fromInt(getMediaEncryption(nativePtr));
    }

    private native void setMediaEncryption(long nativePtr, int encryption);
    @Override
    synchronized public void setMediaEncryption(MediaEncryption encryption)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMediaEncryption() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMediaEncryption(nativePtr, encryption.toInt());
    }

    private native boolean isMicEnabled(long nativePtr);
    @Override
    synchronized public boolean isMicEnabled()  {
        
        
        return isMicEnabled(nativePtr);
    }

    private native void setMicEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setMicEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMicEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMicEnabled(nativePtr, enable);
    }

    private native AudioDevice getOutputAudioDevice(long nativePtr);
    @Override @Nullable
    synchronized public AudioDevice getOutputAudioDevice()  {
        
        
        return (AudioDevice)getOutputAudioDevice(nativePtr);
    }

    private native void setOutputAudioDevice(long nativePtr, AudioDevice audioDevice);
    @Override
    synchronized public void setOutputAudioDevice(@Nullable AudioDevice audioDevice)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOutputAudioDevice() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOutputAudioDevice(nativePtr, audioDevice);
    }

    private native int getPrivacy(long nativePtr);
    @Override
    synchronized public int getPrivacy()  {
        
        
        return getPrivacy(nativePtr);
    }

    private native void setPrivacy(long nativePtr, int privacy);
    @Override
    synchronized public void setPrivacy(int privacy)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPrivacy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPrivacy(nativePtr, privacy);
    }

    private native ProxyConfig getProxyConfig(long nativePtr);
    @Override @Nullable
    synchronized public ProxyConfig getProxyConfig()  {
        
        
        return (ProxyConfig)getProxyConfig(nativePtr);
    }

    private native void setProxyConfig(long nativePtr, ProxyConfig proxyConfig);
    @Override
    synchronized public void setProxyConfig(@Nullable ProxyConfig proxyConfig)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setProxyConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setProxyConfig(nativePtr, proxyConfig);
    }

    private native boolean isRealtimeTextEnabled(long nativePtr);
    @Override
    synchronized public boolean isRealtimeTextEnabled()  {
        
        
        return isRealtimeTextEnabled(nativePtr);
    }

    private native int setRealtimeTextEnabled(long nativePtr, boolean yesno);
    @Override
    synchronized public int setRealtimeTextEnabled(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRealtimeTextEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setRealtimeTextEnabled(nativePtr, yesno);
    }

    private native int getRealtimeTextKeepaliveInterval(long nativePtr);
    @Override
    synchronized public int getRealtimeTextKeepaliveInterval()  {
        
        
        return getRealtimeTextKeepaliveInterval(nativePtr);
    }

    private native void setRealtimeTextKeepaliveInterval(long nativePtr, int interval);
    @Override
    synchronized public void setRealtimeTextKeepaliveInterval(int interval)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRealtimeTextKeepaliveInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRealtimeTextKeepaliveInterval(nativePtr, interval);
    }

    private native float getReceivedFramerate(long nativePtr);
    @Override
    synchronized public float getReceivedFramerate()  {
        
        
        return getReceivedFramerate(nativePtr);
    }

    private native VideoDefinition getReceivedVideoDefinition(long nativePtr);
    @Override @Nullable
    synchronized public VideoDefinition getReceivedVideoDefinition()  {
        
        
        return (VideoDefinition)getReceivedVideoDefinition(nativePtr);
    }

    private native String getRecordFile(long nativePtr);
    @Override @Nullable
    synchronized public String getRecordFile()  {
        
        
        return getRecordFile(nativePtr);
    }

    private native void setRecordFile(long nativePtr, String path);
    @Override
    synchronized public void setRecordFile(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRecordFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRecordFile(nativePtr, path);
    }

    private native boolean isRtpBundleEnabled(long nativePtr);
    @Override
    synchronized public boolean isRtpBundleEnabled()  {
        
        
        return isRtpBundleEnabled(nativePtr);
    }

    private native void setRtpBundleEnabled(long nativePtr, boolean value);
    @Override
    synchronized public void setRtpBundleEnabled(boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRtpBundleEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRtpBundleEnabled(nativePtr, value);
    }

    private native String getRtpProfile(long nativePtr);
    @Override @NonNull
    synchronized public String getRtpProfile()  {
        
        
        return getRtpProfile(nativePtr);
    }

    private native boolean isScreenSharingEnabled(long nativePtr);
    @Override
    synchronized public boolean isScreenSharingEnabled()  {
        
        
        return isScreenSharingEnabled(nativePtr);
    }

    private native void setScreenSharingEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setScreenSharingEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setScreenSharingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setScreenSharingEnabled(nativePtr, enabled);
    }

    private native float getSentFramerate(long nativePtr);
    @Override
    synchronized public float getSentFramerate()  {
        
        
        return getSentFramerate(nativePtr);
    }

    private native VideoDefinition getSentVideoDefinition(long nativePtr);
    @Override @Nullable
    synchronized public VideoDefinition getSentVideoDefinition()  {
        
        
        return (VideoDefinition)getSentVideoDefinition(nativePtr);
    }

    private native String getSessionName(long nativePtr);
    @Override @Nullable
    synchronized public String getSessionName()  {
        
        
        return getSessionName(nativePtr);
    }

    private native void setSessionName(long nativePtr, String name);
    @Override
    synchronized public void setSessionName(@Nullable String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSessionName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSessionName(nativePtr, name);
    }

    private native int[] getSrtpSuites(long nativePtr);
    @Override @NonNull
    synchronized public SrtpSuite[] getSrtpSuites()  {
        
        
        return SrtpSuite.fromIntArray(getSrtpSuites(nativePtr));
    }

    private native void setSrtpSuites(long nativePtr, int[] srtpSuites);
    @Override
    synchronized public void setSrtpSuites(@NonNull SrtpSuite[] srtpSuites)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSrtpSuites() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSrtpSuites(nativePtr, SrtpSuite.toIntArray(srtpSuites));
    }

    private native void setTcapLineMergingEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setTcapLineMergingEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTcapLineMergingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTcapLineMergingEnabled(nativePtr, enabled);
    }

    private native boolean isToneIndicationsEnabled(long nativePtr);
    @Override
    synchronized public boolean isToneIndicationsEnabled()  {
        
        
        return isToneIndicationsEnabled(nativePtr);
    }

    private native void setToneIndicationsEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setToneIndicationsEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setToneIndicationsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setToneIndicationsEnabled(nativePtr, enable);
    }

    private native PayloadType getUsedAudioPayloadType(long nativePtr);
    @Override @Nullable
    synchronized public PayloadType getUsedAudioPayloadType()  {
        
        
        return (PayloadType)getUsedAudioPayloadType(nativePtr);
    }

    private native PayloadType getUsedTextPayloadType(long nativePtr);
    @Override @Nullable
    synchronized public PayloadType getUsedTextPayloadType()  {
        
        
        return (PayloadType)getUsedTextPayloadType(nativePtr);
    }

    private native PayloadType getUsedVideoPayloadType(long nativePtr);
    @Override @Nullable
    synchronized public PayloadType getUsedVideoPayloadType()  {
        
        
        return (PayloadType)getUsedVideoPayloadType(nativePtr);
    }

    private native int getVideoDirection(long nativePtr);
    @Override
    synchronized public MediaDirection getVideoDirection()  {
        
        
        return MediaDirection.fromInt(getVideoDirection(nativePtr));
    }

    private native void setVideoDirection(long nativePtr, int direction);
    @Override
    synchronized public void setVideoDirection(MediaDirection direction)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoDirection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoDirection(nativePtr, direction.toInt());
    }

    private native boolean isVideoEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoEnabled()  {
        
        
        return isVideoEnabled(nativePtr);
    }

    private native void setVideoEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setVideoEnabled(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoEnabled(nativePtr, enabled);
    }

    private native boolean isVideoMulticastEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoMulticastEnabled()  {
        
        
        return isVideoMulticastEnabled(nativePtr);
    }

    private native void setVideoMulticastEnabled(long nativePtr, boolean yesno);
    @Override
    synchronized public void setVideoMulticastEnabled(boolean yesno)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVideoMulticastEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVideoMulticastEnabled(nativePtr, yesno);
    }

    private native void addCustomContent(long nativePtr, Content content);
    @Override
    synchronized public void addCustomContent(@NonNull Content content)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomContent(nativePtr, content);
    }

    private native void addCustomHeader(long nativePtr, String headerName, String headerValue);
    @Override
    synchronized public void addCustomHeader(@NonNull String headerName, @Nullable String headerValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomHeader(nativePtr, headerName, headerValue);
    }

    private native void addCustomSdpAttribute(long nativePtr, String attributeName, String attributeValue);
    @Override
    synchronized public void addCustomSdpAttribute(@NonNull String attributeName, @Nullable String attributeValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomSdpAttribute() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomSdpAttribute(nativePtr, attributeName, attributeValue);
    }

    private native void addCustomSdpMediaAttribute(long nativePtr, int type, String attributeName, String attributeValue);
    @Override
    synchronized public void addCustomSdpMediaAttribute(StreamType type, @NonNull String attributeName, @Nullable String attributeValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomSdpMediaAttribute() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomSdpMediaAttribute(nativePtr, type.toInt(), attributeName, attributeValue);
    }

    private native boolean cfgLinesMerged(long nativePtr);
    @Override
    synchronized public boolean cfgLinesMerged()  {
        
        
        return cfgLinesMerged(nativePtr);
    }

    private native void clearCustomSdpAttributes(long nativePtr);
    @Override
    synchronized public void clearCustomSdpAttributes()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearCustomSdpAttributes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearCustomSdpAttributes(nativePtr);
    }

    private native void clearCustomSdpMediaAttributes(long nativePtr, int type);
    @Override
    synchronized public void clearCustomSdpMediaAttributes(StreamType type)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearCustomSdpMediaAttributes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearCustomSdpMediaAttributes(nativePtr, type.toInt());
    }

    private native CallParams copy(long nativePtr);
    @Override @NonNull
    synchronized public CallParams copy()  {
        
        
        return (CallParams)copy(nativePtr);
    }

    private native void disableRinging(long nativePtr, boolean disable);
    @Override
    synchronized public void disableRinging(boolean disable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call disableRinging() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        disableRinging(nativePtr, disable);
    }

    private native String getCustomHeader(long nativePtr, String headerName);
    @Override @Nullable
    synchronized public String getCustomHeader(@NonNull String headerName)  {
        
        
        return getCustomHeader(nativePtr, headerName);
    }

    private native String getCustomSdpAttribute(long nativePtr, String attributeName);
    @Override @Nullable
    synchronized public String getCustomSdpAttribute(@NonNull String attributeName)  {
        
        
        return getCustomSdpAttribute(nativePtr, attributeName);
    }

    private native String getCustomSdpMediaAttribute(long nativePtr, int type, String attributeName);
    @Override @Nullable
    synchronized public String getCustomSdpMediaAttribute(StreamType type, @NonNull String attributeName)  {
        
        
        return getCustomSdpMediaAttribute(nativePtr, type.toInt(), attributeName);
    }

    private native boolean hasCustomSdpAttribute(long nativePtr, String attributeName);
    @Override
    synchronized public boolean hasCustomSdpAttribute(@NonNull String attributeName)  {
        
        
        return hasCustomSdpAttribute(nativePtr, attributeName);
    }

    private native boolean hasCustomSdpMediaAttribute(long nativePtr, int type, String attributeName);
    @Override
    synchronized public boolean hasCustomSdpMediaAttribute(StreamType type, @NonNull String attributeName)  {
        
        
        return hasCustomSdpMediaAttribute(nativePtr, type.toInt(), attributeName);
    }

    private native boolean isMediaEncryptionSupported(long nativePtr, int encryption);
    @Override
    synchronized public boolean isMediaEncryptionSupported(MediaEncryption encryption)  {
        
        
        return isMediaEncryptionSupported(nativePtr, encryption.toInt());
    }

    private native boolean ringingDisabled(long nativePtr);
    @Override
    synchronized public boolean ringingDisabled()  {
        
        
        return ringingDisabled(nativePtr);
    }

    private native boolean tcapLinesMerged(long nativePtr);
    @Override
    synchronized public boolean tcapLinesMerged()  {
        
        
        return tcapLinesMerged(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
