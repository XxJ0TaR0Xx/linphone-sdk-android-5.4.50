/*
NatPolicy.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Policy to use to pass through NATs/firewalls. <br/>
* <br/>
*/
public interface NatPolicy {
    /**
    * Returns the {@link Core} object managing this nat policy, if any. <br/>
    * <br/>
    * @return the {@link Core} object associated.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Tell whether ICE is enabled. <br/>
    * <br/>
    * @return Boolean value telling whether ICE is enabled. <br/>
    */
    public boolean isIceEnabled();

    /**
    * Enable ICE. <br/>
    * <br/>
    * ICE can be enabled without STUN/TURN, in which case only the local candidates<br/>
    * will be used. <br/>
    * @param enable Boolean value telling whether to enable ICE. <br/>
    */
    public void setIceEnabled(boolean enable);

    /**
    * Get the mandatory v4 IP address to use with this NAT policy as server-reflexive<br/>
    * candidate for ICE. <br/>
    * <br/>
    * Used when STUN or TURN are enabled. <br/>
    * @return the nat v4 address.   <br/>
    */
    @Nullable
    public String getNatV4Address();

    /**
    * Set the mandatory v4 IP address to use with this NAT policy as server-reflexive<br/>
    * candidate for ICE. <br/>
    * <br/>
    * The IP address is used only if no stun server is set for server-reflexive<br/>
    * candidate gathering. Using this method is useful when Liblinphone is used in a<br/>
    * server product, when the server does not own the public IP address. Used when<br/>
    * STUN or TURN are enabled. <br/>
    * @param v4Address The STUN server to use with this NAT policy.   <br/>
    */
    public void setNatV4Address(@Nullable String v4Address);

    /**
    * Get the mandatory v6 IP address to use with this NAT policy as server-reflexive<br/>
    * candidate for ICE. <br/>
    * <br/>
    * Used when STUN or TURN are enabled. <br/>
    * @return the nat v4 address.   <br/>
    */
    @Nullable
    public String getNatV6Address();

    /**
    * Set the mandatory v6 IP address to use with this NAT policy as server-reflexive<br/>
    * candidate for ICE. <br/>
    * <br/>
    * The IP address is used only if no stun server is set for server-reflexive<br/>
    * candidate gathering. Using this method is useful when Liblinphone is used in a<br/>
    * server product, when the server does not own the public IP address. Used when<br/>
    * STUN or TURN are enabled. <br/>
    * @param v4Address The STUN server to use with this NAT policy.   <br/>
    */
    public void setNatV6Address(@Nullable String v4Address);

    /**
    * Tell whether STUN is enabled. <br/>
    * <br/>
    * @return Boolean value telling whether STUN is enabled. <br/>
    */
    public boolean isStunEnabled();

    /**
    * Enable STUN. <br/>
    * <br/>
    * If TURN is also enabled, TURN will be used instead of STUN. <br/>
    * @param enable Boolean value telling whether to enable STUN. <br/>
    */
    public void setStunEnabled(boolean enable);

    /**
    * Get the STUN/TURN server to use with this NAT policy. <br/>
    * <br/>
    * Used when STUN or TURN are enabled. <br/>
    * @return The STUN server used by this NAT policy.   <br/>
    */
    @Nullable
    public String getStunServer();

    /**
    * Set the STUN/TURN server to use with this NAT policy. <br/>
    * <br/>
    * Used when STUN or TURN are enabled. <br/>
    * @param stunServer The STUN server to use with this NAT policy.   <br/>
    */
    public void setStunServer(@Nullable String stunServer);

    /**
    * Get the username used to authenticate with the STUN/TURN server. <br/>
    * <br/>
    * The authentication will search for a {@link AuthInfo} with this username. If it<br/>
    * is not set the username of the currently used {@link ProxyConfig} is used to<br/>
    * search for a LinphoneAuthInfo. <br/>
    * @return The username used to authenticate with the STUN/TURN server.   <br/>
    */
    @Nullable
    public String getStunServerUsername();

    /**
    * Set the username used to authenticate with the STUN/TURN server. <br/>
    * <br/>
    * The authentication will search for a {@link AuthInfo} with this username. If it<br/>
    * is not set the username of the currently used {@link ProxyConfig} is used to<br/>
    * search for a LinphoneAuthInfo. <br/>
    * @param username The username used to authenticate with the STUN/TURN server.   <br/>
    */
    public void setStunServerUsername(@Nullable String username);

    /**
    * Tells whether TCP TURN transport is enabled. <br/>
    * <br/>
    * Used when TURN is enabled. <br/>
    * @return Boolean value telling whether TCP TURN transport is enabled. <br/>
    */
    public boolean isTcpTurnTransportEnabled();

    /**
    * Enable TCP TURN transport. <br/>
    * <br/>
    * Used when TURN is enabled. <br/>
    * @param enable Boolean value telling whether to enable TCP TURN transport. <br/>
    */
    public void setTcpTurnTransportEnabled(boolean enable);

    /**
    * Tells whether TLS TURN transport is enabled. <br/>
    * <br/>
    * Used when TURN is enabled. <br/>
    * @return Boolean value telling whether TLS TURN transport is enabled. <br/>
    */
    public boolean isTlsTurnTransportEnabled();

    /**
    * Enable TLS TURN transport. <br/>
    * <br/>
    * Used when TURN is enabled. <br/>
    * @param enable Boolean value telling whether to enable TLS TURN transport. <br/>
    */
    public void setTlsTurnTransportEnabled(boolean enable);

    /**
    * Get the TURN configuration endpoint. <br/>
    * <br/>
    * @return The TURN configuration endpoint used by this NAT policy.   <br/>
    */
    @Nullable
    public String getTurnConfigurationEndpoint();

    /**
    * Set the TURN configuration endpoint. <br/>
    * <br/>
    * @param endpoint The TURN configuration endpoint to use with this NAT policy.   <br/>
    */
    public void setTurnConfigurationEndpoint(@Nullable String endpoint);

    /**
    * Tell whether TURN is enabled. <br/>
    * <br/>
    * @return Boolean value telling whether TURN is enabled. <br/>
    */
    public boolean isTurnEnabled();

    /**
    * Enable TURN. <br/>
    * <br/>
    * If STUN is also enabled, it is ignored and TURN is used. <br/>
    * @param enable Boolean value telling whether to enable TURN. <br/>
    */
    public void setTurnEnabled(boolean enable);

    /**
    * Tells whether UDP TURN transport is enabled. <br/>
    * <br/>
    * Used when TURN is enabled. <br/>
    * @return Boolean value telling whether UDP TURN transport is enabled. <br/>
    */
    public boolean isUdpTurnTransportEnabled();

    /**
    * Enable UDP TURN transport. <br/>
    * <br/>
    * Used when TURN is enabled. <br/>
    * @param enable Boolean value telling whether to enable UDP TURN transport. <br/>
    */
    public void setUdpTurnTransportEnabled(boolean enable);

    /**
    * Tell whether uPnP is enabled. <br/>
    * <br/>
    * @return Boolean value telling whether uPnP is enabled. <br/>
    */
    public boolean isUpnpEnabled();

    /**
    * Enable uPnP. <br/>
    * <br/>
    * This has the effect to disable every other policies (ICE, STUN and TURN). <br/>
    * @param enable Boolean value telling whether to enable uPnP. <br/>
    */
    public void setUpnpEnabled(boolean enable);

    /**
    * Clear a NAT policy (deactivate all protocols and unset the STUN server). <br/>
    * <br/>
    */
    public void clear();

    /**
    * Clone an existing {@link NatPolicy} object. <br/>
    * <br/>
    * @return A clone of the original {@link NatPolicy} object.   <br/>
    */
    @NonNull
    public NatPolicy clone();

    /**
    * Start a STUN server DNS resolution. <br/>
    * <br/>
    */
    public void resolveStunServer();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class NatPolicyImpl implements NatPolicy {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected NatPolicyImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native boolean isIceEnabled(long nativePtr);
    @Override
    synchronized public boolean isIceEnabled()  {
        synchronized(core) { 
        
        return isIceEnabled(nativePtr);
        }
    }

    private native void setIceEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setIceEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIceEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setIceEnabled(nativePtr, enable);
        }
    }

    private native String getNatV4Address(long nativePtr);
    @Override @Nullable
    synchronized public String getNatV4Address()  {
        synchronized(core) { 
        
        return getNatV4Address(nativePtr);
        }
    }

    private native void setNatV4Address(long nativePtr, String v4Address);
    @Override
    synchronized public void setNatV4Address(@Nullable String v4Address)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNatV4Address() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNatV4Address(nativePtr, v4Address);
        }
    }

    private native String getNatV6Address(long nativePtr);
    @Override @Nullable
    synchronized public String getNatV6Address()  {
        synchronized(core) { 
        
        return getNatV6Address(nativePtr);
        }
    }

    private native void setNatV6Address(long nativePtr, String v4Address);
    @Override
    synchronized public void setNatV6Address(@Nullable String v4Address)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNatV6Address() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNatV6Address(nativePtr, v4Address);
        }
    }

    private native boolean isStunEnabled(long nativePtr);
    @Override
    synchronized public boolean isStunEnabled()  {
        synchronized(core) { 
        
        return isStunEnabled(nativePtr);
        }
    }

    private native void setStunEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setStunEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStunEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStunEnabled(nativePtr, enable);
        }
    }

    private native String getStunServer(long nativePtr);
    @Override @Nullable
    synchronized public String getStunServer()  {
        synchronized(core) { 
        
        return getStunServer(nativePtr);
        }
    }

    private native void setStunServer(long nativePtr, String stunServer);
    @Override
    synchronized public void setStunServer(@Nullable String stunServer)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStunServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStunServer(nativePtr, stunServer);
        }
    }

    private native String getStunServerUsername(long nativePtr);
    @Override @Nullable
    synchronized public String getStunServerUsername()  {
        synchronized(core) { 
        
        return getStunServerUsername(nativePtr);
        }
    }

    private native void setStunServerUsername(long nativePtr, String username);
    @Override
    synchronized public void setStunServerUsername(@Nullable String username)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStunServerUsername() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStunServerUsername(nativePtr, username);
        }
    }

    private native boolean isTcpTurnTransportEnabled(long nativePtr);
    @Override
    synchronized public boolean isTcpTurnTransportEnabled()  {
        synchronized(core) { 
        
        return isTcpTurnTransportEnabled(nativePtr);
        }
    }

    private native void setTcpTurnTransportEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setTcpTurnTransportEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTcpTurnTransportEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTcpTurnTransportEnabled(nativePtr, enable);
        }
    }

    private native boolean isTlsTurnTransportEnabled(long nativePtr);
    @Override
    synchronized public boolean isTlsTurnTransportEnabled()  {
        synchronized(core) { 
        
        return isTlsTurnTransportEnabled(nativePtr);
        }
    }

    private native void setTlsTurnTransportEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setTlsTurnTransportEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsTurnTransportEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsTurnTransportEnabled(nativePtr, enable);
        }
    }

    private native String getTurnConfigurationEndpoint(long nativePtr);
    @Override @Nullable
    synchronized public String getTurnConfigurationEndpoint()  {
        synchronized(core) { 
        
        return getTurnConfigurationEndpoint(nativePtr);
        }
    }

    private native void setTurnConfigurationEndpoint(long nativePtr, String endpoint);
    @Override
    synchronized public void setTurnConfigurationEndpoint(@Nullable String endpoint)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTurnConfigurationEndpoint() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTurnConfigurationEndpoint(nativePtr, endpoint);
        }
    }

    private native boolean isTurnEnabled(long nativePtr);
    @Override
    synchronized public boolean isTurnEnabled()  {
        synchronized(core) { 
        
        return isTurnEnabled(nativePtr);
        }
    }

    private native void setTurnEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setTurnEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTurnEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTurnEnabled(nativePtr, enable);
        }
    }

    private native boolean isUdpTurnTransportEnabled(long nativePtr);
    @Override
    synchronized public boolean isUdpTurnTransportEnabled()  {
        synchronized(core) { 
        
        return isUdpTurnTransportEnabled(nativePtr);
        }
    }

    private native void setUdpTurnTransportEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setUdpTurnTransportEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUdpTurnTransportEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUdpTurnTransportEnabled(nativePtr, enable);
        }
    }

    private native boolean isUpnpEnabled(long nativePtr);
    @Override
    synchronized public boolean isUpnpEnabled()  {
        synchronized(core) { 
        
        return isUpnpEnabled(nativePtr);
        }
    }

    private native void setUpnpEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setUpnpEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUpnpEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUpnpEnabled(nativePtr, enable);
        }
    }

    private native void clear(long nativePtr);
    @Override
    synchronized public void clear()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clear() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clear(nativePtr);
        }
    }

    private native NatPolicy clone(long nativePtr);
    @Override @NonNull
    synchronized public NatPolicy clone()  {
        synchronized(core) { 
        
        return (NatPolicy)clone(nativePtr);
        }
    }

    private native void resolveStunServer(long nativePtr);
    @Override
    synchronized public void resolveStunServer()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call resolveStunServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        resolveStunServer(nativePtr);
        }
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
