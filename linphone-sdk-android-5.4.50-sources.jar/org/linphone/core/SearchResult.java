/*
SearchResult.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* The {@link SearchResult} object represents a result of a search initiated from<br/>
* a {@link MagicSearch}. <br/>
* <br/>
*/
public interface SearchResult {
    /**
    * Gets the address of the search result if any. <br/>
    * <br/>
    * @return The associed {@link Address} or null.   <br/>
    */
    @Nullable
    public Address getAddress();

    /**
    * Returns the capabilities mask of the search result. <br/>
    * <br/>
    * @return the capabilities mask associated to the search result <br/>
    */
    public int getCapabilities();

    /**
    * Gets the friend of the search result if any. <br/>
    * <br/>
    * @return The associated {@link Friend} or null.   <br/>
    */
    @Nullable
    public Friend getFriend();

    /**
    * Gets the phone number of the search result if any. <br/>
    * <br/>
    * @return The associed phone number or null.   <br/>
    */
    @Nullable
    public String getPhoneNumber();

    /**
    * Gets source flags of the search result. <br/>
    * <br/>
    * @return the source flags from {@link MagicSearch#Source} <br/>
    */
    public int getSourceFlags();

    /**
    * Gets the weight of the search result. <br/>
    * <br/>
    * @return the result weight <br/>
    */
    public int getWeight();

    /**
    * Returns whether or not the search result has the given capability. <br/>
    * <br/>
    * @param capability the {@link Friend#Capability} to check <br/>
    * @return true if it has the capability, false otherwise. <br/>
    */
    public boolean hasCapability(Friend.Capability capability);

    /**
    * Returns whether or not the search result has the given source flag. <br/>
    * <br/>
    * @param source the {@link MagicSearch#Source} to check <br/>
    * @return true if it has the source flag, false otherwise. <br/>
    */
    public boolean hasSourceFlag(MagicSearch.Source source);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class SearchResultImpl implements SearchResult {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected SearchResultImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Address getAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getAddress()  {
        
        
        return (Address)getAddress(nativePtr);
    }

    private native int getCapabilities(long nativePtr);
    @Override
    synchronized public int getCapabilities()  {
        
        
        return getCapabilities(nativePtr);
    }

    private native Friend getFriend(long nativePtr);
    @Override @Nullable
    synchronized public Friend getFriend()  {
        
        
        return (Friend)getFriend(nativePtr);
    }

    private native String getPhoneNumber(long nativePtr);
    @Override @Nullable
    synchronized public String getPhoneNumber()  {
        
        
        return getPhoneNumber(nativePtr);
    }

    private native int getSourceFlags(long nativePtr);
    @Override
    synchronized public int getSourceFlags()  {
        
        
        return getSourceFlags(nativePtr);
    }

    private native int getWeight(long nativePtr);
    @Override
    synchronized public int getWeight()  {
        
        
        return getWeight(nativePtr);
    }

    private native boolean hasCapability(long nativePtr, int capability);
    @Override
    synchronized public boolean hasCapability(Friend.Capability capability)  {
        
        
        return hasCapability(nativePtr, capability.toInt());
    }

    private native boolean hasSourceFlag(long nativePtr, int source);
    @Override
    synchronized public boolean hasSourceFlag(MagicSearch.Source source)  {
        
        
        return hasSourceFlag(nativePtr, source.toInt());
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
