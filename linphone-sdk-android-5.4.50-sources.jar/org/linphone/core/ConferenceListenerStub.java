/*
ConferenceListenerStub.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

public class ConferenceListenerStub implements ConferenceListener {
    @Override
    public void onAllowedParticipantListChanged(@NonNull Conference conference) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantAdded(@NonNull Conference conference, @NonNull Participant participant) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantRemoved(@NonNull Conference conference, @NonNull Participant participant) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceAdded(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceRemoved(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceJoiningRequest(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantRoleChanged(@NonNull Conference conference, @NonNull Participant participant) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantAdminStatusChanged(@NonNull Conference conference, @NonNull Participant participant) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceStateChanged(@NonNull Conference conference, @NonNull ParticipantDevice device, ParticipantDevice.State state) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceScreenSharingChanged(@NonNull Conference conference, @NonNull ParticipantDevice device, boolean enabled) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceMediaAvailabilityChanged(@NonNull Conference conference, @NonNull ParticipantDevice device) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceMediaCapabilityChanged(@NonNull Conference conference, @NonNull ParticipantDevice device) {
        // Auto-generated method stub
    }

    @Override
    public void onStateChanged(@NonNull Conference conference, Conference.State newState) {
        // Auto-generated method stub
    }

    @Override
    public void onAvailableMediaChanged(@NonNull Conference conference) {
        // Auto-generated method stub
    }

    @Override
    public void onSubjectChanged(@NonNull Conference conference, @NonNull String subject) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceIsSpeakingChanged(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice, boolean isSpeaking) {
        // Auto-generated method stub
    }

    @Override
    public void onParticipantDeviceIsMuted(@NonNull Conference conference, @NonNull ParticipantDevice participantDevice, boolean isMuted) {
        // Auto-generated method stub
    }

    @Override
    public void onAudioDeviceChanged(@NonNull Conference conference, @NonNull AudioDevice audioDevice) {
        // Auto-generated method stub
    }

    @Override
    public void onActiveSpeakerParticipantDevice(@NonNull Conference conference, @Nullable ParticipantDevice participantDevice) {
        // Auto-generated method stub
    }

    @Override
    public void onFullStateReceived(@NonNull Conference conference) {
        // Auto-generated method stub
    }

}