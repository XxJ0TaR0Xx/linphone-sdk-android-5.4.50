/*
CallLog.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object used to keep track of all calls initiated, received or missed. <br/>
* <br/>
* It contains the call ID, date & time at which the call took place and it's<br/>
* duration (0 if it wasn't answered). You can also know if video was enabled or<br/>
* not or if it was a conference, as well as it's average quality.<br/>
* If needed, you can also create a fake {@link CallLog} using {@link Core#createCallLog}<br/>
* , otherwise use {@link Core#getCallLogs} or even {@link Call#getCallLog} to get<br/>
* the log of an ongoing call. <br/>
*/
public interface CallLog {
    /**
    * Gets the call ID used by the call. <br/>
    * <br/>
    * @return The call ID used by the call as a string.   <br/>
    */
    @Nullable
    public String getCallId();

    /**
    * Returns the chat room associated with this call-log, if any. <br/>
    * <br/>
    * This method is typically useful in order to retrieve an IM conversation<br/>
    * associated with a past conference call. <br/>
    * @return The {@link ChatRoom} associated.   <br/>
    */
    @Nullable
    public ChatRoom getChatRoom();

    /**
    * Retrieves the conference info associated to this call log in DB. <br/>
    * <br/>
    * @return The {@link ConferenceInfo} associated.   <br/>
    */
    @Nullable
    public ConferenceInfo getConferenceInfo();

    /**
    * Gets the direction of the call. <br/>
    * <br/>
    * @return The {@link Call#Dir} of the call. <br/>
    */
    public Call.Dir getDir();

    /**
    * Gets the duration of the call since it was connected. <br/>
    * <br/>
    * @return The duration of the call in seconds. <br/>
    */
    public int getDuration();

    /**
    * When the call was failed, return an object describing the failure. <br/>
    * <br/>
    * @return {@link ErrorInfo} about the error encountered by the call associated<br/>
    * with this call log or null.   <br/>
    */
    @Nullable
    public ErrorInfo getErrorInfo();

    /**
    * Gets the origin address (ie from) of the call. <br/>
    * <br/>
    * @return The origin {@link Address} (ie from) of the call.   <br/>
    */
    @NonNull
    public Address getFromAddress();

    /**
    * Gets the local address (that is from or to depending on call direction) <br/>
    * <br/>
    * @return The local {@link Address} of the call   <br/>
    */
    @NonNull
    public Address getLocalAddress();

    /**
    * Gets the overall quality indication of the call. <br/>
    * <br/>
    * see: {@link Call#getCurrentQuality} <br/>
    * @return The overall quality indication of the call. <br/>
    */
    public float getQuality();

    /**
    * Gets the persistent reference key associated to the call log. <br/>
    * <br/>
    * The reference key can be for example an id to an external database. It is<br/>
    * stored in the config file, thus can survive to process exits/restarts.<br/>
    * @return The reference key string that has been associated to the call log, or<br/>
    * null if none has been associated.    <br/>
    */
    @Nullable
    public String getRefKey();

    /**
    * Associates a persistent reference key to the call log. <br/>
    * <br/>
    * The reference key can be for example an id to an external database. It is<br/>
    * stored in the config file, thus can survive to process exits/restarts.<br/>
    * @param refkey The reference key string to associate to the call log.   <br/>
    */
    public void setRefKey(@Nullable String refkey);

    /**
    * Gets the remote address (that is from or to depending on call direction). <br/>
    * <br/>
    * @return The remote {@link Address} of the call.   <br/>
    */
    @NonNull
    public Address getRemoteAddress();

    /**
    * Sets the remote address (that is 'from' or 'to' depending on call direction). <br/>
    * <br/>
    * It allows to fill more information that the SDK doesn't have. A use case can be<br/>
    * to fill the display name (coming from an external address book) into a call log<br/>
    * on incoming call. When the call end, the database will take account of the new<br/>
    * information and can be used later <br/>
    * @param address {@link Address} object   <br/>
    */
    public void setRemoteAddress(@NonNull Address address);

    /**
    * Gets the start date of the call. <br/>
    * <br/>
    * @return The date of the beginning of the call. <br/>
    */
    public long getStartDate();

    /**
    * Gets the status of the call. <br/>
    * <br/>
    * @return The {@link Call#Status} of the call. <br/>
    */
    public Call.Status getStatus();

    /**
    * Gets the destination address (ie to) of the call. <br/>
    * <br/>
    * @return The destination {@link Address} (ie to) of the call.   <br/>
    */
    @NonNull
    public Address getToAddress();

    /**
    * Tells whether video was enabled at the end of the call or not. <br/>
    * <br/>
    * @return A boolean value telling whether video was enabled at the end of the<br/>
    * call. <br/>
    */
    public boolean isVideoEnabled();

    /**
    * Gets a human readable string describing the call. <br/>
    * <br/>
    * note: : the returned string must be freed by the application (use ms_free()). <br/>
    * @return A human readable string describing the call.     <br/>
    */
    @NonNull
    public String toStr();

    /**
    * Tells whether that call was part of a conference. <br/>
    * <br/>
    * @return true if the call was part of a conference, false otherwise. <br/>
    */
    public boolean wasConference();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class CallLogImpl implements CallLog {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected CallLogImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getCallId(long nativePtr);
    @Override @Nullable
    synchronized public String getCallId()  {
        
        
        return getCallId(nativePtr);
    }

    private native ChatRoom getChatRoom(long nativePtr);
    @Override @Nullable
    synchronized public ChatRoom getChatRoom()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getChatRoom() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatRoom)getChatRoom(nativePtr);
    }

    private native ConferenceInfo getConferenceInfo(long nativePtr);
    @Override @Nullable
    synchronized public ConferenceInfo getConferenceInfo()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getConferenceInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceInfo)getConferenceInfo(nativePtr);
    }

    private native int getDir(long nativePtr);
    @Override
    synchronized public Call.Dir getDir()  {
        
        
        return Call.Dir.fromInt(getDir(nativePtr));
    }

    private native int getDuration(long nativePtr);
    @Override
    synchronized public int getDuration()  {
        
        
        return getDuration(nativePtr);
    }

    private native ErrorInfo getErrorInfo(long nativePtr);
    @Override @Nullable
    synchronized public ErrorInfo getErrorInfo()  {
        
        
        return (ErrorInfo)getErrorInfo(nativePtr);
    }

    private native Address getFromAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getFromAddress()  {
        
        
        return (Address)getFromAddress(nativePtr);
    }

    private native Address getLocalAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getLocalAddress()  {
        
        
        return (Address)getLocalAddress(nativePtr);
    }

    private native float getQuality(long nativePtr);
    @Override
    synchronized public float getQuality()  {
        
        
        return getQuality(nativePtr);
    }

    private native String getRefKey(long nativePtr);
    @Override @Nullable
    synchronized public String getRefKey()  {
        
        
        return getRefKey(nativePtr);
    }

    private native void setRefKey(long nativePtr, String refkey);
    @Override
    synchronized public void setRefKey(@Nullable String refkey)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRefKey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRefKey(nativePtr, refkey);
    }

    private native Address getRemoteAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getRemoteAddress()  {
        
        
        return (Address)getRemoteAddress(nativePtr);
    }

    private native void setRemoteAddress(long nativePtr, Address address);
    @Override
    synchronized public void setRemoteAddress(@NonNull Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRemoteAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRemoteAddress(nativePtr, address);
    }

    private native long getStartDate(long nativePtr);
    @Override
    synchronized public long getStartDate()  {
        
        
        return getStartDate(nativePtr);
    }

    private native int getStatus(long nativePtr);
    @Override
    synchronized public Call.Status getStatus()  {
        
        
        return Call.Status.fromInt(getStatus(nativePtr));
    }

    private native Address getToAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getToAddress()  {
        
        
        return (Address)getToAddress(nativePtr);
    }

    private native boolean isVideoEnabled(long nativePtr);
    @Override
    synchronized public boolean isVideoEnabled()  {
        
        
        return isVideoEnabled(nativePtr);
    }

    private native String toStr(long nativePtr);
    @Override @NonNull
    synchronized public String toStr()  {
        
        
        return toStr(nativePtr);
    }

    private native boolean wasConference(long nativePtr);
    @Override
    synchronized public boolean wasConference()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call wasConference() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return wasConference(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
