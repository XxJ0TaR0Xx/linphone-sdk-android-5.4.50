/*
SrtpSuite.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum describing type of SRTP encryption suite. <br/>
* <br/>
*/
public enum SrtpSuite {
    /**
    * <br/>
    */
    AESCM128HMACSHA180(0),

    /**
    * <br/>
    */
    AESCM128HMACSHA132(1),

    /**
    * <br/>
    */
    AES192CMHMACSHA180(2),

    /**
    * <br/>
    */
    AES192CMHMACSHA132(3),

    /**
    * <br/>
    */
    AES256CMHMACSHA180(4),

    /**
    * <br/>
    */
    AES256CMHMACSHA132(5),

    /**
    * <br/>
    */
    AEADAES128GCM(6),

    /**
    * <br/>
    */
    AEADAES256GCM(7),

    /**
    * <br/>
    */
    Invalid(255);

    protected final int mValue;

    private SrtpSuite (int value) {
        mValue = value;
    }

    static public SrtpSuite fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return AESCM128HMACSHA180;
        case 1: return AESCM128HMACSHA132;
        case 2: return AES192CMHMACSHA180;
        case 3: return AES192CMHMACSHA132;
        case 4: return AES256CMHMACSHA180;
        case 5: return AES256CMHMACSHA132;
        case 6: return AEADAES128GCM;
        case 7: return AEADAES256GCM;
        case 255: return Invalid;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for SrtpSuite");
        }
    }
    
    static protected SrtpSuite[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        SrtpSuite[] enumArray = new SrtpSuite[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = SrtpSuite.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(SrtpSuite[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
