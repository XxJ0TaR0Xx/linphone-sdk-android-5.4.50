/*
Reason.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum describing various failure reasons or contextual information for some<br/>
* events. <br/>
* <br/>
* see: {@link Call#getReason} <br/>
* see: {@link ProxyConfig#getError} <br/>
* see: {@link ErrorInfo#getReason} <br/>
*/
public enum Reason {
    /**
    * No reason has been set by the core. <br/>
    * <br/>
    */
    None(0),

    /**
    * No response received from remote. <br/>
    * <br/>
    */
    NoResponse(1),

    /**
    * Authentication failed due to bad credentials or resource forbidden. <br/>
    * <br/>
    */
    Forbidden(2),

    /**
    * The call has been declined. <br/>
    * <br/>
    */
    Declined(3),

    /**
    * Destination of the call was not found. <br/>
    * <br/>
    */
    NotFound(4),

    /**
    * The call was not answered in time (request timeout) <br/>
    * <br/>
    */
    NotAnswered(5),

    /**
    * Phone line was busy. <br/>
    * <br/>
    */
    Busy(6),

    /**
    * Unsupported content. <br/>
    * <br/>
    */
    UnsupportedContent(7),

    /**
    * Bad event. <br/>
    * <br/>
    */
    BadEvent(8),

    /**
    * Transport error: connection failures, disconnections etc... <br/>
    * <br/>
    */
    IOError(9),

    /**
    * Do not disturb reason. <br/>
    * <br/>
    */
    DoNotDisturb(10),

    /**
    * Operation is unauthorized because missing credential. <br/>
    * <br/>
    */
    Unauthorized(11),

    /**
    * Operation is rejected due to incompatible or unsupported media parameters. <br/>
    * <br/>
    */
    NotAcceptable(12),

    /**
    * Operation could not be executed by server or remote client because it didn't<br/>
    * have any context for it. <br/>
    * <br/>
    */
    NoMatch(13),

    /**
    * Resource moved permanently. <br/>
    * <br/>
    */
    MovedPermanently(14),

    /**
    * Resource no longer exists. <br/>
    * <br/>
    */
    Gone(15),

    /**
    * Temporarily unavailable. <br/>
    * <br/>
    */
    TemporarilyUnavailable(16),

    /**
    * Address incomplete. <br/>
    * <br/>
    */
    AddressIncomplete(17),

    /**
    * Not implemented. <br/>
    * <br/>
    */
    NotImplemented(18),

    /**
    * Bad gateway. <br/>
    * <br/>
    */
    BadGateway(19),

    /**
    * The received request contains a Session-Expires header field with a duration<br/>
    * below the minimum timer. <br/>
    * <br/>
    */
    SessionIntervalTooSmall(20),

    /**
    * Server timeout. <br/>
    * <br/>
    */
    ServerTimeout(21),

    /**
    * Unknown reason. <br/>
    * <br/>
    */
    Unknown(22),

    /**
    * The call has been transferred. <br/>
    * <br/>
    */
    Transferred(23),

    /**
    * Conditional Request Failed. <br/>
    * <br/>
    */
    ConditionalRequestFailed(24),

    /**
    * <br/>
    */
    SasCheckRequired(25);

    protected final int mValue;

    private Reason (int value) {
        mValue = value;
    }

    static public Reason fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return None;
        case 1: return NoResponse;
        case 2: return Forbidden;
        case 3: return Declined;
        case 4: return NotFound;
        case 5: return NotAnswered;
        case 6: return Busy;
        case 7: return UnsupportedContent;
        case 8: return BadEvent;
        case 9: return IOError;
        case 10: return DoNotDisturb;
        case 11: return Unauthorized;
        case 12: return NotAcceptable;
        case 13: return NoMatch;
        case 14: return MovedPermanently;
        case 15: return Gone;
        case 16: return TemporarilyUnavailable;
        case 17: return AddressIncomplete;
        case 18: return NotImplemented;
        case 19: return BadGateway;
        case 20: return SessionIntervalTooSmall;
        case 21: return ServerTimeout;
        case 22: return Unknown;
        case 23: return Transferred;
        case 24: return ConditionalRequestFailed;
        case 25: return SasCheckRequired;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for Reason");
        }
    }
    
    static protected Reason[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        Reason[] enumArray = new Reason[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = Reason.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(Reason[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
