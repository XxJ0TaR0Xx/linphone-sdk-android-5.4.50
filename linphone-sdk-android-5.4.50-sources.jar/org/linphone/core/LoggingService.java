/*
LoggingService.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Singleton class giving access to logging features. <br/>
* <br/>
* It supports custom domain, writing into a file as well as several verbosity<br/>
* levels. The {@link LoggingServiceListener} listener allows you to be notified<br/>
* each time a log is printed.<br/>
* As the {@link LoggingService} is a singleton, use {@link #get} to get it. <br/>
*/
public interface LoggingService {
    /**
    * Get the domain where application logs are written (for example with {@link #message}<br/>
    * ). <br/>
    * <br/>
    * @return The domain where application logs are written.   <br/>
    */
    @Nullable
    public String getDomain();

    /**
    * Set the domain where application logs are written (for example with {@link #message}<br/>
    * ). <br/>
    * <br/>
    * @param domain The domain.   <br/>
    * note: The domain is mandatory to write logs. This needs to be set before<br/>
    * setting the log level. <br/>
    */
    public void setDomain(@Nullable String domain);

    /**
    * Set the verbosity of the log. <br/>
    * <br/>
    * For instance, a level of {@link LogLevel#Message} will let pass fatal, error,<br/>
    * warning and message-typed messages whereas trace and debug messages will be<br/>
    * dumped out. <br/>
    * @param level the {@link LogLevel} to set <br/>
    */
    public void setLogLevel(LogLevel level);

    /**
    * Gets the log level mask. <br/>
    * <br/>
    * @return the log level mask <br/>
    */
    public int getLogLevelMask();

    /**
    * Sets the types of messages that will be authorized to be written in the log. <br/>
    * <br/>
    * @param mask Example: {@link LogLevel#Message}|{@link LogLevel#Error} will ONLY<br/>
    * let pass message-typed and error messages. <br/>
    * note: Calling that function reset the log level that has been specified by<br/>
    * {@link #setLogLevel}. <br/>
    */
    public void setLogLevelMask(int mask);

    /**
    * Allow Linphone to set handlers for catching exceptions and write the stack<br/>
    * trace into log. <br/>
    * <br/>
    * Available for Windows. It keeps old handlers. <br/>
    * @param enable if true global handlers will be prepend by the logger handlers.<br/>
    * By default, it is false. <br/>
    */
    public void setStackTraceDumpsEnabled(boolean enable);

    /**
    * Write a LinphoneLogLevelDebug message to the logs. <br/>
    * <br/>
    * @param message The log message.   <br/>
    */
    public void debug(@NonNull String message);

    /**
    * Write a LinphoneLogLevelError message to the logs. <br/>
    * <br/>
    * @param message The log message.   <br/>
    */
    public void error(@NonNull String message);

    /**
    * Write a LinphoneLogLevelFatal message to the logs. <br/>
    * <br/>
    * @param message The log message.   <br/>
    */
    public void fatal(@NonNull String message);

    /**
    * Write a LinphoneLogLevelMessage message to the logs. <br/>
    * <br/>
    * @param message The log message.   <br/>
    */
    public void message(@NonNull String message);

    /**
    * Enables logging in a file. <br/>
    * <br/>
    * That function enables an internal log handler that writes log messages in<br/>
    * log-rotated files.<br/>
    * @param dir Directory where to create the distinct parts of the log.   <br/>
    * @param filename Name of the log file.   <br/>
    * @param maxSize The maximal size of each part of the log. The log rotating is<br/>
    * triggered each time the currently opened log part reach that limit. <br/>
    */
    public void setLogFile(@NonNull String dir, @NonNull String filename, int maxSize);

    /**
    * Write a LinphoneLogLevelTrace message to the logs. <br/>
    * <br/>
    * @param message The log message.   <br/>
    */
    public void trace(@NonNull String message);

    /**
    * Write a LinphoneLogLevelWarning message to the logs. <br/>
    * <br/>
    * @param message The log message.   <br/>
    */
    public void warning(@NonNull String message);

    /**
    * Gets the singleton logging service object. <br/>
    * <br/>
    * The singleton is automatically instantiated if it hasn't been done yet.<br/>
    * @return A pointer on the {@link LoggingService} singleton.   <br/>
    */
    @NonNull
    public LoggingService get();

    /**
    */
    public void addListener(LoggingServiceListener listener);

    /**
    */
    public void removeListener(LoggingServiceListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class LoggingServiceImpl implements LoggingService {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected LoggingServiceImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getDomain(long nativePtr);
    @Override @Nullable
    synchronized public String getDomain()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDomain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDomain(nativePtr);
    }

    private native void setDomain(long nativePtr, String domain);
    @Override
    synchronized public void setDomain(@Nullable String domain)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDomain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDomain(nativePtr, domain);
    }

    private native void setLogLevel(long nativePtr, int level);
    @Override
    synchronized public void setLogLevel(LogLevel level)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLogLevel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLogLevel(nativePtr, level.toInt());
    }

    private native int getLogLevelMask(long nativePtr);
    @Override
    synchronized public int getLogLevelMask()  {
        
        
        return getLogLevelMask(nativePtr);
    }

    private native void setLogLevelMask(long nativePtr, int mask);
    @Override
    synchronized public void setLogLevelMask(int mask)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLogLevelMask() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLogLevelMask(nativePtr, mask);
    }

    private native void setStackTraceDumpsEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setStackTraceDumpsEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStackTraceDumpsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStackTraceDumpsEnabled(nativePtr, enable);
    }

    private native void debug(long nativePtr, String message);
    @Override
    synchronized public void debug(@NonNull String message)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call debug() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        debug(nativePtr, message);
    }

    private native void error(long nativePtr, String message);
    @Override
    synchronized public void error(@NonNull String message)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call error() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        error(nativePtr, message);
    }

    private native void fatal(long nativePtr, String message);
    @Override
    synchronized public void fatal(@NonNull String message)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call fatal() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        fatal(nativePtr, message);
    }

    private native void message(long nativePtr, String message);
    @Override
    synchronized public void message(@NonNull String message)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call message() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        message(nativePtr, message);
    }

    private native void setLogFile(long nativePtr, String dir, String filename, int maxSize);
    @Override
    synchronized public void setLogFile(@NonNull String dir, @NonNull String filename, int maxSize)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLogFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLogFile(nativePtr, dir, filename, maxSize);
    }

    private native void trace(long nativePtr, String message);
    @Override
    synchronized public void trace(@NonNull String message)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call trace() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        trace(nativePtr, message);
    }

    private native void warning(long nativePtr, String message);
    @Override
    synchronized public void warning(@NonNull String message)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call warning() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        warning(nativePtr, message);
    }

    private native LoggingService get(long nativePtr);
    @Override @NonNull
    synchronized public LoggingService get()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call get() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (LoggingService)get(nativePtr);
    }

    private native void addListener(long nativePtr, LoggingServiceListener listener);
    @Override
    synchronized public void addListener(LoggingServiceListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, LoggingServiceListener listener);
    @Override
    synchronized public void removeListener(LoggingServiceListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
