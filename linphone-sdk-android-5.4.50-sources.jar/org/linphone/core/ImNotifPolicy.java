/*
ImNotifPolicy.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Policy to use to send/receive instant messaging composing/delivery/display<br/>
* notifications. <br/>
* <br/>
* The sending of this information is done as in the RFCs 3994 (is_composing) and<br/>
* 5438 (imdn delivered/displayed). <br/>
*/
public interface ImNotifPolicy {
    /**
    * Tell whether imdn delivered notifications are being notified when received. <br/>
    * <br/>
    * @return Boolean value telling whether imdn delivered notifications are being<br/>
    * notified when received. <br/>
    */
    public boolean getRecvImdnDelivered();

    /**
    * Enable imdn delivered notifications receiving. <br/>
    * <br/>
    * @param enable Boolean value telling whether to notify received imdn delivered<br/>
    * notifications. <br/>
    */
    public void setRecvImdnDelivered(boolean enable);

    /**
    * Tell whether imdn delivery error notifications are being notified when<br/>
    * received. <br/>
    * <br/>
    * @return Boolean value telling whether imdn delivery error notifications are<br/>
    * being notified when received. <br/>
    */
    public boolean getRecvImdnDeliveryError();

    /**
    * Enable imdn delivery error notifications receiving. <br/>
    * <br/>
    * Note: Error IMDN must be enabled for Lime recovery mechanism <br/>
    * @param enable Boolean value telling whether to notify received imdn delivery<br/>
    * error notifications. <br/>
    */
    public void setRecvImdnDeliveryError(boolean enable);

    /**
    * Tell whether imdn displayed notifications are being notified when received. <br/>
    * <br/>
    * @return Boolean value telling whether imdn displayed notifications are being<br/>
    * notified when received. <br/>
    */
    public boolean getRecvImdnDisplayed();

    /**
    * Enable imdn displayed notifications receiving. <br/>
    * <br/>
    * @param enable Boolean value telling whether to notify received imdn displayed<br/>
    * notifications. <br/>
    */
    public void setRecvImdnDisplayed(boolean enable);

    /**
    * Tell whether is_composing notifications are being notified when received. <br/>
    * <br/>
    * @return Boolean value telling whether is_composing notifications are being<br/>
    * notified when received. <br/>
    */
    public boolean getRecvIsComposing();

    /**
    * Enable is_composing notifications receiving. <br/>
    * <br/>
    * @param enable Boolean value telling whether to notify received is_composing<br/>
    * notifications. <br/>
    */
    public void setRecvIsComposing(boolean enable);

    /**
    * Tell whether imdn delivered notifications are being sent. <br/>
    * <br/>
    * @return Boolean value telling whether imdn delivered notifications are being<br/>
    * sent. <br/>
    */
    public boolean getSendImdnDelivered();

    /**
    * Enable imdn delivered notifications sending. <br/>
    * <br/>
    * @param enable Boolean value telling whether to send imdn delivered<br/>
    * notifications. <br/>
    */
    public void setSendImdnDelivered(boolean enable);

    /**
    * Tell whether imdn delivery error notifications are being sent. <br/>
    * <br/>
    * @return Boolean value telling whether imdn delivery error notifications are<br/>
    * being sent. <br/>
    */
    public boolean getSendImdnDeliveryError();

    /**
    * Enable imdn delivery error notifications sending. <br/>
    * <br/>
    * Note: Error IMDN must be enabled for Lime recovery mechanism <br/>
    * @param enable Boolean value telling whether to send imdn delivery error<br/>
    * notifications. <br/>
    */
    public void setSendImdnDeliveryError(boolean enable);

    /**
    * Tell whether imdn displayed notifications are being sent. <br/>
    * <br/>
    * @return Boolean value telling whether imdn displayed notifications are being<br/>
    * sent. <br/>
    */
    public boolean getSendImdnDisplayed();

    /**
    * Enable imdn displayed notifications sending. <br/>
    * <br/>
    * @param enable Boolean value telling whether to send imdn displayed<br/>
    * notifications. <br/>
    */
    public void setSendImdnDisplayed(boolean enable);

    /**
    * Tell whether is_composing notifications are being sent. <br/>
    * <br/>
    * @return Boolean value telling whether is_composing notifications are being<br/>
    * sent. <br/>
    */
    public boolean getSendIsComposing();

    /**
    * Enable is_composing notifications sending. <br/>
    * <br/>
    * @param enable Boolean value telling whether to send is_composing notifications. <br/>
    */
    public void setSendIsComposing(boolean enable);

    /**
    * Clear an IM notif policy (deactivate all receiving and sending of<br/>
    * notifications). <br/>
    * <br/>
    * Note: Error IMDN must be enabled for Lime recovery mechanism <br/>
    */
    public void clear();

    /**
    * Enable all receiving and sending of notifications. <br/>
    * <br/>
    */
    public void enableAll();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ImNotifPolicyImpl implements ImNotifPolicy {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ImNotifPolicyImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native boolean getRecvImdnDelivered(long nativePtr);
    @Override
    synchronized public boolean getRecvImdnDelivered()  {
        
        
        return getRecvImdnDelivered(nativePtr);
    }

    private native void setRecvImdnDelivered(long nativePtr, boolean enable);
    @Override
    synchronized public void setRecvImdnDelivered(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRecvImdnDelivered() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRecvImdnDelivered(nativePtr, enable);
    }

    private native boolean getRecvImdnDeliveryError(long nativePtr);
    @Override
    synchronized public boolean getRecvImdnDeliveryError()  {
        
        
        return getRecvImdnDeliveryError(nativePtr);
    }

    private native void setRecvImdnDeliveryError(long nativePtr, boolean enable);
    @Override
    synchronized public void setRecvImdnDeliveryError(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRecvImdnDeliveryError() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRecvImdnDeliveryError(nativePtr, enable);
    }

    private native boolean getRecvImdnDisplayed(long nativePtr);
    @Override
    synchronized public boolean getRecvImdnDisplayed()  {
        
        
        return getRecvImdnDisplayed(nativePtr);
    }

    private native void setRecvImdnDisplayed(long nativePtr, boolean enable);
    @Override
    synchronized public void setRecvImdnDisplayed(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRecvImdnDisplayed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRecvImdnDisplayed(nativePtr, enable);
    }

    private native boolean getRecvIsComposing(long nativePtr);
    @Override
    synchronized public boolean getRecvIsComposing()  {
        
        
        return getRecvIsComposing(nativePtr);
    }

    private native void setRecvIsComposing(long nativePtr, boolean enable);
    @Override
    synchronized public void setRecvIsComposing(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRecvIsComposing() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRecvIsComposing(nativePtr, enable);
    }

    private native boolean getSendImdnDelivered(long nativePtr);
    @Override
    synchronized public boolean getSendImdnDelivered()  {
        
        
        return getSendImdnDelivered(nativePtr);
    }

    private native void setSendImdnDelivered(long nativePtr, boolean enable);
    @Override
    synchronized public void setSendImdnDelivered(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSendImdnDelivered() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSendImdnDelivered(nativePtr, enable);
    }

    private native boolean getSendImdnDeliveryError(long nativePtr);
    @Override
    synchronized public boolean getSendImdnDeliveryError()  {
        
        
        return getSendImdnDeliveryError(nativePtr);
    }

    private native void setSendImdnDeliveryError(long nativePtr, boolean enable);
    @Override
    synchronized public void setSendImdnDeliveryError(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSendImdnDeliveryError() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSendImdnDeliveryError(nativePtr, enable);
    }

    private native boolean getSendImdnDisplayed(long nativePtr);
    @Override
    synchronized public boolean getSendImdnDisplayed()  {
        
        
        return getSendImdnDisplayed(nativePtr);
    }

    private native void setSendImdnDisplayed(long nativePtr, boolean enable);
    @Override
    synchronized public void setSendImdnDisplayed(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSendImdnDisplayed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSendImdnDisplayed(nativePtr, enable);
    }

    private native boolean getSendIsComposing(long nativePtr);
    @Override
    synchronized public boolean getSendIsComposing()  {
        
        
        return getSendIsComposing(nativePtr);
    }

    private native void setSendIsComposing(long nativePtr, boolean enable);
    @Override
    synchronized public void setSendIsComposing(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSendIsComposing() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSendIsComposing(nativePtr, enable);
    }

    private native void clear(long nativePtr);
    @Override
    synchronized public void clear()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clear() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clear(nativePtr);
    }

    private native void enableAll(long nativePtr);
    @Override
    synchronized public void enableAll()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enableAll() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        enableAll(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
