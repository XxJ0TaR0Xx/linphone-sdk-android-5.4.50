/*
ChatParams.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object defining settings strictly associated with {@link ChatRoom} objects such<br/>
* as ephemeral settings and backends. <br/>
* <br/>
* It is automatically created when you enable chat capabilities in the {@link ConferenceParams}<br/>
* .<br/>
* If the {@link ChatRoom} backend is {@link ChatRoom#Backend#Basic}, then no<br/>
* other parameter is required, but {@link ChatMessage} sent and received won't<br/>
* benefit from all features a {@link ChatRoom#Backend#FlexisipChat} can offer<br/>
* like conversation with multiple participants and a subject, end-to-end<br/>
* encryption, ephemeral messages, etc... but this type is the only one that can<br/>
* interoperate with other SIP clients or with non-flexisip SIP proxies. <br/>
*/
public interface ChatParams {
    /**
    * Get the backend implementation of the text capabilities of the chat associated<br/>
    * with the given parameters. <br/>
    * <br/>
    * @return the {@link ChatRoom#Backend} <br/>
    */
    public ChatRoom.Backend getBackend();

    /**
    * Set the backend implementation of these text capabilities of the chat<br/>
    * parameters. <br/>
    * <br/>
    * @param backend The {@link ChatRoom#Backend} enum value <br/>
    */
    public void setBackend(ChatRoom.Backend backend);

    /**
    * Get the encryption implementation of the text capabilities of the chat<br/>
    * associated with the given parameters. <br/>
    * <br/>
    * @return the {@link ChatRoom#EncryptionBackend} <br/>
    */
    public ChatRoom.EncryptionBackend getEncryptionBackend();

    /**
    * Set the encryption backend implementation of these text capabilities of the<br/>
    * chat parameters. <br/>
    * <br/>
    * @param backend The {@link ChatRoom#EncryptionBackend} enum value <br/>
    */
    public void setEncryptionBackend(ChatRoom.EncryptionBackend backend);

    /**
    * Get the encryption status of the text capabilities of the chat associated with<br/>
    * the given parameters. <br/>
    * <br/>
    * @return true if encryption is enabled, false otherwise <br/>
    */
    public boolean isEncryptionEnabled();

    /**
    * Get lifetime (in seconds) for all new ephemeral messages in the text<br/>
    * capabilities of the chat. <br/>
    * <br/>
    * After the message is read, it will be deleted after "time" seconds. see:<br/>
    * linphone_chat_params_ephemeral_enabled() <br/>
    * @return the ephemeral lifetime (in seconds) <br/>
    */
    public long getEphemeralLifetime();

    /**
    * Set lifetime (in seconds) for all new ephemral messages in the text<br/>
    * capabilities of the chat. <br/>
    * <br/>
    * After the message is read, it will be deleted after "time" seconds. see:<br/>
    * linphone_chat_params_ephemeral_enabled() <br/>
    * @param time The ephemeral lifetime, default is disabled (0) <br/>
    */
    public void setEphemeralLifetime(long time);

    /**
    * Get the ephemeral message mode of the text capabilities of the chat associated<br/>
    * with the given parameters. <br/>
    * <br/>
    * @return the ephemeral message mode {@link ChatRoom#EphemeralMode} <br/>
    */
    public ChatRoom.EphemeralMode getEphemeralMode();

    /**
    * Enables or disables forcing of ephemeral messages for the text capabilities of<br/>
    * the chat associated with the given parameters. <br/>
    * <br/>
    * @param mode Ephemeral message mode {@link ChatRoom#EphemeralMode}. <br/>
    */
    public void setEphemeralMode(ChatRoom.EphemeralMode mode);

    /**
    * Get the real time text status of the text capabilities of the chat associated<br/>
    * with the given parameters. <br/>
    * <br/>
    * @return true if real time text is enabled, false otherwise <br/>
    */
    public boolean isRttEnabled();

    /**
    * Enables or disables real time text for the text capabilities of the chat<br/>
    * associated with the given parameters. <br/>
    * <br/>
    * @param rtt true to enable real time text, false to disable. <br/>
    */
    public void setRttEnabled(boolean rtt);

    /**
    * Clone a {@link ChatParams}. <br/>
    * <br/>
    * @return An allocated {@link ChatParams} with the same parameters than params   <br/>
    */
    @NonNull
    public ChatParams clone();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ChatParamsImpl implements ChatParams {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected ChatParamsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getBackend(long nativePtr);
    @Override
    synchronized public ChatRoom.Backend getBackend()  {
        
        
        return ChatRoom.Backend.fromInt(getBackend(nativePtr));
    }

    private native void setBackend(long nativePtr, int backend);
    @Override
    synchronized public void setBackend(ChatRoom.Backend backend)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBackend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBackend(nativePtr, backend.toInt());
    }

    private native int getEncryptionBackend(long nativePtr);
    @Override
    synchronized public ChatRoom.EncryptionBackend getEncryptionBackend()  {
        
        
        return ChatRoom.EncryptionBackend.fromInt(getEncryptionBackend(nativePtr));
    }

    private native void setEncryptionBackend(long nativePtr, int backend);
    @Override
    synchronized public void setEncryptionBackend(ChatRoom.EncryptionBackend backend)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEncryptionBackend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEncryptionBackend(nativePtr, backend.toInt());
    }

    private native boolean isEncryptionEnabled(long nativePtr);
    @Override
    synchronized public boolean isEncryptionEnabled()  {
        
        
        return isEncryptionEnabled(nativePtr);
    }

    private native long getEphemeralLifetime(long nativePtr);
    @Override
    synchronized public long getEphemeralLifetime()  {
        
        
        return getEphemeralLifetime(nativePtr);
    }

    private native void setEphemeralLifetime(long nativePtr, long time);
    @Override
    synchronized public void setEphemeralLifetime(long time)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEphemeralLifetime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEphemeralLifetime(nativePtr, time);
    }

    private native int getEphemeralMode(long nativePtr);
    @Override
    synchronized public ChatRoom.EphemeralMode getEphemeralMode()  {
        
        
        return ChatRoom.EphemeralMode.fromInt(getEphemeralMode(nativePtr));
    }

    private native void setEphemeralMode(long nativePtr, int mode);
    @Override
    synchronized public void setEphemeralMode(ChatRoom.EphemeralMode mode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEphemeralMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEphemeralMode(nativePtr, mode.toInt());
    }

    private native boolean isRttEnabled(long nativePtr);
    @Override
    synchronized public boolean isRttEnabled()  {
        
        
        return isRttEnabled(nativePtr);
    }

    private native void setRttEnabled(long nativePtr, boolean rtt);
    @Override
    synchronized public void setRttEnabled(boolean rtt)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRttEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRttEnabled(nativePtr, rtt);
    }

    private native ChatParams clone(long nativePtr);
    @Override @NonNull
    synchronized public ChatParams clone()  {
        
        
        return (ChatParams)clone(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
