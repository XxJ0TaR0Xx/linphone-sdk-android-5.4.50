/*
PresencePerson.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Presence person holding information about a presence person. <br/>
* <br/>
*/
public interface PresencePerson {
    /**
    * Gets the id of a presence person. <br/>
    * <br/>
    * @return A pointer to a dynamically allocated string containing the id, or null<br/>
    * in case of error.    <br/>
    * The returned string is to be freed by calling ms_free(). <br/>
    */
    @Nullable
    public String getId();

    /**
    * Sets the id of a presence person. <br/>
    * <br/>
    * @param id The id string to set. Can be null to generate it automatically.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int setId(@Nullable String id);

    /**
    * Gets the number of activities included in the presence person. <br/>
    * <br/>
    * @return The number of activities included in the {@link PresencePerson} object. <br/>
    */
    public int getNbActivities();

    /**
    * Gets the number of activities notes included in the presence person. <br/>
    * <br/>
    * @return The number of activities notes included in the {@link PresencePerson}<br/>
    * object. <br/>
    */
    public int getNbActivitiesNotes();

    /**
    * Gets the number of notes included in the presence person. <br/>
    * <br/>
    * @return The number of notes included in the {@link PresencePerson} object. <br/>
    */
    public int getNbNotes();

    /**
    * Adds an activities note to a presence person. <br/>
    * <br/>
    * @param note The {@link PresenceNote} object to add to the person.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int addActivitiesNote(@NonNull PresenceNote note);

    /**
    * Adds an activity to a presence person. <br/>
    * <br/>
    * @param activity The {@link PresenceActivity} object to add to the person.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int addActivity(@NonNull PresenceActivity activity);

    /**
    * Adds a note to a presence person. <br/>
    * <br/>
    * @param note The {@link PresenceNote} object to add to the person.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int addNote(@NonNull PresenceNote note);

    /**
    * Clears the activities of a presence person. <br/>
    * <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int clearActivities();

    /**
    * Clears the activities notes of a presence person. <br/>
    * <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int clearActivitiesNotes();

    /**
    * Clears the notes of a presence person. <br/>
    * <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int clearNotes();

    /**
    * Gets the nth activities note of a presence person. <br/>
    * <br/>
    * @param index The index of the activities note to get (the first note having the<br/>
    * index 0). <br/>
    * @return A pointer to a {@link PresenceNote} object if successful, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public PresenceNote getNthActivitiesNote(int index);

    /**
    * Gets the nth activity of a presence person. <br/>
    * <br/>
    * @param index The index of the activity to get (the first activity having the<br/>
    * index 0). <br/>
    * @return A pointer to a {@link PresenceActivity} object if successful, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public PresenceActivity getNthActivity(int index);

    /**
    * Gets the nth note of a presence person. <br/>
    * <br/>
    * @param index The index of the note to get (the first note having the index 0). <br/>
    * @return A pointer to a {@link PresenceNote} object if successful, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public PresenceNote getNthNote(int index);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class PresencePersonImpl implements PresencePerson {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected PresencePersonImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getId(long nativePtr);
    @Override @Nullable
    synchronized public String getId()  {
        
        
        return getId(nativePtr);
    }

    private native int setId(long nativePtr, String id);
    @Override
    synchronized public int setId(@Nullable String id)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setId(nativePtr, id);
    }

    private native int getNbActivities(long nativePtr);
    @Override
    synchronized public int getNbActivities()  {
        
        
        return getNbActivities(nativePtr);
    }

    private native int getNbActivitiesNotes(long nativePtr);
    @Override
    synchronized public int getNbActivitiesNotes()  {
        
        
        return getNbActivitiesNotes(nativePtr);
    }

    private native int getNbNotes(long nativePtr);
    @Override
    synchronized public int getNbNotes()  {
        
        
        return getNbNotes(nativePtr);
    }

    private native int addActivitiesNote(long nativePtr, PresenceNote note);
    @Override
    synchronized public int addActivitiesNote(@NonNull PresenceNote note)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addActivitiesNote() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addActivitiesNote(nativePtr, note);
    }

    private native int addActivity(long nativePtr, PresenceActivity activity);
    @Override
    synchronized public int addActivity(@NonNull PresenceActivity activity)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addActivity() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addActivity(nativePtr, activity);
    }

    private native int addNote(long nativePtr, PresenceNote note);
    @Override
    synchronized public int addNote(@NonNull PresenceNote note)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addNote() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addNote(nativePtr, note);
    }

    private native int clearActivities(long nativePtr);
    @Override
    synchronized public int clearActivities()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearActivities() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return clearActivities(nativePtr);
    }

    private native int clearActivitiesNotes(long nativePtr);
    @Override
    synchronized public int clearActivitiesNotes()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearActivitiesNotes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return clearActivitiesNotes(nativePtr);
    }

    private native int clearNotes(long nativePtr);
    @Override
    synchronized public int clearNotes()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearNotes() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return clearNotes(nativePtr);
    }

    private native PresenceNote getNthActivitiesNote(long nativePtr, int index);
    @Override @Nullable
    synchronized public PresenceNote getNthActivitiesNote(int index)  {
        
        
        return (PresenceNote)getNthActivitiesNote(nativePtr, index);
    }

    private native PresenceActivity getNthActivity(long nativePtr, int index);
    @Override @Nullable
    synchronized public PresenceActivity getNthActivity(int index)  {
        
        
        return (PresenceActivity)getNthActivity(nativePtr, index);
    }

    private native PresenceNote getNthNote(long nativePtr, int index);
    @Override @Nullable
    synchronized public PresenceNote getNthNote(int index)  {
        
        
        return (PresenceNote)getNthNote(nativePtr, index);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
