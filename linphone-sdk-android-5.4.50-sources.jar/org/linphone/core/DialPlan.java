/*
DialPlan.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Represents a dial plan. <br/>
* <br/>
*/
public interface DialPlan {
    /**
    * Returns the country name of the dialplan. <br/>
    * <br/>
    * @return the country name <br/>
    */
    public String getCountry();

    /**
    * Returns the country calling code of the dialplan. <br/>
    * <br/>
    * @return the country calling code   <br/>
    */
    @NonNull
    public String getCountryCallingCode();

    /**
    * Returns the flag of the teritory as unicode characters. <br/>
    * <br/>
    * @return the flag as unicode characters   <br/>
    */
    @NonNull
    public String getFlag();

    /**
    * Returns the international call prefix of the dialplan. <br/>
    * <br/>
    * @return the international call prefix   <br/>
    */
    @NonNull
    public String getInternationalCallPrefix();

    /**
    * Return if given plan is generic. <br/>
    * <br/>
    * @return true if generic, false otherwise <br/>
    */
    public boolean isGeneric();

    /**
    * Returns the iso country code of the dialplan. <br/>
    * <br/>
    * @return the iso country code   <br/>
    */
    @NonNull
    public String getIsoCountryCode();

    /**
    * Returns the national number length of the dialplan. <br/>
    * <br/>
    * @return the national number length <br/>
    */
    public int getNationalNumberLength();

    /**
    * Formats a phone number using dial plan informations. <br/>
    * <br/>
    * @param phoneNumber the phone number to format.   <br/>
    * @param escapePlus whether or not to use + or international calling prefix <br/>
    * @return the formatted phone number, or the original phone number if couldn't be<br/>
    * formatted for some reason.      <br/>
    */
    @NonNull
    public String formatPhoneNumber(@NonNull String phoneNumber, boolean escapePlus);

    /**
    * Find best match for given CCC. <br/>
    * <br/>
    * @param ccc The country calling code   <br/>
    * @return the matching dial plan, or a generic one if none found   <br/>
    */
    @NonNull
    public DialPlan byCcc(@NonNull String ccc);

    /**
    * Find best match for given CCC. <br/>
    * <br/>
    * @param ccc the country calling code   <br/>
    * @return the matching dial plan, or a generic one if none found   <br/>
    */
    @NonNull
    public DialPlan byCccAsInt(@NonNull int ccc);

    /**
    * Returns a list of all known dial plans. <br/>
    * <br/>
    * @return The list of all known dial plans.      <br/>
    */
    @NonNull
    public DialPlan[] getAllList();

    /**
    * Function to get call country code from an e164 number, ex: +33952650121 will<br/>
    * return 33. <br/>
    * <br/>
    * @param e164 phone number   <br/>
    * @return call country code or -1 if not found <br/>
    */
    public int lookupCccFromE164(@NonNull String e164);

    /**
    * Function to get call country code from ISO 3166-1 alpha-2 code, ex: FR returns<br/>
    * 33. <br/>
    * <br/>
    * @param iso country code alpha2   <br/>
    * @return call country code or -1 if not found <br/>
    */
    public int lookupCccFromIso(@NonNull String iso);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class DialPlanImpl implements DialPlan {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected DialPlanImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getCountry(long nativePtr);
    @Override
    synchronized public String getCountry()  {
        
        
        return getCountry(nativePtr);
    }

    private native String getCountryCallingCode(long nativePtr);
    @Override @NonNull
    synchronized public String getCountryCallingCode()  {
        
        
        return getCountryCallingCode(nativePtr);
    }

    private native String getFlag(long nativePtr);
    @Override @NonNull
    synchronized public String getFlag()  {
        
        
        return getFlag(nativePtr);
    }

    private native String getInternationalCallPrefix(long nativePtr);
    @Override @NonNull
    synchronized public String getInternationalCallPrefix()  {
        
        
        return getInternationalCallPrefix(nativePtr);
    }

    private native boolean isGeneric(long nativePtr);
    @Override
    synchronized public boolean isGeneric()  {
        
        
        return isGeneric(nativePtr);
    }

    private native String getIsoCountryCode(long nativePtr);
    @Override @NonNull
    synchronized public String getIsoCountryCode()  {
        
        
        return getIsoCountryCode(nativePtr);
    }

    private native int getNationalNumberLength(long nativePtr);
    @Override
    synchronized public int getNationalNumberLength()  {
        
        
        return getNationalNumberLength(nativePtr);
    }

    private native String formatPhoneNumber(long nativePtr, String phoneNumber, boolean escapePlus);
    @Override @NonNull
    synchronized public String formatPhoneNumber(@NonNull String phoneNumber, boolean escapePlus)  {
        
        
        return formatPhoneNumber(nativePtr, phoneNumber, escapePlus);
    }

    private native DialPlan byCcc(long nativePtr, String ccc);
    @Override @NonNull
    synchronized public DialPlan byCcc(@NonNull String ccc)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call byCcc() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (DialPlan)byCcc(nativePtr, ccc);
    }

    private native DialPlan byCccAsInt(long nativePtr, int ccc);
    @Override @NonNull
    synchronized public DialPlan byCccAsInt(@NonNull int ccc)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call byCccAsInt() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (DialPlan)byCccAsInt(nativePtr, ccc);
    }

    private native DialPlan[] getAllList(long nativePtr);
    @Override @NonNull
    synchronized public DialPlan[] getAllList()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getAllList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getAllList(nativePtr);
    }

    private native int lookupCccFromE1644(long nativePtr, String e164);
    @Override
    synchronized public int lookupCccFromE164(@NonNull String e164)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call lookupCccFromE164() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return lookupCccFromE1644(nativePtr, e164);
    }

    private native int lookupCccFromIso(long nativePtr, String iso);
    @Override
    synchronized public int lookupCccFromIso(@NonNull String iso)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call lookupCccFromIso() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return lookupCccFromIso(nativePtr, iso);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
