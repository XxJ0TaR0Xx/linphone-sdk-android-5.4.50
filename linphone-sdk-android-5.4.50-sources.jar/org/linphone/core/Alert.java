/*
Alert.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that represents an alert. <br/>
* <br/>
* Alerts are raised at run-time when particular conditions are met, for example<br/>
* bad network quality. The full list of available alert types is described by the<br/>
* {@link Type} enum. An application is notified of new alerts through the {@link CoreListener}<br/>
* interface. Once raised, the application may use the {@link AlertListener}<br/>
* interface to get notified when the alert stops. For each kind of alert, a<br/>
* {@link Dictionary} is filled with relevant informations, returned by {@link #getInformations}<br/>
* . The keys available are documented per-type in {@link Type} enum. <br/>
*/
public interface Alert {
    public enum Type {
        /**
        * Camera is not working. <br/>
        * <br/>
        * No other information note: Use the key "camera_misfunction_interval" in the<br/>
        * section "alerts::camera" to set the interval at which the problem is checked in<br/>
        * a {@link Config}. <br/>
        */
        QoSCameraMisfunction(0),

        /**
        * Camera is capturing low framerate. <br/>
        * <br/>
        * Information supplied : float framerate; note: Use the key<br/>
        * "low_framerate_interval" in the section "alerts::camera" to set or get the<br/>
        * interval at which the problem is checked in a {@link Config}. <br/>
        */
        QoSCameraLowFramerate(1),

        /**
        * Video decoding has stopped for a given period (10 s by default). <br/>
        * <br/>
        * No other information. note: Use the key "video_stalled_interval" in the section<br/>
        * "alerts::camera" to set or get the interval at which the problem is checked in<br/>
        * a {@link Config}. <br/>
        */
        QoSVideoStalled(2),

        /**
        * A received media stream suffers from high loss or late rate. <br/>
        * <br/>
        * Information provided is:<br/>
        */
        QoSHighLossLateRate(3),

        /**
        * A report of high loss rate is received from remote party. <br/>
        * <br/>
        * Information provided: loss-rate (float). note: Use the key<br/>
        * "remote_loss_rate_interval" in the section "alerts::network" to set or get the<br/>
        * interval at which the problem is checked in a {@link Config}. <br/>
        */
        QoSHighRemoteLossRate(4),

        /**
        * Packet Burst phenomenon. <br/>
        * <br/>
        * note: Use the key "burst_occured_interval" in the section "alerts::network" to<br/>
        * set or get the interval at which the problem is checked in a {@link Config}. <br/>
        */
        QoSBurstOccured(5),

        /**
        * Loss rate is significant but retransmissions fail to arrive on time. <br/>
        * <br/>
        * Information provided: nack-performance (float) the fraction of lost packets<br/>
        * recovered thanks to nack-triggered retransmissions. note: Use the key<br/>
        * "nack_check_interval" in the section "alerts::network" to set or get the<br/>
        * interval at which the problem is checked in a {@link Config}. <br/>
        */
        QoSRetransmissionFailures(6),

        /**
        * Low bandwidth detected. <br/>
        * <br/>
        * Information provided: bandwidth (float) in kbit/s. note: Use the key<br/>
        * "download_bandwidth_interval" in the section "alerts::video" to set or get the<br/>
        * interval at which the problem is checked in a {@link Config}. <br/>
        */
        QoSLowDownloadBandwidthEstimation(7),

        /**
        * Low quality (bitrate) video received. <br/>
        * <br/>
        * Information provided: bitrate (float) in kbit/s, width (integer), int height<br/>
        * (integer). note: Use the key "low_quality_received_interval" in the section<br/>
        * "alerts::video" to set or get the interval at which the problem is checked in a<br/>
        * {@link Config}. <br/>
        */
        QoSLowQualityReceivedVideo(8),

        /**
        * Low quality video is being sent. <br/>
        * <br/>
        * Information provided: bitrate (float)in kbit/s, width (integer), height<br/>
        * (integer). note: Use the key "quality_sent_interval" in the section<br/>
        * "alerts::camera" to set or get the interval at which the problem is checked in<br/>
        * a {@link Config}. <br/>
        */
        QoSLowQualitySentVideo(9),

        /**
        * The operating system reports a low radio signal (wifi or mobile) <br/>
        * <br/>
        * note: Use the key "low_signal_interval" in the section "alerts::network" to set<br/>
        * or get the interval at which the problem is checked in a {@link Config}. <br/>
        */
        QoSLowSignal(10),

        /**
        * The operating system reports a loss of radio signal (wifi or mobile). <br/>
        * <br/>
        * Information provided: rssi-value (float), signal-type (string) with values<br/>
        * {"wifi", "mobile", "other"}. note: Use the key "lost_signal_interval" in the<br/>
        * section "alerts::network" to set or get the interval at which the problem is<br/>
        * checked in a {@link Config}. <br/>
        */
        QoSLostSignal(11);

        protected final int mValue;

        private Type (int value) {
            mValue = value;
        }

        static public Type fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return QoSCameraMisfunction;
            case 1: return QoSCameraLowFramerate;
            case 2: return QoSVideoStalled;
            case 3: return QoSHighLossLateRate;
            case 4: return QoSHighRemoteLossRate;
            case 5: return QoSBurstOccured;
            case 6: return QoSRetransmissionFailures;
            case 7: return QoSLowDownloadBandwidthEstimation;
            case 8: return QoSLowQualityReceivedVideo;
            case 9: return QoSLowQualitySentVideo;
            case 10: return QoSLowSignal;
            case 11: return QoSLostSignal;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Type");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Return the call from the alert. <br/>
    * <br/>
    * @return A {@link Call} from the alert.   <br/>
    */
    @Nullable
    public Call getCall();

    /**
    * Return the end time of the alert. <br/>
    * <br/>
    * @return the end time of the alert. <br/>
    */
    public long getEndTime();

    /**
    * Return more informations about the alerts. <br/>
    * <br/>
    * @return A {@link Dictionary} containing informations about the current alert.   <br/>
    */
    @Nullable
    public Dictionary getInformations();

    /**
    * Return the start time of the alert. <br/>
    * <br/>
    * @return the start time of the alert. <br/>
    */
    public long getStartTime();

    /**
    * Return the state of the alert. <br/>
    * <br/>
    * @return true if and only if the alert is active. <br/>
    */
    public boolean getState();

    /**
    * Return the type of the alert. <br/>
    * <br/>
    * @return A {@link Type} corresponding to the current alert. <br/>
    */
    public Alert.Type getType();

    /**
    * Clone the given alert. <br/>
    * <br/>
    * @return A new alert with exactly same informations that param.   <br/>
    */
    @NonNull
    public Alert clone();

    /**
    * Notify the alert if it is terminated. <br/>
    * <br/>
    */
    public void notifyOnTerminated();

    /**
    * Provide a string describing the alert type. <br/>
    * <br/>
    * @param type the {@link Type} <br/>
    * @return a string <br/>
    */
    public String typeToString(Alert.Type type);

    /**
    */
    public void addListener(AlertListener listener);

    /**
    */
    public void removeListener(AlertListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AlertImpl implements Alert {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AlertImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Call getCall(long nativePtr);
    @Override @Nullable
    synchronized public Call getCall()  {
        
        
        return (Call)getCall(nativePtr);
    }

    private native long getEndTime(long nativePtr);
    @Override
    synchronized public long getEndTime()  {
        
        
        return getEndTime(nativePtr);
    }

    private native Dictionary getInformations(long nativePtr);
    @Override @Nullable
    synchronized public Dictionary getInformations()  {
        
        
        return (Dictionary)getInformations(nativePtr);
    }

    private native long getStartTime(long nativePtr);
    @Override
    synchronized public long getStartTime()  {
        
        
        return getStartTime(nativePtr);
    }

    private native boolean getState(long nativePtr);
    @Override
    synchronized public boolean getState()  {
        
        
        return getState(nativePtr);
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public Alert.Type getType()  {
        
        
        return Alert.Type.fromInt(getType(nativePtr));
    }

    private native Alert clone(long nativePtr);
    @Override @NonNull
    synchronized public Alert clone()  {
        
        
        return (Alert)clone(nativePtr);
    }

    private native void notifyOnTerminated(long nativePtr);
    @Override
    synchronized public void notifyOnTerminated()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call notifyOnTerminated() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        notifyOnTerminated(nativePtr);
    }

    private native String typeToString(long nativePtr, int type);
    @Override
    synchronized public String typeToString(Alert.Type type)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call typeToString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return typeToString(nativePtr, type.toInt());
    }

    private native void addListener(long nativePtr, AlertListener listener);
    @Override
    synchronized public void addListener(AlertListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, AlertListener listener);
    @Override
    synchronized public void removeListener(AlertListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
