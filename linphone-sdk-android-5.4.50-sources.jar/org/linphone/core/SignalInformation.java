/*
SignalInformation.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object to get signal (wifi/4G etc...) informations. <br/>
* <br/>
*/
public interface SignalInformation {
    /**
    * Get the {@link SignalType} of the {@link SignalInformation}. <br/>
    * <br/>
    * @return A {@link SignalType}. <br/>
    */
    public SignalType getSignalType();

    /**
    * Set a new {@link SignalType} to a {@link SignalInformation}. <br/>
    * <br/>
    * @param type The new {@link SignalType} to set. <br/>
    */
    public void setSignalType(SignalType type);

    /**
    * Get the {@link SignalStrengthUnit} value of the {@link SignalInformation}. <br/>
    * <br/>
    * @return A {@link SignalStrengthUnit}. <br/>
    */
    public SignalStrengthUnit getSignalUnit();

    /**
    * Set a new {@link SignalStrengthUnit} to a {@link SignalInformation}. <br/>
    * <br/>
    * @param unit The new {@link SignalStrengthUnit} to set. <br/>
    */
    public void setSignalUnit(SignalStrengthUnit unit);

    /**
    * Get the value of the {@link SignalInformation}. <br/>
    * <br/>
    * @return A float containing the value. <br/>
    */
    public float getStrength();

    /**
    * Set a new value to a {@link SignalInformation}. <br/>
    * <br/>
    * @param value a float containing the new value to set. <br/>
    */
    public void setValue(float value);

    /**
    * Clone the given signalInformation. <br/>
    * <br/>
    * @return A new signalInformation with exactly same informations that param.    <br/>
    */
    @NonNull
    public SignalInformation clone();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class SignalInformationImpl implements SignalInformation {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected SignalInformationImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getSignalType(long nativePtr);
    @Override
    synchronized public SignalType getSignalType()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSignalType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return SignalType.fromInt(getSignalType(nativePtr));
    }

    private native void setSignalType(long nativePtr, int type);
    @Override
    synchronized public void setSignalType(SignalType type)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSignalType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSignalType(nativePtr, type.toInt());
    }

    private native int getSignalUnit(long nativePtr);
    @Override
    synchronized public SignalStrengthUnit getSignalUnit()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSignalUnit() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return SignalStrengthUnit.fromInt(getSignalUnit(nativePtr));
    }

    private native void setSignalUnit(long nativePtr, int unit);
    @Override
    synchronized public void setSignalUnit(SignalStrengthUnit unit)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSignalUnit() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSignalUnit(nativePtr, unit.toInt());
    }

    private native float getStrength(long nativePtr);
    @Override
    synchronized public float getStrength()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getStrength() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getStrength(nativePtr);
    }

    private native void setValue(long nativePtr, float value);
    @Override
    synchronized public void setValue(float value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setValue() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setValue(nativePtr, value);
    }

    private native SignalInformation clone(long nativePtr);
    @Override @NonNull
    synchronized public SignalInformation clone()  {
        
        
        return (SignalInformation)clone(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
