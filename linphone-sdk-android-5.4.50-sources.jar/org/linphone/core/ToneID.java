/*
ToneID.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum listing frequent telephony tones. <br/>
* <br/>
*/
public enum ToneID {
    /**
    * Not a tone. <br/>
    * <br/>
    */
    Undefined(0),

    /**
    * Busy tone. <br/>
    * <br/>
    */
    Busy(1),

    /**
    * Call waiting tone. <br/>
    * <br/>
    */
    CallWaiting(2),

    /**
    * Call on hold tone. <br/>
    * <br/>
    */
    CallOnHold(3),

    /**
    * Tone played when call is abruptly disconnected (media lost) <br/>
    * <br/>
    */
    CallLost(4),

    /**
    * When the call end for any reason but lost. <br/>
    * <br/>
    */
    CallEnd(5),

    /**
    * When the call is not answered. <br/>
    * <br/>
    */
    CallNotAnswered(6),

    /**
    * When the SAS check is required. <br/>
    * <br/>
    */
    SasCheckRequired(7);

    protected final int mValue;

    private ToneID (int value) {
        mValue = value;
    }

    static public ToneID fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Undefined;
        case 1: return Busy;
        case 2: return CallWaiting;
        case 3: return CallOnHold;
        case 4: return CallLost;
        case 5: return CallEnd;
        case 6: return CallNotAnswered;
        case 7: return SasCheckRequired;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for ToneID");
        }
    }
    
    static protected ToneID[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        ToneID[] enumArray = new ToneID[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = ToneID.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(ToneID[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
