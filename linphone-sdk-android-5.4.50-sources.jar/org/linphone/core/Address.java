/*
Address.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that represents a parsed SIP address. <br/>
* <br/>
* A SIP address is made of display name, username, domain name, port, and various<br/>
* uri headers (such as tags). It looks like 'Alice <sip:alice@example.net>'.<br/>
* You can create an address using {@link Factory#createAddress} or {@link Core#interpretUrl}<br/>
* and both will return a null object if it doesn't match the grammar defined by<br/>
* the standard.<br/>
* This object is used in almost every other major objects to identity people<br/>
* (including yourself) & servers.<br/>
* The {@link Address} has methods to extract and manipulate all parts of the<br/>
* address. <br/>
*/
public interface Address {
    public enum Family {
        /**
        * IpV4. <br/>
        * <br/>
        */
        Inet(0),

        /**
        * IpV6. <br/>
        * <br/>
        */
        Inet6(1),

        /**
        * Unknown. <br/>
        * <br/>
        */
        Unspec(2);

        protected final int mValue;

        private Family (int value) {
            mValue = value;
        }

        static public Family fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Inet;
            case 1: return Inet6;
            case 2: return Unspec;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Family");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Returns the display name. <br/>
    * <br/>
    * @return the display name if any, null otherwise.   <br/>
    */
    @Nullable
    public String getDisplayName();

    /**
    * Sets the display name. <br/>
    * <br/>
    * @param displayName the display name to set.   <br/>
    */
    public int setDisplayName(@Nullable String displayName);

    /**
    * Returns the domain name. <br/>
    * <br/>
    * @return the domain name if any, null otherwise.   <br/>
    */
    @Nullable
    public String getDomain();

    /**
    * Sets the domain. <br/>
    * <br/>
    * @param domain the domain to set.   <br/>
    */
    public int setDomain(@Nullable String domain);

    /**
    * returns whether the address is a routable SIP address or not <br/>
    * <br/>
    * @return true if it is a routable SIP address, false otherwise <br/>
    */
    public boolean isSip();

    /**
    * Returns if address is valid. <br/>
    * <br/>
    * @return true is the address is valid, false otherwise <br/>
    */
    public boolean isValid();

    /**
    * Get the value of the method parameter. <br/>
    * <br/>
    * @return the value of the parameter or null.   <br/>
    */
    @Nullable
    public String getMethodParam();

    /**
    * Set the value of the method parameter. <br/>
    * <br/>
    * @param methodParam the value to set to the method parameter.   <br/>
    */
    public void setMethodParam(@Nullable String methodParam);

    /**
    * Get the password encoded in the address. <br/>
    * <br/>
    * It is used for basic authentication (not recommended). <br/>
    * @return the password if any, null otherwise.   <br/>
    */
    @Nullable
    public String getPassword();

    /**
    * Set the password encoded in the address. <br/>
    * <br/>
    * It is used for basic authentication (not recommended). <br/>
    * @param password the password to set.   <br/>
    */
    public void setPassword(@Nullable String password);

    /**
    * Get port number as an integer value, 0 if not present. <br/>
    * <br/>
    * @return the port set in the address or 0 if not present. <br/>
    */
    public int getPort();

    /**
    * Sets the port number. <br/>
    * <br/>
    * @param port the port to set in the address <br/>
    */
    public int setPort(int port);

    /**
    * Returns the address scheme, normally "sip". <br/>
    * <br/>
    * @return the scheme if any, null otherwise.   <br/>
    */
    @Nullable
    public String getScheme();

    /**
    * Returns whether the address refers to a secure location (sips) or not. <br/>
    * <br/>
    * @return true if address refers to a secure location, false otherwise <br/>
    */
    public boolean getSecure();

    /**
    * Make the address refer to a secure location (sips scheme) <br/>
    * <br/>
    * @param enabled true if address is requested to be secure. <br/>
    */
    public void setSecure(boolean enabled);

    /**
    * Get the transport. <br/>
    * <br/>
    * @return a {@link TransportType}, default value if not set is UDP. <br/>
    */
    public TransportType getTransport();

    /**
    * Set a transport. <br/>
    * <br/>
    * @param transport a {@link TransportType} <br/>
    */
    public int setTransport(TransportType transport);

    /**
    * Set the value of the parameters of the URI of the address. <br/>
    * <br/>
    * @param params The parameters string <br/>
    */
    public void setUriParams(String params);

    /**
    * Returns the username. <br/>
    * <br/>
    * @return the username name if any, null otherwise.   <br/>
    */
    @Nullable
    public String getUsername();

    /**
    * Sets the username. <br/>
    * <br/>
    * @param username the username to set.   <br/>
    */
    public int setUsername(@Nullable String username);

    /**
    * Returns the address as a string. <br/>
    * <br/>
    * The returned char * must be freed by the application. Use ms_free(). <br/>
    * @return a string representation of the address.     <br/>
    */
    @NonNull
    public String asString();

    /**
    * Returns the SIP uri only as a string, that is display name is removed. <br/>
    * <br/>
    * The returned char * must be freed by the application. Use ms_free(). <br/>
    * @return a string representation of the address.     <br/>
    */
    @NonNull
    public String asStringUriOnly();

    /**
    * Returns the SIP uri only as a string, that is display name is removed. <br/>
    * <br/>
    * This function always returns a string whose URI parameters has a constant order<br/>
    * allowing to easily compute hashes for example. The returned char * must be<br/>
    * freed by the application. Use ms_free(). <br/>
    * @return a string representation of the address.     <br/>
    */
    @NonNull
    public String asStringUriOnlyOrdered();

    /**
    * Removes address's tags and uri headers so that it is displayable to the user. <br/>
    * <br/>
    */
    public void clean();

    /**
    * Clones a {@link Address} object. <br/>
    * <br/>
    * @return a new {@link Address} object.   <br/>
    */
    @NonNull
    public Address clone();

    /**
    * Compare two {@link Address} taking the tags and headers into account. <br/>
    * <br/>
    * @param address2 {@link Address} object.   <br/>
    * @return Boolean value telling if the {@link Address} objects are equal. <br/>
    * see: {@link #weakEqual} <br/>
    */
    public boolean equal(@NonNull Address address2);

    /**
    * Get the header encoded in the address. <br/>
    * <br/>
    * @param headerName the header name.   <br/>
    * @return the header value or null if it doesn't exists.   <br/>
    */
    @Nullable
    public String getHeader(@NonNull String headerName);

    /**
    * Get the value of a parameter of the address. <br/>
    * <br/>
    * @param paramName The name of the parameter.   <br/>
    * @return The value of the parameter or null if it doesn't exists.   <br/>
    */
    @Nullable
    public String getParam(@NonNull String paramName);

    /**
    * Get the value of a parameter of the URI of the address. <br/>
    * <br/>
    * @param uriParamName The name of the parameter.   <br/>
    * @return The value of the parameter or null if it doesn't exists.   <br/>
    */
    @Nullable
    public String getUriParam(@NonNull String uriParamName);

    /**
    * Tell whether a parameter is present in the address. <br/>
    * <br/>
    * @param paramName The name of the parameter.   <br/>
    * @return A boolean value telling whether the parameter is present in the address <br/>
    */
    public boolean hasParam(@NonNull String paramName);

    /**
    * Tell whether a parameter is present in the URI of the address. <br/>
    * <br/>
    * @param uriParamName The name of the parameter.   <br/>
    * @return A boolean value telling whether the parameter is present in the URI of<br/>
    * the address <br/>
    */
    public boolean hasUriParam(@NonNull String uriParamName);

    /**
    * Compare two addresses. <br/>
    * <br/>
    * @param other an other {@link Address} object.   <br/>
    */
    public boolean lesser(@NonNull Address other);

    /**
    * Removes the value of a parameter of the URI of the address. <br/>
    * <br/>
    * @param uriParamName The name of the parameter.   <br/>
    */
    public void removeUriParam(@NonNull String uriParamName);

    /**
    * Set a header into the address. <br/>
    * <br/>
    * Headers appear in the URI with '?', such as<br/>
    * <sip:test@linphone.org?SomeHeader=SomeValue>. <br/>
    * @param headerName the header name.   <br/>
    * @param headerValue the header value.   <br/>
    */
    public void setHeader(@NonNull String headerName, @Nullable String headerValue);

    /**
    * Set the value of a parameter of the address. <br/>
    * <br/>
    * @param paramName The name of the parameter.   <br/>
    * @param paramValue The new value of the parameter.   <br/>
    */
    public void setParam(@NonNull String paramName, @Nullable String paramValue);

    /**
    * Set the value of a parameter of the URI of the address. <br/>
    * <br/>
    * @param uriParamName The name of the parameter.   <br/>
    * @param uriParamValue The new value of the parameter.   <br/>
    */
    public void setUriParam(@NonNull String uriParamName, @Nullable String uriParamValue);

    /**
    * Compare two {@link Address} ignoring tags and headers, basically just domain,<br/>
    * username, and port. <br/>
    * <br/>
    * @param address2 {@link Address} object.   <br/>
    * @return Boolean value telling if the {@link Address} objects are equal. <br/>
    * see: {@link #equal} <br/>
    */
    public boolean weakEqual(@NonNull Address address2);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AddressImpl implements Address {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AddressImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getDisplayName(long nativePtr);
    @Override @Nullable
    synchronized public String getDisplayName()  {
        
        
        return getDisplayName(nativePtr);
    }

    private native int setDisplayName(long nativePtr, String displayName);
    @Override
    synchronized public int setDisplayName(@Nullable String displayName)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDisplayName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setDisplayName(nativePtr, displayName);
    }

    private native String getDomain(long nativePtr);
    @Override @Nullable
    synchronized public String getDomain()  {
        
        
        return getDomain(nativePtr);
    }

    private native int setDomain(long nativePtr, String domain);
    @Override
    synchronized public int setDomain(@Nullable String domain)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDomain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setDomain(nativePtr, domain);
    }

    private native boolean isSip(long nativePtr);
    @Override
    synchronized public boolean isSip()  {
        
        
        return isSip(nativePtr);
    }

    private native boolean isValid(long nativePtr);
    @Override
    synchronized public boolean isValid()  {
        
        
        return isValid(nativePtr);
    }

    private native String getMethodParam(long nativePtr);
    @Override @Nullable
    synchronized public String getMethodParam()  {
        
        
        return getMethodParam(nativePtr);
    }

    private native void setMethodParam(long nativePtr, String methodParam);
    @Override
    synchronized public void setMethodParam(@Nullable String methodParam)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMethodParam() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMethodParam(nativePtr, methodParam);
    }

    private native String getPassword(long nativePtr);
    @Override @Nullable
    synchronized public String getPassword()  {
        
        
        return getPassword(nativePtr);
    }

    private native void setPassword(long nativePtr, String password);
    @Override
    synchronized public void setPassword(@Nullable String password)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPassword() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPassword(nativePtr, password);
    }

    private native int getPort(long nativePtr);
    @Override
    synchronized public int getPort()  {
        
        
        return getPort(nativePtr);
    }

    private native int setPort(long nativePtr, int port);
    @Override
    synchronized public int setPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setPort(nativePtr, port);
    }

    private native String getScheme(long nativePtr);
    @Override @Nullable
    synchronized public String getScheme()  {
        
        
        return getScheme(nativePtr);
    }

    private native boolean getSecure(long nativePtr);
    @Override
    synchronized public boolean getSecure()  {
        
        
        return getSecure(nativePtr);
    }

    private native void setSecure(long nativePtr, boolean enabled);
    @Override
    synchronized public void setSecure(boolean enabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSecure() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSecure(nativePtr, enabled);
    }

    private native int getTransport(long nativePtr);
    @Override
    synchronized public TransportType getTransport()  {
        
        
        return TransportType.fromInt(getTransport(nativePtr));
    }

    private native int setTransport(long nativePtr, int transport);
    @Override
    synchronized public int setTransport(TransportType transport)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTransport() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setTransport(nativePtr, transport.toInt());
    }

    private native void setUriParams(long nativePtr, String params);
    @Override
    synchronized public void setUriParams(String params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUriParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUriParams(nativePtr, params);
    }

    private native String getUsername(long nativePtr);
    @Override @Nullable
    synchronized public String getUsername()  {
        
        
        return getUsername(nativePtr);
    }

    private native int setUsername(long nativePtr, String username);
    @Override
    synchronized public int setUsername(@Nullable String username)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUsername() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setUsername(nativePtr, username);
    }

    private native String asString(long nativePtr);
    @Override @NonNull
    synchronized public String asString()  {
        
        
        return asString(nativePtr);
    }

    private native String asStringUriOnly(long nativePtr);
    @Override @NonNull
    synchronized public String asStringUriOnly()  {
        
        
        return asStringUriOnly(nativePtr);
    }

    private native String asStringUriOnlyOrdered(long nativePtr);
    @Override @NonNull
    synchronized public String asStringUriOnlyOrdered()  {
        
        
        return asStringUriOnlyOrdered(nativePtr);
    }

    private native void clean(long nativePtr);
    @Override
    synchronized public void clean()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clean() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clean(nativePtr);
    }

    private native Address clone(long nativePtr);
    @Override @NonNull
    synchronized public Address clone()  {
        
        
        return (Address)clone(nativePtr);
    }

    private native boolean equal(long nativePtr, Address address2);
    @Override
    synchronized public boolean equal(@NonNull Address address2)  {
        
        
        return equal(nativePtr, address2);
    }

    private native String getHeader(long nativePtr, String headerName);
    @Override @Nullable
    synchronized public String getHeader(@NonNull String headerName)  {
        
        
        return getHeader(nativePtr, headerName);
    }

    private native String getParam(long nativePtr, String paramName);
    @Override @Nullable
    synchronized public String getParam(@NonNull String paramName)  {
        
        
        return getParam(nativePtr, paramName);
    }

    private native String getUriParam(long nativePtr, String uriParamName);
    @Override @Nullable
    synchronized public String getUriParam(@NonNull String uriParamName)  {
        
        
        return getUriParam(nativePtr, uriParamName);
    }

    private native boolean hasParam(long nativePtr, String paramName);
    @Override
    synchronized public boolean hasParam(@NonNull String paramName)  {
        
        
        return hasParam(nativePtr, paramName);
    }

    private native boolean hasUriParam(long nativePtr, String uriParamName);
    @Override
    synchronized public boolean hasUriParam(@NonNull String uriParamName)  {
        
        
        return hasUriParam(nativePtr, uriParamName);
    }

    private native boolean lesser(long nativePtr, Address other);
    @Override
    synchronized public boolean lesser(@NonNull Address other)  {
        
        
        return lesser(nativePtr, other);
    }

    private native void removeUriParam(long nativePtr, String uriParamName);
    @Override
    synchronized public void removeUriParam(@NonNull String uriParamName)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeUriParam() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeUriParam(nativePtr, uriParamName);
    }

    private native void setHeader(long nativePtr, String headerName, String headerValue);
    @Override
    synchronized public void setHeader(@NonNull String headerName, @Nullable String headerValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHeader(nativePtr, headerName, headerValue);
    }

    private native void setParam(long nativePtr, String paramName, String paramValue);
    @Override
    synchronized public void setParam(@NonNull String paramName, @Nullable String paramValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParam() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParam(nativePtr, paramName, paramValue);
    }

    private native void setUriParam(long nativePtr, String uriParamName, String uriParamValue);
    @Override
    synchronized public void setUriParam(@NonNull String uriParamName, @Nullable String uriParamValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUriParam() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUriParam(nativePtr, uriParamName, uriParamValue);
    }

    private native boolean weakEqual(long nativePtr, Address address2);
    @Override
    synchronized public boolean weakEqual(@NonNull Address address2)  {
        
        
        return weakEqual(nativePtr, address2);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
