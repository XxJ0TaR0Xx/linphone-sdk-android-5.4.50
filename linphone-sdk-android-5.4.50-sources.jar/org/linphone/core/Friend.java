/*
Friend.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* This object is used to store a SIP address. <br/>
* <br/>
* {@link Friend} is mainly used to implement an adressbook feature, and are used<br/>
* as data for the {@link MagicSearch} object. If your proxy supports it, you can<br/>
* also use it to subscribe to presence information.<br/>
* The objects are stored in a {@link FriendList} which are in turn stored inside<br/>
* the {@link Core}. They can be stored inside a database if the path to it is<br/>
* configured, otherwise they will be lost after the {@link Core} is destroyed.<br/>
* Thanks to the vCard plugin, you can also store more information like phone<br/>
* numbers, organization, etc... <br/>
*/
public interface Friend {
    public enum Capability {
        /**
        * No capabilities populated. <br/>
        * <br/>
        */
        None(0),

        /**
        * This friend can be invited in a Flexisip backend {@link ChatRoom}. <br/>
        * <br/>
        */
        GroupChat(1<<0),

        /**
        * This friend can be invited in a Flexisip backend end-to-end encrypted {@link ChatRoom}<br/>
        * . <br/>
        * <br/>
        */
        LimeX3Dh(1<<1),

        /**
        * This friend is able to delete ephemeral messages once they have expired. <br/>
        * <br/>
        */
        EphemeralMessages(1<<2);

        protected final int mValue;

        private Capability (int value) {
            mValue = value;
        }

        static public Capability fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1<<0: return GroupChat;
            case 1<<1: return LimeX3Dh;
            case 1<<2: return EphemeralMessages;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Capability");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Get address of this friend. <br/>
    * <br/>
    * note: the {@link Address} object returned is hold by the LinphoneFriend,<br/>
    * however calling several time this function may return different objects. <br/>
    * @return the {@link Address}.   <br/>
    */
    @Nullable
    public Address getAddress();

    /**
    * Set {@link Address} for this friend. <br/>
    * <br/>
    * @param address the {@link Address} to set   return 0 if successful, -1<br/>
    * otherwise <br/>
    */
    public int setAddress(@Nullable Address address);

    /**
    * Returns a list of {@link Address} for this friend. <br/>
    * <br/>
    * @return A list of {@link Address}.    <br/>
    */
    @NonNull
    public Address[] getAddresses();

    /**
    * Returns the capabilities associated to this friend. <br/>
    * <br/>
    * @return an int representing the capabilities of the friend <br/>
    */
    public int getCapabilities();

    /**
    * Get the consolidated presence of a friend. <br/>
    * <br/>
    * It will return the "most open" presence found if more than one presence model<br/>
    * are found. <br/>
    * @return The {@link ConsolidatedPresence} of the friend <br/>
    */
    public ConsolidatedPresence getConsolidatedPresence();

    /**
    * Returns the {@link Core} object managing this friend, if any. <br/>
    * <br/>
    * @return the {@link Core} object associated.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Returns a list of {@link FriendDevice} for this friend, for all known<br/>
    * addresses. <br/>
    * <br/>
    * @return A list of {@link FriendDevice}.      <br/>
    */
    @NonNull
    public FriendDevice[] getDevices();

    /**
    * Gets the first name for this friend if vCard exists. <br/>
    * <br/>
    * @return The first name of this friend.   <br/>
    */
    @Nullable
    public String getFirstName();

    /**
    * Sets the first name for this friend is available. <br/>
    * <br/>
    * @param firstName the first name to set   <br/>
    * @return 0 if successful, -1 otherwise <br/>
    */
    public int setFirstName(@Nullable String firstName);

    /**
    * Check that the given friend is in a friend list. <br/>
    * <br/>
    * @return The {@link FriendList} the friend is in if any, null otherwise.   <br/>
    */
    @Nullable
    public FriendList getFriendList();

    /**
    * get current subscription policy for this {@link Friend} <br/>
    * <br/>
    * @return the {@link SubscribePolicy} enum <br/>
    */
    public SubscribePolicy getIncSubscribePolicy();

    /**
    * Configure incoming subscription policy for this friend. <br/>
    * <br/>
    * @param policy {@link SubscribePolicy} policy to apply. <br/>
    * @return 0 <br/>
    */
    public int setIncSubscribePolicy(SubscribePolicy policy);

    /**
    * Tells whether we already received presence information for a friend. <br/>
    * <br/>
    * @return true if presence information has been received for the friend, false<br/>
    * otherwise. <br/>
    */
    public boolean isPresenceReceived();

    /**
    * Gets the contact's job title from it's vCard. <br/>
    * <br/>
    * It's a shortcut to {@link #getVcard} and {@link Vcard#getJobTitle}. <br/>
    * @return the job_title set if any & vCard is available, null otherwise.   <br/>
    */
    @Nullable
    public String getJobTitle();

    /**
    * Sets the contact's job title. <br/>
    * <br/>
    * It's a shortcut to {@link #getVcard} and {@link Vcard#setJobTitle}. <br/>
    * @param jobTitle the job title to store in Friend's vCard.   <br/>
    */
    public void setJobTitle(@Nullable String jobTitle);

    /**
    * Gets the last name for this friend if vCard exists. <br/>
    * <br/>
    * @return The last name of this friend.   <br/>
    */
    @Nullable
    public String getLastName();

    /**
    * Sets the last name for this friend if vCard is available. <br/>
    * <br/>
    * @param lastName the last name to set   <br/>
    * @return 0 if successful, -1 otherwise <br/>
    */
    public int setLastName(@Nullable String lastName);

    /**
    * Gets the display name for this friend. <br/>
    * <br/>
    * @return The display name of this friend.   <br/>
    */
    @Nullable
    public String getName();

    /**
    * Sets the display name for this friend. <br/>
    * <br/>
    * @param name the display name to set   <br/>
    * @return 0 if successful, -1 otherwise <br/>
    */
    public int setName(@Nullable String name);

    /**
    * Gets the contact's native URI. <br/>
    * <br/>
    * @return the native URI set if any, null otherwise.   <br/>
    */
    @Nullable
    public String getNativeUri();

    /**
    * Sets the contact's native URI. <br/>
    * <br/>
    * @param nativeUri the URI that matches the contact on the native system.   <br/>
    */
    public void setNativeUri(@Nullable String nativeUri);

    /**
    * Gets the contact's organization from it's vCard. <br/>
    * <br/>
    * It's a shortcut to {@link #getVcard} and {@link Vcard#getOrganization}. <br/>
    * @return the organization set if any & vCard is available, null otherwise.   <br/>
    */
    @Nullable
    public String getOrganization();

    /**
    * Sets the contact's organization. <br/>
    * <br/>
    * It's a shortcut to {@link #getVcard} and {@link Vcard#setOrganization}. <br/>
    * @param organization the organization to store in Friend's vCard.   <br/>
    */
    public void setOrganization(@Nullable String organization);

    /**
    * Returns a list of phone numbers for this friend. <br/>
    * <br/>
    * @return A list of phone numbers as string.      <br/>
    */
    @NonNull
    public String[] getPhoneNumbers();

    /**
    * Returns a list of {@link FriendPhoneNumber} for this friend. <br/>
    * <br/>
    * @return A list of phone numbers as string.      <br/>
    */
    @NonNull
    public FriendPhoneNumber[] getPhoneNumbersWithLabel();

    /**
    * Gets the contact's picture URI. <br/>
    * <br/>
    * @return the picture URI set if any, null otherwise.   <br/>
    */
    @Nullable
    public String getPhoto();

    /**
    * Sets the contact's picture URI. <br/>
    * <br/>
    * @param pictureUri the picture URI to set.   <br/>
    */
    public void setPhoto(@Nullable String pictureUri);

    /**
    * Get the presence model of a friend. <br/>
    * <br/>
    * If a friend has more than one SIP address and phone number, this method will<br/>
    * return the most recent presence model using {@link PresenceModel#getTimestamp}. <br/>
    * @return A {@link PresenceModel} object, or null if the friend do not have<br/>
    * presence information (in which case he is considered offline).   <br/>
    */
    @Nullable
    public PresenceModel getPresenceModel();

    /**
    * Set the presence model of a friend. <br/>
    * <br/>
    * @param presence The {@link PresenceModel} object to set for the friend   <br/>
    */
    public void setPresenceModel(@Nullable PresenceModel presence);

    /**
    * Get the reference key of a friend. <br/>
    * <br/>
    * @return The reference key of the friend.   <br/>
    */
    @Nullable
    public String getRefKey();

    /**
    * Set the reference key of a friend. <br/>
    * <br/>
    * @param key The reference key to use for the friend.   <br/>
    */
    public void setRefKey(@Nullable String key);

    /**
    * Returns the security level of a friend which is the lowest among all devices we<br/>
    * know for it. <br/>
    * <br/>
    * @return A {@link SecurityLevel}, which is the lowest among all known devices. <br/>
    */
    public SecurityLevel getSecurityLevel();

    /**
    * Gets if the friend is to be considered as important for the user. <br/>
    * <br/>
    * @return true if the contact is a user's favorite, false otherwise. <br/>
    */
    public boolean getStarred();

    /**
    * Sets if the friend is a user's favorite or important contact. <br/>
    * <br/>
    * @param isStarred true if the friend is to be considered as important, false<br/>
    * otherwise. <br/>
    */
    public void setStarred(boolean isStarred);

    /**
    * get subscription flag value <br/>
    * <br/>
    * @return returns true is subscription is activated for this friend <br/>
    */
    public boolean isSubscribesEnabled();

    /**
    * Configure {@link Friend} to subscribe to presence information. <br/>
    * <br/>
    * @param enable if true this friend will receive subscription message <br/>
    * @return 0 <br/>
    */
    public int setSubscribesEnabled(boolean enable);

    /**
    * Get subscription state of a friend. <br/>
    * <br/>
    * @return the {@link SubscriptionState} enum <br/>
    */
    public SubscriptionState getSubscriptionState();

    /**
    * Returns the vCard object associated to this friend, if any. <br/>
    * <br/>
    * @return the {@link Vcard} or null.   <br/>
    */
    @Nullable
    public Vcard getVcard();

    /**
    * Binds a vCard object to a friend. <br/>
    * <br/>
    * @param vcard The {@link Vcard} object to bind   <br/>
    */
    public void setVcard(@Nullable Vcard vcard);

    /**
    * Adds an address in this friend. <br/>
    * <br/>
    * @param address {@link Address} object   <br/>
    */
    public void addAddress(@NonNull Address address);

    /**
    * Adds a phone number in this friend. <br/>
    * <br/>
    * @param phoneNumber number to add   <br/>
    */
    public void addPhoneNumber(@NonNull String phoneNumber);

    /**
    * Adds a {@link FriendPhoneNumber} to this friend. <br/>
    * <br/>
    * @param phoneNumber the {@link FriendPhoneNumber} to add   <br/>
    */
    public void addPhoneNumberWithLabel(@NonNull FriendPhoneNumber phoneNumber);

    /**
    * Creates a vCard object associated to this friend if there isn't one yet and if<br/>
    * the full name is available, either by the parameter or the one in the friend's<br/>
    * SIP URI. <br/>
    * <br/>
    * @param name The full name of the friend or null to use the one from the<br/>
    * friend's SIP URI   <br/>
    * @return true if the vCard has been created, false if it wasn't possible (for<br/>
    * exemple if name and the friend's SIP URI are null or if the friend's SIP URI<br/>
    * doesn't have a display name), or if there is already one vcard <br/>
    */
    public boolean createVcard(@Nullable String name);

    /**
    * Commits modification made to the friend configuration. <br/>
    * <br/>
    */
    public void done();

    /**
    * Returns the a string matching the vCard inside the friend, if any. <br/>
    * <br/>
    * @return the vCard as a string or null.   <br/>
    */
    @Nullable
    public String dumpVcard();

    /**
    * Starts editing a friend configuration. <br/>
    * <br/>
    * Because friend configuration must be consistent, applications MUST call {@link #edit}<br/>
    * before doing any attempts to modify friend configuration (such as {@link #setAddress}<br/>
    * or {@link #setIncSubscribePolicy}). Once the modifications are done, then the<br/>
    * application must call {@link #done} to commit the changes. <br/>
    */
    public void edit();

    /**
    * Returns the version of a friend's capbility. <br/>
    * <br/>
    * @param capability {@link Capability} object <br/>
    * @return the version of a friend's capbility. <br/>
    */
    public float getCapabilityVersion(Friend.Capability capability);

    /**
    * Returns a list of {@link FriendDevice} for this friend and a specific address. <br/>
    * <br/>
    * @param address {@link Address} object   <br/>
    * @return A list of {@link FriendDevice}.      <br/>
    */
    @NonNull
    public FriendDevice[] getDevicesForAddress(@NonNull Address address);

    /**
    * Get the presence model for a specific SIP URI or phone number of a friend. <br/>
    * <br/>
    * @param uriOrTel The SIP URI or phone number for which to get the presence model<br/>
    *   <br/>
    * @return A {@link PresenceModel} object, or null if the friend do not have<br/>
    * presence information for this SIP URI or phone number.   <br/>
    */
    @Nullable
    public PresenceModel getPresenceModelForUriOrTel(@NonNull String uriOrTel);

    /**
    * Returns the security level of a friend for a given address which is the lowest<br/>
    * among all devices we know for that address. <br/>
    * <br/>
    * @param address {@link Address} object   <br/>
    * @return A {@link SecurityLevel}, which is the lowest among all known devices<br/>
    * for that address. <br/>
    */
    public SecurityLevel getSecurityLevelForAddress(@NonNull Address address);

    /**
    * Returns whether or not a friend has a capbility. <br/>
    * <br/>
    * @param capability {@link Capability} object <br/>
    * @return whether or not a friend has a capbility <br/>
    */
    public boolean hasCapability(Friend.Capability capability);

    /**
    * Returns whether or not a friend has a capbility with a given version. <br/>
    * <br/>
    * @param capability {@link Capability} object <br/>
    * @param version the version to test <br/>
    * @return whether or not a friend has a capbility with a given version or -1.0 if<br/>
    * friend has not capability. <br/>
    */
    public boolean hasCapabilityWithVersion(Friend.Capability capability, float version);

    /**
    * Returns whether or not a friend has a capbility with a given version or more. <br/>
    * <br/>
    * @param capability {@link Capability} object <br/>
    * @param version the version to test <br/>
    * @return whether or not a friend has a capbility with a given version or more. <br/>
    */
    public boolean hasCapabilityWithVersionOrMore(Friend.Capability capability, float version);

    /**
    * Returns whether a friend contains the given phone number. <br/>
    * <br/>
    * @param phoneNumber the phone number to search for   <br/>
    * @return true if found, false otherwise <br/>
    */
    public boolean hasPhoneNumber(@NonNull String phoneNumber);

    /**
    * Check that the given friend is in a friend list. <br/>
    * <br/>
    * @return true if the friend is in a friend list, false otherwise. <br/>
    */
    public boolean inList();

    /**
    * Removes a friend from it's friend list and from the rc if exists. <br/>
    * <br/>
    */
    public void remove();

    /**
    * Removes an address in this friend. <br/>
    * <br/>
    * @param address {@link Address} object   <br/>
    */
    public void removeAddress(@NonNull Address address);

    /**
    * Removes a phone number in this friend. <br/>
    * <br/>
    * @param phoneNumber number to remove   <br/>
    */
    public void removePhoneNumber(@NonNull String phoneNumber);

    /**
    * Removes a {@link FriendPhoneNumber} from this friend. <br/>
    * <br/>
    * @param phoneNumber the {@link FriendPhoneNumber} to remove   <br/>
    */
    public void removePhoneNumberWithLabel(@NonNull FriendPhoneNumber phoneNumber);

    /**
    * Saves a friend either in database if configured, otherwise in linphonerc. <br/>
    * <br/>
    * @param core the linphone core   <br/>
    */
    public void save(@NonNull Core core);

    /**
    * Set the presence model for a specific SIP URI or phone number of a friend. <br/>
    * <br/>
    * @param uriOrTel The SIP URI or phone number for which to set the presence model<br/>
    *   <br/>
    * @param presence The {@link PresenceModel} object to set   <br/>
    */
    public void setPresenceModelForUriOrTel(@NonNull String uriOrTel, @Nullable PresenceModel presence);

    /**
    */
    public void addListener(FriendListener listener);

    /**
    */
    public void removeListener(FriendListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class FriendImpl implements Friend {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected FriendImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Address getAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getAddress()  {
        synchronized(core) { 
        
        return (Address)getAddress(nativePtr);
        }
    }

    private native int setAddress(long nativePtr, Address address);
    @Override
    synchronized public int setAddress(@Nullable Address address)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setAddress(nativePtr, address);
        }
    }

    private native Address[] getAddresses(long nativePtr);
    @Override @NonNull
    synchronized public Address[] getAddresses()  {
        synchronized(core) { 
        
        return getAddresses(nativePtr);
        }
    }

    private native int getCapabilities(long nativePtr);
    @Override
    synchronized public int getCapabilities()  {
        synchronized(core) { 
        
        return getCapabilities(nativePtr);
        }
    }

    private native int getConsolidatedPresence(long nativePtr);
    @Override
    synchronized public ConsolidatedPresence getConsolidatedPresence()  {
        synchronized(core) { 
        
        return ConsolidatedPresence.fromInt(getConsolidatedPresence(nativePtr));
        }
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native FriendDevice[] getDevices(long nativePtr);
    @Override @NonNull
    synchronized public FriendDevice[] getDevices()  {
        synchronized(core) { 
        
        return getDevices(nativePtr);
        }
    }

    private native String getFirstName(long nativePtr);
    @Override @Nullable
    synchronized public String getFirstName()  {
        synchronized(core) { 
        
        return getFirstName(nativePtr);
        }
    }

    private native int setFirstName(long nativePtr, String firstName);
    @Override
    synchronized public int setFirstName(@Nullable String firstName)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFirstName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setFirstName(nativePtr, firstName);
        }
    }

    private native FriendList getFriendList(long nativePtr);
    @Override @Nullable
    synchronized public FriendList getFriendList()  {
        synchronized(core) { 
        
        return (FriendList)getFriendList(nativePtr);
        }
    }

    private native int getIncSubscribePolicy(long nativePtr);
    @Override
    synchronized public SubscribePolicy getIncSubscribePolicy()  {
        synchronized(core) { 
        
        return SubscribePolicy.fromInt(getIncSubscribePolicy(nativePtr));
        }
    }

    private native int setIncSubscribePolicy(long nativePtr, int policy);
    @Override
    synchronized public int setIncSubscribePolicy(SubscribePolicy policy)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIncSubscribePolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setIncSubscribePolicy(nativePtr, policy.toInt());
        }
    }

    private native boolean isPresenceReceived(long nativePtr);
    @Override
    synchronized public boolean isPresenceReceived()  {
        synchronized(core) { 
        
        return isPresenceReceived(nativePtr);
        }
    }

    private native String getJobTitle(long nativePtr);
    @Override @Nullable
    synchronized public String getJobTitle()  {
        synchronized(core) { 
        
        return getJobTitle(nativePtr);
        }
    }

    private native void setJobTitle(long nativePtr, String jobTitle);
    @Override
    synchronized public void setJobTitle(@Nullable String jobTitle)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setJobTitle() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setJobTitle(nativePtr, jobTitle);
        }
    }

    private native String getLastName(long nativePtr);
    @Override @Nullable
    synchronized public String getLastName()  {
        synchronized(core) { 
        
        return getLastName(nativePtr);
        }
    }

    private native int setLastName(long nativePtr, String lastName);
    @Override
    synchronized public int setLastName(@Nullable String lastName)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLastName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setLastName(nativePtr, lastName);
        }
    }

    private native String getName(long nativePtr);
    @Override @Nullable
    synchronized public String getName()  {
        synchronized(core) { 
        
        return getName(nativePtr);
        }
    }

    private native int setName(long nativePtr, String name);
    @Override
    synchronized public int setName(@Nullable String name)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setName(nativePtr, name);
        }
    }

    private native String getNativeUri(long nativePtr);
    @Override @Nullable
    synchronized public String getNativeUri()  {
        synchronized(core) { 
        
        return getNativeUri(nativePtr);
        }
    }

    private native void setNativeUri(long nativePtr, String nativeUri);
    @Override
    synchronized public void setNativeUri(@Nullable String nativeUri)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNativeUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNativeUri(nativePtr, nativeUri);
        }
    }

    private native String getOrganization(long nativePtr);
    @Override @Nullable
    synchronized public String getOrganization()  {
        synchronized(core) { 
        
        return getOrganization(nativePtr);
        }
    }

    private native void setOrganization(long nativePtr, String organization);
    @Override
    synchronized public void setOrganization(@Nullable String organization)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOrganization() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOrganization(nativePtr, organization);
        }
    }

    private native String[] getPhoneNumbers(long nativePtr);
    @Override @NonNull
    synchronized public String[] getPhoneNumbers()  {
        synchronized(core) { 
        
        return getPhoneNumbers(nativePtr);
        }
    }

    private native FriendPhoneNumber[] getPhoneNumbersWithLabel(long nativePtr);
    @Override @NonNull
    synchronized public FriendPhoneNumber[] getPhoneNumbersWithLabel()  {
        synchronized(core) { 
        
        return getPhoneNumbersWithLabel(nativePtr);
        }
    }

    private native String getPhoto(long nativePtr);
    @Override @Nullable
    synchronized public String getPhoto()  {
        synchronized(core) { 
        
        return getPhoto(nativePtr);
        }
    }

    private native void setPhoto(long nativePtr, String pictureUri);
    @Override
    synchronized public void setPhoto(@Nullable String pictureUri)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPhoto() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPhoto(nativePtr, pictureUri);
        }
    }

    private native PresenceModel getPresenceModel(long nativePtr);
    @Override @Nullable
    synchronized public PresenceModel getPresenceModel()  {
        synchronized(core) { 
        
        return (PresenceModel)getPresenceModel(nativePtr);
        }
    }

    private native void setPresenceModel(long nativePtr, PresenceModel presence);
    @Override
    synchronized public void setPresenceModel(@Nullable PresenceModel presence)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPresenceModel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPresenceModel(nativePtr, presence);
        }
    }

    private native String getRefKey(long nativePtr);
    @Override @Nullable
    synchronized public String getRefKey()  {
        synchronized(core) { 
        
        return getRefKey(nativePtr);
        }
    }

    private native void setRefKey(long nativePtr, String key);
    @Override
    synchronized public void setRefKey(@Nullable String key)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRefKey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRefKey(nativePtr, key);
        }
    }

    private native int getSecurityLevel(long nativePtr);
    @Override
    synchronized public SecurityLevel getSecurityLevel()  {
        synchronized(core) { 
        
        return SecurityLevel.fromInt(getSecurityLevel(nativePtr));
        }
    }

    private native boolean getStarred(long nativePtr);
    @Override
    synchronized public boolean getStarred()  {
        synchronized(core) { 
        
        return getStarred(nativePtr);
        }
    }

    private native void setStarred(long nativePtr, boolean isStarred);
    @Override
    synchronized public void setStarred(boolean isStarred)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setStarred() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setStarred(nativePtr, isStarred);
        }
    }

    private native boolean isSubscribesEnabled(long nativePtr);
    @Override
    synchronized public boolean isSubscribesEnabled()  {
        synchronized(core) { 
        
        return isSubscribesEnabled(nativePtr);
        }
    }

    private native int setSubscribesEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public int setSubscribesEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubscribesEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setSubscribesEnabled(nativePtr, enable);
        }
    }

    private native int getSubscriptionState(long nativePtr);
    @Override
    synchronized public SubscriptionState getSubscriptionState()  {
        synchronized(core) { 
        
        return SubscriptionState.fromInt(getSubscriptionState(nativePtr));
        }
    }

    private native Vcard getVcard(long nativePtr);
    @Override @Nullable
    synchronized public Vcard getVcard()  {
        synchronized(core) { 
        
        return (Vcard)getVcard(nativePtr);
        }
    }

    private native void setVcard(long nativePtr, Vcard vcard);
    @Override
    synchronized public void setVcard(@Nullable Vcard vcard)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVcard() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVcard(nativePtr, vcard);
        }
    }

    private native void addAddress(long nativePtr, Address address);
    @Override
    synchronized public void addAddress(@NonNull Address address)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addAddress(nativePtr, address);
        }
    }

    private native void addPhoneNumber(long nativePtr, String phoneNumber);
    @Override
    synchronized public void addPhoneNumber(@NonNull String phoneNumber)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addPhoneNumber() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addPhoneNumber(nativePtr, phoneNumber);
        }
    }

    private native void addPhoneNumberWithLabel(long nativePtr, FriendPhoneNumber phoneNumber);
    @Override
    synchronized public void addPhoneNumberWithLabel(@NonNull FriendPhoneNumber phoneNumber)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addPhoneNumberWithLabel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addPhoneNumberWithLabel(nativePtr, phoneNumber);
        }
    }

    private native boolean createVcard(long nativePtr, String name);
    @Override
    synchronized public boolean createVcard(@Nullable String name)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createVcard() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return createVcard(nativePtr, name);
        }
    }

    private native void done(long nativePtr);
    @Override
    synchronized public void done()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call done() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        done(nativePtr);
        }
    }

    private native String dumpVcard(long nativePtr);
    @Override @Nullable
    synchronized public String dumpVcard()  {
        synchronized(core) { 
        
        return dumpVcard(nativePtr);
        }
    }

    private native void edit(long nativePtr);
    @Override
    synchronized public void edit()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call edit() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        edit(nativePtr);
        }
    }

    private native float getCapabilityVersion(long nativePtr, int capability);
    @Override
    synchronized public float getCapabilityVersion(Friend.Capability capability)  {
        synchronized(core) { 
        
        return getCapabilityVersion(nativePtr, capability.toInt());
        }
    }

    private native FriendDevice[] getDevicesForAddress(long nativePtr, Address address);
    @Override @NonNull
    synchronized public FriendDevice[] getDevicesForAddress(@NonNull Address address)  {
        synchronized(core) { 
        
        return getDevicesForAddress(nativePtr, address);
        }
    }

    private native PresenceModel getPresenceModelForUriOrTel(long nativePtr, String uriOrTel);
    @Override @Nullable
    synchronized public PresenceModel getPresenceModelForUriOrTel(@NonNull String uriOrTel)  {
        synchronized(core) { 
        
        return (PresenceModel)getPresenceModelForUriOrTel(nativePtr, uriOrTel);
        }
    }

    private native int getSecurityLevelForAddress(long nativePtr, Address address);
    @Override
    synchronized public SecurityLevel getSecurityLevelForAddress(@NonNull Address address)  {
        synchronized(core) { 
        
        return SecurityLevel.fromInt(getSecurityLevelForAddress(nativePtr, address));
        }
    }

    private native boolean hasCapability(long nativePtr, int capability);
    @Override
    synchronized public boolean hasCapability(Friend.Capability capability)  {
        synchronized(core) { 
        
        return hasCapability(nativePtr, capability.toInt());
        }
    }

    private native boolean hasCapabilityWithVersion(long nativePtr, int capability, float version);
    @Override
    synchronized public boolean hasCapabilityWithVersion(Friend.Capability capability, float version)  {
        synchronized(core) { 
        
        return hasCapabilityWithVersion(nativePtr, capability.toInt(), version);
        }
    }

    private native boolean hasCapabilityWithVersionOrMore(long nativePtr, int capability, float version);
    @Override
    synchronized public boolean hasCapabilityWithVersionOrMore(Friend.Capability capability, float version)  {
        synchronized(core) { 
        
        return hasCapabilityWithVersionOrMore(nativePtr, capability.toInt(), version);
        }
    }

    private native boolean hasPhoneNumber(long nativePtr, String phoneNumber);
    @Override
    synchronized public boolean hasPhoneNumber(@NonNull String phoneNumber)  {
        synchronized(core) { 
        
        return hasPhoneNumber(nativePtr, phoneNumber);
        }
    }

    private native boolean inList(long nativePtr);
    @Override
    synchronized public boolean inList()  {
        synchronized(core) { 
        
        return inList(nativePtr);
        }
    }

    private native void remove(long nativePtr);
    @Override
    synchronized public void remove()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call remove() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        remove(nativePtr);
        }
    }

    private native void removeAddress(long nativePtr, Address address);
    @Override
    synchronized public void removeAddress(@NonNull Address address)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeAddress(nativePtr, address);
        }
    }

    private native void removePhoneNumber(long nativePtr, String phoneNumber);
    @Override
    synchronized public void removePhoneNumber(@NonNull String phoneNumber)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removePhoneNumber() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removePhoneNumber(nativePtr, phoneNumber);
        }
    }

    private native void removePhoneNumberWithLabel(long nativePtr, FriendPhoneNumber phoneNumber);
    @Override
    synchronized public void removePhoneNumberWithLabel(@NonNull FriendPhoneNumber phoneNumber)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removePhoneNumberWithLabel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removePhoneNumberWithLabel(nativePtr, phoneNumber);
        }
    }

    private native void save(long nativePtr, Core core);
    @Override
    synchronized public void save(@NonNull Core core)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call save() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        save(nativePtr, core);
        }
    }

    private native void setPresenceModelForUriOrTel(long nativePtr, String uriOrTel, PresenceModel presence);
    @Override
    synchronized public void setPresenceModelForUriOrTel(@NonNull String uriOrTel, @Nullable PresenceModel presence)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPresenceModelForUriOrTel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPresenceModelForUriOrTel(nativePtr, uriOrTel, presence);
        }
    }

    private native void addListener(long nativePtr, FriendListener listener);
    @Override
    synchronized public void addListener(FriendListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, FriendListener listener);
    @Override
    synchronized public void removeListener(FriendListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
