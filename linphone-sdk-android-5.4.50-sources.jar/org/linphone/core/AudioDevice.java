/*
AudioDevice.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object holding audio device information. <br/>
* <br/>
* It contains the name of the device, it's type if available (Earpiece, Speaker,<br/>
* Bluetooth, etc..) and capabilities (input, output or both) the name of the<br/>
* driver that created it (filter in mediastreamer).<br/>
* You can use the {@link AudioDevice} objects to configure default input/output<br/>
* devices or do it dynamically during a call.<br/>
* To get the list of available devices, use {@link Core#getAudioDevices}. This<br/>
* list will be limited to one device of each type. Use {@link Core#getExtendedAudioDevices}<br/>
* for a complete list. <br/>
*/
public interface AudioDevice {
    public enum Capabilities {
        /**
        * Can record audio. <br/>
        * <br/>
        */
        CapabilityRecord(1<<0),

        /**
        * Can play audio. <br/>
        * <br/>
        */
        CapabilityPlay(1<<1),

        /**
        * Can play and record audio. <br/>
        * <br/>
        */
        CapabilityAll(3);

        protected final int mValue;

        private Capabilities (int value) {
            mValue = value;
        }

        static public Capabilities fromInt(int value) throws RuntimeException {
            switch(value) {
            case 1<<0: return CapabilityRecord;
            case 1<<1: return CapabilityPlay;
            case 3: return CapabilityAll;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Capabilities");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Type {
        /**
        * Unknown. <br/>
        * <br/>
        */
        Unknown(0),

        /**
        * Microphone. <br/>
        * <br/>
        */
        Microphone(1),

        /**
        * Earpiece. <br/>
        * <br/>
        */
        Earpiece(2),

        /**
        * Speaker. <br/>
        * <br/>
        */
        Speaker(3),

        /**
        * Bluetooth. <br/>
        * <br/>
        */
        Bluetooth(4),

        /**
        * Bluetooth A2DP. <br/>
        * <br/>
        */
        BluetoothA2DP(5),

        /**
        * Telephony. <br/>
        * <br/>
        */
        Telephony(6),

        /**
        * AuxLine. <br/>
        * <br/>
        */
        AuxLine(7),

        /**
        * GenericUsb. <br/>
        * <br/>
        */
        GenericUsb(8),

        /**
        * Headset. <br/>
        * <br/>
        */
        Headset(9),

        /**
        * Headphones. <br/>
        * <br/>
        */
        Headphones(10),

        /**
        * Hearing Aid. <br/>
        * <br/>
        */
        HearingAid(11);

        protected final int mValue;

        private Type (int value) {
            mValue = value;
        }

        static public Type fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Unknown;
            case 1: return Microphone;
            case 2: return Earpiece;
            case 3: return Speaker;
            case 4: return Bluetooth;
            case 5: return BluetoothA2DP;
            case 6: return Telephony;
            case 7: return AuxLine;
            case 8: return GenericUsb;
            case 9: return Headset;
            case 10: return Headphones;
            case 11: return HearingAid;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Type");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Returns the capabilities of the device. <br/>
    * <br/>
    * @return the {@link Capabilities} of the audio device (RECORD, PLAY or both) as<br/>
    * a bit mask <br/>
    */
    public AudioDevice.Capabilities getCapabilities();

    /**
    * Returns the name of the audio device. <br/>
    * <br/>
    * @return the name of the audio device.   <br/>
    */
    @NonNull
    public String getDeviceName();

    /**
    * Returns the driver name used by the device. <br/>
    * <br/>
    * @return the name of the driver used by this audio device.   <br/>
    */
    @NonNull
    public String getDriverName();

    /**
    * Returns whether the audio device automatically follows the system's audio<br/>
    * routing policy. <br/>
    * <br/>
    * This capability is available on some system (typically iOS) and might be<br/>
    * convenient to simply specify liblinphone to let the system decide about which<br/>
    * audio route is being used to handle a call. The actual {@link Type} may be<br/>
    * unknown at some point, typically when no calls are running, otherwise it is<br/>
    * reflected to be the actual system's audio route. <br/>
    * @return true if the audio device automatically follows the system audio routing<br/>
    * policy. <br/>
    */
    public boolean getFollowsSystemRoutingPolicy();

    /**
    * Returns the id of the audio device. <br/>
    * <br/>
    * @return the id of the audio device.   <br/>
    */
    @NonNull
    public String getId();

    /**
    * Returns the type of the device. <br/>
    * <br/>
    * @return the {@link Type} of the audio device (microphone, speaker, earpiece,<br/>
    * bluetooth, etc...) <br/>
    */
    public AudioDevice.Type getType();

    /**
    * Returns whether or not the audio device has the given capability. <br/>
    * <br/>
    * @param capability the {@link Capabilities} to check <br/>
    * @return true if the audio device has the capability, false otherwise <br/>
    */
    public boolean hasCapability(AudioDevice.Capabilities capability);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AudioDeviceImpl implements AudioDevice {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AudioDeviceImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getCapabilities(long nativePtr);
    @Override
    synchronized public AudioDevice.Capabilities getCapabilities()  {
        
        
        return AudioDevice.Capabilities.fromInt(getCapabilities(nativePtr));
    }

    private native String getDeviceName(long nativePtr);
    @Override @NonNull
    synchronized public String getDeviceName()  {
        
        
        return getDeviceName(nativePtr);
    }

    private native String getDriverName(long nativePtr);
    @Override @NonNull
    synchronized public String getDriverName()  {
        
        
        return getDriverName(nativePtr);
    }

    private native boolean getFollowsSystemRoutingPolicy(long nativePtr);
    @Override
    synchronized public boolean getFollowsSystemRoutingPolicy()  {
        
        
        return getFollowsSystemRoutingPolicy(nativePtr);
    }

    private native String getId(long nativePtr);
    @Override @NonNull
    synchronized public String getId()  {
        
        
        return getId(nativePtr);
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public AudioDevice.Type getType()  {
        
        
        return AudioDevice.Type.fromInt(getType(nativePtr));
    }

    private native boolean hasCapability(long nativePtr, int capability);
    @Override
    synchronized public boolean hasCapability(AudioDevice.Capabilities capability)  {
        
        
        return hasCapability(nativePtr, capability.toInt());
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
