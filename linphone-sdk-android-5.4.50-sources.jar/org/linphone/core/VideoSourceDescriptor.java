/*
VideoSourceDescriptor.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that is used to describe a video source. <br/>
* <br/>
*/
public interface VideoSourceDescriptor {
    /**
    * Gets the call of a {@link VideoSourceDescriptor}. <br/>
    * <br/>
    * @return The {@link Call} of the video source descriptor if it's type is<br/>
    * LinphoneVideoSourceCall, null otherwise.    <br/>
    */
    @Nullable
    public Call getCall();

    /**
    * Sets the source of a {@link VideoSourceDescriptor} with a call. <br/>
    * <br/>
    * Setting a {@link VideoSourceDescriptor} with a call will require the lib to<br/>
    * have two calls running at the same time. To do so the media resource mode has<br/>
    * to be set to LinphoneSharedMediaResources with {@link Core#setMediaResourceMode}<br/>
    * .<br/>
    * @param call The {@link Call} that will be used as a video source.   <br/>
    */
    public void setCall(@Nullable Call call);

    /**
    * Gets the camera id of a {@link VideoSourceDescriptor}. <br/>
    * <br/>
    * @return The camera id of the video source descriptor if it's type is<br/>
    * LinphoneVideoSourceCamera, null otherwise.    <br/>
    */
    @Nullable
    public String getCameraId();

    /**
    * Sets the source of a {@link VideoSourceDescriptor} with a camera id. <br/>
    * <br/>
    * @param cameraId The camera id that will be used as a video source.   <br/>
    */
    public void setCameraId(@Nullable String cameraId);

    /**
    * Gets the image path of a {@link VideoSourceDescriptor}. <br/>
    * <br/>
    * @return The image path of the video source descriptor if it's type is<br/>
    * LinphoneVideoSourceImage, null otherwise.    <br/>
    */
    @Nullable
    public String getImage();

    /**
    * Sets the source of a {@link VideoSourceDescriptor} with an image path. <br/>
    * <br/>
    * @param imagePath The image path that will be used as a video source.   <br/>
    */
    public void setImage(@Nullable String imagePath);

    /**
    * Gets the screen sharing description of a {@link VideoSourceDescriptor}. <br/>
    * <br/>
    * @return The native screen sharing description   <br/>
    */
    @Nullable
    public Object getScreenSharing();

    /**
    * Gets the screen sharing type of a {@link VideoSourceDescriptor}. <br/>
    * <br/>
    * @return The {@link VideoSourceType#ScreenSharing} Type corresponding to this<br/>
    * video source descriptor. <br/>
    */
    public VideoSourceScreenSharingType getScreenSharingType();

    /**
    * Gets the type of a {@link VideoSourceDescriptor}. <br/>
    * <br/>
    * @return The {@link VideoSourceType} corresponding to this video source<br/>
    * descriptor. <br/>
    */
    public VideoSourceType getType();

    /**
    * Instantiate a new video source descriptor with values from source. <br/>
    * <br/>
    * @return The newly created {@link VideoSourceDescriptor} object.   <br/>
    */
    @NonNull
    public VideoSourceDescriptor clone();

    /**
    * Sets the source of a {@link VideoSourceDescriptor} as screen sharing. <br/>
    * <br/>
    * native_data depends of the type and the current platform:<br/>
    * @param type The {@link VideoSourceScreenSharingType} type of native_data.   <br/>
    * @param nativeData The screen handle that will be used as a video source.   <br/>
    */
    public void setScreenSharing(@NonNull VideoSourceScreenSharingType type, @Nullable Object nativeData);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class VideoSourceDescriptorImpl implements VideoSourceDescriptor {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected VideoSourceDescriptorImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Call getCall(long nativePtr);
    @Override @Nullable
    synchronized public Call getCall()  {
        
        
        return (Call)getCall(nativePtr);
    }

    private native void setCall(long nativePtr, Call call);
    @Override
    synchronized public void setCall(@Nullable Call call)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCall() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCall(nativePtr, call);
    }

    private native String getCameraId(long nativePtr);
    @Override @Nullable
    synchronized public String getCameraId()  {
        
        
        return getCameraId(nativePtr);
    }

    private native void setCameraId(long nativePtr, String cameraId);
    @Override
    synchronized public void setCameraId(@Nullable String cameraId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCameraId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCameraId(nativePtr, cameraId);
    }

    private native String getImage(long nativePtr);
    @Override @Nullable
    synchronized public String getImage()  {
        
        
        return getImage(nativePtr);
    }

    private native void setImage(long nativePtr, String imagePath);
    @Override
    synchronized public void setImage(@Nullable String imagePath)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setImage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setImage(nativePtr, imagePath);
    }

    private native Object getScreenSharing(long nativePtr);
    @Override @Nullable
    synchronized public Object getScreenSharing()  {
        
        
        return getScreenSharing(nativePtr);
    }

    private native int getScreenSharingType(long nativePtr);
    @Override
    synchronized public VideoSourceScreenSharingType getScreenSharingType()  {
        
        
        return VideoSourceScreenSharingType.fromInt(getScreenSharingType(nativePtr));
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public VideoSourceType getType()  {
        
        
        return VideoSourceType.fromInt(getType(nativePtr));
    }

    private native VideoSourceDescriptor clone(long nativePtr);
    @Override @NonNull
    synchronized public VideoSourceDescriptor clone()  {
        
        
        return (VideoSourceDescriptor)clone(nativePtr);
    }

    private native void setScreenSharing(long nativePtr, int type, Object nativeData);
    @Override
    synchronized public void setScreenSharing(@NonNull VideoSourceScreenSharingType type, @Nullable Object nativeData)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setScreenSharing() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setScreenSharing(nativePtr, type.toInt(), nativeData);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
