/*
AuthInfo.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object holding authentication information. <br/>
* <br/>
* In most case, authentication information consists of a username and password.<br/>
* If realm isn't set, it will be deduced automatically from the first<br/>
* authentication challenge as for the hash algorithm. Sometimes, a userid is<br/>
* required by the proxy and then domain can be useful to discriminate different<br/>
* credentials. You can also use this object if you need to use a client<br/>
* certificate.<br/>
* Once created and filled, a {@link AuthInfo} must be added to the {@link Core}<br/>
* in order to become known and used automatically when needed. Use {@link Core#addAuthInfo}<br/>
* for that purpose.<br/>
* The {@link Core} object can take the initiative to request authentication<br/>
* information when needed to the application through the<br/>
* authentication_requested() callback of it's {@link CoreListener}.<br/>
* The application can respond to this information request later using {@link Core#addAuthInfo}<br/>
* . This will unblock all pending authentication transactions and retry them with<br/>
* authentication headers. <br/>
*/
public interface AuthInfo {
    /**
    * Return a previously set access token. <br/>
    * <br/>
    * @return the access token, as a {@link BearerToken} object   <br/>
    */
    @Nullable
    public BearerToken getAccessToken();

    /**
    * Set an access token to authenticate, to be used when the server supports the<br/>
    * "bearer" authentication method. <br/>
    * <br/>
    * The {@link AuthInfo} takes a reference to the supplied token, it is not making<br/>
    * any copy. <br/>
    * @param token The {@link BearerToken} object representing the access token.   <br/>
    */
    public void setAccessToken(@Nullable BearerToken token);

    /**
    * Gets the algorithm. <br/>
    * <br/>
    * @return The algorithm.   <br/>
    */
    @Nullable
    public String getAlgorithm();

    /**
    * Sets the algorithm to use. <br/>
    * <br/>
    * @param algorithm The algorithm.   <br/>
    */
    public void setAlgorithm(@Nullable String algorithm);

    /**
    * Get the previously set authorization server uri. <br/>
    * <br/>
    * @return the authorization server uri.   <br/>
    */
    @Nullable
    public String getAuthorizationServer();

    /**
    * Set the authorization server uri. <br/>
    * <br/>
    * @param uri the authorization server uri.   <br/>
    */
    public void setAuthorizationServer(@Nullable String uri);

    /**
    * Gets all available algorithms. <br/>
    * <br/>
    * @return A list of available algorithms.    <br/>
    */
    @NonNull
    public String[] getAvailableAlgorithms();

    /**
    * Sets the available algorithms list without testing unicity. <br/>
    * <br/>
    * @param algorithms The available algorithms list.    <br/>
    */
    public void setAvailableAlgorithms(@Nullable String[] algorithms);

    /**
    * Get the previously set OAUTH2 client_id. <br/>
    * <br/>
    * @return the client_id.   <br/>
    */
    @Nullable
    public String getClientId();

    /**
    * Set the OAUTH2 client_id. <br/>
    * <br/>
    * The client_id may be used to renew access token from refresh token. If a<br/>
    * client_secret is required, it has to be set through {@link #setClientSecret}.<br/>
    * see: {@link #setRefreshToken} <br/>
    * @param clientId the client_id.   <br/>
    */
    public void setClientId(@Nullable String clientId);

    /**
    * Get the previously set OAUTH2 client_secret. <br/>
    * <br/>
    * @return the client_secret.   <br/>
    */
    @Nullable
    public String getClientSecret();

    /**
    * Set the OAUTH2 client_secret. <br/>
    * <br/>
    * The client_secret may be used to renew access token from refresh token.<br/>
    * see: {@link #setRefreshToken} <br/>
    * @param clientSecret the client_secret.   <br/>
    */
    public void setClientSecret(@Nullable String clientSecret);

    /**
    * Gets the domain. <br/>
    * <br/>
    * @return The domain.   <br/>
    */
    @Nullable
    public String getDomain();

    /**
    * Sets the domain for which this authentication is valid. <br/>
    * <br/>
    * @param domain The domain.   This should not be necessary because realm is<br/>
    * supposed to be unique and sufficient. However, many SIP servers don't set realm<br/>
    * correctly, then domain has to be used to distinguish between several SIP<br/>
    * account bearing the same username. <br/>
    */
    public void setDomain(@Nullable String domain);

    /**
    * Get the expiration time for the current authentication information. <br/>
    * <br/>
    * @return The expiration time as a number of seconds since the Epoch, 1970-01-01<br/>
    * 00:00:00 +0000 (UTC) <br/>
    */
    public long getExpires();

    /**
    * Set the expiration time for the current authentication information. <br/>
    * <br/>
    * @param expires The new expiration time in seconds. Use 0 to indicate no<br/>
    * expiration. <br/>
    */
    public void setExpires(long expires);

    /**
    * Gets the ha1. <br/>
    * <br/>
    * @return The ha1.   <br/>
    */
    @Nullable
    public String getHa1();

    /**
    * Sets the ha1. <br/>
    * <br/>
    * @param ha1 The ha1.   <br/>
    */
    public void setHa1(@Nullable String ha1);

    /**
    * Gets the password. <br/>
    * <br/>
    * @return The password.   <br/>
    */
    @Nullable
    public String getPassword();

    /**
    * Sets the password. <br/>
    * <br/>
    * @param password The password.   <br/>
    */
    public void setPassword(@Nullable String password);

    /**
    * Gets the realm. <br/>
    * <br/>
    * @return The realm.   <br/>
    */
    @Nullable
    public String getRealm();

    /**
    * Sets the realm. <br/>
    * <br/>
    * @param realm The realm.   <br/>
    */
    public void setRealm(@Nullable String realm);

    /**
    * Return a previously set refresh token. <br/>
    * <br/>
    * @return the refresh token, as a {@link BearerToken} object.   <br/>
    */
    @Nullable
    public BearerToken getRefreshToken();

    /**
    * Set a refresh token to use when the access token set with {@link #setAccessToken}<br/>
    * expires. <br/>
    * <br/>
    * The {@link AuthInfo} takes a reference to the supplied token, it is not making<br/>
    * any copy. Provided that the token endpoint uri was assigned with {@link #setTokenEndpointUri}<br/>
    * , once the {@link AuthInfo} is pushed in the {@link Core}, {@link AuthInfo}<br/>
    * object automatically obtains new access token when needed, from the supplied<br/>
    * refresh token. <br/>
    * @param token The {@link BearerToken} object representing the refresh token.   <br/>
    */
    public void setRefreshToken(@Nullable BearerToken token);

    /**
    * Gets the TLS certificate. <br/>
    * <br/>
    * @return The TLS certificate.   <br/>
    */
    @Nullable
    public String getTlsCert();

    /**
    * Sets the TLS certificate. <br/>
    * <br/>
    * @param tlsCert The TLS certificate.   <br/>
    */
    public void setTlsCert(@Nullable String tlsCert);

    /**
    * Gets the TLS certificate path. <br/>
    * <br/>
    * @return The TLS certificate path.   <br/>
    */
    @Nullable
    public String getTlsCertPath();

    /**
    * Sets the TLS certificate path. <br/>
    * <br/>
    * @param tlsCertPath The TLS certificate path.   <br/>
    */
    public void setTlsCertPath(@Nullable String tlsCertPath);

    /**
    * Gets the TLS key. <br/>
    * <br/>
    * @return The TLS key.   <br/>
    */
    @Nullable
    public String getTlsKey();

    /**
    * Sets the TLS key. <br/>
    * <br/>
    * @param tlsKey The TLS key.   <br/>
    */
    public void setTlsKey(@Nullable String tlsKey);

    /**
    * Gets the TLS key path. <br/>
    * <br/>
    * @return The TLS key path.   <br/>
    */
    @Nullable
    public String getTlsKeyPath();

    /**
    * Sets the TLS key path. <br/>
    * <br/>
    * @param tlsKeyPath The TLS key path.   <br/>
    */
    public void setTlsKeyPath(@Nullable String tlsKeyPath);

    /**
    * Get the previously set token endpoint https uri (OAUTH2). <br/>
    * <br/>
    * @return the token endpoint uri.   <br/>
    */
    @Nullable
    public String getTokenEndpointUri();

    /**
    * Set the token endpoint https uri (OAUTH2). <br/>
    * <br/>
    * The token endpoint uri is used to renew access token from refresh token. see:<br/>
    * {@link #setRefreshToken} <br/>
    * @param uri the token endpoint uri.   <br/>
    */
    public void setTokenEndpointUri(@Nullable String uri);

    /**
    * Gets the user id. <br/>
    * <br/>
    * @return The user id.   <br/>
    */
    @Nullable
    public String getUserid();

    /**
    * Sets the user ID. <br/>
    * <br/>
    * @param userId The userid.   <br/>
    */
    public void setUserid(@Nullable String userId);

    /**
    * Gets the username. <br/>
    * <br/>
    * @return The username.   <br/>
    */
    @Nullable
    public String getUsername();

    /**
    * Sets the username. <br/>
    * <br/>
    * @param username The username.   <br/>
    */
    public void setUsername(@Nullable String username);

    /**
    * Add an unique algorithm in the the available algorithms list : Algorithms that<br/>
    * already exist will not be added. <br/>
    * <br/>
    * @param algorithm The algorithm to add.   <br/>
    */
    public void addAvailableAlgorithm(@Nullable String algorithm);

    /**
    * Remove all algorithms from the available algorithms list. <br/>
    * <br/>
    */
    public void clearAvailableAlgorithms();

    /**
    * Instantiates a new auth info with values from source. <br/>
    * <br/>
    * @return The newly created {@link AuthInfo} object.   <br/>
    */
    @NonNull
    public AuthInfo clone();

    /**
    * Check if Authinfos are the same without taking account algorithms. <br/>
    * <br/>
    * @param authInfo2 The second {@link AuthInfo} object.   <br/>
    * @return true if all fields (Username, UserId, Realm, Domain) are the same. <br/>
    */
    public boolean isEqualButAlgorithms(@Nullable AuthInfo authInfo2);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AuthInfoImpl implements AuthInfo {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AuthInfoImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native BearerToken getAccessToken(long nativePtr);
    @Override @Nullable
    synchronized public BearerToken getAccessToken()  {
        
        
        return (BearerToken)getAccessToken(nativePtr);
    }

    private native void setAccessToken(long nativePtr, BearerToken token);
    @Override
    synchronized public void setAccessToken(@Nullable BearerToken token)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccessToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccessToken(nativePtr, token);
    }

    private native String getAlgorithm(long nativePtr);
    @Override @Nullable
    synchronized public String getAlgorithm()  {
        
        
        return getAlgorithm(nativePtr);
    }

    private native void setAlgorithm(long nativePtr, String algorithm);
    @Override
    synchronized public void setAlgorithm(@Nullable String algorithm)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAlgorithm() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAlgorithm(nativePtr, algorithm);
    }

    private native String getAuthorizationServer(long nativePtr);
    @Override @Nullable
    synchronized public String getAuthorizationServer()  {
        
        
        return getAuthorizationServer(nativePtr);
    }

    private native void setAuthorizationServer(long nativePtr, String uri);
    @Override
    synchronized public void setAuthorizationServer(@Nullable String uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAuthorizationServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAuthorizationServer(nativePtr, uri);
    }

    private native String[] getAvailableAlgorithms(long nativePtr);
    @Override @NonNull
    synchronized public String[] getAvailableAlgorithms()  {
        
        
        return getAvailableAlgorithms(nativePtr);
    }

    private native void setAvailableAlgorithms(long nativePtr, String[] algorithms);
    @Override
    synchronized public void setAvailableAlgorithms(@Nullable String[] algorithms)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAvailableAlgorithms() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAvailableAlgorithms(nativePtr, algorithms);
    }

    private native String getClientId(long nativePtr);
    @Override @Nullable
    synchronized public String getClientId()  {
        
        
        return getClientId(nativePtr);
    }

    private native void setClientId(long nativePtr, String clientId);
    @Override
    synchronized public void setClientId(@Nullable String clientId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setClientId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setClientId(nativePtr, clientId);
    }

    private native String getClientSecret(long nativePtr);
    @Override @Nullable
    synchronized public String getClientSecret()  {
        
        
        return getClientSecret(nativePtr);
    }

    private native void setClientSecret(long nativePtr, String clientSecret);
    @Override
    synchronized public void setClientSecret(@Nullable String clientSecret)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setClientSecret() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setClientSecret(nativePtr, clientSecret);
    }

    private native String getDomain(long nativePtr);
    @Override @Nullable
    synchronized public String getDomain()  {
        
        
        return getDomain(nativePtr);
    }

    private native void setDomain(long nativePtr, String domain);
    @Override
    synchronized public void setDomain(@Nullable String domain)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDomain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDomain(nativePtr, domain);
    }

    private native long getExpires(long nativePtr);
    @Override
    synchronized public long getExpires()  {
        
        
        return getExpires(nativePtr);
    }

    private native void setExpires(long nativePtr, long expires);
    @Override
    synchronized public void setExpires(long expires)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setExpires() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setExpires(nativePtr, expires);
    }

    private native String getHa11(long nativePtr);
    @Override @Nullable
    synchronized public String getHa1()  {
        
        
        return getHa11(nativePtr);
    }

    private native void setHa11(long nativePtr, String ha1);
    @Override
    synchronized public void setHa1(@Nullable String ha1)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHa1() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHa11(nativePtr, ha1);
    }

    private native String getPassword(long nativePtr);
    @Override @Nullable
    synchronized public String getPassword()  {
        
        
        return getPassword(nativePtr);
    }

    private native void setPassword(long nativePtr, String password);
    @Override
    synchronized public void setPassword(@Nullable String password)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPassword() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPassword(nativePtr, password);
    }

    private native String getRealm(long nativePtr);
    @Override @Nullable
    synchronized public String getRealm()  {
        
        
        return getRealm(nativePtr);
    }

    private native void setRealm(long nativePtr, String realm);
    @Override
    synchronized public void setRealm(@Nullable String realm)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRealm() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRealm(nativePtr, realm);
    }

    private native BearerToken getRefreshToken(long nativePtr);
    @Override @Nullable
    synchronized public BearerToken getRefreshToken()  {
        
        
        return (BearerToken)getRefreshToken(nativePtr);
    }

    private native void setRefreshToken(long nativePtr, BearerToken token);
    @Override
    synchronized public void setRefreshToken(@Nullable BearerToken token)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRefreshToken() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRefreshToken(nativePtr, token);
    }

    private native String getTlsCert(long nativePtr);
    @Override @Nullable
    synchronized public String getTlsCert()  {
        
        
        return getTlsCert(nativePtr);
    }

    private native void setTlsCert(long nativePtr, String tlsCert);
    @Override
    synchronized public void setTlsCert(@Nullable String tlsCert)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsCert() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsCert(nativePtr, tlsCert);
    }

    private native String getTlsCertPath(long nativePtr);
    @Override @Nullable
    synchronized public String getTlsCertPath()  {
        
        
        return getTlsCertPath(nativePtr);
    }

    private native void setTlsCertPath(long nativePtr, String tlsCertPath);
    @Override
    synchronized public void setTlsCertPath(@Nullable String tlsCertPath)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsCertPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsCertPath(nativePtr, tlsCertPath);
    }

    private native String getTlsKey(long nativePtr);
    @Override @Nullable
    synchronized public String getTlsKey()  {
        
        
        return getTlsKey(nativePtr);
    }

    private native void setTlsKey(long nativePtr, String tlsKey);
    @Override
    synchronized public void setTlsKey(@Nullable String tlsKey)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsKey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsKey(nativePtr, tlsKey);
    }

    private native String getTlsKeyPath(long nativePtr);
    @Override @Nullable
    synchronized public String getTlsKeyPath()  {
        
        
        return getTlsKeyPath(nativePtr);
    }

    private native void setTlsKeyPath(long nativePtr, String tlsKeyPath);
    @Override
    synchronized public void setTlsKeyPath(@Nullable String tlsKeyPath)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsKeyPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsKeyPath(nativePtr, tlsKeyPath);
    }

    private native String getTokenEndpointUri(long nativePtr);
    @Override @Nullable
    synchronized public String getTokenEndpointUri()  {
        
        
        return getTokenEndpointUri(nativePtr);
    }

    private native void setTokenEndpointUri(long nativePtr, String uri);
    @Override
    synchronized public void setTokenEndpointUri(@Nullable String uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTokenEndpointUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTokenEndpointUri(nativePtr, uri);
    }

    private native String getUserid(long nativePtr);
    @Override @Nullable
    synchronized public String getUserid()  {
        
        
        return getUserid(nativePtr);
    }

    private native void setUserid(long nativePtr, String userId);
    @Override
    synchronized public void setUserid(@Nullable String userId)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUserid() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUserid(nativePtr, userId);
    }

    private native String getUsername(long nativePtr);
    @Override @Nullable
    synchronized public String getUsername()  {
        
        
        return getUsername(nativePtr);
    }

    private native void setUsername(long nativePtr, String username);
    @Override
    synchronized public void setUsername(@Nullable String username)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUsername() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUsername(nativePtr, username);
    }

    private native void addAvailableAlgorithm(long nativePtr, String algorithm);
    @Override
    synchronized public void addAvailableAlgorithm(@Nullable String algorithm)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addAvailableAlgorithm() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addAvailableAlgorithm(nativePtr, algorithm);
    }

    private native void clearAvailableAlgorithms(long nativePtr);
    @Override
    synchronized public void clearAvailableAlgorithms()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clearAvailableAlgorithms() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clearAvailableAlgorithms(nativePtr);
    }

    private native AuthInfo clone(long nativePtr);
    @Override @NonNull
    synchronized public AuthInfo clone()  {
        
        
        return (AuthInfo)clone(nativePtr);
    }

    private native boolean isEqualButAlgorithms(long nativePtr, AuthInfo authInfo2);
    @Override
    synchronized public boolean isEqualButAlgorithms(@Nullable AuthInfo authInfo2)  {
        
        
        return isEqualButAlgorithms(nativePtr, authInfo2);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
