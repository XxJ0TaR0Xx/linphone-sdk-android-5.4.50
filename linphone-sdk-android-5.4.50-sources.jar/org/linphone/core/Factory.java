/*
Factory.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import android.content.Context;
import android.os.Build;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.linphone.mediastream.Version;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* The factory is a singleton object devoted to the creation of all the objects of<br/>
* Liblinphone that cannot be created by {@link Core} itself. <br/>
* <br/>
* It is also used to configure a few behaviors before creating the {@link Core},<br/>
* like the logs verbosity or collection. <br/>
*/
public abstract class Factory {
    static Factory _Factory;

    public static final synchronized Factory instance() {
        try {
            if (_Factory == null) {
                _Factory = new FactoryImpl();
            }
        } catch (Exception e) {
            System.err.println("Cannot instanciate factory");
        }
        return _Factory;
    }

    /**
      * Gets the LoggingService singleton
      */
    abstract public LoggingService getLoggingService();

    /**
     * When enabled, sets the verbosity level to MESSAGE and every log will be printed into logcat.
     * @deprecated use {@link #enableVerboseLogs}, {@link #setLoggerDomain} and {@link LoggingService#setLogLevel} instead.
     */
    abstract public void setDebugMode(boolean enable, String tag);

    /**
     * Used to change the domain name in the app Logger (default is Linphone).
     */
    abstract public void setLoggerDomain(String domain);

    /**
     * When enabled logs are printed into logcat.
     * warning: This won't have any effect if there is a {@link LoggingServiceListener} set by the app!
     */
    abstract public void enableLogcatLogs(boolean enable);

    /**
    * Set the directory where the application local cache is located. <br/>
    * <br/>
    * If the path is empty (default value), the path will be computed when calling<br/>
    * {@link #getDataDir} <br/>
    * @param path The path to the directory where the application local cache is<br/>
    * located   <br/>
    */
    abstract public void setCacheDir(@Nullable String path);

    /**
    * Set the directory where the configurations are located. <br/>
    * <br/>
    * If the path is empty (default value), the path will be computed when calling<br/>
    * {@link #getConfigDir} <br/>
    * @param path The path to the directory where the configurations are located   <br/>
    */
    abstract public void setConfigDir(@Nullable String path);

    /**
    * Set the directory where the application local data are located. <br/>
    * <br/>
    * If the path is empty (default value), the path will be computed when calling<br/>
    * {@link #getDataDir} <br/>
    * @param path The path to the directory where the application local data are<br/>
    * located   <br/>
    */
    abstract public void setDataDir(@Nullable String path);

    /**
    * Get the directory where the data resources are located. <br/>
    * <br/>
    * @return The path to the directory where the data resources are located   <br/>
    */
    @Nullable
    abstract public String getDataResourcesDir();

    /**
    * Set the directory where the data resources are located. <br/>
    * <br/>
    * @param path The path where the data resources are located   <br/>
    */
    abstract public void setDataResourcesDir(@Nullable String path);

    /**
    * Returns a bctbx_list_t of all DialPlans. <br/>
    * <br/>
    * @return A list of {@link DialPlan}    <br/>
    */
    @NonNull
    abstract public DialPlan[] getDialPlans();

    /**
    * Set the directory where downloads are located. <br/>
    * <br/>
    * If the path is empty (default value), the path will be computed when calling<br/>
    * {@link #getDownloadDir} <br/>
    * @param path The path to the directory where downloads are located   <br/>
    */
    abstract public void setDownloadDir(@Nullable String path);

    /**
    * Get the directory where the image resources are located. <br/>
    * <br/>
    * @return The path to the directory where the image resources are located   <br/>
    */
    @Nullable
    abstract public String getImageResourcesDir();

    /**
    * Set the directory where the image resources are located. <br/>
    * <br/>
    * @param path The path where the image resources are located   <br/>
    */
    abstract public void setImageResourcesDir(@Nullable String path);

    /**
    * Test if cache dir has been set. <br/>
    * <br/>
    * @return true if cache dir has been set. <br/>
    */
    abstract public boolean isCacheDirSet();

    /**
    * Test if config dir has been set. <br/>
    * <br/>
    * @return true if config dir has been set. <br/>
    */
    abstract public boolean isConfigDirSet();

    /**
    * Test if data dir has been set. <br/>
    * <br/>
    * @return true if data dir has been set. <br/>
    */
    abstract public boolean isDataDirSet();

    /**
    * Indicates if the storage in database is available. <br/>
    * <br/>
    * @return true if the database storage is available, false otherwise <br/>
    */
    abstract public boolean isDatabaseStorageAvailable();

    /**
    * Test if download dir has been set. <br/>
    * <br/>
    * @return true if download dir has been set. <br/>
    */
    abstract public boolean isDownloadDirSet();

    /**
    * Indicates if IMDN are available. <br/>
    * <br/>
    * @return true if IDMN are available <br/>
    */
    abstract public boolean isImdnAvailable();

    /**
    * Indicates if the QRCode feature is available. <br/>
    * <br/>
    * @return true if QRCodes can be used <br/>
    */
    abstract public boolean isQrcodeAvailable();

    /**
    * Get the directory where the liblinphone plugins are located. <br/>
    * <br/>
    * @return The path to the directory where the liblinphone plugins are located, or<br/>
    * null if it has not been set.    <br/>
    */
    @Nullable
    abstract public String getLiblinphonePluginsDir();

    /**
    * Set the directory where the liblinphone plugins are located. <br/>
    * <br/>
    * @param path The path to the directory where the liblinphone plugins are located<br/>
    *   <br/>
    */
    abstract public void setLiblinphonePluginsDir(@Nullable String path);

    /**
    * Sets the log collection path. <br/>
    * <br/>
    * @param path the path of the logs   <br/>
    */
    abstract public void setLogCollectionPath(@Nullable String path);

    /**
    * Get the directory where the mediastreamer2 plugins are located. <br/>
    * <br/>
    * @return The path to the directory where the mediastreamer2 plugins are located,<br/>
    * or null if it has not been set.    <br/>
    */
    @Nullable
    abstract public String getMspluginsDir();

    /**
    * Set the directory where the mediastreamer2 plugins are located. <br/>
    * <br/>
    * @param path The path to the directory where the mediastreamer2 plugins are<br/>
    * located   <br/>
    */
    abstract public void setMspluginsDir(@Nullable String path);

    /**
    * Get the recommended list of standard video definitions. <br/>
    * <br/>
    * This list is suitable for a widest set of hardware for all video codec<br/>
    * implementations, and thus excludes some very high definition formats that are<br/>
    * unlikely to work unless specific hardware or codecs are used. <br/>
    * @return A list of video definitions.    <br/>
    */
    @NonNull
    abstract public VideoDefinition[] getRecommendedVideoDefinitions();

    /**
    * Get the directory where the ring resources are located. <br/>
    * <br/>
    * @return The path to the directory where the ring resources are located   <br/>
    */
    @Nullable
    abstract public String getRingResourcesDir();

    /**
    * Set the directory where the ring resources are located. <br/>
    * <br/>
    * @param path The path where the ring resources are located   <br/>
    */
    abstract public void setRingResourcesDir(@Nullable String path);

    /**
    * Get the directory where the sound resources are located. <br/>
    * <br/>
    * @return The path to the directory where the sound resources are located   <br/>
    */
    @Nullable
    abstract public String getSoundResourcesDir();

    /**
    * Set the directory where the sound resources are located. <br/>
    * <br/>
    * @param path The path where the sound resources are located   <br/>
    */
    abstract public void setSoundResourcesDir(@Nullable String path);

    /**
    * Get the list of standard video definitions supported by Linphone. <br/>
    * <br/>
    * @return A list of video definitions.    <br/>
    */
    @NonNull
    abstract public VideoDefinition[] getSupportedVideoDefinitions();

    /**
    * Get the top directory where the resources are located. <br/>
    * <br/>
    * @return The path to the top directory where the resources are located   <br/>
    */
    @Nullable
    abstract public String getTopResourcesDir();

    /**
    * Set the top directory where the resources are located. <br/>
    * <br/>
    * If you only define this top directory, the other resources directory will<br/>
    * automatically be derived form this one. <br/>
    * @param path The path to the top directory where the resources are located   <br/>
    */
    abstract public void setTopResourcesDir(@Nullable String path);

    /**
    * Computes the hashed version of the password given the user ID and the realm,<br/>
    * using given algorithm. <br/>
    * <br/>
    * @param userid the username or user ID to use.   <br/>
    * @param password the password to hash.   <br/>
    * @param realm the real to use.   <br/>
    * @param algorithm the algorithm to use (MD5 or SHA-256).   <br/>
    * @return the generated hash if it succeeded, null otherwise.     <br/>
    */
    @Nullable
    abstract public String computeHa1ForAlgorithm(@NonNull String userid, @NonNull String password, @NonNull String realm, @NonNull String algorithm);

    /**
    * Parse a string holding a SIP URI and create the according {@link Address}<br/>
    * object. <br/>
    * <br/>
    * @param addr A string holding the SIP URI to parse.   <br/>
    * @return A new {@link Address}.   <br/>
    */
    @Nullable
    abstract public Address createAddress(@NonNull String addr);

    /**
    * Creates a {@link AuthInfo} object. <br/>
    * <br/>
    * The object can be created empty, that is with all arguments set to null.<br/>
    * Username, userid, password, realm and domain can be set later using specific<br/>
    * methods. At the end, username and passwd (or ha1) are required. <br/>
    * @param username The username that needs to be authenticated   <br/>
    * @param userid The userid used for authenticating (use null if you don't know<br/>
    * what it is)   <br/>
    * @param passwd The password in clear text   <br/>
    * @param ha1 The ha1-encrypted password if password is not given in clear text.   <br/>
    * @param realm The authentication domain (which can be larger than the sip<br/>
    * domain. Unfortunately many SIP servers don't use this parameter.   <br/>
    * @param domain The SIP domain for which this authentication information is<br/>
    * valid, if it has to be restricted for a single SIP domain.   <br/>
    * @return A {@link AuthInfo} object. linphone_auth_info_destroy must be used to<br/>
    * destroy it when no longer needed. The {@link Core} makes a copy of {@link AuthInfo}<br/>
    * passed through {@link Core#addAuthInfo}.   <br/>
    */
    @NonNull
    abstract public AuthInfo createAuthInfo(@NonNull String username, @Nullable String userid, @Nullable String passwd, @Nullable String ha1, @Nullable String realm, @Nullable String domain);

    /**
    * Creates a {@link AuthInfo} object. <br/>
    * <br/>
    * The object can be created empty, that is with all arguments set to null.<br/>
    * Username, userid, password, realm and domain can be set later using specific<br/>
    * methods. At the end, username and passwd (or ha1) are required. <br/>
    * @param username The username that needs to be authenticated   <br/>
    * @param userid The userid used for authenticating (use null if you don't know<br/>
    * what it is)   <br/>
    * @param passwd The password in clear text   <br/>
    * @param ha1 The ha1-encrypted password if password is not given in clear text.   <br/>
    * @param realm The authentication domain (which can be larger than the sip<br/>
    * domain. Unfortunately many SIP servers don't use this parameter.   <br/>
    * @param domain The SIP domain for which this authentication information is<br/>
    * valid, if it has to be restricted for a single SIP domain.   <br/>
    * @param algorithm The algorithm for encrypting password.   <br/>
    * @return A {@link AuthInfo} object. linphone_auth_info_destroy must be used to<br/>
    * destroy it when no longer needed. The {@link Core} makes a copy of {@link AuthInfo}<br/>
    * passed through {@link Core#addAuthInfo}.   <br/>
    */
    @NonNull
    abstract public AuthInfo createAuthInfo(@NonNull String username, @Nullable String userid, @Nullable String passwd, @Nullable String ha1, @Nullable String realm, @Nullable String domain, @Nullable String algorithm);

    /**
    * Creates a {@link AuthInfo} object. <br/>
    * <br/>
    * The object can be created empty, that is with all arguments set to null.<br/>
    * Username, userid, password, realm and domain can be set later using specific<br/>
    * methods. At the end, username and passwd (or ha1) are required. <br/>
    * @param username The username that needs to be authenticated   <br/>
    * @param accessToken An access token to send to authenticate   <br/>
    * @param realm The authentication domain (which can be larger than the sip<br/>
    * domain. Unfortunately many SIP servers don't use this parameter.   <br/>
    * @return A {@link AuthInfo} object. linphone_auth_info_unref must be used to<br/>
    * destroy it when no longer needed. The {@link Core} makes a copy of {@link AuthInfo}<br/>
    * passed through {@link Core#addAuthInfo}.   <br/>
    */
    @NonNull
    abstract public AuthInfo createAuthInfo(@NonNull String username, @Nullable BearerToken accessToken, @Nullable String realm);

    /**
    * Create a new {@link BearerToken} object. <br/>
    * <br/>
    * The expiration time may be set to zero if unknown, in which case the {@link Core}<br/>
    * will anyway use the refresh token if an access token is rejected by a server. <br/>
    * @param token the token, as an opaque string.   <br/>
    * @param expirationTime the expiration time as the number of seconds since the<br/>
    * Epoch, 1970-01-01 00:00:00 +0000 (UTC). <br/>
    * @return the newly created {@link BearerToken} .   <br/>
    */
    @NonNull
    abstract public BearerToken createBearerToken(@NonNull String token, long expirationTime);

    /**
    * Creates an object {@link Buffer}. <br/>
    * <br/>
    * @return a {@link Buffer}   <br/>
    */
    @NonNull
    abstract public Buffer createBuffer();

    /**
    * Creates an object {@link Buffer}. <br/>
    * <br/>
    * @param data the data to set in the buffer   <br/>
    * @param size the size of the data <br/>
    * @return a {@link Buffer}   <br/>
    */
    @NonNull
    abstract public Buffer createBufferFromData(@NonNull byte[] data, int size);

    /**
    * Creates an object {@link Buffer}. <br/>
    * <br/>
    * @param data the data to set in the buffer   <br/>
    * @return a {@link Buffer}   <br/>
    */
    @NonNull
    abstract public Buffer createBufferFromString(@NonNull String data);

    /**
    * Creates an object {@link ConferenceInfo}. <br/>
    * <br/>
    * @return a {@link ConferenceInfo}   <br/>
    */
    @NonNull
    abstract public ConferenceInfo createConferenceInfo();

    /**
    * Creates an object {@link ConferenceInfo} from an Icalendar {@link Content}. <br/>
    * <br/>
    * @param content the Icalendar {@link Content}   <br/>
    * @return a {@link ConferenceInfo} created from an Icalendar {@link Content}   <br/>
    */
    @Nullable
    abstract public ConferenceInfo createConferenceInfoFromIcalendarContent(@NonNull Content content);

    /**
    * Creates an object {@link Config}. <br/>
    * <br/>
    * @param path the path of the config   <br/>
    * @return a {@link Config}   <br/>
    */
    @NonNull
    abstract public Config createConfig(@Nullable String path);

    /**
    * Creates an object {@link Config}. <br/>
    * <br/>
    * @param data the config data   <br/>
    * @return a {@link Config}   <br/>
    */
    @NonNull
    abstract public Config createConfigFromString(@NonNull String data);

    /**
    * Creates an object {@link Config}. <br/>
    * <br/>
    * @param path the path of the config   <br/>
    * @param factoryPath the path of the factory   <br/>
    * @return a {@link Config}   <br/>
    */
    @NonNull
    abstract public Config createConfigWithFactory(@Nullable String path, @Nullable String factoryPath);

    /**
    * Creates an object {@link Content}. <br/>
    * <br/>
    * @return a {@link Content}   <br/>
    */
    @NonNull
    abstract public Content createContent();

    /**
    * Creates a file object of {@link Content} from a file path. <br/>
    * <br/>
    * @param filePath the path of the file   <br/>
    * @return a {@link Content} which can be used as a file   <br/>
    */
    @NonNull
    abstract public Content createContentFromFile(@NonNull String filePath);

    /**
    * Instantiate a {@link Core} object. <br/>
    * <br/>
    * The {@link Core} object is the primary handle for doing all phone actions. It<br/>
    * should be unique within your application. The {@link Core} object is not<br/>
    * started automatically, you need to call {@link Core#start} to that effect. The<br/>
    * returned {@link Core} will be in {@link GlobalState} Ready. Core ressources can<br/>
    * be released using {@link Core#stop} which is strongly encouraged on garbage<br/>
    * collected languages. <br/>
    * @param configPath A path to a config file. If it does not exists it will be<br/>
    * created. The config file is used to store all settings, proxies... so that all<br/>
    * these settings become persistent over the life of the {@link Core} object. It<br/>
    * is allowed to set a null config file. In that case {@link Core} will not store<br/>
    * any settings.   <br/>
    * @param factoryConfigPath A path to a read-only config file that can be used to<br/>
    * store hard-coded preferences such as proxy settings or internal preferences.<br/>
    * The settings in this factory file always override the ones in the normal config<br/>
    * file. It is optional, use null if unneeded.   <br/>
    * @param systemContext A pointer to a system object required by the core to<br/>
    * operate. Currently it is required to pass an android Context on android, pass<br/>
    * null on other platforms.   <br/>
    * @return a {@link Core} object   <br/>
    * see: linphone_core_new_with_config_3() <br/>
    */
    @NonNull
    abstract public Core createCore(@Nullable String configPath, @Nullable String factoryConfigPath, @Nullable Object systemContext);

    /**
    * Instantiate a {@link Core} object with a given LinphoneConfig. <br/>
    * <br/>
    * The {@link Core} object is the primary handle for doing all phone actions. It<br/>
    * should be unique within your application. The {@link Core} object is not<br/>
    * started automatically, you need to call {@link Core#start} to that effect. The<br/>
    * returned {@link Core} will be in {@link GlobalState} Ready. Core ressources can<br/>
    * be released using {@link Core#stop} which is strongly encouraged on garbage<br/>
    * collected languages. <br/>
    * @param config A {@link Config} object holding the configuration for the {@link Core}<br/>
    * to be instantiated.   <br/>
    * @param systemContext A pointer to a system object required by the core to<br/>
    * operate. Currently it is required to pass an android Context on android, pass<br/>
    * null on other platforms.   <br/>
    * @return a {@link Core} object   <br/>
    * see: {@link #createCore} <br/>
    */
    @NonNull
    abstract public Core createCoreWithConfig(@NonNull Config config, @Nullable Object systemContext);

    /**
    * Create a {@link DigestAuthenticationPolicy} object. <br/>
    * <br/>
    * The {@link DigestAuthenticationPolicy} object which is used to configure a<br/>
    * policy for digest authentication, such as allowing MD5 or mode without<br/>
    * qop=auth. <br/>
    * @return a new {@link DigestAuthenticationPolicy} .   <br/>
    */
    @NonNull
    abstract public DigestAuthenticationPolicy createDigestAuthenticationPolicy();

    /**
    * Create an empty {@link EktInfo} object. <br/>
    * <br/>
    * @return A new {@link EktInfo} object   <br/>
    */
    @NonNull
    abstract public EktInfo createEktInfo();

    /**
    * Creates an object LinphoneErrorInfo. <br/>
    * <br/>
    * @return a {@link ErrorInfo} object.   <br/>
    */
    @NonNull
    abstract public ErrorInfo createErrorInfo();

    /**
    * Creates a new {@link FriendPhoneNumber} object. <br/>
    * <br/>
    * @param phoneNumber The phone number.   <br/>
    * @param label the type of phone number, for example "home", "cell", etc. Use<br/>
    * null or empty for no label.   <br/>
    * @return The newly created {@link FriendPhoneNumber} object.   <br/>
    */
    @NonNull
    abstract public FriendPhoneNumber createFriendPhoneNumber(@NonNull String phoneNumber, @Nullable String label);

    /**
    * Create a {@link ParticipantDeviceIdentity} object. <br/>
    * <br/>
    * @param address {@link Address} object.   <br/>
    * @param name the name given to the device.   <br/>
    * @return A new {@link ParticipantDeviceIdentity}.   <br/>
    */
    @NonNull
    abstract public ParticipantDeviceIdentity createParticipantDeviceIdentity(@NonNull Address address, @Nullable String name);

    /**
    * Creates an object {@link ConferenceInfo} from an Icalendar {@link Content}. <br/>
    * <br/>
    * @param address the {@link Address} of the participant   <br/>
    * @return a {@link ParticipantInfo}   <br/>
    */
    @Nullable
    abstract public ParticipantInfo createParticipantInfo(@NonNull Address address);

    /**
    * Creates a Bitmap QRCode and return it into an object {@link Content}. <br/>
    * <br/>
    * @param code The code to be generated into an image. It must not be empty.   <br/>
    * @param width The requested width of the QRCode image. It will be 100 if 0. <br/>
    * @param height The requested height of the QRCode image. It will be 100 if 0. <br/>
    * @param margin The requested margin of the QRCode image. <br/>
    * @return a {@link Content}   <br/>
    */
    @Nullable
    abstract public Content createQrcode(@NonNull String code, int width, int height, int margin);

    /**
    * Creates an object LinphoneRange. <br/>
    * <br/>
    * @return a {@link Range} object.   <br/>
    */
    @NonNull
    abstract public Range createRange();

    /**
    * Creates an object {@link SignalInformation}. <br/>
    * <br/>
    * @return a {@link SignalInformation}   <br/>
    */
    @NonNull
    abstract public SignalInformation createSignalInformation();

    /**
    * Creates an object LinphoneTransports. <br/>
    * <br/>
    * @return a {@link Transports} object.   <br/>
    */
    @NonNull
    abstract public Transports createTransports();

    /**
    * Creates an object {@link TunnelConfig}. <br/>
    * <br/>
    * @return a {@link TunnelConfig}   <br/>
    */
    @NonNull
    abstract public TunnelConfig createTunnelConfig();

    /**
    * Create an empty {@link Vcard}. <br/>
    * <br/>
    * @return a new {@link Vcard}.   <br/>
    */
    @NonNull
    abstract public Vcard createVcard();

    /**
    * Creates an object LinphoneVideoActivationPolicy. <br/>
    * <br/>
    * @return {@link VideoActivationPolicy} object.   <br/>
    */
    @NonNull
    abstract public VideoActivationPolicy createVideoActivationPolicy();

    /**
    * Create a {@link VideoDefinition} from a given width and height. <br/>
    * <br/>
    * @param width The width of the created video definition <br/>
    * @param height The height of the created video definition <br/>
    * @return A new {@link VideoDefinition} object   <br/>
    */
    @NonNull
    abstract public VideoDefinition createVideoDefinition(int width, int height);

    /**
    * Create a {@link VideoDefinition} from a given standard definition name. <br/>
    * <br/>
    * @param name The standard definition name of the video definition to create   <br/>
    * @return A new {@link VideoDefinition} object   <br/>
    */
    @NonNull
    abstract public VideoDefinition createVideoDefinitionFromName(@NonNull String name);

    /**
    * Creates an object {@link VideoSourceDescriptor}. <br/>
    * <br/>
    * @return a {@link VideoSourceDescriptor}   <br/>
    */
    @NonNull
    abstract public VideoSourceDescriptor createVideoSourceDescriptor();

    /**
    * Enables or disables log collection. <br/>
    * <br/>
    * @param state the {@link LogCollectionState} for log collection <br/>
    */
    abstract public void enableLogCollection(LogCollectionState state);

    /**
    * Get the cache path. <br/>
    * <br/>
    * @param context used to compute path. Can be null. JavaPlatformHelper on Android<br/>
    * and char *appGroupId on iOS with shared core.   <br/>
    * @return The cache path   <br/>
    */
    @Nullable
    abstract public String getCacheDir(@Nullable Object context);

    /**
    * Get the config path. <br/>
    * <br/>
    * @param context used to compute path. Can be null. JavaPlatformHelper on Android<br/>
    * and char *appGroupId on iOS with shared core.   <br/>
    * @return The config path   <br/>
    */
    @Nullable
    abstract public String getConfigDir(@Nullable Object context);

    /**
    * Get the data path. <br/>
    * <br/>
    * @param context used to compute path. Can be null. JavaPlatformHelper on Android<br/>
    * and char *appGroupId on iOS with shared core.   <br/>
    * @return The data path   <br/>
    */
    @Nullable
    abstract public String getDataDir(@Nullable Object context);

    /**
    * Get the download path. <br/>
    * <br/>
    * @param context used to compute path. Can be null. JavaPlatformHelper on Android<br/>
    * and char *appGroupId on iOS with shared core.   <br/>
    * @return The download path   <br/>
    */
    @Nullable
    abstract public String getDownloadDir(@Nullable Object context);

    /**
    * Indicates if the given LinphoneChatRoomBackend is available. <br/>
    * <br/>
    * @param chatroomBackend the {@link ChatRoom#Backend} <br/>
    * @return true if the chatroom backend is available, false otherwise <br/>
    */
    abstract public boolean isChatroomBackendAvailable(ChatRoom.Backend chatroomBackend);

    /**
    * Select encryption module and set secret material to encrypt the files. <br/>
    * <br/>
    * @param encryptionModule One of the available encryption module for VFS, pick in<br/>
    * the LINPHONE_VFS_ENCRYPTION_* list if set to _UNSET, default bctoolbox VFS is<br/>
    * switch to Standard one <br/>
    * @param secret the secret material used to encrypt the files, can be null for<br/>
    * the _PLAIN module    <br/>
    * @param secretSize size of the secret<br/>
    * @return true if everything went well, false if it appears that the given secret<br/>
    * is unable to decrypt existing configuration <br/>
    */
    abstract public boolean setVfsEncryption(int encryptionModule, @Nullable byte[] secret, int secretSize);

    /**
    * Creates a QRCode and write it into a JPEG file specified by file_path (only if<br/>
    * build with JPEG). <br/>
    * <br/>
    * @param filePath The file where to write the QRCode JPEG image.   <br/>
    * @param code The code to be generated into an image. It must not be empty.   <br/>
    * @param width The requested width of the QRCode image. It will be 100 if 0. <br/>
    * @param height The requested height of the QRCode image. It will be 100 if 0. <br/>
    * @param margin The requested margin of the QRCode image. <br/>
    * @return 0 if successful, -2 if JPEG is not supported, -1 otherwise <br/>
    */
    abstract public int writeQrcodeFile(@NonNull String filePath, @NonNull String code, int width, int height, int margin);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    abstract public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    abstract public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    abstract public long getNativePointer();

    
}

class FactoryImpl extends Factory {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected LoggingService loggingService = null;

    protected FactoryImpl() {
        nativePtr = init();
    }

    private native long init();

    public long getNativePointer() {
        return nativePtr;
    }

    private static boolean loadOptionalLibrary(String s) {
        try {
            System.loadLibrary(s);
            return true;
        } catch (Throwable e) {
            android.util.Log.w("FactoryImpl", "Unable to load optional library " + s + ": " + e.getMessage());
        }
        return false;
    }

    static {
        System.loadLibrary("linphone");
        Version.dumpCapabilities();
    }

    @Override
    public LoggingService getLoggingService() {
        if (loggingService == null) {
            loggingService = new LoggingServiceImpl(0, false).get();
        }
        return loggingService;
    }

    @Override
    public native void setDebugMode(boolean enable, String tag);

    
    @Override
    public native void setLoggerDomain(String domain);

    
    @Override
    public native void enableLogcatLogs(boolean enable);


    public boolean isConst() {
        return _isConst;
    }

    private native void setCacheDir(long nativePtr, String path);
    @Override
    synchronized public void setCacheDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCacheDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCacheDir(nativePtr, path);
    }

    private native void setConfigDir(long nativePtr, String path);
    @Override
    synchronized public void setConfigDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConfigDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConfigDir(nativePtr, path);
    }

    private native void setDataDir(long nativePtr, String path);
    @Override
    synchronized public void setDataDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDataDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDataDir(nativePtr, path);
    }

    private native String getDataResourcesDir(long nativePtr);
    @Override @Nullable
    synchronized public String getDataResourcesDir()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDataResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDataResourcesDir(nativePtr);
    }

    private native void setDataResourcesDir(long nativePtr, String path);
    @Override
    synchronized public void setDataResourcesDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDataResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDataResourcesDir(nativePtr, path);
    }

    private native DialPlan[] getDialPlans(long nativePtr);
    @Override @NonNull
    synchronized public DialPlan[] getDialPlans()  {
        
        
        return getDialPlans(nativePtr);
    }

    private native void setDownloadDir(long nativePtr, String path);
    @Override
    synchronized public void setDownloadDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDownloadDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDownloadDir(nativePtr, path);
    }

    private native String getImageResourcesDir(long nativePtr);
    @Override @Nullable
    synchronized public String getImageResourcesDir()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getImageResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getImageResourcesDir(nativePtr);
    }

    private native void setImageResourcesDir(long nativePtr, String path);
    @Override
    synchronized public void setImageResourcesDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setImageResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setImageResourcesDir(nativePtr, path);
    }

    private native boolean isCacheDirSet(long nativePtr);
    @Override
    synchronized public boolean isCacheDirSet()  {
        
        
        return isCacheDirSet(nativePtr);
    }

    private native boolean isConfigDirSet(long nativePtr);
    @Override
    synchronized public boolean isConfigDirSet()  {
        
        
        return isConfigDirSet(nativePtr);
    }

    private native boolean isDataDirSet(long nativePtr);
    @Override
    synchronized public boolean isDataDirSet()  {
        
        
        return isDataDirSet(nativePtr);
    }

    private native boolean isDatabaseStorageAvailable(long nativePtr);
    @Override
    synchronized public boolean isDatabaseStorageAvailable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isDatabaseStorageAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isDatabaseStorageAvailable(nativePtr);
    }

    private native boolean isDownloadDirSet(long nativePtr);
    @Override
    synchronized public boolean isDownloadDirSet()  {
        
        
        return isDownloadDirSet(nativePtr);
    }

    private native boolean isImdnAvailable(long nativePtr);
    @Override
    synchronized public boolean isImdnAvailable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isImdnAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isImdnAvailable(nativePtr);
    }

    private native boolean isQrcodeAvailable(long nativePtr);
    @Override
    synchronized public boolean isQrcodeAvailable()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isQrcodeAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isQrcodeAvailable(nativePtr);
    }

    private native String getLiblinphonePluginsDir(long nativePtr);
    @Override @Nullable
    synchronized public String getLiblinphonePluginsDir()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLiblinphonePluginsDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getLiblinphonePluginsDir(nativePtr);
    }

    private native void setLiblinphonePluginsDir(long nativePtr, String path);
    @Override
    synchronized public void setLiblinphonePluginsDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLiblinphonePluginsDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLiblinphonePluginsDir(nativePtr, path);
    }

    private native void setLogCollectionPath(long nativePtr, String path);
    @Override
    synchronized public void setLogCollectionPath(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLogCollectionPath() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLogCollectionPath(nativePtr, path);
    }

    private native String getMspluginsDir(long nativePtr);
    @Override @Nullable
    synchronized public String getMspluginsDir()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getMspluginsDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getMspluginsDir(nativePtr);
    }

    private native void setMspluginsDir(long nativePtr, String path);
    @Override
    synchronized public void setMspluginsDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMspluginsDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMspluginsDir(nativePtr, path);
    }

    private native VideoDefinition[] getRecommendedVideoDefinitions(long nativePtr);
    @Override @NonNull
    synchronized public VideoDefinition[] getRecommendedVideoDefinitions()  {
        
        
        return getRecommendedVideoDefinitions(nativePtr);
    }

    private native String getRingResourcesDir(long nativePtr);
    @Override @Nullable
    synchronized public String getRingResourcesDir()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getRingResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getRingResourcesDir(nativePtr);
    }

    private native void setRingResourcesDir(long nativePtr, String path);
    @Override
    synchronized public void setRingResourcesDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRingResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRingResourcesDir(nativePtr, path);
    }

    private native String getSoundResourcesDir(long nativePtr);
    @Override @Nullable
    synchronized public String getSoundResourcesDir()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSoundResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getSoundResourcesDir(nativePtr);
    }

    private native void setSoundResourcesDir(long nativePtr, String path);
    @Override
    synchronized public void setSoundResourcesDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSoundResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSoundResourcesDir(nativePtr, path);
    }

    private native VideoDefinition[] getSupportedVideoDefinitions(long nativePtr);
    @Override @NonNull
    synchronized public VideoDefinition[] getSupportedVideoDefinitions()  {
        
        
        return getSupportedVideoDefinitions(nativePtr);
    }

    private native String getTopResourcesDir(long nativePtr);
    @Override @Nullable
    synchronized public String getTopResourcesDir()  {
        
        
        return getTopResourcesDir(nativePtr);
    }

    private native void setTopResourcesDir(long nativePtr, String path);
    @Override
    synchronized public void setTopResourcesDir(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTopResourcesDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTopResourcesDir(nativePtr, path);
    }

    private native String computeHa1ForAlgorithm(long nativePtr, String userid, String password, String realm, String algorithm);
    @Override @Nullable
    synchronized public String computeHa1ForAlgorithm(@NonNull String userid, @NonNull String password, @NonNull String realm, @NonNull String algorithm)  {
        
        
        return computeHa1ForAlgorithm(nativePtr, userid, password, realm, algorithm);
    }

    private native Address createAddress(long nativePtr, String addr);
    @Override @Nullable
    synchronized public Address createAddress(@NonNull String addr)  {
        
        
        return (Address)createAddress(nativePtr, addr);
    }

    private native AuthInfo createAuthInfo(long nativePtr, String username, String userid, String passwd, String ha1, String realm, String domain);
    @Override @NonNull
    synchronized public AuthInfo createAuthInfo(@NonNull String username, @Nullable String userid, @Nullable String passwd, @Nullable String ha1, @Nullable String realm, @Nullable String domain)  {
        
        
        return (AuthInfo)createAuthInfo(nativePtr, username, userid, passwd, ha1, realm, domain);
    }

    private native AuthInfo createAuthInfo2(long nativePtr, String username, String userid, String passwd, String ha1, String realm, String domain, String algorithm);
    @Override @NonNull
    synchronized public AuthInfo createAuthInfo(@NonNull String username, @Nullable String userid, @Nullable String passwd, @Nullable String ha1, @Nullable String realm, @Nullable String domain, @Nullable String algorithm)  {
        
        
        return (AuthInfo)createAuthInfo2(nativePtr, username, userid, passwd, ha1, realm, domain, algorithm);
    }

    private native AuthInfo createAuthInfo3(long nativePtr, String username, BearerToken accessToken, String realm);
    @Override @NonNull
    synchronized public AuthInfo createAuthInfo(@NonNull String username, @Nullable BearerToken accessToken, @Nullable String realm)  {
        
        
        return (AuthInfo)createAuthInfo3(nativePtr, username, accessToken, realm);
    }

    private native BearerToken createBearerToken(long nativePtr, String token, long expirationTime);
    @Override @NonNull
    synchronized public BearerToken createBearerToken(@NonNull String token, long expirationTime)  {
        
        
        return (BearerToken)createBearerToken(nativePtr, token, expirationTime);
    }

    private native Buffer createBuffer(long nativePtr);
    @Override @NonNull
    synchronized public Buffer createBuffer()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createBuffer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Buffer)createBuffer(nativePtr);
    }

    private native Buffer createBufferFromData(long nativePtr, byte[] data, int size);
    @Override @NonNull
    synchronized public Buffer createBufferFromData(@NonNull byte[] data, int size)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createBufferFromData() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Buffer)createBufferFromData(nativePtr, data, size);
    }

    private native Buffer createBufferFromString(long nativePtr, String data);
    @Override @NonNull
    synchronized public Buffer createBufferFromString(@NonNull String data)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createBufferFromString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Buffer)createBufferFromString(nativePtr, data);
    }

    private native ConferenceInfo createConferenceInfo(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceInfo createConferenceInfo()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConferenceInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceInfo)createConferenceInfo(nativePtr);
    }

    private native ConferenceInfo createConferenceInfoFromIcalendarContent(long nativePtr, Content content);
    @Override @Nullable
    synchronized public ConferenceInfo createConferenceInfoFromIcalendarContent(@NonNull Content content)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConferenceInfoFromIcalendarContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceInfo)createConferenceInfoFromIcalendarContent(nativePtr, content);
    }

    private native Config createConfig(long nativePtr, String path);
    @Override @NonNull
    synchronized public Config createConfig(@Nullable String path)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Config)createConfig(nativePtr, path);
    }

    private native Config createConfigFromString(long nativePtr, String data);
    @Override @NonNull
    synchronized public Config createConfigFromString(@NonNull String data)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConfigFromString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Config)createConfigFromString(nativePtr, data);
    }

    private native Config createConfigWithFactory(long nativePtr, String path, String factoryPath);
    @Override @NonNull
    synchronized public Config createConfigWithFactory(@Nullable String path, @Nullable String factoryPath)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createConfigWithFactory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Config)createConfigWithFactory(nativePtr, path, factoryPath);
    }

    private native Content createContent(long nativePtr);
    @Override @NonNull
    synchronized public Content createContent()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Content)createContent(nativePtr);
    }

    private native Content createContentFromFile(long nativePtr, String filePath);
    @Override @NonNull
    synchronized public Content createContentFromFile(@NonNull String filePath)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createContentFromFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Content)createContentFromFile(nativePtr, filePath);
    }

    private native Core createCore3(long nativePtr, String configPath, String factoryConfigPath, Object systemContext);
    @Override @NonNull
    synchronized public Core createCore(@Nullable String configPath, @Nullable String factoryConfigPath, @Nullable Object systemContext)  {
        
        
        return (Core)createCore3(nativePtr, configPath, factoryConfigPath, systemContext);
    }

    private native Core createCoreWithConfig3(long nativePtr, Config config, Object systemContext);
    @Override @NonNull
    synchronized public Core createCoreWithConfig(@NonNull Config config, @Nullable Object systemContext)  {
        
        
        return (Core)createCoreWithConfig3(nativePtr, config, systemContext);
    }

    private native DigestAuthenticationPolicy createDigestAuthenticationPolicy(long nativePtr);
    @Override @NonNull
    synchronized public DigestAuthenticationPolicy createDigestAuthenticationPolicy()  {
        
        
        return (DigestAuthenticationPolicy)createDigestAuthenticationPolicy(nativePtr);
    }

    private native EktInfo createEktInfo(long nativePtr);
    @Override @NonNull
    synchronized public EktInfo createEktInfo()  {
        
        
        return (EktInfo)createEktInfo(nativePtr);
    }

    private native ErrorInfo createErrorInfo(long nativePtr);
    @Override @NonNull
    synchronized public ErrorInfo createErrorInfo()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createErrorInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ErrorInfo)createErrorInfo(nativePtr);
    }

    private native FriendPhoneNumber createFriendPhoneNumber(long nativePtr, String phoneNumber, String label);
    @Override @NonNull
    synchronized public FriendPhoneNumber createFriendPhoneNumber(@NonNull String phoneNumber, @Nullable String label)  {
        
        
        return (FriendPhoneNumber)createFriendPhoneNumber(nativePtr, phoneNumber, label);
    }

    private native ParticipantDeviceIdentity createParticipantDeviceIdentity(long nativePtr, Address address, String name);
    @Override @NonNull
    synchronized public ParticipantDeviceIdentity createParticipantDeviceIdentity(@NonNull Address address, @Nullable String name)  {
        
        
        return (ParticipantDeviceIdentity)createParticipantDeviceIdentity(nativePtr, address, name);
    }

    private native ParticipantInfo createParticipantInfo(long nativePtr, Address address);
    @Override @Nullable
    synchronized public ParticipantInfo createParticipantInfo(@NonNull Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createParticipantInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ParticipantInfo)createParticipantInfo(nativePtr, address);
    }

    private native Content createQrcode(long nativePtr, String code, int width, int height, int margin);
    @Override @Nullable
    synchronized public Content createQrcode(@NonNull String code, int width, int height, int margin)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createQrcode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Content)createQrcode(nativePtr, code, width, height, margin);
    }

    private native Range createRange(long nativePtr);
    @Override @NonNull
    synchronized public Range createRange()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createRange() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Range)createRange(nativePtr);
    }

    private native SignalInformation createSignalInformation(long nativePtr);
    @Override @NonNull
    synchronized public SignalInformation createSignalInformation()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createSignalInformation() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (SignalInformation)createSignalInformation(nativePtr);
    }

    private native Transports createTransports(long nativePtr);
    @Override @NonNull
    synchronized public Transports createTransports()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createTransports() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Transports)createTransports(nativePtr);
    }

    private native TunnelConfig createTunnelConfig(long nativePtr);
    @Override @NonNull
    synchronized public TunnelConfig createTunnelConfig()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createTunnelConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (TunnelConfig)createTunnelConfig(nativePtr);
    }

    private native Vcard createVcard(long nativePtr);
    @Override @NonNull
    synchronized public Vcard createVcard()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createVcard() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Vcard)createVcard(nativePtr);
    }

    private native VideoActivationPolicy createVideoActivationPolicy(long nativePtr);
    @Override @NonNull
    synchronized public VideoActivationPolicy createVideoActivationPolicy()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createVideoActivationPolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (VideoActivationPolicy)createVideoActivationPolicy(nativePtr);
    }

    private native VideoDefinition createVideoDefinition(long nativePtr, int width, int height);
    @Override @NonNull
    synchronized public VideoDefinition createVideoDefinition(int width, int height)  {
        
        
        return (VideoDefinition)createVideoDefinition(nativePtr, width, height);
    }

    private native VideoDefinition createVideoDefinitionFromName(long nativePtr, String name);
    @Override @NonNull
    synchronized public VideoDefinition createVideoDefinitionFromName(@NonNull String name)  {
        
        
        return (VideoDefinition)createVideoDefinitionFromName(nativePtr, name);
    }

    private native VideoSourceDescriptor createVideoSourceDescriptor(long nativePtr);
    @Override @NonNull
    synchronized public VideoSourceDescriptor createVideoSourceDescriptor()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createVideoSourceDescriptor() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (VideoSourceDescriptor)createVideoSourceDescriptor(nativePtr);
    }

    private native void enableLogCollection(long nativePtr, int state);
    @Override
    synchronized public void enableLogCollection(LogCollectionState state)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call enableLogCollection() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        enableLogCollection(nativePtr, state.toInt());
    }

    private native String getCacheDir(long nativePtr, Object context);
    @Override @Nullable
    synchronized public String getCacheDir(@Nullable Object context)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCacheDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCacheDir(nativePtr, context);
    }

    private native String getConfigDir(long nativePtr, Object context);
    @Override @Nullable
    synchronized public String getConfigDir(@Nullable Object context)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getConfigDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getConfigDir(nativePtr, context);
    }

    private native String getDataDir(long nativePtr, Object context);
    @Override @Nullable
    synchronized public String getDataDir(@Nullable Object context)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDataDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDataDir(nativePtr, context);
    }

    private native String getDownloadDir(long nativePtr, Object context);
    @Override @Nullable
    synchronized public String getDownloadDir(@Nullable Object context)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDownloadDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDownloadDir(nativePtr, context);
    }

    private native boolean isChatroomBackendAvailable(long nativePtr, int chatroomBackend);
    @Override
    synchronized public boolean isChatroomBackendAvailable(ChatRoom.Backend chatroomBackend)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isChatroomBackendAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isChatroomBackendAvailable(nativePtr, chatroomBackend.toInt());
    }

    private native boolean setVfsEncryption(long nativePtr, int encryptionModule, byte[] secret, int secretSize);
    @Override
    synchronized public boolean setVfsEncryption(int encryptionModule, @Nullable byte[] secret, int secretSize)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVfsEncryption() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setVfsEncryption(nativePtr, encryptionModule, secret, secretSize);
    }

    private native int writeQrcodeFile(long nativePtr, String filePath, String code, int width, int height, int margin);
    @Override
    synchronized public int writeQrcodeFile(@NonNull String filePath, @NonNull String code, int width, int height, int margin)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call writeQrcodeFile() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return writeQrcodeFile(nativePtr, filePath, code, width, height, margin);
    }


    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    
}
