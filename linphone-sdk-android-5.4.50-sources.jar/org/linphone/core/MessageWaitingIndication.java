/*
MessageWaitingIndication.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object representing a Message Waiting Indication. <br/>
* <br/>
*/
public interface MessageWaitingIndication {
    public enum ContextClass {
        /**
        * <br/>
        */
        Voice(0),

        /**
        * <br/>
        */
        Fax(1),

        /**
        * <br/>
        */
        Pager(2),

        /**
        * <br/>
        */
        Multimedia(3),

        /**
        * <br/>
        */
        Text(4),

        /**
        * <br/>
        */
        None(5);

        protected final int mValue;

        private ContextClass (int value) {
            mValue = value;
        }

        static public ContextClass fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Voice;
            case 1: return Fax;
            case 2: return Pager;
            case 3: return Multimedia;
            case 4: return Text;
            case 5: return None;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for ContextClass");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Get the address of the message account concerned by this message waiting<br/>
    * indication. <br/>
    * <br/>
    * @return The address of the message account concerned by this message waiting<br/>
    * indication.   <br/>
    */
    @Nullable
    public Address getAccountAddress();

    /**
    * Set the address of the message account concerned by this message waiting<br/>
    * indication. <br/>
    * <br/>
    * @param address The address of the message account concerned by this message<br/>
    * waiting indication.   <br/>
    */
    public void setAccountAddress(@Nullable Address address);

    /**
    * Get the message waiting indication summaries. <br/>
    * <br/>
    * @return The message waiting indication summaries.    <br/>
    */
    @NonNull
    public MessageWaitingIndicationSummary[] getSummaries();

    /**
    * Instantiate a new message waiting indication with values from source. <br/>
    * <br/>
    * @return The newly created {@link MessageWaitingIndication} object.   <br/>
    */
    @NonNull
    public MessageWaitingIndication clone();

    /**
    * Get the message waiting indication summary for a given context class. <br/>
    * <br/>
    * @param contextClass the {@link ContextClass} for which we want to get the<br/>
    * summary. <br/>
    * @return The {@link MessageWaitingIndicationSummary} for the given context<br/>
    * class.   <br/>
    */
    @Nullable
    public MessageWaitingIndicationSummary getSummary(MessageWaitingIndication.ContextClass contextClass);

    /**
    * Tells whether there are messages waiting or not. <br/>
    * <br/>
    * @return true if there are waiting messages, false otherwise. <br/>
    */
    public boolean hasMessageWaiting();

    /**
    * Get a {@link Content} object to put in a NOTIFY message from a {@link MessageWaitingIndication}<br/>
    * object. <br/>
    * <br/>
    * @return The {@link Content} to put in a NOTIFY message.     <br/>
    */
    @NonNull
    public Content toContent();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class MessageWaitingIndicationImpl implements MessageWaitingIndication {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected MessageWaitingIndicationImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Address getAccountAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getAccountAddress()  {
        
        
        return (Address)getAccountAddress(nativePtr);
    }

    private native void setAccountAddress(long nativePtr, Address address);
    @Override
    synchronized public void setAccountAddress(@Nullable Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAccountAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAccountAddress(nativePtr, address);
    }

    private native MessageWaitingIndicationSummary[] getSummaries(long nativePtr);
    @Override @NonNull
    synchronized public MessageWaitingIndicationSummary[] getSummaries()  {
        
        
        return getSummaries(nativePtr);
    }

    private native MessageWaitingIndication clone(long nativePtr);
    @Override @NonNull
    synchronized public MessageWaitingIndication clone()  {
        
        
        return (MessageWaitingIndication)clone(nativePtr);
    }

    private native MessageWaitingIndicationSummary getSummary(long nativePtr, int contextClass);
    @Override @Nullable
    synchronized public MessageWaitingIndicationSummary getSummary(MessageWaitingIndication.ContextClass contextClass)  {
        
        
        return (MessageWaitingIndicationSummary)getSummary(nativePtr, contextClass.toInt());
    }

    private native boolean hasMessageWaiting(long nativePtr);
    @Override
    synchronized public boolean hasMessageWaiting()  {
        
        
        return hasMessageWaiting(nativePtr);
    }

    private native Content toContent(long nativePtr);
    @Override @NonNull
    synchronized public Content toContent()  {
        
        
        return (Content)toContent(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
