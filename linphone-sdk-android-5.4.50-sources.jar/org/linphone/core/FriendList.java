/*
FriendList.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* This object representing a list of {@link Friend}. <br/>
* <br/>
* You can use it to store contacts locally or synchronize them through CardDAV<br/>
* protocol. <br/>
*/
public interface FriendList {
    public enum SyncStatus {
        /**
        * Synchronization started. <br/>
        * <br/>
        */
        Started(0),

        /**
        * Synchronization finished successfuly. <br/>
        * <br/>
        */
        Successful(1),

        /**
        * Synchronization failed. <br/>
        * <br/>
        */
        Failure(2);

        protected final int mValue;

        private SyncStatus (int value) {
            mValue = value;
        }

        static public SyncStatus fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Started;
            case 1: return Successful;
            case 2: return Failure;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for SyncStatus");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Status {
        /**
        * Operation went fine. <br/>
        * <br/>
        */
        OK(0),

        /**
        * {@link Friend} wasn't found in the {@link FriendList} <br/>
        * <br/>
        */
        NonExistentFriend(1),

        /**
        * {@link Friend} is already present in a {@link FriendList} <br/>
        * <br/>
        */
        InvalidFriend(2);

        protected final int mValue;

        private Status (int value) {
            mValue = value;
        }

        static public Status fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return OK;
            case 1: return NonExistentFriend;
            case 2: return InvalidFriend;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Status");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Type {
        /**
        * Default value, used when no other type applies. <br/>
        * <br/>
        */
        Default(-1),

        /**
        * Used when list is synchronized with a remote CardDAV server. <br/>
        * <br/>
        */
        CardDAV(0),

        /**
        * Used for simple vCards list remotely provisionned by a server. <br/>
        * <br/>
        */
        VCard4(1),

        /**
        * Friend list used by app for cache purposes, friends added in this list will be<br/>
        * ignored by {@link MagicSearch}  <br/>
        * <br/>
        */
        ApplicationCache(2);

        protected final int mValue;

        private Type (int value) {
            mValue = value;
        }

        static public Type fromInt(int value) throws RuntimeException {
            switch(value) {
            case -1: return Default;
            case 0: return CardDAV;
            case 1: return VCard4;
            case 2: return ApplicationCache;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Type");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Returns the {@link Core} object attached to this LinphoneFriendList. <br/>
    * <br/>
    * @return a {@link Core} object   <br/>
    */
    @Nullable
    public Core getCore();

    /**
    * Gets whether this friend list and it's friends will be stored in DB or not. <br/>
    * <br/>
    * @return Whether the list and it's friends will be saved in database or not <br/>
    */
    public boolean isDatabaseStorageEnabled();

    /**
    * Sets whether this friend list and it's friends will be stored in DB or not. <br/>
    * <br/>
    * @param enable true to enable this friend list storage in DB, false to disable<br/>
    * it. <br/>
    */
    public void setDatabaseStorageEnabled(boolean enable);

    /**
    * Get the display name of the friend list. <br/>
    * <br/>
    * @return The display name of the friend list.   <br/>
    */
    @Nullable
    public String getDisplayName();

    /**
    * Set the display name of the friend list. <br/>
    * <br/>
    * @param displayName The new display name of the friend list.   <br/>
    */
    public void setDisplayName(@Nullable String displayName);

    /**
    * Retrieves the list of {@link Friend} from this LinphoneFriendList. <br/>
    * <br/>
    * @return A list of {@link Friend}    <br/>
    */
    @NonNull
    public Friend[] getFriends();

    /**
    * Get wheter the subscription of the friend list is bodyless or not. <br/>
    * <br/>
    * @return Wheter the subscription of the friend list is bodyless or not. <br/>
    */
    public boolean isSubscriptionBodyless();

    /**
    * Get the RLS (Resource List Server) URI associated with the friend list to<br/>
    * subscribe to these friends presence. <br/>
    * <br/>
    * @return The RLS URI as {@link Address} associated with the friend list.   <br/>
    */
    @Nullable
    public Address getRlsAddress();

    /**
    * Set the RLS (Resource List Server) URI associated with the friend list to<br/>
    * subscribe to these friends presence. <br/>
    * <br/>
    * @param rlsAddr The RLS URI to associate with the friend list.   <br/>
    */
    public void setRlsAddress(@Nullable Address rlsAddr);

    /**
    * Get the RLS (Resource List Server) URI associated with the friend list to<br/>
    * subscribe to these friends presence. <br/>
    * <br/>
    * @return The RLS URI associated with the friend list.   <br/>
    * @deprecated 27/10/2020. Use {@link #getRlsAddress} instead. <br/>
    */
    @Deprecated
    @Nullable
    public String getRlsUri();

    /**
    * Set the RLS (Resource List Server) URI associated with the friend list to<br/>
    * subscribe to these friends presence. <br/>
    * <br/>
    * @param rlsUri The RLS URI to associate with the friend list.   <br/>
    * @deprecated 27/10/2020. Use {@link #setRlsAddress} instead. <br/>
    */
    @Deprecated
    public void setRlsUri(@Nullable String rlsUri);

    /**
    * Set wheter the subscription of the friend list is bodyless or not. <br/>
    * <br/>
    * @param bodyless boolean telling if the subscription of the friend list is<br/>
    * bodyless or not. <br/>
    */
    public void setSubscriptionBodyless(boolean bodyless);

    /**
    * Gets whether subscription to NOTIFYs are enabled or not. <br/>
    * <br/>
    * @return Whether subscriptions are enabled or not <br/>
    */
    public boolean isSubscriptionsEnabled();

    /**
    * Enable subscription to NOTIFYs. <br/>
    * <br/>
    * @param enabled should subscription be enabled or not <br/>
    */
    public void setSubscriptionsEnabled(boolean enabled);

    /**
    * Get the {@link Type} of a friend list. <br/>
    * <br/>
    */
    public FriendList.Type getType();

    /**
    * Assign a friend list type to the friend list. <br/>
    * <br/>
    * @param type {@link Type} to assign <br/>
    */
    public void setType(FriendList.Type type);

    /**
    * Get the URI associated with the friend list. <br/>
    * <br/>
    * @return The URI associated with the friend list.   <br/>
    */
    @Nullable
    public String getUri();

    /**
    * Set the URI associated with the friend list. <br/>
    * <br/>
    * @param uri The URI to associate with the friend list.   <br/>
    */
    public void setUri(@Nullable String uri);

    /**
    * Add a friend to a friend list. <br/>
    * <br/>
    * If or when a remote CardDAV server will be attached to the list, the friend<br/>
    * will be sent to the server. <br/>
    * @param linphoneFriend {@link Friend} object to add to the friend list.   <br/>
    * @return {@link Status#OK} if successfully added, {@link Status#InvalidFriend}<br/>
    * if the friend is not valid. <br/>
    */
    public FriendList.Status addFriend(@NonNull Friend linphoneFriend);

    /**
    * Add a friend to a friend list. <br/>
    * <br/>
    * The friend will never be sent to a remote CardDAV server. Warning! {@link Friend}<br/>
    * added this way will be removed on the next synchronization, and the callback<br/>
    * contact_deleted will be called. <br/>
    * @param linphoneFriend {@link Friend} object to add to the friend list.   <br/>
    * @return {@link Status#OK} if successfully added, {@link Status#InvalidFriend}<br/>
    * if the friend is not valid. <br/>
    */
    public FriendList.Status addLocalFriend(@NonNull Friend linphoneFriend);

    /**
    * Creates and export {@link Friend} objects from {@link FriendList} to a file<br/>
    * using vCard 4 format. <br/>
    * <br/>
    * @param vcardFile the path to a file that will contain the vCards   <br/>
    */
    public void exportFriendsAsVcard4File(@NonNull String vcardFile);

    /**
    * Find a friend in the friend list using a LinphoneAddress. <br/>
    * <br/>
    * @param address {@link Address} object of the friend we want to search for.   <br/>
    * @return A {@link Friend} if found, null otherwise.   <br/>
    */
    @Nullable
    public Friend findFriendByAddress(@NonNull Address address);

    /**
    * Find a friend in the friend list using a phone number. <br/>
    * <br/>
    * @param phoneNumber a string of the phone number for which we want to find a<br/>
    * friend.   <br/>
    * @return A {@link Friend} if found, null otherwise.   <br/>
    */
    @Nullable
    public Friend findFriendByPhoneNumber(@NonNull String phoneNumber);

    /**
    * Find a friend in the friend list using a ref key. <br/>
    * <br/>
    * @param refKey The ref key string of the friend we want to search for.   <br/>
    * @return A {@link Friend} if found, null otherwise.   <br/>
    */
    @Nullable
    public Friend findFriendByRefKey(@NonNull String refKey);

    /**
    * Find a friend in the friend list using an URI string. <br/>
    * <br/>
    * @param uri A string containing the URI of the friend we want to search for.   <br/>
    * @return A {@link Friend} if found, null otherwise.   <br/>
    */
    @Nullable
    public Friend findFriendByUri(@NonNull String uri);

    /**
    * Find all friends in the friend list using a LinphoneAddress. <br/>
    * <br/>
    * @param address {@link Address} object of the friends we want to search for.   <br/>
    * @return A list of {@link Friend} if found, null otherwise.    <br/>
    */
    @NonNull
    public Friend[] findFriendsByAddress(@NonNull Address address);

    /**
    * Find all friends in the friend list using an URI string. <br/>
    * <br/>
    * @param uri A string containing the URI of the friends we want to search for.   <br/>
    * @return A list of {@link Friend} if found, null otherwise.    <br/>
    */
    @NonNull
    public Friend[] findFriendsByUri(@NonNull String uri);

    /**
    * Creates and adds {@link Friend} objects to {@link FriendList} from a buffer<br/>
    * that contains the vCard(s) to parse. <br/>
    * <br/>
    * @param vcardBuffer the buffer that contains the vCard(s) to parse   <br/>
    * @return the amount of linphone friends created <br/>
    */
    public int importFriendsFromVcard4Buffer(@NonNull String vcardBuffer);

    /**
    * Creates and adds {@link Friend} objects to {@link FriendList} from a file that<br/>
    * contains the vCard(s) to parse. <br/>
    * <br/>
    * @param vcardFile the path to a file that contains the vCard(s) to parse   <br/>
    * @return the amount of linphone friends created <br/>
    */
    public int importFriendsFromVcard4File(@NonNull String vcardFile);

    /**
    * Notify our presence to all the friends in the friend list that have subscribed<br/>
    * to our presence directly (not using a RLS). <br/>
    * <br/>
    * @param presence {@link PresenceModel} object.   <br/>
    */
    public void notifyPresence(@NonNull PresenceModel presence);

    /**
    * Remove a friend from a friend list. <br/>
    * <br/>
    * @param linphoneFriend {@link Friend} object to remove from the friend list.   <br/>
    * @return {@link Status#OK} if removed successfully, {@link Status#NonExistentFriend}<br/>
    * if the friend is not in the list. <br/>
    */
    public FriendList.Status removeFriend(@NonNull Friend linphoneFriend);

    /**
    * Starts a CardDAV synchronization using value set using<br/>
    * linphone_friend_list_set_uri. <br/>
    * <br/>
    */
    public void synchronizeFriendsFromServer();

    /**
    * Goes through all the {@link Friend} that are dirty and does a CardDAV PUT to<br/>
    * update the server. <br/>
    * <br/>
    */
    public void updateDirtyFriends();

    /**
    * Sets the revision from the last synchronization. <br/>
    * <br/>
    * @param revision The revision.   <br/>
    * warning: before 5.4.0 release revision was an int, it's now a string. <br/>
    */
    public void updateRevision(@Nullable String revision);

    /**
    * Update presence subscriptions for the entire list. <br/>
    * <br/>
    * Calling this function is necessary when list subscriptions are enabled, ie when<br/>
    * a RLS presence server is used. <br/>
    */
    public void updateSubscriptions();

    /**
    */
    public void addListener(FriendListListener listener);

    /**
    */
    public void removeListener(FriendListListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class FriendListImpl implements FriendList {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected FriendListImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Core getCore(long nativePtr);
    @Override @Nullable
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native boolean isDatabaseStorageEnabled(long nativePtr);
    @Override
    synchronized public boolean isDatabaseStorageEnabled()  {
        synchronized(core) { 
        
        return isDatabaseStorageEnabled(nativePtr);
        }
    }

    private native void setDatabaseStorageEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setDatabaseStorageEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDatabaseStorageEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDatabaseStorageEnabled(nativePtr, enable);
        }
    }

    private native String getDisplayName(long nativePtr);
    @Override @Nullable
    synchronized public String getDisplayName()  {
        synchronized(core) { 
        
        return getDisplayName(nativePtr);
        }
    }

    private native void setDisplayName(long nativePtr, String displayName);
    @Override
    synchronized public void setDisplayName(@Nullable String displayName)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDisplayName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDisplayName(nativePtr, displayName);
        }
    }

    private native Friend[] getFriends(long nativePtr);
    @Override @NonNull
    synchronized public Friend[] getFriends()  {
        synchronized(core) { 
        
        return getFriends(nativePtr);
        }
    }

    private native boolean isSubscriptionBodyless(long nativePtr);
    @Override
    synchronized public boolean isSubscriptionBodyless()  {
        synchronized(core) { 
        
        return isSubscriptionBodyless(nativePtr);
        }
    }

    private native Address getRlsAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getRlsAddress()  {
        synchronized(core) { 
        
        return (Address)getRlsAddress(nativePtr);
        }
    }

    private native void setRlsAddress(long nativePtr, Address rlsAddr);
    @Override
    synchronized public void setRlsAddress(@Nullable Address rlsAddr)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRlsAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRlsAddress(nativePtr, rlsAddr);
        }
    }

    private native String getRlsUri(long nativePtr);
    @Override @Nullable
    synchronized public String getRlsUri()  {
        synchronized(core) { 
        
        return getRlsUri(nativePtr);
        }
    }

    private native void setRlsUri(long nativePtr, String rlsUri);
    @Override
    synchronized public void setRlsUri(@Nullable String rlsUri)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRlsUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRlsUri(nativePtr, rlsUri);
        }
    }

    private native void setSubscriptionBodyless(long nativePtr, boolean bodyless);
    @Override
    synchronized public void setSubscriptionBodyless(boolean bodyless)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubscriptionBodyless() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubscriptionBodyless(nativePtr, bodyless);
        }
    }

    private native boolean isSubscriptionsEnabled(long nativePtr);
    @Override
    synchronized public boolean isSubscriptionsEnabled()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isSubscriptionsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isSubscriptionsEnabled(nativePtr);
        }
    }

    private native void setSubscriptionsEnabled(long nativePtr, boolean enabled);
    @Override
    synchronized public void setSubscriptionsEnabled(boolean enabled)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubscriptionsEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubscriptionsEnabled(nativePtr, enabled);
        }
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public FriendList.Type getType()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return FriendList.Type.fromInt(getType(nativePtr));
        }
    }

    private native void setType(long nativePtr, int type);
    @Override
    synchronized public void setType(FriendList.Type type)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setType(nativePtr, type.toInt());
        }
    }

    private native String getUri(long nativePtr);
    @Override @Nullable
    synchronized public String getUri()  {
        synchronized(core) { 
        
        return getUri(nativePtr);
        }
    }

    private native void setUri(long nativePtr, String uri);
    @Override
    synchronized public void setUri(@Nullable String uri)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUri(nativePtr, uri);
        }
    }

    private native int addFriend(long nativePtr, Friend linphoneFriend);
    @Override
    synchronized public FriendList.Status addFriend(@NonNull Friend linphoneFriend)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addFriend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return FriendList.Status.fromInt(addFriend(nativePtr, linphoneFriend));
        }
    }

    private native int addLocalFriend(long nativePtr, Friend linphoneFriend);
    @Override
    synchronized public FriendList.Status addLocalFriend(@NonNull Friend linphoneFriend)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addLocalFriend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return FriendList.Status.fromInt(addLocalFriend(nativePtr, linphoneFriend));
        }
    }

    private native void exportFriendsAsVcard4File(long nativePtr, String vcardFile);
    @Override
    synchronized public void exportFriendsAsVcard4File(@NonNull String vcardFile)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call exportFriendsAsVcard4File() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        exportFriendsAsVcard4File(nativePtr, vcardFile);
        }
    }

    private native Friend findFriendByAddress(long nativePtr, Address address);
    @Override @Nullable
    synchronized public Friend findFriendByAddress(@NonNull Address address)  {
        synchronized(core) { 
        
        return (Friend)findFriendByAddress(nativePtr, address);
        }
    }

    private native Friend findFriendByPhoneNumber(long nativePtr, String phoneNumber);
    @Override @Nullable
    synchronized public Friend findFriendByPhoneNumber(@NonNull String phoneNumber)  {
        synchronized(core) { 
        
        return (Friend)findFriendByPhoneNumber(nativePtr, phoneNumber);
        }
    }

    private native Friend findFriendByRefKey(long nativePtr, String refKey);
    @Override @Nullable
    synchronized public Friend findFriendByRefKey(@NonNull String refKey)  {
        synchronized(core) { 
        
        return (Friend)findFriendByRefKey(nativePtr, refKey);
        }
    }

    private native Friend findFriendByUri(long nativePtr, String uri);
    @Override @Nullable
    synchronized public Friend findFriendByUri(@NonNull String uri)  {
        synchronized(core) { 
        
        return (Friend)findFriendByUri(nativePtr, uri);
        }
    }

    private native Friend[] findFriendsByAddress(long nativePtr, Address address);
    @Override @NonNull
    synchronized public Friend[] findFriendsByAddress(@NonNull Address address)  {
        synchronized(core) { 
        
        return findFriendsByAddress(nativePtr, address);
        }
    }

    private native Friend[] findFriendsByUri(long nativePtr, String uri);
    @Override @NonNull
    synchronized public Friend[] findFriendsByUri(@NonNull String uri)  {
        synchronized(core) { 
        
        return findFriendsByUri(nativePtr, uri);
        }
    }

    private native int importFriendsFromVcard4Buffer(long nativePtr, String vcardBuffer);
    @Override
    synchronized public int importFriendsFromVcard4Buffer(@NonNull String vcardBuffer)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call importFriendsFromVcard4Buffer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return importFriendsFromVcard4Buffer(nativePtr, vcardBuffer);
        }
    }

    private native int importFriendsFromVcard4File(long nativePtr, String vcardFile);
    @Override
    synchronized public int importFriendsFromVcard4File(@NonNull String vcardFile)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call importFriendsFromVcard4File() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return importFriendsFromVcard4File(nativePtr, vcardFile);
        }
    }

    private native void notifyPresence(long nativePtr, PresenceModel presence);
    @Override
    synchronized public void notifyPresence(@NonNull PresenceModel presence)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call notifyPresence() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        notifyPresence(nativePtr, presence);
        }
    }

    private native int removeFriend(long nativePtr, Friend linphoneFriend);
    @Override
    synchronized public FriendList.Status removeFriend(@NonNull Friend linphoneFriend)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeFriend() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return FriendList.Status.fromInt(removeFriend(nativePtr, linphoneFriend));
        }
    }

    private native void synchronizeFriendsFromServer(long nativePtr);
    @Override
    synchronized public void synchronizeFriendsFromServer()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call synchronizeFriendsFromServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        synchronizeFriendsFromServer(nativePtr);
        }
    }

    private native void updateDirtyFriends(long nativePtr);
    @Override
    synchronized public void updateDirtyFriends()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call updateDirtyFriends() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        updateDirtyFriends(nativePtr);
        }
    }

    private native void updateRevision(long nativePtr, String revision);
    @Override
    synchronized public void updateRevision(@Nullable String revision)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call updateRevision() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        updateRevision(nativePtr, revision);
        }
    }

    private native void updateSubscriptions(long nativePtr);
    @Override
    synchronized public void updateSubscriptions()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call updateSubscriptions() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        updateSubscriptions(nativePtr);
        }
    }

    private native void addListener(long nativePtr, FriendListListener listener);
    @Override
    synchronized public void addListener(FriendListListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, FriendListListener listener);
    @Override
    synchronized public void removeListener(FriendListListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
