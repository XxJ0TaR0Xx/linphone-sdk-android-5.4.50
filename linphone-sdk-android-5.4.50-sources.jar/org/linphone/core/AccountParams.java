/*
AccountParams.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that is used to set the different parameters of a {@link Account}. <br/>
* <br/>
* Note that authenticated accounts should have a corresponding {@link AuthInfo}<br/>
* added to the {@link Core} to register properly. <br/>
*/
public interface AccountParams {
    /**
    * Get the audio video conference factory uri. <br/>
    * <br/>
    * @return The {@link Address} of the audio video conference factory.   <br/>
    */
    @Nullable
    public Address getAudioVideoConferenceFactoryAddress();

    /**
    * Set the audio video conference factory uri. <br/>
    * <br/>
    * @param address The {@link Address} to set.   <br/>
    */
    public void setAudioVideoConferenceFactoryAddress(@Nullable Address address);

    /**
    * Get enablement status of RTCP feedback (also known as AVPF profile). <br/>
    * <br/>
    * @return the enablement mode, which can be {@link AVPFMode#Default} (use<br/>
    * LinphoneCore's mode), {@link AVPFMode#Enabled} (avpf is enabled), or {@link AVPFMode#Disabled}<br/>
    * (disabled). <br/>
    */
    public AVPFMode getAvpfMode();

    /**
    * Enable the use of RTCP feedback (also known as AVPF profile). <br/>
    * <br/>
    * @param mode the enablement mode, which can be {@link AVPFMode#Default} (use<br/>
    * LinphoneCore's mode), {@link AVPFMode#Enabled} (avpf is enabled), or {@link AVPFMode#Disabled}<br/>
    * (disabled). <br/>
    */
    public void setAvpfMode(AVPFMode mode);

    /**
    * Get the interval between regular RTCP reports when using AVPF/SAVPF. <br/>
    * <br/>
    * @return The interval in seconds. <br/>
    */
    public int getAvpfRrInterval();

    /**
    * Set the interval between regular RTCP reports when using AVPF/SAVPF. <br/>
    * <br/>
    * @param interval The interval in seconds (between 0 and 5 seconds). <br/>
    */
    public void setAvpfRrInterval(int interval);

    /**
    * Get the CCMP server address. <br/>
    * <br/>
    * @return The URL of the CCMP server.   <br/>
    */
    @Nullable
    public String getCcmpServerUrl();

    /**
    * Set the CCMP server address. <br/>
    * <br/>
    * @param url The URL of the CCMP server.   <br/>
    */
    public void setCcmpServerUrl(@Nullable String url);

    /**
    * Get the CCMP user ID. <br/>
    * <br/>
    * @return The ID of the CCMP user.   <br/>
    */
    @Nullable
    public String getCcmpUserId();

    /**
    * Get the conference factory uri. <br/>
    * <br/>
    * @return The {@link Address} of the conference factory.   <br/>
    */
    @Nullable
    public Address getConferenceFactoryAddress();

    /**
    * Set the conference factory uri. <br/>
    * <br/>
    * @param address The {@link Address} to set.   <br/>
    */
    public void setConferenceFactoryAddress(@Nullable Address address);

    /**
    * Get the conference factory uri. <br/>
    * <br/>
    * @return The uri of the conference factory.   <br/>
    */
    @Nullable
    public String getConferenceFactoryUri();

    /**
    * Set the conference factory uri. <br/>
    * <br/>
    * @param uri The uri of the conference factory.   <br/>
    * @deprecated 16/08/2023 Use {@link #setConferenceFactoryAddress} instead. <br/>
    */
    @Deprecated
    public void setConferenceFactoryUri(@Nullable String uri);

    /**
    * Returns the contact parameters. <br/>
    * <br/>
    * @return The previously set contact parameters.   <br/>
    */
    @Nullable
    public String getContactParameters();

    /**
    * Set optional contact parameters that will be added to the contact information<br/>
    * sent in the registration. <br/>
    * <br/>
    * @param contactParams A string contaning the additional parameters in text form,<br/>
    * like "myparam=something;myparam2=something_else"  <br/>
    * The main use case for this function is provide the proxy additional information<br/>
    * regarding the user agent, like for example unique identifier or apple push id.<br/>
    * As an example, the contact address in the SIP register sent will look like<br/>
    * <sip:joe@15.128.128.93:50421>;apple-push-id=43143-DFE23F-2323-FA2232. <br/>
    */
    public void setContactParameters(@Nullable String contactParams);

    /**
    * Return the contact URI parameters. <br/>
    * <br/>
    * @return The previously set contact URI parameters.   <br/>
    */
    @Nullable
    public String getContactUriParameters();

    /**
    * Set optional contact parameters that will be added to the contact information<br/>
    * sent in the registration, inside the URI. <br/>
    * <br/>
    * @param contactUriParams A string containing the additional parameters in text<br/>
    * form, like "myparam=something;myparam2=something_else"  <br/>
    * The main use case for this function is provide the proxy additional information<br/>
    * regarding the user agent, like for example unique identifier or apple push id.<br/>
    * As an example, the contact address in the SIP register sent will look like<br/>
    * <sip:joe@15.128.128.93:50421;apple-push-id=43143-DFE23F-2323-FA2232>. <br/>
    */
    public void setContactUriParameters(@Nullable String contactUriParams);

    /**
    * Indicates whether chat messages sent by this account in a {@link ChatRoom#Backend#Basic}<br/>
    * chat room will be using CPIM format or not. <br/>
    * <br/>
    * By default SIP SIMPLE format is used for "basic" chat rooms, CPIM is only used<br/>
    * for {@link ChatRoom#Backend#FlexisipChat} chat rooms. see:<br/>
    * https://wiki.linphone.org/xwiki/wiki/public/view/Lib/Features/Instant%20Messaging/Reply%20to%20a%20specific%20message/ <br/>
    * @return true if chat messages will be sent out in CPIM format, false if chat<br/>
    * messages will be sent out as SIP SIMPLE. <br/>
    */
    public boolean isCpimInBasicChatRoomEnabled();

    /**
    * Indicates whether chat messages sent by this account in a {@link ChatRoom#Backend#Basic}<br/>
    * chat room will be using CPIM format or not. <br/>
    * <br/>
    * @param enable true to send messages in CPIM format, false to keep using the SIP<br/>
    * SIMPLE format. <br/>
    */
    public void setCpimInBasicChatRoomEnabled(boolean enable);

    /**
    * Get the custom contact address previously used when registering to the SIP<br/>
    * server. <br/>
    * <br/>
    * @return a {@link Address}   <br/>
    */
    @Nullable
    public Address getCustomContact();

    /**
    * Set a an optional custom contact address to be used when registering to the SIP<br/>
    * server. <br/>
    * <br/>
    * This is typically used to supply an alternative SIP address to call in case the<br/>
    * main one is not reachable. <br/>
    * @param contact a {@link Address} the optional alternative contact address.   <br/>
    */
    public void setCustomContact(@Nullable Address contact);

    /**
    * Return whether or not the + should be replaced by the International Call<br/>
    * Prefix. <br/>
    * <br/>
    * @return Whether liblinphone should replace "+" by the International Call<br/>
    * Prefix. in dialed numbers (passed to {@link Core#invite}). <br/>
    */
    public boolean isDialEscapePlusEnabled();

    /**
    * Set whether liblinphone should replace "+" by international calling prefix<br/>
    * (ICP) in dialed numbers (passed to linphone_core_invite). <br/>
    * <br/>
    * @param enable true to replace + by the international prefix, false otherwise. <br/>
    */
    public void setDialEscapePlusEnabled(boolean enable);

    /**
    * Get the domain name of the given account params. <br/>
    * <br/>
    * @return The domain name of the account params.   <br/>
    */
    @Nullable
    public String getDomain();

    /**
    * Get the account params expires. <br/>
    * <br/>
    * @return The duration of registration. <br/>
    */
    public int getExpires();

    /**
    * Sets the registration expiration time in seconds. <br/>
    * <br/>
    * @param expires The expiration time to set. <br/>
    */
    public void setExpires(int expires);

    /**
    * Get the identity of the account params. <br/>
    * <br/>
    * @return The SIP identity that belongs to this account params.   <br/>
    * @deprecated 01/03/2021 Use {@link #getIdentityAddress} instead. <br/>
    */
    @Deprecated
    @Nullable
    public String getIdentity();

    /**
    * Get the identity address of the account params. <br/>
    * <br/>
    * @return The SIP identity that belongs to this account params.   <br/>
    */
    @Nullable
    public Address getIdentityAddress();

    /**
    * Sets the user identity as a SIP address. <br/>
    * <br/>
    * This identity is normally formed with display name, username and domain, such<br/>
    * as: Alice <sip:alice@example.net> The REGISTER messages will have from and to<br/>
    * set to this identity. <br/>
    * @param identity The {@link Address} of the identity to set.   <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    */
    public int setIdentityAddress(@Nullable Address identity);

    /**
    * Get the idkey property of a {@link AccountParams}. <br/>
    * <br/>
    * @return The idkey string, or null.   <br/>
    */
    @Nullable
    public String getIdkey();

    /**
    * Set the idkey property on the given account params. <br/>
    * <br/>
    * This property can the be referenced by another account params 'depends_on' to<br/>
    * create a dependency relation between them.<br/>
    * @param idkey The idkey string to associate to the given {@link AccountParams}. <br/>
    *  <br/>
    */
    public void setIdkey(@Nullable String idkey);

    /**
    * Checks if encryption is mandatory for instant messages or not. <br/>
    * <br/>
    * @return true if encryption is mandatory; false otherwise. <br/>
    */
    public boolean getInstantMessagingEncryptionMandatory();

    /**
    * Defines whether the encryption of instant messages is mandatory. <br/>
    * <br/>
    * If it is, clear text messages will be denied. <br/>
    * @param mandatory true to set it mandatory; false otherwise. <br/>
    */
    public void setInstantMessagingEncryptionMandatory(boolean mandatory);

    /**
    * Gets the prefix set for this account params. <br/>
    * <br/>
    * @return The international prefix if set, null otherwise.   <br/>
    */
    @Nullable
    public String getInternationalPrefix();

    /**
    * Sets an international prefix (country code) to be automatically prepended when<br/>
    * inviting a number with {@link Core#invite} or when using {@link Account#normalizePhoneNumber}<br/>
    * . <br/>
    * <br/>
    * This international prefix shall usually be the country code of the country<br/>
    * where the user is living, without "+". warning: It is also referred as 'ccc'<br/>
    * (Calling Country Code) and must not be confused with the ICP (International<br/>
    * Call Prefix). The ICP is a fixed property of the country dial plan, and cannot<br/>
    * be set in the {@link AccountParams} . <br/>
    * @param prefix The prefix to set (withouth the +).   <br/>
    */
    public void setInternationalPrefix(@Nullable String prefix);

    /**
    * Gets the ISO country code set for the international prefix in this account<br/>
    * params. <br/>
    * <br/>
    * @return The international prefix ISO country code if set, null otherwise.   <br/>
    */
    @Nullable
    public String getInternationalPrefixIsoCountryCode();

    /**
    * Sets the ISO country code matching the international prefix. <br/>
    * <br/>
    * @param prefixIsoCountryCode The ISO country code to set.   <br/>
    */
    public void setInternationalPrefixIsoCountryCode(@Nullable String prefixIsoCountryCode);

    /**
    * Gets whether push notifications are available or not (Android & iOS only). <br/>
    * <br/>
    * @return true if push notifications are available, false otherwise <br/>
    */
    public boolean isPushNotificationAvailable();

    /**
    * Get the base x3dh algorithm. <br/>
    * <br/>
    * @return The x3dh base algorithm.   <br/>
    */
    @Nullable
    public String getLimeAlgo();

    /**
    * Set the base(s) x3dh algorithm. <br/>
    * <br/>
    * accept an ordered comma separated list (without space) of lime base algorithms<br/>
    * accepted values are a combination of: c25519, c448 and c25519mlk512 null is<br/>
    * also valid, it will unset the value <br/>
    * @param algo The x3dh base algorithm.   <br/>
    */
    public void setLimeAlgo(@Nullable String algo);

    /**
    * Get the x3dh server url. <br/>
    * <br/>
    * @return The x3dh server url.   <br/>
    */
    @Nullable
    public String getLimeServerUrl();

    /**
    * Set the x3dh server url. <br/>
    * <br/>
    * If empty, this function will disable LIME X3DH from core. Otherwise, or if<br/>
    * different from the existing value, this will (re-)initialize the LIME X3DH<br/>
    * engine. <br/>
    * @param url The x3dh server url.   <br/>
    */
    public void setLimeServerUrl(@Nullable String url);

    /**
    * Gets the Message Waiting Indication server address. <br/>
    * <br/>
    * @return The Message Waiting Indication server address.   <br/>
    */
    @Nullable
    public Address getMwiServerAddress();

    /**
    * Sets the Message Waiting Indication server address. <br/>
    * <br/>
    * @param address The Message Waiting Indication server address.   <br/>
    */
    public void setMwiServerAddress(@Nullable Address address);

    /**
    * Get The policy that is used to pass through NATs/firewalls when using this<br/>
    * account params. <br/>
    * <br/>
    * If it is set to null, the default NAT policy from the core will be used<br/>
    * instead. <br/>
    * @return The {@link NatPolicy} object in use.   <br/>
    * see: {@link Core#getNatPolicy} <br/>
    */
    @Nullable
    public NatPolicy getNatPolicy();

    /**
    * Set the policy to use to pass through NATs/firewalls when using this account<br/>
    * params. <br/>
    * <br/>
    * If it is set to null, the default NAT policy from the core will be used<br/>
    * instead. <br/>
    * @param policy The {@link NatPolicy} object.   <br/>
    * see: {@link Core#setNatPolicy} <br/>
    */
    public void setNatPolicy(@Nullable NatPolicy policy);

    /**
    * Tell if the proxy is used as the only route. <br/>
    * <br/>
    * @return enable true if enabled, false otherwise. <br/>
    */
    public boolean isOutboundProxyEnabled();

    /**
    * If enabled, the proxy will be used as the only route. <br/>
    * <br/>
    * warning: This function will replace or remove any routes previously set with<br/>
    * {@link #setRoutesAddresses} if any. For that reason {@link #enableOutboundProxy}<br/>
    * shall not be used with {@link #setRoutesAddresses}. Application shall consider<br/>
    * either using the restrictive notion of outbound proxy (a single route identical<br/>
    * to the registrar URI), either the notion of predefined route-set where routes<br/>
    * can be multiple and different from registrar URI. <br/>
    * @param enable true to enable, false otherwise. <br/>
    */
    public void setOutboundProxyEnabled(boolean enable);

    /**
    * Gets the account picture URI if set, null otherwise. <br/>
    * <br/>
    * @return The account picture URI.   <br/>
    */
    @Nullable
    public String getPictureUri();

    /**
    * Sets an URI for the account picture. <br/>
    * <br/>
    * @param uri The account picture URI.   <br/>
    */
    public void setPictureUri(@Nullable String uri);

    /**
    * Get default privacy policy for all calls routed through this proxy. <br/>
    * <br/>
    * @return Privacy mode as LinphonePrivacyMask <br/>
    */
    public int getPrivacy();

    /**
    * Set default privacy policy for all calls routed through this proxy. <br/>
    * <br/>
    * @param privacy LinphonePrivacyMask to configure privacy <br/>
    */
    public void setPrivacy(int privacy);

    /**
    * Tell if the PUBLISH is enabled. <br/>
    * <br/>
    * @return true if PUBLISH request is enabled for this proxy. <br/>
    */
    public boolean isPublishEnabled();

    /**
    * Indicates either or not, PUBLISH must be issued for this {@link AccountParams}. <br/>
    * <br/>
    * @param enable If true, publish will be engaged. <br/>
    */
    public void setPublishEnabled(boolean enable);

    /**
    * Get the publish expiration time in second. <br/>
    * <br/>
    * Default value is the registration expiration value. <br/>
    * @return The expire time in seconds. <br/>
    */
    public int getPublishExpires();

    /**
    * Set the publish expiration time in second. <br/>
    * <br/>
    * @param expires The expire time in seconds. <br/>
    */
    public void setPublishExpires(int expires);

    /**
    * Indicates whether to add to the contact parameters the push notification<br/>
    * information. <br/>
    * <br/>
    * For IOS, it indicates for VOIP push notification. <br/>
    * @return true if push notification informations should be added, false<br/>
    * otherwise. <br/>
    */
    public boolean getPushNotificationAllowed();

    /**
    * Indicates whether to add to the contact parameters the push notification<br/>
    * information. <br/>
    * <br/>
    * For IOS, it indicates for VOIP push notification. <br/>
    * @param allow true to allow push notification information, false otherwise. <br/>
    */
    public void setPushNotificationAllowed(boolean allow);

    /**
    * Returns the push notification configuration. <br/>
    * <br/>
    * @return The {@link PushNotificationConfig} object.   <br/>
    */
    @NonNull
    public PushNotificationConfig getPushNotificationConfig();

    /**
    * Sets the push notification configuration. <br/>
    * <br/>
    * @param config The {@link PushNotificationConfig} object.   <br/>
    */
    public void setPushNotificationConfig(@NonNull PushNotificationConfig config);

    /**
    * Get the route of the collector end-point when using quality reporting. <br/>
    * <br/>
    * This SIP address should be used on server-side to process packets directly<br/>
    * before discarding packets. Collector address should be a non existing account<br/>
    * and will not receive any messages. If null, reports will be send to the proxy<br/>
    * domain. <br/>
    * @return The SIP address of the collector end-point.   <br/>
    */
    @Nullable
    public String getQualityReportingCollector();

    /**
    * Set the route of the collector end-point when using quality reporting. <br/>
    * <br/>
    * This SIP address should be used on server-side to process packets directly<br/>
    * before discarding packets. Collector address should be a non existing account<br/>
    * and will not receive any messages. If null, reports will be send to the proxy<br/>
    * domain. <br/>
    * @param collector route of the collector end-point, if null PUBLISH will be sent<br/>
    * to the proxy domain.   <br/>
    */
    public void setQualityReportingCollector(@Nullable String collector);

    /**
    * Indicates whether quality statistics during call should be stored and sent to a<br/>
    * collector according to RFC 6035. <br/>
    * <br/>
    * @return true if quality repotring is enabled, false otherwise. <br/>
    */
    public boolean isQualityReportingEnabled();

    /**
    * Indicates whether quality statistics during call should be stored and sent to a<br/>
    * collector according to RFC 6035. <br/>
    * <br/>
    * @param enable true to store quality statistics and send them to the collector,<br/>
    * false to disable it. <br/>
    */
    public void setQualityReportingEnabled(boolean enable);

    /**
    * Get the interval between interval reports when using quality reporting. <br/>
    * <br/>
    * @return The interval in seconds, 0 means interval reports are disabled. <br/>
    */
    public int getQualityReportingInterval();

    /**
    * Set the interval between 2 interval reports sending when using quality<br/>
    * reporting. <br/>
    * <br/>
    * If call exceed interval size, an interval report will be sent to the collector.<br/>
    * On call termination, a session report will be sent for the remaining period.<br/>
    * Value must be 0 (disabled) or positive. <br/>
    * @param interval The interval in seconds, 0 means interval reports are disabled. <br/>
    */
    public void setQualityReportingInterval(int interval);

    /**
    * Get the realm of the given account params. <br/>
    * <br/>
    * This is optional, but recommended as it allows digest authentication context to<br/>
    * be re-used accross subsequent SIP requests, which reduces by almost half the<br/>
    * number of SIP rmessages exchanged between a client and a server. The server is<br/>
    * required to support the qop=auth digest authentication mode to benefit from<br/>
    * this feature. see: rfc7616 https://datatracker.ietf.org/doc/html/rfc7616 <br/>
    * @return The realm of the account params.   <br/>
    */
    @Nullable
    public String getRealm();

    /**
    * Set the realm of the given account params. <br/>
    * <br/>
    * This is optional, but recommended as it allows digest authentication context to<br/>
    * be re-used accross subsequent SIP requests, which reduces by almost half the<br/>
    * number of SIP rmessages exchanged between a client and a server. The server is<br/>
    * required to support the qop=auth digest authentication mode to benefit from<br/>
    * this feature. see: rfc7616 https://datatracker.ietf.org/doc/html/rfc7616 <br/>
    * @param realm New realm value.   <br/>
    */
    public void setRealm(@Nullable String realm);

    /**
    * Get the persistent reference key associated to the account params. <br/>
    * <br/>
    * The reference key can be for example an id to an external database. It is<br/>
    * stored in the config file, thus can survive to process exits/restarts.<br/>
    * @return The reference key string that has been associated to the account<br/>
    * params, or null if none has been associated.    <br/>
    */
    @Nullable
    public String getRefKey();

    /**
    * Associate a persistent reference key to the account params. <br/>
    * <br/>
    * The reference key can be for example an id to an external database. It is<br/>
    * stored in the config file, thus can survive to process exits/restarts.<br/>
    * @param refkey The reference key string to associate to the account params.   <br/>
    */
    public void setRefKey(@Nullable String refkey);

    /**
    * Returns whether the account params is enabled or not. <br/>
    * <br/>
    * @return true if registration to the proxy is enabled. <br/>
    */
    public boolean isRegisterEnabled();

    /**
    * Indicates either or not, REGISTRATION must be issued for this {@link AccountParams}<br/>
    * . <br/>
    * <br/>
    * @param enable If true, registration will be engaged. <br/>
    */
    public void setRegisterEnabled(boolean enable);

    /**
    * Indicates whether to add to the contact parameters the push notification<br/>
    * information. <br/>
    * <br/>
    * @return true if remote push notification informations should be added, false<br/>
    * otherwise. <br/>
    */
    public boolean getRemotePushNotificationAllowed();

    /**
    * Indicates whether to add to the contact parameters the push notification<br/>
    * information. <br/>
    * <br/>
    * @param allow true to allow remote push notification information, false<br/>
    * otherwise. <br/>
    */
    public void setRemotePushNotificationAllowed(boolean allow);

    /**
    * Gets the list of the routes set for this account params. <br/>
    * <br/>
    * @return The list of routes.    <br/>
    */
    @NonNull
    public Address[] getRoutesAddresses();

    /**
    * Sets a list of SIP route. <br/>
    * <br/>
    * When a route is set, all outgoing calls will go to the route's destination if<br/>
    * this account is the default one (see {@link Core#setDefaultAccount}).<br/>
    * warning: This function shall not be used in conjunction with {@link #enableOutboundProxy}<br/>
    * . <br/>
    * @param routes A list of routes.    <br/>
    * @return -1 if routes are invalid, 0 otherwise. <br/>
    */
    public int setRoutesAddresses(@Nullable Address[] routes);

    /**
    * Returns whether RTP bundle mode is assumed. <br/>
    * <br/>
    * See https://datatracker.ietf.org/doc/html/rfc8843 for more information. <br/>
    * @return a boolean indicating when rtp bundle support is assumed. <br/>
    */
    public boolean isRtpBundleAssumptionEnabled();

    /**
    * Indicates whether support of rtp bundle is assumed. <br/>
    * <br/>
    * See {@link #enableRtpBundle} for background information about rtp bundle.<br/>
    * Assumption that RTP bundling support allows interesting optimizations, such as<br/>
    * not gathering RTCP candidates, and not gathering candidates for video stream<br/>
    * when making an outgoing call. This setting is meaningful only if rtp bundle is<br/>
    * enabled. See https://datatracker.ietf.org/doc/html/rfc8843 for more information<br/>
    * about the feature. <br/>
    * @param value a boolean to indicate whether RTP bundle support can be assumed. <br/>
    */
    public void setRtpBundleAssumptionEnabled(boolean value);

    /**
    * Returns whether RTP bundle mode (also known as Media Multiplexing) is enabled. <br/>
    * <br/>
    * See https://datatracker.ietf.org/doc/html/rfc8843 for more information. <br/>
    * @return a boolean indicating the enablement of rtp bundle mode. <br/>
    */
    public boolean isRtpBundleEnabled();

    /**
    * Enables or disables RTP bundle mode (Media Multiplexing). <br/>
    * <br/>
    * See https://datatracker.ietf.org/doc/html/rfc8843 for more information about<br/>
    * the feature. When enabled, liblinphone will try to negociate the use of a<br/>
    * single port for all streams when doing an outgoing call. It automatically<br/>
    * enables rtcp-mux. <br/>
    * @param value a boolean to indicate whether the feature is to be enabled. <br/>
    */
    public void setRtpBundleEnabled(boolean value);

    /**
    * Get the account params proxy address. <br/>
    * <br/>
    * @return The proxy's SIP address.   <br/>
    * @deprecated 01/03/2021 Use {@link #getServerAddress} instead. <br/>
    */
    @Deprecated
    @Nullable
    public String getServerAddr();

    /**
    * Sets the proxy address. <br/>
    * <br/>
    * Examples of valid sip proxy address are:<br/>
    * @param serverAddress The proxy address to set.   <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    * @deprecated 01/03/2021 Use {@link #setServerAddress} instead. <br/>
    */
    @Deprecated
    public int setServerAddr(@Nullable String serverAddress);

    /**
    * Get the account params SIP proxy or registrar address. <br/>
    * <br/>
    * @return The proxy's SIP {@link Address}.   <br/>
    */
    @Nullable
    public Address getServerAddress();

    /**
    * Sets the SIP proxy or registrar address. <br/>
    * <br/>
    * Examples of valid sip proxy address are:<br/>
    * @param serverAddress The proxy as {@link Address} to set.   <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    */
    public int setServerAddress(@Nullable Address serverAddress);

    /**
    * Gets the list of supported tags. <br/>
    * <br/>
    * @return The list of supported tags .   <br/>
    */
    @NonNull
    public String[] getSupportedTagsList();

    /**
    * Sets the list of supported tags. <br/>
    * <br/>
    * @param supportedTags The list of supported tags .   <br/>
    */
    public void setSupportedTagsList(@Nullable String[] supportedTags);

    /**
    * Returns the transport type of the server address. <br/>
    * <br/>
    * @return The {@link TransportType} of the server address. <br/>
    */
    public TransportType getTransport();

    /**
    * Sets the transport type of the server address. <br/>
    * <br/>
    * @param transport The {@link TransportType} to set. <br/>
    */
    public void setTransport(TransportType transport);

    /**
    * Gets whether the account will unREGISTER when the core stops but only if the<br/>
    * push notifications are not allowed for the account. <br/>
    * <br/>
    * @return true if the account will unREGISTER at stop, false otherwise. <br/>
    */
    public boolean isUnregisterAtStopEnabled();

    /**
    * Sets whether the account will unREGISTER when the core stops but only if the<br/>
    * push notifications are not allowed for the account. <br/>
    * <br/>
    * @param unregister true to unregister the account, false otherwise. <br/>
    */
    public void setUnregisterAtStopEnabled(boolean unregister);

    /**
    * Return whether or not the international prefix will automaticaly be used for<br/>
    * calls and chats. <br/>
    * <br/>
    * @return Whether we should use international prefix automatically for calls. <br/>
    */
    public boolean getUseInternationalPrefixForCallsAndChats();

    /**
    * If enabled, the international prefix will automaticaly be used for calls and<br/>
    * chats. <br/>
    * <br/>
    * @param enable true to use the international prefix for calls, false otherwise. <br/>
    */
    public void setUseInternationalPrefixForCallsAndChats(boolean enable);

    /**
    * Gets the Voicemail address. <br/>
    * <br/>
    * @return The Voicemail address.   <br/>
    */
    @Nullable
    public Address getVoicemailAddress();

    /**
    * Sets the Voicemail address. <br/>
    * <br/>
    * @param address The Voicemail address.   <br/>
    */
    public void setVoicemailAddress(@Nullable Address address);

    /**
    * Set one custom parameter to this {@link AccountParams}. <br/>
    * <br/>
    * @param key key of the searched parameter.   <br/>
    * @param value value of the searched parameter.   <br/>
    */
    public void addCustomParam(@NonNull String key, @NonNull String value);

    /**
    * Instantiate a new account params with values from source. <br/>
    * <br/>
    * @return The newly created {@link AccountParams} object.   <br/>
    */
    @NonNull
    public AccountParams clone();

    /**
    * Get the custom parameter with key to this {@link AccountParams}. <br/>
    * <br/>
    * @param key key of the searched parameter.   <br/>
    * @return The value of the parameter with key if found or an empty string<br/>
    * otherwise.   <br/>
    */
    @NonNull
    public String getCustomParam(@NonNull String key);

    /**
    * Create a new {@link AccountParams} object from a configuration. <br/>
    * <br/>
    * @param lc The {@link Core} object.   <br/>
    * @param index The index of the configuration. <br/>
    * @return The newly created {@link AccountParams} object.   <br/>
    */
    @NonNull
    public AccountParams newWithConfig(@NonNull Core lc, int index);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AccountParamsImpl implements AccountParams {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AccountParamsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Address getAudioVideoConferenceFactoryAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getAudioVideoConferenceFactoryAddress()  {
        
        
        return (Address)getAudioVideoConferenceFactoryAddress(nativePtr);
    }

    private native void setAudioVideoConferenceFactoryAddress(long nativePtr, Address address);
    @Override
    synchronized public void setAudioVideoConferenceFactoryAddress(@Nullable Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAudioVideoConferenceFactoryAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAudioVideoConferenceFactoryAddress(nativePtr, address);
    }

    private native int getAvpfMode(long nativePtr);
    @Override
    synchronized public AVPFMode getAvpfMode()  {
        
        
        return AVPFMode.fromInt(getAvpfMode(nativePtr));
    }

    private native void setAvpfMode(long nativePtr, int mode);
    @Override
    synchronized public void setAvpfMode(AVPFMode mode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAvpfMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAvpfMode(nativePtr, mode.toInt());
    }

    private native int getAvpfRrInterval(long nativePtr);
    @Override
    synchronized public int getAvpfRrInterval()  {
        
        
        return getAvpfRrInterval(nativePtr);
    }

    private native void setAvpfRrInterval(long nativePtr, int interval);
    @Override
    synchronized public void setAvpfRrInterval(int interval)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAvpfRrInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAvpfRrInterval(nativePtr, interval);
    }

    private native String getCcmpServerUrl(long nativePtr);
    @Override @Nullable
    synchronized public String getCcmpServerUrl()  {
        
        
        return getCcmpServerUrl(nativePtr);
    }

    private native void setCcmpServerUrl(long nativePtr, String url);
    @Override
    synchronized public void setCcmpServerUrl(@Nullable String url)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCcmpServerUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCcmpServerUrl(nativePtr, url);
    }

    private native String getCcmpUserId(long nativePtr);
    @Override @Nullable
    synchronized public String getCcmpUserId()  {
        
        
        return getCcmpUserId(nativePtr);
    }

    private native Address getConferenceFactoryAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getConferenceFactoryAddress()  {
        
        
        return (Address)getConferenceFactoryAddress(nativePtr);
    }

    private native void setConferenceFactoryAddress(long nativePtr, Address address);
    @Override
    synchronized public void setConferenceFactoryAddress(@Nullable Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceFactoryAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceFactoryAddress(nativePtr, address);
    }

    private native String getConferenceFactoryUri(long nativePtr);
    @Override @Nullable
    synchronized public String getConferenceFactoryUri()  {
        
        
        return getConferenceFactoryUri(nativePtr);
    }

    private native void setConferenceFactoryUri(long nativePtr, String uri);
    @Override
    synchronized public void setConferenceFactoryUri(@Nullable String uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceFactoryUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceFactoryUri(nativePtr, uri);
    }

    private native String getContactParameters(long nativePtr);
    @Override @Nullable
    synchronized public String getContactParameters()  {
        
        
        return getContactParameters(nativePtr);
    }

    private native void setContactParameters(long nativePtr, String contactParams);
    @Override
    synchronized public void setContactParameters(@Nullable String contactParams)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setContactParameters() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setContactParameters(nativePtr, contactParams);
    }

    private native String getContactUriParameters(long nativePtr);
    @Override @Nullable
    synchronized public String getContactUriParameters()  {
        
        
        return getContactUriParameters(nativePtr);
    }

    private native void setContactUriParameters(long nativePtr, String contactUriParams);
    @Override
    synchronized public void setContactUriParameters(@Nullable String contactUriParams)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setContactUriParameters() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setContactUriParameters(nativePtr, contactUriParams);
    }

    private native boolean isCpimInBasicChatRoomEnabled(long nativePtr);
    @Override
    synchronized public boolean isCpimInBasicChatRoomEnabled()  {
        
        
        return isCpimInBasicChatRoomEnabled(nativePtr);
    }

    private native void setCpimInBasicChatRoomEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setCpimInBasicChatRoomEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCpimInBasicChatRoomEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCpimInBasicChatRoomEnabled(nativePtr, enable);
    }

    private native Address getCustomContact(long nativePtr);
    @Override @Nullable
    synchronized public Address getCustomContact()  {
        
        
        return (Address)getCustomContact(nativePtr);
    }

    private native void setCustomContact(long nativePtr, Address contact);
    @Override
    synchronized public void setCustomContact(@Nullable Address contact)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCustomContact() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCustomContact(nativePtr, contact);
    }

    private native boolean isDialEscapePlusEnabled(long nativePtr);
    @Override
    synchronized public boolean isDialEscapePlusEnabled()  {
        
        
        return isDialEscapePlusEnabled(nativePtr);
    }

    private native void setDialEscapePlusEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setDialEscapePlusEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDialEscapePlusEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDialEscapePlusEnabled(nativePtr, enable);
    }

    private native String getDomain(long nativePtr);
    @Override @Nullable
    synchronized public String getDomain()  {
        
        
        return getDomain(nativePtr);
    }

    private native int getExpires(long nativePtr);
    @Override
    synchronized public int getExpires()  {
        
        
        return getExpires(nativePtr);
    }

    private native void setExpires(long nativePtr, int expires);
    @Override
    synchronized public void setExpires(int expires)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setExpires() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setExpires(nativePtr, expires);
    }

    private native String getIdentity(long nativePtr);
    @Override @Nullable
    synchronized public String getIdentity()  {
        
        
        return getIdentity(nativePtr);
    }

    private native Address getIdentityAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getIdentityAddress()  {
        
        
        return (Address)getIdentityAddress(nativePtr);
    }

    private native int setIdentityAddress(long nativePtr, Address identity);
    @Override
    synchronized public int setIdentityAddress(@Nullable Address identity)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIdentityAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setIdentityAddress(nativePtr, identity);
    }

    private native String getIdkey(long nativePtr);
    @Override @Nullable
    synchronized public String getIdkey()  {
        
        
        return getIdkey(nativePtr);
    }

    private native void setIdkey(long nativePtr, String idkey);
    @Override
    synchronized public void setIdkey(@Nullable String idkey)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIdkey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setIdkey(nativePtr, idkey);
    }

    private native boolean getInstantMessagingEncryptionMandatory(long nativePtr);
    @Override
    synchronized public boolean getInstantMessagingEncryptionMandatory()  {
        
        
        return getInstantMessagingEncryptionMandatory(nativePtr);
    }

    private native void setInstantMessagingEncryptionMandatory(long nativePtr, boolean mandatory);
    @Override
    synchronized public void setInstantMessagingEncryptionMandatory(boolean mandatory)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInstantMessagingEncryptionMandatory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInstantMessagingEncryptionMandatory(nativePtr, mandatory);
    }

    private native String getInternationalPrefix(long nativePtr);
    @Override @Nullable
    synchronized public String getInternationalPrefix()  {
        
        
        return getInternationalPrefix(nativePtr);
    }

    private native void setInternationalPrefix(long nativePtr, String prefix);
    @Override
    synchronized public void setInternationalPrefix(@Nullable String prefix)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInternationalPrefix() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInternationalPrefix(nativePtr, prefix);
    }

    private native String getInternationalPrefixIsoCountryCode(long nativePtr);
    @Override @Nullable
    synchronized public String getInternationalPrefixIsoCountryCode()  {
        
        
        return getInternationalPrefixIsoCountryCode(nativePtr);
    }

    private native void setInternationalPrefixIsoCountryCode(long nativePtr, String prefixIsoCountryCode);
    @Override
    synchronized public void setInternationalPrefixIsoCountryCode(@Nullable String prefixIsoCountryCode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInternationalPrefixIsoCountryCode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInternationalPrefixIsoCountryCode(nativePtr, prefixIsoCountryCode);
    }

    private native boolean isPushNotificationAvailable(long nativePtr);
    @Override
    synchronized public boolean isPushNotificationAvailable()  {
        
        
        return isPushNotificationAvailable(nativePtr);
    }

    private native String getLimeAlgo(long nativePtr);
    @Override @Nullable
    synchronized public String getLimeAlgo()  {
        
        
        return getLimeAlgo(nativePtr);
    }

    private native void setLimeAlgo(long nativePtr, String algo);
    @Override
    synchronized public void setLimeAlgo(@Nullable String algo)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLimeAlgo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLimeAlgo(nativePtr, algo);
    }

    private native String getLimeServerUrl(long nativePtr);
    @Override @Nullable
    synchronized public String getLimeServerUrl()  {
        
        
        return getLimeServerUrl(nativePtr);
    }

    private native void setLimeServerUrl(long nativePtr, String url);
    @Override
    synchronized public void setLimeServerUrl(@Nullable String url)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLimeServerUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLimeServerUrl(nativePtr, url);
    }

    private native Address getMwiServerAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getMwiServerAddress()  {
        
        
        return (Address)getMwiServerAddress(nativePtr);
    }

    private native void setMwiServerAddress(long nativePtr, Address address);
    @Override
    synchronized public void setMwiServerAddress(@Nullable Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMwiServerAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMwiServerAddress(nativePtr, address);
    }

    private native NatPolicy getNatPolicy(long nativePtr);
    @Override @Nullable
    synchronized public NatPolicy getNatPolicy()  {
        
        
        return (NatPolicy)getNatPolicy(nativePtr);
    }

    private native void setNatPolicy(long nativePtr, NatPolicy policy);
    @Override
    synchronized public void setNatPolicy(@Nullable NatPolicy policy)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setNatPolicy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setNatPolicy(nativePtr, policy);
    }

    private native boolean isOutboundProxyEnabled(long nativePtr);
    @Override
    synchronized public boolean isOutboundProxyEnabled()  {
        
        
        return isOutboundProxyEnabled(nativePtr);
    }

    private native void setOutboundProxyEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setOutboundProxyEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setOutboundProxyEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setOutboundProxyEnabled(nativePtr, enable);
    }

    private native String getPictureUri(long nativePtr);
    @Override @Nullable
    synchronized public String getPictureUri()  {
        
        
        return getPictureUri(nativePtr);
    }

    private native void setPictureUri(long nativePtr, String uri);
    @Override
    synchronized public void setPictureUri(@Nullable String uri)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPictureUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPictureUri(nativePtr, uri);
    }

    private native int getPrivacy(long nativePtr);
    @Override
    synchronized public int getPrivacy()  {
        
        
        return getPrivacy(nativePtr);
    }

    private native void setPrivacy(long nativePtr, int privacy);
    @Override
    synchronized public void setPrivacy(int privacy)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPrivacy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPrivacy(nativePtr, privacy);
    }

    private native boolean isPublishEnabled(long nativePtr);
    @Override
    synchronized public boolean isPublishEnabled()  {
        
        
        return isPublishEnabled(nativePtr);
    }

    private native void setPublishEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setPublishEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPublishEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPublishEnabled(nativePtr, enable);
    }

    private native int getPublishExpires(long nativePtr);
    @Override
    synchronized public int getPublishExpires()  {
        
        
        return getPublishExpires(nativePtr);
    }

    private native void setPublishExpires(long nativePtr, int expires);
    @Override
    synchronized public void setPublishExpires(int expires)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPublishExpires() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPublishExpires(nativePtr, expires);
    }

    private native boolean getPushNotificationAllowed(long nativePtr);
    @Override
    synchronized public boolean getPushNotificationAllowed()  {
        
        
        return getPushNotificationAllowed(nativePtr);
    }

    private native void setPushNotificationAllowed(long nativePtr, boolean allow);
    @Override
    synchronized public void setPushNotificationAllowed(boolean allow)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPushNotificationAllowed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPushNotificationAllowed(nativePtr, allow);
    }

    private native PushNotificationConfig getPushNotificationConfig(long nativePtr);
    @Override @NonNull
    synchronized public PushNotificationConfig getPushNotificationConfig()  {
        
        
        return (PushNotificationConfig)getPushNotificationConfig(nativePtr);
    }

    private native void setPushNotificationConfig(long nativePtr, PushNotificationConfig config);
    @Override
    synchronized public void setPushNotificationConfig(@NonNull PushNotificationConfig config)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setPushNotificationConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setPushNotificationConfig(nativePtr, config);
    }

    private native String getQualityReportingCollector(long nativePtr);
    @Override @Nullable
    synchronized public String getQualityReportingCollector()  {
        
        
        return getQualityReportingCollector(nativePtr);
    }

    private native void setQualityReportingCollector(long nativePtr, String collector);
    @Override
    synchronized public void setQualityReportingCollector(@Nullable String collector)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setQualityReportingCollector() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setQualityReportingCollector(nativePtr, collector);
    }

    private native boolean isQualityReportingEnabled(long nativePtr);
    @Override
    synchronized public boolean isQualityReportingEnabled()  {
        
        
        return isQualityReportingEnabled(nativePtr);
    }

    private native void setQualityReportingEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setQualityReportingEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setQualityReportingEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setQualityReportingEnabled(nativePtr, enable);
    }

    private native int getQualityReportingInterval(long nativePtr);
    @Override
    synchronized public int getQualityReportingInterval()  {
        
        
        return getQualityReportingInterval(nativePtr);
    }

    private native void setQualityReportingInterval(long nativePtr, int interval);
    @Override
    synchronized public void setQualityReportingInterval(int interval)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setQualityReportingInterval() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setQualityReportingInterval(nativePtr, interval);
    }

    private native String getRealm(long nativePtr);
    @Override @Nullable
    synchronized public String getRealm()  {
        
        
        return getRealm(nativePtr);
    }

    private native void setRealm(long nativePtr, String realm);
    @Override
    synchronized public void setRealm(@Nullable String realm)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRealm() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRealm(nativePtr, realm);
    }

    private native String getRefKey(long nativePtr);
    @Override @Nullable
    synchronized public String getRefKey()  {
        
        
        return getRefKey(nativePtr);
    }

    private native void setRefKey(long nativePtr, String refkey);
    @Override
    synchronized public void setRefKey(@Nullable String refkey)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRefKey() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRefKey(nativePtr, refkey);
    }

    private native boolean isRegisterEnabled(long nativePtr);
    @Override
    synchronized public boolean isRegisterEnabled()  {
        
        
        return isRegisterEnabled(nativePtr);
    }

    private native void setRegisterEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setRegisterEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRegisterEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRegisterEnabled(nativePtr, enable);
    }

    private native boolean getRemotePushNotificationAllowed(long nativePtr);
    @Override
    synchronized public boolean getRemotePushNotificationAllowed()  {
        
        
        return getRemotePushNotificationAllowed(nativePtr);
    }

    private native void setRemotePushNotificationAllowed(long nativePtr, boolean allow);
    @Override
    synchronized public void setRemotePushNotificationAllowed(boolean allow)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRemotePushNotificationAllowed() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRemotePushNotificationAllowed(nativePtr, allow);
    }

    private native Address[] getRoutesAddresses(long nativePtr);
    @Override @NonNull
    synchronized public Address[] getRoutesAddresses()  {
        
        
        return getRoutesAddresses(nativePtr);
    }

    private native int setRoutesAddresses(long nativePtr, Address[] routes);
    @Override
    synchronized public int setRoutesAddresses(@Nullable Address[] routes)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRoutesAddresses() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setRoutesAddresses(nativePtr, routes);
    }

    private native boolean isRtpBundleAssumptionEnabled(long nativePtr);
    @Override
    synchronized public boolean isRtpBundleAssumptionEnabled()  {
        
        
        return isRtpBundleAssumptionEnabled(nativePtr);
    }

    private native void setRtpBundleAssumptionEnabled(long nativePtr, boolean value);
    @Override
    synchronized public void setRtpBundleAssumptionEnabled(boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRtpBundleAssumptionEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRtpBundleAssumptionEnabled(nativePtr, value);
    }

    private native boolean isRtpBundleEnabled(long nativePtr);
    @Override
    synchronized public boolean isRtpBundleEnabled()  {
        
        
        return isRtpBundleEnabled(nativePtr);
    }

    private native void setRtpBundleEnabled(long nativePtr, boolean value);
    @Override
    synchronized public void setRtpBundleEnabled(boolean value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRtpBundleEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRtpBundleEnabled(nativePtr, value);
    }

    private native String getServerAddr(long nativePtr);
    @Override @Nullable
    synchronized public String getServerAddr()  {
        
        
        return getServerAddr(nativePtr);
    }

    private native int setServerAddr(long nativePtr, String serverAddress);
    @Override
    synchronized public int setServerAddr(@Nullable String serverAddress)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setServerAddr() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setServerAddr(nativePtr, serverAddress);
    }

    private native Address getServerAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getServerAddress()  {
        
        
        return (Address)getServerAddress(nativePtr);
    }

    private native int setServerAddress(long nativePtr, Address serverAddress);
    @Override
    synchronized public int setServerAddress(@Nullable Address serverAddress)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setServerAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setServerAddress(nativePtr, serverAddress);
    }

    private native String[] getSupportedTagsList(long nativePtr);
    @Override @NonNull
    synchronized public String[] getSupportedTagsList()  {
        
        
        return getSupportedTagsList(nativePtr);
    }

    private native void setSupportedTagsList(long nativePtr, String[] supportedTags);
    @Override
    synchronized public void setSupportedTagsList(@Nullable String[] supportedTags)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSupportedTagsList() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSupportedTagsList(nativePtr, supportedTags);
    }

    private native int getTransport(long nativePtr);
    @Override
    synchronized public TransportType getTransport()  {
        
        
        return TransportType.fromInt(getTransport(nativePtr));
    }

    private native void setTransport(long nativePtr, int transport);
    @Override
    synchronized public void setTransport(TransportType transport)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTransport() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTransport(nativePtr, transport.toInt());
    }

    private native boolean isUnregisterAtStopEnabled(long nativePtr);
    @Override
    synchronized public boolean isUnregisterAtStopEnabled()  {
        
        
        return isUnregisterAtStopEnabled(nativePtr);
    }

    private native void setUnregisterAtStopEnabled(long nativePtr, boolean unregister);
    @Override
    synchronized public void setUnregisterAtStopEnabled(boolean unregister)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUnregisterAtStopEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUnregisterAtStopEnabled(nativePtr, unregister);
    }

    private native boolean getUseInternationalPrefixForCallsAndChats(long nativePtr);
    @Override
    synchronized public boolean getUseInternationalPrefixForCallsAndChats()  {
        
        
        return getUseInternationalPrefixForCallsAndChats(nativePtr);
    }

    private native void setUseInternationalPrefixForCallsAndChats(long nativePtr, boolean enable);
    @Override
    synchronized public void setUseInternationalPrefixForCallsAndChats(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUseInternationalPrefixForCallsAndChats() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUseInternationalPrefixForCallsAndChats(nativePtr, enable);
    }

    private native Address getVoicemailAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getVoicemailAddress()  {
        
        
        return (Address)getVoicemailAddress(nativePtr);
    }

    private native void setVoicemailAddress(long nativePtr, Address address);
    @Override
    synchronized public void setVoicemailAddress(@Nullable Address address)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVoicemailAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVoicemailAddress(nativePtr, address);
    }

    private native void addCustomParam(long nativePtr, String key, String value);
    @Override
    synchronized public void addCustomParam(@NonNull String key, @NonNull String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomParam() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomParam(nativePtr, key, value);
    }

    private native AccountParams clone(long nativePtr);
    @Override @NonNull
    synchronized public AccountParams clone()  {
        
        
        return (AccountParams)clone(nativePtr);
    }

    private native String getCustomParam(long nativePtr, String key);
    @Override @NonNull
    synchronized public String getCustomParam(@NonNull String key)  {
        
        
        return getCustomParam(nativePtr, key);
    }

    private native AccountParams newWithConfig(long nativePtr, Core lc, int index);
    @Override @NonNull
    synchronized public AccountParams newWithConfig(@NonNull Core lc, int index)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newWithConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountParams)newWithConfig(nativePtr, lc, index);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
