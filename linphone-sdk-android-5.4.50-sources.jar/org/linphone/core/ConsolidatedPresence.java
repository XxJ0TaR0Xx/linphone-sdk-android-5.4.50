/*
ConsolidatedPresence.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Consolidated presence information: 'online' means the user is open for<br/>
* communication, 'busy' means the user is open for communication but involved in<br/>
* an other activity, 'do not disturb' means the user is not open for<br/>
* communication, and 'offline' means that no presence information is available. <br/>
* <br/>
*/
public enum ConsolidatedPresence {
    /**
    * <br/>
    */
    Online(0),

    /**
    * <br/>
    */
    Busy(1),

    /**
    * <br/>
    */
    DoNotDisturb(2),

    /**
    * <br/>
    */
    Offline(3);

    protected final int mValue;

    private ConsolidatedPresence (int value) {
        mValue = value;
    }

    static public ConsolidatedPresence fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Online;
        case 1: return Busy;
        case 2: return DoNotDisturb;
        case 3: return Offline;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for ConsolidatedPresence");
        }
    }
    
    static protected ConsolidatedPresence[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        ConsolidatedPresence[] enumArray = new ConsolidatedPresence[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = ConsolidatedPresence.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(ConsolidatedPresence[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
