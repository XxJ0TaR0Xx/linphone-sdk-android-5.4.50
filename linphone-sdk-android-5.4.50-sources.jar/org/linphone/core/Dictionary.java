/*
Dictionary.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that represents key-value pair container. <br/>
* <br/>
*/
public interface Dictionary {
    /**
    * Returns the list of keys present in the dictionary. <br/>
    * <br/>
    * @return the  of keys inside the dictionary.     <br/>
    */
    @NonNull
    public String[] getKeys();

    /**
    * Clears the dictionary. <br/>
    * <br/>
    */
    public void clear();

    /**
    * Instantiates a new dictionary with values from source. <br/>
    * <br/>
    * @return The newly created {@link Dictionary} object.   <br/>
    */
    @NonNull
    public Dictionary clone();

    /**
    * Gets the LinphoneBuffer value of a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @return The value.   <br/>
    */
    @Nullable
    public Buffer getBuffer(@Nullable String key);

    /**
    * Gets the float value of a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @return The value. <br/>
    */
    public float getFloat(@Nullable String key);

    /**
    * Gets the int value of a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @return The value. <br/>
    */
    public int getInt(@Nullable String key);

    /**
    * Gets the int64 value of a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @return The value. <br/>
    */
    public int getInt64(@Nullable String key);

    /**
    * Gets the char* value of a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @return The value.   <br/>
    */
    @Nullable
    public String getString(@Nullable String key);

    /**
    * Search if the key is present in the dictionary. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @return The LinphoneStatus of the operation. <br/>
    */
    public int hasKey(@Nullable String key);

    /**
    * Removes the pair of the key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @return The LinphoneStatus of the operation. <br/>
    */
    public int remove(@Nullable String key);

    /**
    * Sets a LinphoneBuffer value to a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @param value The LinphoneBuffer value.   <br/>
    */
    public void setBuffer(@Nullable String key, @Nullable Buffer value);

    /**
    * Sets a float value to a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @param value The int value. <br/>
    */
    public void setFloat(@Nullable String key, float value);

    /**
    * Sets a int value to a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @param value The int value. <br/>
    */
    public void setInt(@Nullable String key, int value);

    /**
    * Sets a int64 value to a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @param value The int64 value. <br/>
    */
    public void setInt64(@Nullable String key, int value);

    /**
    * Sets a char* value to a key. <br/>
    * <br/>
    * @param key The key.   <br/>
    * @param value The value.   <br/>
    */
    public void setString(@Nullable String key, @Nullable String value);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class DictionaryImpl implements Dictionary {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected DictionaryImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String[] getKeys(long nativePtr);
    @Override @NonNull
    synchronized public String[] getKeys()  {
        
        
        return getKeys(nativePtr);
    }

    private native void clear(long nativePtr);
    @Override
    synchronized public void clear()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call clear() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        clear(nativePtr);
    }

    private native Dictionary clone(long nativePtr);
    @Override @NonNull
    synchronized public Dictionary clone()  {
        
        
        return (Dictionary)clone(nativePtr);
    }

    private native Buffer getBuffer(long nativePtr, String key);
    @Override @Nullable
    synchronized public Buffer getBuffer(@Nullable String key)  {
        
        
        return (Buffer)getBuffer(nativePtr, key);
    }

    private native float getFloat(long nativePtr, String key);
    @Override
    synchronized public float getFloat(@Nullable String key)  {
        
        
        return getFloat(nativePtr, key);
    }

    private native int getInt(long nativePtr, String key);
    @Override
    synchronized public int getInt(@Nullable String key)  {
        
        
        return getInt(nativePtr, key);
    }

    private native int getInt644(long nativePtr, String key);
    @Override
    synchronized public int getInt64(@Nullable String key)  {
        
        
        return getInt644(nativePtr, key);
    }

    private native String getString(long nativePtr, String key);
    @Override @Nullable
    synchronized public String getString(@Nullable String key)  {
        
        
        return getString(nativePtr, key);
    }

    private native int hasKey(long nativePtr, String key);
    @Override
    synchronized public int hasKey(@Nullable String key)  {
        
        
        return hasKey(nativePtr, key);
    }

    private native int remove(long nativePtr, String key);
    @Override
    synchronized public int remove(@Nullable String key)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call remove() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return remove(nativePtr, key);
    }

    private native void setBuffer(long nativePtr, String key, Buffer value);
    @Override
    synchronized public void setBuffer(@Nullable String key, @Nullable Buffer value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setBuffer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setBuffer(nativePtr, key, value);
    }

    private native void setFloat(long nativePtr, String key, float value);
    @Override
    synchronized public void setFloat(@Nullable String key, float value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setFloat() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setFloat(nativePtr, key, value);
    }

    private native void setInt(long nativePtr, String key, int value);
    @Override
    synchronized public void setInt(@Nullable String key, int value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInt() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInt(nativePtr, key, value);
    }

    private native void setInt644(long nativePtr, String key, int value);
    @Override
    synchronized public void setInt64(@Nullable String key, int value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setInt64() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setInt644(nativePtr, key, value);
    }

    private native void setString(long nativePtr, String key, String value);
    @Override
    synchronized public void setString(@Nullable String key, @Nullable String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setString(nativePtr, key, value);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
