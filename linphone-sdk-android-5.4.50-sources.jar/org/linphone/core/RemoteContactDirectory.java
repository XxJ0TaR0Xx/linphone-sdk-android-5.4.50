/*
RemoteContactDirectory.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that represents a remote contact directory such as a LDAP or CardDAV<br/>
* server; used as a {@link MagicSearch} source. <br/>
* <br/>
*/
public interface RemoteContactDirectory {
    public enum Type {
        /**
        * Remote contact directory will use #CardDavParams. <br/>
        * <br/>
        */
        CardDav(0),

        /**
        * Remote contact directory will use #LdapParams. <br/>
        * <br/>
        */
        Ldap(1);

        protected final int mValue;

        private Type (int value) {
            mValue = value;
        }

        static public Type fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return CardDav;
            case 1: return Ldap;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Type");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Gets the CardDAV params if {@link #getType} returns CardDAV. <br/>
    * <br/>
    * @return the {@link CardDavParams} or null if not of CardDAV type.   <br/>
    */
    @Nullable
    public CardDavParams getCardDavParams();

    /**
    * Gets the LDAP params if {@link #getType} returns LDAP. <br/>
    * <br/>
    * @return the {@link LdapParams} or null if not of LDAP type.   <br/>
    */
    @Nullable
    public LdapParams getLdapParams();

    /**
    * Gets the maximum number of results to fetch, 0 means no limit. <br/>
    * <br/>
    * @return the maximum number of results, 0 means no limit. <br/>
    */
    public int getLimit();

    /**
    * Sets the maximum number of results to fetch, 0 means no limit. <br/>
    * <br/>
    * @param limit the maximum number of results to return. <br/>
    */
    public void setLimit(int limit);

    /**
    * Gets the minimum number of characters to have before sending the query to the<br/>
    * server. <br/>
    * <br/>
    * @return The mininum number of characters to have before sending the query. <br/>
    */
    public int getMinCharacters();

    /**
    * Sets the minimum number of characters to have before sending the query to the<br/>
    * server. <br/>
    * <br/>
    * @param min the minimum characters to have in user input filter before sending<br/>
    * the query. <br/>
    */
    public void setMinCharacters(int min);

    /**
    * Gets the configured remote contact directory server URL. <br/>
    * <br/>
    * @return the remote contact directory server URL.   <br/>
    */
    @Nullable
    public String getServerUrl();

    /**
    * Sets the server URL to use to reach the remote contact directory server. <br/>
    * <br/>
    * @param serverUrl the remote contact directory server URL.   <br/>
    */
    public void setServerUrl(@Nullable String serverUrl);

    /**
    * Gets the timeout (in seconds) after which the query is abandonned. <br/>
    * <br/>
    * @return The timeout (in seconds) after which the query is considered to be<br/>
    * timed-out. <br/>
    */
    public int getTimeout();

    /**
    * Sets the timeout (in seconds) after which the query is abandonned. <br/>
    * <br/>
    * @param seconds the number of seconds before considering the query as timed-out. <br/>
    */
    public void setTimeout(int seconds);

    /**
    * Gets the type of remote contact directory (LDAP, CardDAV). <br/>
    * <br/>
    * @return the {@link Type} of this remote contact directory. <br/>
    */
    public RemoteContactDirectory.Type getType();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class RemoteContactDirectoryImpl implements RemoteContactDirectory {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected RemoteContactDirectoryImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native CardDavParams getCardDavParams(long nativePtr);
    @Override @Nullable
    synchronized public CardDavParams getCardDavParams()  {
        
        
        return (CardDavParams)getCardDavParams(nativePtr);
    }

    private native LdapParams getLdapParams(long nativePtr);
    @Override @Nullable
    synchronized public LdapParams getLdapParams()  {
        
        
        return (LdapParams)getLdapParams(nativePtr);
    }

    private native int getLimit(long nativePtr);
    @Override
    synchronized public int getLimit()  {
        
        
        return getLimit(nativePtr);
    }

    private native void setLimit(long nativePtr, int limit);
    @Override
    synchronized public void setLimit(int limit)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLimit() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLimit(nativePtr, limit);
    }

    private native int getMinCharacters(long nativePtr);
    @Override
    synchronized public int getMinCharacters()  {
        
        
        return getMinCharacters(nativePtr);
    }

    private native void setMinCharacters(long nativePtr, int min);
    @Override
    synchronized public void setMinCharacters(int min)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMinCharacters() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMinCharacters(nativePtr, min);
    }

    private native String getServerUrl(long nativePtr);
    @Override @Nullable
    synchronized public String getServerUrl()  {
        
        
        return getServerUrl(nativePtr);
    }

    private native void setServerUrl(long nativePtr, String serverUrl);
    @Override
    synchronized public void setServerUrl(@Nullable String serverUrl)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setServerUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setServerUrl(nativePtr, serverUrl);
    }

    private native int getTimeout(long nativePtr);
    @Override
    synchronized public int getTimeout()  {
        
        
        return getTimeout(nativePtr);
    }

    private native void setTimeout(long nativePtr, int seconds);
    @Override
    synchronized public void setTimeout(int seconds)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTimeout() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTimeout(nativePtr, seconds);
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public RemoteContactDirectory.Type getType()  {
        
        
        return RemoteContactDirectory.Type.fromInt(getType(nativePtr));
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
