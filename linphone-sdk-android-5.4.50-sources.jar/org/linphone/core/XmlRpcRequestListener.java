/*
XmlRpcRequestListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for handling the {@link XmlRpcRequest}<br/>
* operations. <br/>
* <br/>
*/
public interface XmlRpcRequestListener {
    /**
    * Callback used to notify the response to an XML-RPC request. <br/>
    * <br/>
    * @param request {@link XmlRpcRequest} object   <br/>
    */
    public void onResponse(@NonNull XmlRpcRequest request);

}