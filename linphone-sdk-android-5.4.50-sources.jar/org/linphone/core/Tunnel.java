/*
Tunnel.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Linphone tunnel object. <br/>
* <br/>
*/
public interface Tunnel {
    public enum Mode {
        /**
        * The tunnel is disabled. <br/>
        * <br/>
        */
        Disable(0),

        /**
        * The tunnel is enabled. <br/>
        * <br/>
        */
        Enable(1),

        /**
        * The tunnel is enabled automatically if it is required. <br/>
        * <br/>
        */
        Auto(2);

        protected final int mValue;

        private Mode (int value) {
            mValue = value;
        }

        static public Mode fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Disable;
            case 1: return Enable;
            case 2: return Auto;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Mode");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Returns whether the tunnel is activated. <br/>
    * <br/>
    * If mode is set to auto, this gives indication whether the automatic detection<br/>
    * determined that tunnel was necessary or not. <br/>
    * @return true if tunnel is in use, false otherwise. <br/>
    */
    public boolean getActivated();

    /**
    * Get the domain. <br/>
    * <br/>
    * @return The domain.   <br/>
    */
    @Nullable
    public String getDomain();

    /**
    * Set the domain. <br/>
    * <br/>
    * Required for tunnel TLS client authentification. Certificate Altname or CName<br/>
    * should be sip:<tunnel_username><tunnel_domain> <br/>
    * @param domain The domain.   <br/>
    */
    public void setDomain(@Nullable String domain);

    /**
    * Get the dual tunnel client mode. <br/>
    * <br/>
    * @return true if dual tunnel client mode is enabled, false otherwise <br/>
    */
    public boolean isDualModeEnabled();

    /**
    * Sets whether or not to use the dual tunnel client mode. <br/>
    * <br/>
    * By default this feature is disabled. After enabling it, add a server with 2<br/>
    * hosts and 2 ports for the feature to work. <br/>
    * @param dualModeEnabled true to enable it, false to disable it <br/>
    */
    public void setDualModeEnabled(boolean dualModeEnabled);

    /**
    * Get the tunnel mode. <br/>
    * <br/>
    * @return The current {@link Mode} <br/>
    */
    public Tunnel.Mode getMode();

    /**
    * Set the tunnel mode. <br/>
    * <br/>
    * The tunnel mode can be 'enable', 'disable' or 'auto' If the mode is set to<br/>
    * 'auto', the tunnel manager will try to established an RTP session with the<br/>
    * tunnel server on the UdpMirrorPort. If the connection fail, the tunnel is<br/>
    * automatically activated whereas the tunnel is automatically disabled if the<br/>
    * connection succeed. <br/>
    * @param mode The desired {@link Mode} <br/>
    */
    public void setMode(Tunnel.Mode mode);

    /**
    * Get added servers. <br/>
    * <br/>
    * @return The list of servers.    <br/>
    */
    @NonNull
    public TunnelConfig[] getServers();

    /**
    * Check whether tunnel is set to transport SIP packets. <br/>
    * <br/>
    * @return A boolean value telling whether SIP packets shall pass through the<br/>
    * tunnel <br/>
    */
    public boolean isSipEnabled();

    /**
    * Set whether SIP packets must be directly sent to a UA or pass through the<br/>
    * tunnel. <br/>
    * <br/>
    * @param enable If true, SIP packets shall pass through the tunnel <br/>
    */
    public void setSipEnabled(boolean enable);

    /**
    * Get the username. <br/>
    * <br/>
    * @return The username.   <br/>
    */
    @Nullable
    public String getUsername();

    /**
    * Set the username. <br/>
    * <br/>
    * Required for tunnel TLS client authentification. Certificate Altname or CName<br/>
    * should be sip:<tunnel_username><tunnel_domain> <br/>
    * @param username The username.   <br/>
    */
    public void setUsername(@Nullable String username);

    /**
    * Add a tunnel server configuration. <br/>
    * <br/>
    * @param tunnelConfig {@link TunnelConfig} object   <br/>
    */
    public void addServer(@NonNull TunnelConfig tunnelConfig);

    /**
    * Remove all tunnel server addresses previously entered with {@link #addServer} <br/>
    * <br/>
    */
    public void cleanServers();

    /**
    * Check whether the tunnel is connected. <br/>
    * <br/>
    * @return A boolean value telling if the tunnel is connected <br/>
    */
    public boolean connected();

    /**
    * Force reconnection to the tunnel server. <br/>
    * <br/>
    * This method is useful when the device switches from wifi to Edge/3G or vice<br/>
    * versa. In most cases the tunnel client socket won't be notified promptly that<br/>
    * its connection is now zombie, so it is recommended to call this method that<br/>
    * will cause the lost connection to be closed and new connection to be issued. <br/>
    */
    public void reconnect();

    /**
    * Remove a tunnel server configuration. <br/>
    * <br/>
    * @param tunnelConfig {@link TunnelConfig} object   <br/>
    */
    public void removeServer(@NonNull TunnelConfig tunnelConfig);

    /**
    * Set an optional http proxy to go through when connecting to tunnel server. <br/>
    * <br/>
    * @param host http proxy host   <br/>
    * @param port http proxy port <br/>
    * @param username Optional http proxy username if the proxy request<br/>
    * authentication. Currently only basic authentication is supported. Use null if<br/>
    * not needed.   <br/>
    * @param passwd Optional http proxy password. Use null if not needed.   <br/>
    */
    public void setHttpProxy(@NonNull String host, int port, @Nullable String username, @Nullable String passwd);

    /**
    * Set authentication info for the http proxy. <br/>
    * <br/>
    * @param username User name   <br/>
    * @param passwd Password   <br/>
    */
    public void setHttpProxyAuthInfo(@Nullable String username, @Nullable String passwd);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class TunnelImpl implements Tunnel {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected TunnelImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native boolean getActivated(long nativePtr);
    @Override
    synchronized public boolean getActivated()  {
        
        
        return getActivated(nativePtr);
    }

    private native String getDomain(long nativePtr);
    @Override @Nullable
    synchronized public String getDomain()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDomain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDomain(nativePtr);
    }

    private native void setDomain(long nativePtr, String domain);
    @Override
    synchronized public void setDomain(@Nullable String domain)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDomain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDomain(nativePtr, domain);
    }

    private native boolean isDualModeEnabled(long nativePtr);
    @Override
    synchronized public boolean isDualModeEnabled()  {
        
        
        return isDualModeEnabled(nativePtr);
    }

    private native void setDualModeEnabled(long nativePtr, boolean dualModeEnabled);
    @Override
    synchronized public void setDualModeEnabled(boolean dualModeEnabled)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDualModeEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDualModeEnabled(nativePtr, dualModeEnabled);
    }

    private native int getMode(long nativePtr);
    @Override
    synchronized public Tunnel.Mode getMode()  {
        
        
        return Tunnel.Mode.fromInt(getMode(nativePtr));
    }

    private native void setMode(long nativePtr, int mode);
    @Override
    synchronized public void setMode(Tunnel.Mode mode)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMode(nativePtr, mode.toInt());
    }

    private native TunnelConfig[] getServers(long nativePtr);
    @Override @NonNull
    synchronized public TunnelConfig[] getServers()  {
        
        
        return getServers(nativePtr);
    }

    private native boolean isSipEnabled(long nativePtr);
    @Override
    synchronized public boolean isSipEnabled()  {
        
        
        return isSipEnabled(nativePtr);
    }

    private native void setSipEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setSipEnabled(boolean enable)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSipEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSipEnabled(nativePtr, enable);
    }

    private native String getUsername(long nativePtr);
    @Override @Nullable
    synchronized public String getUsername()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUsername() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUsername(nativePtr);
    }

    private native void setUsername(long nativePtr, String username);
    @Override
    synchronized public void setUsername(@Nullable String username)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUsername() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUsername(nativePtr, username);
    }

    private native void addServer(long nativePtr, TunnelConfig tunnelConfig);
    @Override
    synchronized public void addServer(@NonNull TunnelConfig tunnelConfig)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addServer(nativePtr, tunnelConfig);
    }

    private native void cleanServers(long nativePtr);
    @Override
    synchronized public void cleanServers()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call cleanServers() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        cleanServers(nativePtr);
    }

    private native boolean connected(long nativePtr);
    @Override
    synchronized public boolean connected()  {
        
        
        return connected(nativePtr);
    }

    private native void reconnect(long nativePtr);
    @Override
    synchronized public void reconnect()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call reconnect() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        reconnect(nativePtr);
    }

    private native void removeServer(long nativePtr, TunnelConfig tunnelConfig);
    @Override
    synchronized public void removeServer(@NonNull TunnelConfig tunnelConfig)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeServer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeServer(nativePtr, tunnelConfig);
    }

    private native void setHttpProxy(long nativePtr, String host, int port, String username, String passwd);
    @Override
    synchronized public void setHttpProxy(@NonNull String host, int port, @Nullable String username, @Nullable String passwd)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHttpProxy() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHttpProxy(nativePtr, host, port, username, passwd);
    }

    private native void setHttpProxyAuthInfo(long nativePtr, String username, String passwd);
    @Override
    synchronized public void setHttpProxyAuthInfo(@Nullable String username, @Nullable String passwd)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHttpProxyAuthInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHttpProxyAuthInfo(nativePtr, username, passwd);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
