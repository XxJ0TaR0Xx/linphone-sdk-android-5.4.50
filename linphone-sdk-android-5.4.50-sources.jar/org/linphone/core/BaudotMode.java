/*
BaudotMode.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* {@link BaudotMode} enum represents the Baudot mode to use for the call. <br/>
* <br/>
*/
public enum BaudotMode {
    /**
    * Send and receive audio. <br/>
    * <br/>
    */
    Voice(0),

    /**
    * Send and receive Baudot tones. <br/>
    * <br/>
    */
    Tty(1),

    /**
    * Send Baudot tones, but receive audio. <br/>
    * <br/>
    */
    HearingCarryOver(2),

    /**
    * Send audio, but receive Baudot tones. <br/>
    * <br/>
    */
    VoiceCarryOver(3);

    protected final int mValue;

    private BaudotMode (int value) {
        mValue = value;
    }

    static public BaudotMode fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Voice;
        case 1: return Tty;
        case 2: return HearingCarryOver;
        case 3: return VoiceCarryOver;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for BaudotMode");
        }
    }
    
    static protected BaudotMode[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        BaudotMode[] enumArray = new BaudotMode[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = BaudotMode.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(BaudotMode[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
