/*
AccountCreatorListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the responses callbacks for handling the {@link AccountCreator}<br/>
* operations. <br/>
* <br/>
*/
public interface AccountCreatorListener {
    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onCreateAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onIsAccountExist(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onActivateAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onSendToken(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onAccountCreationRequestToken(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onAccountCreationTokenUsingRequestToken(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onIsAccountActivated(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onLinkAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onActivateAlias(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onIsAliasUsed(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onIsAccountLinked(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onRecoverAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onUpdateAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

    /**
    * Callback to notify a response of server. <br/>
    * <br/>
    * @param creator {@link AccountCreator} object   <br/>
    * @param status The status of the {@link AccountCreator} test existence operation<br/>
    * that has just finished <br/>
    * @param response The response has a string   <br/>
    * @deprecated 11/06/2024 use {@link AccountManagerServices} instead <br/>
    */
    public void onLoginLinphoneAccount(@NonNull AccountCreator creator, AccountCreator.Status status, @Nullable String response);

}