/*
ChatRoom.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* A chat room is the place where {@link ChatMessage} are exchanged. <br/>
* <br/>
* To create (or find) a {@link ChatRoom}, you first need a {@link ChatRoomParams}<br/>
* object. A chat room is uniquely identified by it's local and remote SIP<br/>
* addresses, meaning you can only have one chat room between two accounts (unless<br/>
* the backend is {@link Backend#FlexisipChat}). Then you can call {@link Core#searchChatRoom}<br/>
* or {@link Core#createChatRoom}.<br/>
* Be careful as a {@link Backend#FlexisipChat} backend {@link ChatRoom} will be<br/>
* created asynchronously, so make sure you add a {@link ChatRoomListener} to the<br/>
* returned object to be notified when it will be in state {@link State#Created}.<br/>
* All chat rooms are loaded from database when the {@link Core} starts, and you<br/>
* can get them using {@link Core#getChatRooms}. This method doesn't return empty<br/>
* chat rooms nor ones for which the local address doesn't match an existing<br/>
* {@link Account} identity, unless you specify otherwise in the [misc] section of<br/>
* your configuration file by setting hide_empty_chat_rooms=0 and/or<br/>
* hide_chat_rooms_from_removed_proxies=0. <br/>
*/
public interface ChatRoom {
    public enum Capabilities {
        /**
        * No capabilities. <br/>
        * <br/>
        */
        None(0),

        /**
        * No server. <br/>
        * <br/>
        * It's a direct communication <br/>
        */
        Basic(1<<0),

        /**
        * Supports RTT. <br/>
        * <br/>
        */
        RealTimeText(1<<1),

        /**
        * Use server (supports group chat) <br/>
        * <br/>
        */
        Conference(1<<2),

        /**
        * Special proxy chat room flag. <br/>
        * <br/>
        */
        Proxy(1<<3),

        /**
        * Chat room migratable from Basic to Conference. <br/>
        * <br/>
        */
        Migratable(1<<4),

        /**
        * A communication between two participants (can be Basic or Conference) <br/>
        * <br/>
        */
        OneToOne(1<<5),

        /**
        * Chat room is encrypted. <br/>
        * <br/>
        */
        Encrypted(1<<6),

        /**
        * Chat room can enable ephemeral messages. <br/>
        * <br/>
        */
        Ephemeral(1<<7);

        protected final int mValue;

        private Capabilities (int value) {
            mValue = value;
        }

        static public Capabilities fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1<<0: return Basic;
            case 1<<1: return RealTimeText;
            case 1<<2: return Conference;
            case 1<<3: return Proxy;
            case 1<<4: return Migratable;
            case 1<<5: return OneToOne;
            case 1<<6: return Encrypted;
            case 1<<7: return Ephemeral;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Capabilities");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Backend {
        /**
        * Basic (client-to-client) chat room. <br/>
        * <br/>
        */
        Basic(1<<0),

        /**
        * Server-based chat room. <br/>
        * <br/>
        */
        FlexisipChat(1<<1);

        protected final int mValue;

        private Backend (int value) {
            mValue = value;
        }

        static public Backend fromInt(int value) throws RuntimeException {
            switch(value) {
            case 1<<0: return Basic;
            case 1<<1: return FlexisipChat;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Backend");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum SecurityLevel {
        /**
        * Security failure. <br/>
        * <br/>
        */
        Unsafe(0),

        /**
        * No encryption. <br/>
        * <br/>
        */
        ClearText(1),

        /**
        * Encrypted. <br/>
        * <br/>
        */
        Encrypted(2),

        /**
        * Encrypted and verified. <br/>
        * <br/>
        */
        Safe(3);

        protected final int mValue;

        private SecurityLevel (int value) {
            mValue = value;
        }

        static public SecurityLevel fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Unsafe;
            case 1: return ClearText;
            case 2: return Encrypted;
            case 3: return Safe;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for SecurityLevel");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum HistoryFilter {
        /**
        * No filter. <br/>
        * <br/>
        */
        None(0),

        /**
        * Retrieve calls. <br/>
        * <br/>
        */
        Call(1<<0),

        /**
        * Retrieve chat messages. <br/>
        * <br/>
        */
        ChatMessage(1<<1),

        /**
        * Retrieve chat messages and security events. <br/>
        * <br/>
        */
        ChatMessageSecurity(1<<2),

        /**
        * Retrieve all chat room events. <br/>
        * <br/>
        */
        Info(1<<3),

        /**
        * Retrieve all chat room events without device events. <br/>
        * <br/>
        */
        InfoNoDevice(1<<4);

        protected final int mValue;

        private HistoryFilter (int value) {
            mValue = value;
        }

        static public HistoryFilter fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1<<0: return Call;
            case 1<<1: return ChatMessage;
            case 1<<2: return ChatMessageSecurity;
            case 1<<3: return Info;
            case 1<<4: return InfoNoDevice;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for HistoryFilter");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum EphemeralMode {
        /**
        * Each device manages its own ephemeral settings. <br/>
        * <br/>
        */
        DeviceManaged(0),

        /**
        * Ephemeral settings are chatroom wide and only admins can change them. <br/>
        * <br/>
        */
        AdminManaged(1);

        protected final int mValue;

        private EphemeralMode (int value) {
            mValue = value;
        }

        static public EphemeralMode fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return DeviceManaged;
            case 1: return AdminManaged;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for EphemeralMode");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum EncryptionBackend {
        /**
        * No encryption. <br/>
        * <br/>
        */
        None(0),

        /**
        * Lime x3dh encryption. <br/>
        * <br/>
        */
        Lime(1<<0);

        protected final int mValue;

        private EncryptionBackend (int value) {
            mValue = value;
        }

        static public EncryptionBackend fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1<<0: return Lime;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for EncryptionBackend");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum State {
        /**
        * Initial state. <br/>
        * <br/>
        */
        None(0),

        /**
        * Chat room is now instantiated on local. <br/>
        * <br/>
        */
        Instantiated(1),

        /**
        * One creation request was sent to the server. <br/>
        * <br/>
        */
        CreationPending(2),

        /**
        * Chat room was created on the server. <br/>
        * <br/>
        */
        Created(3),

        /**
        * Chat room creation failed. <br/>
        * <br/>
        */
        CreationFailed(4),

        /**
        * Wait for chat room termination. <br/>
        * <br/>
        */
        TerminationPending(5),

        /**
        * Chat room exists on server but not in local. <br/>
        * <br/>
        */
        Terminated(6),

        /**
        * The chat room termination failed. <br/>
        * <br/>
        */
        TerminationFailed(7),

        /**
        * Chat room was deleted on the server. <br/>
        * <br/>
        */
        Deleted(8);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return None;
            case 1: return Instantiated;
            case 2: return CreationPending;
            case 3: return Created;
            case 4: return CreationFailed;
            case 5: return TerminationPending;
            case 6: return Terminated;
            case 7: return TerminationFailed;
            case 8: return Deleted;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Returns the local account to which this chat room is related. <br/>
    * <br/>
    * @return the related {@link Account} object if any, null otherwise.   <br/>
    */
    @Nullable
    public Account getAccount();

    /**
    * Gets the current call associated to this chatroom if any To commit a message,<br/>
    * use {@link ChatMessage#send} <br/>
    * <br/>
    * @return {@link Call} or null.   <br/>
    */
    @Nullable
    public Call getCall();

    /**
    * Gets the capabilities of a chat room. <br/>
    * <br/>
    * @return The capabilities of the chat room (as a<br/>
    * LinphoneChatRoomCapabilitiesMask) <br/>
    */
    public int getCapabilities();

    /**
    * When realtime text is enabled in a {@link Call} (see {@link CallParams#realtimeTextEnabled}<br/>
    * ), LinphoneCoreIsComposingReceivedCb is called everytime a Real-Time Text<br/>
    * character is received from peer. <br/>
    * <br/>
    * {@link #getChar} pops a character previously received from the receive queue,<br/>
    * and returns it. When a new line character is received, a {@link ChatMessage} is<br/>
    * automatically created with received characters and notified to the application<br/>
    * through the {@link CoreListener} or {@link ChatRoomListener} interfaces. <br/>
    * @return RFC 4103/T.140 char <br/>
    */
    public int getChar();

    /**
    * Gets the list of participants that are currently composing. <br/>
    * <br/>
    * @return List of addresses that are in the is_composing state.  <br/>
    */
    @NonNull
    public Address[] getComposingAddresses();

    /**
    * Gets the conference address of the chat room. <br/>
    * <br/>
    * @return The conference address of the chat room or null if this type of chat<br/>
    * room is not conference based.   <br/>
    */
    @Nullable
    public Address getConferenceAddress();

    /**
    * Sets the conference address of a group chat room. <br/>
    * <br/>
    * This function needs to be called from the<br/>
    * LinphoneChatRoomCbsConferenceAddressGenerationCb callback and only there. This<br/>
    * function is meaningful only for server implementation of chatroom, and shall<br/>
    * not by used by client applications. <br/>
    * @param conferenceAddress The conference {@link Address} to be used by the group<br/>
    * chat room   <br/>
    */
    public void setConferenceAddress(@Nullable Address conferenceAddress);

    /**
    * Gets the conference information associated to the chatroom. <br/>
    * <br/>
    * @return the {@link ConferenceInfo}.   <br/>
    */
    @Nullable
    public ConferenceInfo getConferenceInfo();

    /**
    * Returns back pointer to {@link Core} object. <br/>
    * <br/>
    * @return the {@link Core} object this chat room is attached to.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Returns the creation time for the chat room. <br/>
    * <br/>
    * @return the time at which the chat room was created <br/>
    */
    public long getCreationTime();

    /**
    * Returns current parameters associated with the chat room. <br/>
    * <br/>
    * This is typically the parameters passed during the {@link ChatRoom} creation<br/>
    * process to linphone_core_chat_room_create_chat_room() or some default<br/>
    * parameters if no {@link ChatRoomParams} was explicitely passed during {@link ChatRoom}<br/>
    * creation. <br/>
    * @return the current {@link ChatRoomParams} parameters.   <br/>
    * @deprecated 17/07/2025. Use {@link #getParams} instead. <br/>
    */
    @Deprecated
    @NonNull
    public ChatRoomParams getCurrentParams();

    /**
    * Gets all contents for which content-type starts with either text/ or<br/>
    * application/. <br/>
    * <br/>
    * @return A list of contents considered as "document".    <br/>
    */
    @NonNull
    public Content[] getDocumentContents();

    /**
    * Returns whether or not the ephemeral message feature is enabled in the chat<br/>
    * room. <br/>
    * <br/>
    * @return true if ephemeral is enabled, false otherwise. <br/>
    */
    public boolean isEphemeralEnabled();

    /**
    * Enable or disable the ephemeral message feature in the chat room. <br/>
    * <br/>
    * Works only for flexisip-based chat room. An ephemeral message will<br/>
    * automatically disappear from the sender and recipient's chatrooms after a<br/>
    * specified timeout configurable with {@link #setEphemeralLifetime}. The timer<br/>
    * starts when the message has been displayed at the recipent, which means:<br/>
    * @param enable true if the ephemeral message feature is enabled, false<br/>
    * otherwise. <br/>
    */
    public void setEphemeralEnabled(boolean enable);

    /**
    * Gets lifetime (in seconds) for all new ephemeral messages in the chat room. <br/>
    * <br/>
    * After the message is read, it will be deleted after "time" seconds. see: {@link #ephemeralEnabled}<br/>
    * @return the ephemeral lifetime (in secoonds) <br/>
    */
    public long getEphemeralLifetime();

    /**
    * Sets lifetime (in seconds) for all new ephemeral messages in the chat room. <br/>
    * <br/>
    * After the message is read, it will be deleted after "time" seconds. see: {@link #ephemeralEnabled}<br/>
    * @param time The ephemeral lifetime, default is 0 (disabled) <br/>
    * warning: A value of "time" equal to 0 disables ephemeral messages <br/>
    */
    public void setEphemeralLifetime(long time);

    /**
    * Gets the ephemeral mode of the chat room. <br/>
    * <br/>
    * see: {@link #ephemeralEnabled} <br/>
    * @return the ephemeral mode {@link EphemeralMode} <br/>
    */
    public ChatRoom.EphemeralMode getEphemeralMode();

    /**
    * Sets the ephemeral mode of the chat room. <br/>
    * <br/>
    * see: {@link #ephemeralEnabled} <br/>
    * @param mode The ephemeral mode {@link EphemeralMode} <br/>
    * warning: This function only changes the mode of ephemeral messages {@link EphemeralMode}<br/>
    * . It is required to manually enable ephemeral messages after setting the mode<br/>
    * by calling {@link #enableEphemeral} <br/>
    */
    public void setEphemeralMode(ChatRoom.EphemeralMode mode);

    /**
    * Gets the number of events in a chat room. <br/>
    * <br/>
    * @return the number of events. <br/>
    */
    public int getHistoryEventsSize();

    /**
    * Gets the number of messages in a chat room. <br/>
    * <br/>
    * @return the number of messages. <br/>
    * @deprecated 30/07/2024. Use {@link #getHistorySize} instead. <br/>
    */
    @Deprecated
    public int getHistorySize();

    /**
    * Returns the chat room identifier. <br/>
    * <br/>
    * warning: This method returns a null pointer if the ChatRoom is in the<br/>
    * Instantiated state <br/>
    * @return the conference identifier.   <br/>
    */
    @Nullable
    public String getIdentifier();

    /**
    * Returns whether or not a {@link ChatRoom} has at least one {@link ChatMessage}<br/>
    * or not. <br/>
    * <br/>
    * @return true if there are no {@link ChatMessage}, false otherwise. <br/>
    */
    public boolean isEmpty();

    /**
    * Returns whether or not a message can be sent using this chat room. <br/>
    * <br/>
    * A chat room may be read only until it's created, or when it's a group you have<br/>
    * left. <br/>
    * @return true if a chat message can't be sent in it, false otherwise. <br/>
    */
    public boolean isReadOnly();

    /**
    * Tells whether the remote is currently composing a message. <br/>
    * <br/>
    * @return true if the remote is currently composing a message, false otherwise. <br/>
    */
    public boolean isRemoteComposing();

    /**
    * Gets the last chat message sent or received in this chat room. <br/>
    * <br/>
    * @return the latest {@link ChatMessage} or null if no message.   <br/>
    */
    @Nullable
    public ChatMessage getLastMessageInHistory();

    /**
    * Returns the last updated time for the chat room. <br/>
    * <br/>
    * @return the last updated time <br/>
    */
    public long getLastUpdateTime();

    /**
    * Get the local address associated to this chat room. <br/>
    * <br/>
    * warning: This method returns a guessed address based on the me participant if<br/>
    * the ChatRoom is in the Instantiated state <br/>
    * @return The local address.   <br/>
    */
    @NonNull
    public Address getLocalAddress();

    /**
    * Gets the participant representing myself in the chat room. <br/>
    * <br/>
    * @return The participant representing myself in the conference or null if me is<br/>
    * not set.   <br/>
    */
    @Nullable
    public Participant getMe();

    /**
    * Gets all contents for which content-type starts with either video/, audio/ or<br/>
    * image/. <br/>
    * <br/>
    * @return A list of contents considered as "media".    <br/>
    */
    @NonNull
    public Content[] getMediaContents();

    /**
    * Gets if a chat room has been flagged as muted (not by default). <br/>
    * <br/>
    * A muted chat room isn't used to compute unread messages total count. <br/>
    * @return true if the chat room is muted, false otherwise. <br/>
    */
    public boolean getMuted();

    /**
    * Sets if a chat room should be considered as muted or not. <br/>
    * <br/>
    * A muted chat room isn't used to compute unread messages total count. <br/>
    * @param muted true to flag it as muted, false to un-mute it. <br/>
    */
    public void setMuted(boolean muted);

    /**
    * Gets the number of participants in the chat room (that is without ourselves). <br/>
    * <br/>
    * @return The number of participants in the chat room <br/>
    */
    public int getNbParticipants();

    /**
    * Returns current parameters associated with the chat room. <br/>
    * <br/>
    * This is typically the parameters passed during the {@link ChatRoom} creation<br/>
    * process to linphone_core_chat_room_create_chat_room() or some default<br/>
    * parameters if no {@link ChatRoomParams} was explicitely passed during {@link ChatRoom}<br/>
    * creation. <br/>
    * @return the current {@link ChatRoomParams} parameters.   <br/>
    */
    @NonNull
    public ConferenceParams getParams();

    /**
    * Gets the list of participants of a chat room. <br/>
    * <br/>
    * @return A  of the participants     <br/>
    */
    @NonNull
    public Participant[] getParticipants();

    /**
    * Get the peer address associated to this chat room. <br/>
    * <br/>
    * warning: This method returns an invalid address if the ChatRoom is in the<br/>
    * Instantiated state <br/>
    * @return The peer address.   <br/>
    */
    @NonNull
    public Address getPeerAddress();

    /**
    * Gets the security level of a chat room. <br/>
    * <br/>
    * @return The current {@link SecurityLevel} of the chat room <br/>
    */
    public ChatRoom.SecurityLevel getSecurityLevel();

    /**
    * Gets the state of the chat room. <br/>
    * <br/>
    * @return The current {@link State} of the chat room <br/>
    */
    public ChatRoom.State getState();

    /**
    * Gets the subject of a chat room. <br/>
    * <br/>
    * @return The subject of the chat room.   <br/>
    */
    @Nullable
    public String getSubject();

    /**
    * Sets the subject of a chat room. <br/>
    * <br/>
    * @param subject The new subject to set for the chat room   <br/>
    */
    public void setSubject(@Nullable String subject);

    /**
    * Gets the subject of a chat room (as an UTF8 string) <br/>
    * <br/>
    * @return The subject of the chat room.   <br/>
    */
    @Nullable
    public String getSubjectUtf8();

    /**
    * Sets the subject of a chat room (utf-8 string). <br/>
    * <br/>
    * @param subject The new subject to set for the chat room   <br/>
    */
    public void setSubjectUtf8(@Nullable String subject);

    /**
    * Gets all unread messages for this chat room, sorted from oldest to most recent. <br/>
    * <br/>
    * @return A list of unread chat messages.    <br/>
    */
    @NonNull
    public ChatMessage[] getUnreadHistory();

    /**
    * Gets the number of unread messages in the chatroom. <br/>
    * <br/>
    * @return the number of unread messages. <br/>
    */
    public int getUnreadMessagesCount();

    /**
    * Adds a participant to a chat room. <br/>
    * <br/>
    * This may fail if this type of chat room does not handle participants. Use<br/>
    * {@link #canHandleParticipants} to know if this chat room handles participants. <br/>
    * @param addr The address of the participant to add to the chat room   <br/>
    */
    public void addParticipant(@NonNull Address addr);

    /**
    * Adds several participants to a chat room at once. <br/>
    * <br/>
    * This may fail if this type of chat room does not handle participants. Use<br/>
    * {@link #canHandleParticipants} to know if this chat room handles participants. <br/>
    * @param addresses The participants to add.    <br/>
    * @return true if everything is OK, false otherwise <br/>
    */
    public boolean addParticipants(@NonNull Address[] addresses);

    /**
    * Allow cpim on a basic chat room   . <br/>
    * <br/>
    */
    public void allowCpim();

    /**
    * Allow multipart on a basic chat room   . <br/>
    * <br/>
    */
    public void allowMultipart();

    /**
    * Tells whether a chat room is able to handle participants. <br/>
    * <br/>
    * @return true if the chat room can handle participants, false otherwise <br/>
    */
    public boolean canHandleParticipants();

    /**
    * Notifies the destination of the chat message being composed that the user is<br/>
    * typing a new message. <br/>
    * <br/>
    */
    public void compose();

    /**
    * Creates an empty message attached to the given chat room. <br/>
    * <br/>
    * @return a new {@link ChatMessage}   <br/>
    */
    @NonNull
    public ChatMessage createEmptyMessage();

    /**
    * Creates a message attached to the given chat room with a particular content. <br/>
    * <br/>
    * Use {@link ChatMessage#send} to initiate the transfer <br/>
    * @param initialContent {@link Content} initial content.   <br/>
    * @return a new {@link ChatMessage}   <br/>
    */
    @NonNull
    public ChatMessage createFileTransferMessage(@NonNull Content initialContent);

    /**
    * Creates a forward message attached to the given chat room with a particular<br/>
    * message. <br/>
    * <br/>
    * @param message {@link ChatMessage} message to be forwarded.   <br/>
    * @return a new {@link ChatMessage}   <br/>
    */
    @NonNull
    public ChatMessage createForwardMessage(@NonNull ChatMessage message);

    /**
    * Creates a message attached to the given chat room with a plain text content<br/>
    * filled with the given message. <br/>
    * <br/>
    * @param message text message, null if absent.   <br/>
    * @return a new {@link ChatMessage}   <br/>
    * @deprecated 01/07/2020. Use {@link #createMessageFromUtf8} instead. <br/>
    */
    @Deprecated
    @NonNull
    public ChatMessage createMessage(@Nullable String message);

    /**
    * Creates a message attached to the given chat room with a plain text content<br/>
    * filled with the given message. <br/>
    * <br/>
    * Introduced in 01/07/2020 <br/>
    * @param message text message in UTF8, null if absent.   <br/>
    * @return a new {@link ChatMessage}   <br/>
    */
    @NonNull
    public ChatMessage createMessageFromUtf8(@Nullable String message);

    /**
    * Creates a reply message attached to the given chat room with a particular<br/>
    * message. <br/>
    * <br/>
    * @param message {@link ChatMessage} message to reply to.   <br/>
    * @return a new {@link ChatMessage}   <br/>
    */
    @NonNull
    public ChatMessage createReplyMessage(@NonNull ChatMessage message);

    /**
    * Creates a chat message with a voice recording attached to the given chat room. <br/>
    * <br/>
    * warning: If the recorder isn't in Closed state, it will return an empty<br/>
    * message! <br/>
    * @param recorder the {@link Recorder} object used to record the voice message.   <br/>
    * @return a new {@link ChatMessage}   <br/>
    */
    @NonNull
    public ChatMessage createVoiceRecordingMessage(@NonNull Recorder recorder);

    /**
    * Delete all messages from the history. <br/>
    * <br/>
    */
    public void deleteHistory();

    /**
    * Delete a message from the chat room history. <br/>
    * <br/>
    * @param message The {@link ChatMessage} object to remove.   <br/>
    */
    public void deleteMessage(@NonNull ChatMessage message);

    /**
    * Check if all participants support ephemeral messages. <br/>
    * <br/>
    * It doesn't prevent to send ephemeral messages in the room but those who don't<br/>
    * support it won't delete messages after lifetime has expired. The check is done<br/>
    * by verifying the participant's advertised capabilities (+org.linphone.specs<br/>
    * parameter). see: {@link #ephemeralEnabled} <br/>
    * @return true if all participants in the chat room support ephemeral messages,<br/>
    * false otherwise <br/>
    */
    public boolean ephemeralSupportedByAllParticipants();

    /**
    * Gets the event log sent or received in this chat room that matches a chat<br/>
    * message with the given message_id. <br/>
    * <br/>
    * @param messageId The id of the message to find   <br/>
    * @return the {@link EventLog} if found or null.   <br/>
    */
    @Nullable
    public EventLog findEventLog(@NonNull String messageId);

    /**
    * Gets the chat message sent or received in this chat room that matches the<br/>
    * message_id. <br/>
    * <br/>
    * @param messageId The id of the message to find   <br/>
    * @return the {@link ChatMessage} if found or null.   <br/>
    */
    @Nullable
    public ChatMessage findMessage(@NonNull String messageId);

    /**
    * Finds a participant of a chat room from its address. <br/>
    * <br/>
    * @param address The {@link Address} to search in the list of participants of the<br/>
    * chat room   <br/>
    * @return The participant if found, null otherwise.   <br/>
    */
    @Nullable
    public Participant findParticipant(@NonNull Address address);

    /**
    * Gets nb_message most recent events from chat_room chat room, sorted from oldest<br/>
    * to most recent. <br/>
    * <br/>
    * @param nbMessage Number of events to retrieve. 0 means everything. <br/>
    * @param filters The LinphoneChatRoomHistoryFilterMask mask to filter the results<br/>
    * with {@link HistoryFilter} <br/>
    * @return A list of    <br/>
    */
    @NonNull
    public EventLog[] getHistory(int nbMessage, int filters);

    /**
    * Gets nb_message most recent messages from chat_room chat room, sorted from<br/>
    * oldest to most recent. <br/>
    * <br/>
    * @param nbMessage Number of message to retrieve. 0 means everything. <br/>
    * @return A list of    <br/>
    * @deprecated 30/07/2024. Use {@link #getHistory} instead. <br/>
    */
    @Deprecated
    @NonNull
    public ChatMessage[] getHistory(int nbMessage);

    /**
    * Gets nb_events most recent events from chat_room chat room, sorted from oldest<br/>
    * to most recent. <br/>
    * <br/>
    * @param nbEvents Number of events to retrieve. 0 means everything. <br/>
    * @return The list of the most recent events.    <br/>
    */
    @NonNull
    public EventLog[] getHistoryEvents(int nbEvents);

    /**
    * Gets nb_events most recent chat message events from chat_room chat room, sorted<br/>
    * from oldest to most recent. <br/>
    * <br/>
    * @param nbEvents Number of events to retrieve. 0 means everything. <br/>
    * @return A list    <br/>
    */
    @NonNull
    public EventLog[] getHistoryMessageEvents(int nbEvents);

    /**
    * Gets the partial list of events in the given range, sorted from oldest to most<br/>
    * recent. <br/>
    * <br/>
    * @param begin The first event of the range to be retrieved. History most recent<br/>
    * message has index 0. <br/>
    * @param end The last event of the range to be retrieved. History oldest message<br/>
    * has index of history size - 1 (use {@link #getHistorySize} to retrieve history<br/>
    * size) <br/>
    * @return A list of    <br/>
    */
    @NonNull
    public EventLog[] getHistoryRange(int begin, int end, int filters);

    /**
    * Gets the partial list of messages in the given range, sorted from oldest to<br/>
    * most recent. <br/>
    * <br/>
    * @param begin The first message of the range to be retrieved. History most<br/>
    * recent message has index 0. <br/>
    * @param end The last message of the range to be retrieved. History oldest<br/>
    * message has index of history size - 1 (use {@link #getHistorySize} to retrieve<br/>
    * history size) <br/>
    * @return A list of chat messages.    <br/>
    * @deprecated 30/07/2024. Use {@link #getHistoryRange} instead. <br/>
    */
    @Deprecated
    @NonNull
    public ChatMessage[] getHistoryRange(int begin, int end);

    /**
    * Gets the partial list of messages between two given {@link EventLog}, sorted<br/>
    * from oldest to most recent. <br/>
    * <br/>
    * If either first_event or last_event is null, then nothing is returned. <br/>
    * @param firstEvent The {@link EventLog} object corresponding to the event.   <br/>
    * @param lastEvent The {@link EventLog} object corresponding to the event.   <br/>
    * @param filters The LinphoneChatRoomHistoryFilterMask mask to filter the results<br/>
    * with {@link HistoryFilter} <br/>
    * @return A list of  between the two provided events, if any.   <br/>
    */
    @NonNull
    public EventLog[] getHistoryRangeBetween(@Nullable EventLog firstEvent, @Nullable EventLog lastEvent, int filters);

    /**
    * Gets the partial list of events in the given range, sorted from oldest to most<br/>
    * recent. <br/>
    * <br/>
    * @param begin The first event of the range to be retrieved. History most recent<br/>
    * event has index 0. <br/>
    * @param end The last event of the range to be retrieved. History oldest event<br/>
    * has index of history size - 1 <br/>
    * @return The list of the found events.    <br/>
    */
    @NonNull
    public EventLog[] getHistoryRangeEvents(int begin, int end);

    /**
    * Gets the partial list of chat message events in the given range, sorted from<br/>
    * oldest to most recent. <br/>
    * <br/>
    * @param begin The first event of the range to be retrieved. History most recent<br/>
    * event has index 0. <br/>
    * @param end The last event of the range to be retrieved. History oldest event<br/>
    * has index of history size - 1 <br/>
    * @return The list of chat message events.    <br/>
    */
    @NonNull
    public EventLog[] getHistoryRangeMessageEvents(int begin, int end);

    /**
    * Gets the partial list of messages in the given range near the {@link EventLog}<br/>
    * provided, sorted from oldest to most recent. <br/>
    * <br/>
    * If before and after are both set to 0, the returned list is empty. <br/>
    * @param before The number of messages to retrieve before the event provided. <br/>
    * @param after The number of messages to retrieve after the event provided. <br/>
    * @param event The {@link EventLog} object corresponding to the event.   <br/>
    * @param filters The LinphoneChatRoomHistoryFilterMask mask to filter the results<br/>
    * with {@link HistoryFilter} <br/>
    * @return A list of  near the event provided included.   <br/>
    */
    @NonNull
    public EventLog[] getHistoryRangeNear(int before, int after, @Nullable EventLog event, int filters);

    /**
    * Gets the number of messages in a chat room. <br/>
    * <br/>
    * @param filters The LinphoneChatRoomHistoryFilterMask mask to filter the result<br/>
    * with {@link HistoryFilter}    <br/>
    * @return the number of messages. <br/>
    */
    public int getHistorySize(@NonNull int filters);

    /**
    * Returns whether or not the chat room has been left. <br/>
    * <br/>
    * @return true if the chat room has been left, false otherwise. <br/>
    * @deprecated 16/03/2022 use {@link #isReadOnly} instead. <br/>
    */
    @Deprecated
    public boolean hasBeenLeft();

    /**
    * Checks if a chat room has given capabilities. <br/>
    * <br/>
    * @param mask a LinphoneChatRoomCapabilitiesMask mask <br/>
    * @return true if the mask matches, false otherwise <br/>
    */
    public boolean hasCapability(int mask);

    /**
    * Leaves a chat room. <br/>
    * <br/>
    */
    public void leave();

    /**
    * Mark all messages of the conversation as read. <br/>
    * <br/>
    */
    public void markAsRead();

    /**
    * Notifies the chatroom that a participant device has just registered. <br/>
    * <br/>
    * This function is meaningful only for server implementation of chatroom, and<br/>
    * shall not by used by client applications. <br/>
    * @param participantDevice list of the participant devices to be used by the<br/>
    * group chat room   <br/>
    */
    public void notifyParticipantDeviceRegistration(@NonNull Address participantDevice);

    /**
    * Used to receive a chat message when using async mechanism with IM<br/>
    * enchat_roomyption engine. <br/>
    * <br/>
    * @param message {@link ChatMessage} object   <br/>
    */
    public void receiveChatMessage(@NonNull ChatMessage message);

    /**
    * Removes a participant of a chat room. <br/>
    * <br/>
    * @param participant The participant to remove from the chat room   <br/>
    */
    public void removeParticipant(@NonNull Participant participant);

    /**
    * Removes several participants of a chat room at once. <br/>
    * <br/>
    * @param participants The participants to remove.    <br/>
    */
    public void removeParticipants(@NonNull Participant[] participants);

    /**
    * Searches chat messages by text. <br/>
    * <br/>
    * @param text The text to search in messages   <br/>
    * @param from The {@link EventLog} object corresponding to the event where to<br/>
    * start the search   <br/>
    * @param direction The {@link SearchDirection} where to search,<br/>
    * LinphoneSearchDirectionUp will search older messages while<br/>
    * LinphoneSearchDirectionDown will search newer messages <br/>
    * @return the {@link EventLog} corresponding to the message if found or null.   <br/>
    */
    @Nullable
    public EventLog searchChatMessageByText(@NonNull String text, @Nullable EventLog from, SearchDirection direction);

    /**
    * Changes the admin status of a participant of a chat room (you need to be an<br/>
    * admin yourself to do this). <br/>
    * <br/>
    * @param participant The Participant for which to change the admin status   <br/>
    * @param isAdmin A boolean value telling whether the participant should now be an<br/>
    * admin or not <br/>
    */
    public void setParticipantAdminStatus(@NonNull Participant participant, boolean isAdmin);

    /**
    * Sets the list of participant devices in the form of SIP URIs with GRUUs for a<br/>
    * given participant. <br/>
    * <br/>
    * This function is meaningful only for server implementation of chatroom, and<br/>
    * shall not by used by client applications. <br/>
    * @param participantAddress The participant address   <br/>
    * @param deviceIdentities List of the participant devices to be used by the group<br/>
    * chat room     <br/>
    */
    public void setParticipantDevices(@NonNull Address participantAddress, @NonNull ParticipantDeviceIdentity[] deviceIdentities);

    /**
    * Converts a {@link State} enum to a string. <br/>
    * <br/>
    * @param state a {@link State} to convert to string <br/>
    * @return the string representation of the {@link State}   <br/>
    */
    @NonNull
    public String stateToString(ChatRoom.State state);

    /**
    */
    public void addListener(ChatRoomListener listener);

    /**
    */
    public void removeListener(ChatRoomListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ChatRoomImpl implements ChatRoom {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected ChatRoomImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Account getAccount(long nativePtr);
    @Override @Nullable
    synchronized public Account getAccount()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getAccount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Account)getAccount(nativePtr);
        }
    }

    private native Call getCall(long nativePtr);
    @Override @Nullable
    synchronized public Call getCall()  {
        synchronized(core) { 
        
        return (Call)getCall(nativePtr);
        }
    }

    private native int getCapabilities(long nativePtr);
    @Override
    synchronized public int getCapabilities()  {
        synchronized(core) { 
        
        return getCapabilities(nativePtr);
        }
    }

    private native int getChar(long nativePtr);
    @Override
    synchronized public int getChar()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getChar() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getChar(nativePtr);
        }
    }

    private native Address[] getComposingAddresses(long nativePtr);
    @Override @NonNull
    synchronized public Address[] getComposingAddresses()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getComposingAddresses() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getComposingAddresses(nativePtr);
        }
    }

    private native Address getConferenceAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getConferenceAddress()  {
        synchronized(core) { 
        
        return (Address)getConferenceAddress(nativePtr);
        }
    }

    private native void setConferenceAddress(long nativePtr, Address conferenceAddress);
    @Override
    synchronized public void setConferenceAddress(@Nullable Address conferenceAddress)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setConferenceAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setConferenceAddress(nativePtr, conferenceAddress);
        }
    }

    private native ConferenceInfo getConferenceInfo(long nativePtr);
    @Override @Nullable
    synchronized public ConferenceInfo getConferenceInfo()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getConferenceInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ConferenceInfo)getConferenceInfo(nativePtr);
        }
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native long getCreationTime(long nativePtr);
    @Override
    synchronized public long getCreationTime()  {
        synchronized(core) { 
        
        return getCreationTime(nativePtr);
        }
    }

    private native ChatRoomParams getCurrentParams(long nativePtr);
    @Override @NonNull
    synchronized public ChatRoomParams getCurrentParams()  {
        synchronized(core) { 
        
        return (ChatRoomParams)getCurrentParams(nativePtr);
        }
    }

    private native Content[] getDocumentContents(long nativePtr);
    @Override @NonNull
    synchronized public Content[] getDocumentContents()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDocumentContents() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDocumentContents(nativePtr);
        }
    }

    private native boolean isEphemeralEnabled(long nativePtr);
    @Override
    synchronized public boolean isEphemeralEnabled()  {
        synchronized(core) { 
        
        return isEphemeralEnabled(nativePtr);
        }
    }

    private native void setEphemeralEnabled(long nativePtr, boolean enable);
    @Override
    synchronized public void setEphemeralEnabled(boolean enable)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEphemeralEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEphemeralEnabled(nativePtr, enable);
        }
    }

    private native long getEphemeralLifetime(long nativePtr);
    @Override
    synchronized public long getEphemeralLifetime()  {
        synchronized(core) { 
        
        return getEphemeralLifetime(nativePtr);
        }
    }

    private native void setEphemeralLifetime(long nativePtr, long time);
    @Override
    synchronized public void setEphemeralLifetime(long time)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEphemeralLifetime() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEphemeralLifetime(nativePtr, time);
        }
    }

    private native int getEphemeralMode(long nativePtr);
    @Override
    synchronized public ChatRoom.EphemeralMode getEphemeralMode()  {
        synchronized(core) { 
        
        return ChatRoom.EphemeralMode.fromInt(getEphemeralMode(nativePtr));
        }
    }

    private native void setEphemeralMode(long nativePtr, int mode);
    @Override
    synchronized public void setEphemeralMode(ChatRoom.EphemeralMode mode)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setEphemeralMode() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setEphemeralMode(nativePtr, mode.toInt());
        }
    }

    private native int getHistoryEventsSize(long nativePtr);
    @Override
    synchronized public int getHistoryEventsSize()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryEventsSize() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryEventsSize(nativePtr);
        }
    }

    private native int getHistorySize(long nativePtr);
    @Override
    synchronized public int getHistorySize()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistorySize() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistorySize(nativePtr);
        }
    }

    private native String getIdentifier(long nativePtr);
    @Override @Nullable
    synchronized public String getIdentifier()  {
        synchronized(core) { 
        
        return getIdentifier(nativePtr);
        }
    }

    private native boolean isEmpty(long nativePtr);
    @Override
    synchronized public boolean isEmpty()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isEmpty() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isEmpty(nativePtr);
        }
    }

    private native boolean isReadOnly(long nativePtr);
    @Override
    synchronized public boolean isReadOnly()  {
        synchronized(core) { 
        
        return isReadOnly(nativePtr);
        }
    }

    private native boolean isRemoteComposing(long nativePtr);
    @Override
    synchronized public boolean isRemoteComposing()  {
        synchronized(core) { 
        
        return isRemoteComposing(nativePtr);
        }
    }

    private native ChatMessage getLastMessageInHistory(long nativePtr);
    @Override @Nullable
    synchronized public ChatMessage getLastMessageInHistory()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLastMessageInHistory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)getLastMessageInHistory(nativePtr);
        }
    }

    private native long getLastUpdateTime(long nativePtr);
    @Override
    synchronized public long getLastUpdateTime()  {
        synchronized(core) { 
        
        return getLastUpdateTime(nativePtr);
        }
    }

    private native Address getLocalAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getLocalAddress()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getLocalAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)getLocalAddress(nativePtr);
        }
    }

    private native Participant getMe(long nativePtr);
    @Override @Nullable
    synchronized public Participant getMe()  {
        synchronized(core) { 
        
        return (Participant)getMe(nativePtr);
        }
    }

    private native Content[] getMediaContents(long nativePtr);
    @Override @NonNull
    synchronized public Content[] getMediaContents()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getMediaContents() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getMediaContents(nativePtr);
        }
    }

    private native boolean getMuted(long nativePtr);
    @Override
    synchronized public boolean getMuted()  {
        synchronized(core) { 
        
        return getMuted(nativePtr);
        }
    }

    private native void setMuted(long nativePtr, boolean muted);
    @Override
    synchronized public void setMuted(boolean muted)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setMuted() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setMuted(nativePtr, muted);
        }
    }

    private native int getNbParticipants(long nativePtr);
    @Override
    synchronized public int getNbParticipants()  {
        synchronized(core) { 
        
        return getNbParticipants(nativePtr);
        }
    }

    private native ConferenceParams getParams(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceParams getParams()  {
        synchronized(core) { 
        
        return (ConferenceParams)getParams(nativePtr);
        }
    }

    private native Participant[] getParticipants(long nativePtr);
    @Override @NonNull
    synchronized public Participant[] getParticipants()  {
        synchronized(core) { 
        
        return getParticipants(nativePtr);
        }
    }

    private native Address getPeerAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getPeerAddress()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getPeerAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)getPeerAddress(nativePtr);
        }
    }

    private native int getSecurityLevel(long nativePtr);
    @Override
    synchronized public ChatRoom.SecurityLevel getSecurityLevel()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSecurityLevel() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return ChatRoom.SecurityLevel.fromInt(getSecurityLevel(nativePtr));
        }
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public ChatRoom.State getState()  {
        synchronized(core) { 
        
        return ChatRoom.State.fromInt(getState(nativePtr));
        }
    }

    private native String getSubject(long nativePtr);
    @Override @Nullable
    synchronized public String getSubject()  {
        synchronized(core) { 
        
        return getSubject(nativePtr);
        }
    }

    private native void setSubject(long nativePtr, String subject);
    @Override
    synchronized public void setSubject(@Nullable String subject)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubject() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubject(nativePtr, subject);
        }
    }

    private native String getSubjectUtf88(long nativePtr);
    @Override @Nullable
    synchronized public String getSubjectUtf8()  {
        synchronized(core) { 
        
        return getSubjectUtf88(nativePtr);
        }
    }

    private native void setSubjectUtf88(long nativePtr, String subject);
    @Override
    synchronized public void setSubjectUtf8(@Nullable String subject)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setSubjectUtf8() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setSubjectUtf88(nativePtr, subject);
        }
    }

    private native ChatMessage[] getUnreadHistory(long nativePtr);
    @Override @NonNull
    synchronized public ChatMessage[] getUnreadHistory()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUnreadHistory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUnreadHistory(nativePtr);
        }
    }

    private native int getUnreadMessagesCount(long nativePtr);
    @Override
    synchronized public int getUnreadMessagesCount()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getUnreadMessagesCount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getUnreadMessagesCount(nativePtr);
        }
    }

    private native void addParticipant(long nativePtr, Address addr);
    @Override
    synchronized public void addParticipant(@NonNull Address addr)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addParticipant(nativePtr, addr);
        }
    }

    private native boolean addParticipants(long nativePtr, Address[] addresses);
    @Override
    synchronized public boolean addParticipants(@NonNull Address[] addresses)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addParticipants() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return addParticipants(nativePtr, addresses);
        }
    }

    private native void allowCpim(long nativePtr);
    @Override
    synchronized public void allowCpim()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call allowCpim() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        allowCpim(nativePtr);
        }
    }

    private native void allowMultipart(long nativePtr);
    @Override
    synchronized public void allowMultipart()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call allowMultipart() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        allowMultipart(nativePtr);
        }
    }

    private native boolean canHandleParticipants(long nativePtr);
    @Override
    synchronized public boolean canHandleParticipants()  {
        synchronized(core) { 
        
        return canHandleParticipants(nativePtr);
        }
    }

    private native void compose(long nativePtr);
    @Override
    synchronized public void compose()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call compose() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        compose(nativePtr);
        }
    }

    private native ChatMessage createEmptyMessage(long nativePtr);
    @Override @NonNull
    synchronized public ChatMessage createEmptyMessage()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createEmptyMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)createEmptyMessage(nativePtr);
        }
    }

    private native ChatMessage createFileTransferMessage(long nativePtr, Content initialContent);
    @Override @NonNull
    synchronized public ChatMessage createFileTransferMessage(@NonNull Content initialContent)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createFileTransferMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)createFileTransferMessage(nativePtr, initialContent);
        }
    }

    private native ChatMessage createForwardMessage(long nativePtr, ChatMessage message);
    @Override @NonNull
    synchronized public ChatMessage createForwardMessage(@NonNull ChatMessage message)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createForwardMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)createForwardMessage(nativePtr, message);
        }
    }

    private native ChatMessage createMessage(long nativePtr, String message);
    @Override @NonNull
    synchronized public ChatMessage createMessage(@Nullable String message)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)createMessage(nativePtr, message);
        }
    }

    private native ChatMessage createMessageFromUtf88(long nativePtr, String message);
    @Override @NonNull
    synchronized public ChatMessage createMessageFromUtf8(@Nullable String message)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createMessageFromUtf8() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)createMessageFromUtf88(nativePtr, message);
        }
    }

    private native ChatMessage createReplyMessage(long nativePtr, ChatMessage message);
    @Override @NonNull
    synchronized public ChatMessage createReplyMessage(@NonNull ChatMessage message)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createReplyMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)createReplyMessage(nativePtr, message);
        }
    }

    private native ChatMessage createVoiceRecordingMessage(long nativePtr, Recorder recorder);
    @Override @NonNull
    synchronized public ChatMessage createVoiceRecordingMessage(@NonNull Recorder recorder)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createVoiceRecordingMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)createVoiceRecordingMessage(nativePtr, recorder);
        }
    }

    private native void deleteHistory(long nativePtr);
    @Override
    synchronized public void deleteHistory()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call deleteHistory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        deleteHistory(nativePtr);
        }
    }

    private native void deleteMessage(long nativePtr, ChatMessage message);
    @Override
    synchronized public void deleteMessage(@NonNull ChatMessage message)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call deleteMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        deleteMessage(nativePtr, message);
        }
    }

    private native boolean ephemeralSupportedByAllParticipants(long nativePtr);
    @Override
    synchronized public boolean ephemeralSupportedByAllParticipants()  {
        synchronized(core) { 
        
        return ephemeralSupportedByAllParticipants(nativePtr);
        }
    }

    private native EventLog findEventLog(long nativePtr, String messageId);
    @Override @Nullable
    synchronized public EventLog findEventLog(@NonNull String messageId)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findEventLog() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (EventLog)findEventLog(nativePtr, messageId);
        }
    }

    private native ChatMessage findMessage(long nativePtr, String messageId);
    @Override @Nullable
    synchronized public ChatMessage findMessage(@NonNull String messageId)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)findMessage(nativePtr, messageId);
        }
    }

    private native Participant findParticipant(long nativePtr, Address address);
    @Override @Nullable
    synchronized public Participant findParticipant(@NonNull Address address)  {
        synchronized(core) { 
        
        return (Participant)findParticipant(nativePtr, address);
        }
    }

    private native EventLog[] getHistory2(long nativePtr, int nbMessage, int filters);
    @Override @NonNull
    synchronized public EventLog[] getHistory(int nbMessage, int filters)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistory2(nativePtr, nbMessage, filters);
        }
    }

    private native ChatMessage[] getHistory(long nativePtr, int nbMessage);
    @Override @NonNull
    synchronized public ChatMessage[] getHistory(int nbMessage)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistory() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistory(nativePtr, nbMessage);
        }
    }

    private native EventLog[] getHistoryEvents(long nativePtr, int nbEvents);
    @Override @NonNull
    synchronized public EventLog[] getHistoryEvents(int nbEvents)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryEvents() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryEvents(nativePtr, nbEvents);
        }
    }

    private native EventLog[] getHistoryMessageEvents(long nativePtr, int nbEvents);
    @Override @NonNull
    synchronized public EventLog[] getHistoryMessageEvents(int nbEvents)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryMessageEvents() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryMessageEvents(nativePtr, nbEvents);
        }
    }

    private native EventLog[] getHistoryRange2(long nativePtr, int begin, int end, int filters);
    @Override @NonNull
    synchronized public EventLog[] getHistoryRange(int begin, int end, int filters)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryRange() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryRange2(nativePtr, begin, end, filters);
        }
    }

    private native ChatMessage[] getHistoryRange(long nativePtr, int begin, int end);
    @Override @NonNull
    synchronized public ChatMessage[] getHistoryRange(int begin, int end)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryRange() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryRange(nativePtr, begin, end);
        }
    }

    private native EventLog[] getHistoryRangeBetween(long nativePtr, EventLog firstEvent, EventLog lastEvent, int filters);
    @Override @NonNull
    synchronized public EventLog[] getHistoryRangeBetween(@Nullable EventLog firstEvent, @Nullable EventLog lastEvent, int filters)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryRangeBetween() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryRangeBetween(nativePtr, firstEvent, lastEvent, filters);
        }
    }

    private native EventLog[] getHistoryRangeEvents(long nativePtr, int begin, int end);
    @Override @NonNull
    synchronized public EventLog[] getHistoryRangeEvents(int begin, int end)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryRangeEvents() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryRangeEvents(nativePtr, begin, end);
        }
    }

    private native EventLog[] getHistoryRangeMessageEvents(long nativePtr, int begin, int end);
    @Override @NonNull
    synchronized public EventLog[] getHistoryRangeMessageEvents(int begin, int end)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryRangeMessageEvents() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryRangeMessageEvents(nativePtr, begin, end);
        }
    }

    private native EventLog[] getHistoryRangeNear(long nativePtr, int before, int after, EventLog event, int filters);
    @Override @NonNull
    synchronized public EventLog[] getHistoryRangeNear(int before, int after, @Nullable EventLog event, int filters)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistoryRangeNear() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistoryRangeNear(nativePtr, before, after, event, filters);
        }
    }

    private native int getHistorySize2(long nativePtr, int filters);
    @Override
    synchronized public int getHistorySize(@NonNull int filters)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getHistorySize() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getHistorySize2(nativePtr, filters);
        }
    }

    private native boolean hasBeenLeft(long nativePtr);
    @Override
    synchronized public boolean hasBeenLeft()  {
        synchronized(core) { 
        
        return hasBeenLeft(nativePtr);
        }
    }

    private native boolean hasCapability(long nativePtr, int mask);
    @Override
    synchronized public boolean hasCapability(int mask)  {
        synchronized(core) { 
        
        return hasCapability(nativePtr, mask);
        }
    }

    private native void leave(long nativePtr);
    @Override
    synchronized public void leave()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call leave() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        leave(nativePtr);
        }
    }

    private native void markAsRead(long nativePtr);
    @Override
    synchronized public void markAsRead()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call markAsRead() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        markAsRead(nativePtr);
        }
    }

    private native void notifyParticipantDeviceRegistration(long nativePtr, Address participantDevice);
    @Override
    synchronized public void notifyParticipantDeviceRegistration(@NonNull Address participantDevice)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call notifyParticipantDeviceRegistration() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        notifyParticipantDeviceRegistration(nativePtr, participantDevice);
        }
    }

    private native void receiveChatMessage(long nativePtr, ChatMessage message);
    @Override
    synchronized public void receiveChatMessage(@NonNull ChatMessage message)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call receiveChatMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        receiveChatMessage(nativePtr, message);
        }
    }

    private native void removeParticipant(long nativePtr, Participant participant);
    @Override
    synchronized public void removeParticipant(@NonNull Participant participant)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeParticipant() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeParticipant(nativePtr, participant);
        }
    }

    private native void removeParticipants(long nativePtr, Participant[] participants);
    @Override
    synchronized public void removeParticipants(@NonNull Participant[] participants)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeParticipants() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeParticipants(nativePtr, participants);
        }
    }

    private native EventLog searchChatMessageByText(long nativePtr, String text, EventLog from, int direction);
    @Override @Nullable
    synchronized public EventLog searchChatMessageByText(@NonNull String text, @Nullable EventLog from, SearchDirection direction)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call searchChatMessageByText() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (EventLog)searchChatMessageByText(nativePtr, text, from, direction.toInt());
        }
    }

    private native void setParticipantAdminStatus(long nativePtr, Participant participant, boolean isAdmin);
    @Override
    synchronized public void setParticipantAdminStatus(@NonNull Participant participant, boolean isAdmin)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParticipantAdminStatus() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParticipantAdminStatus(nativePtr, participant, isAdmin);
        }
    }

    private native void setParticipantDevices(long nativePtr, Address participantAddress, ParticipantDeviceIdentity[] deviceIdentities);
    @Override
    synchronized public void setParticipantDevices(@NonNull Address participantAddress, @NonNull ParticipantDeviceIdentity[] deviceIdentities)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParticipantDevices() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParticipantDevices(nativePtr, participantAddress, deviceIdentities);
        }
    }

    private native String stateToString(long nativePtr, int state);
    @Override @NonNull
    synchronized public String stateToString(ChatRoom.State state)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call stateToString() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return stateToString(nativePtr, state.toInt());
        }
    }

    private native void addListener(long nativePtr, ChatRoomListener listener);
    @Override
    synchronized public void addListener(ChatRoomListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, ChatRoomListener listener);
    @Override
    synchronized public void removeListener(ChatRoomListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
