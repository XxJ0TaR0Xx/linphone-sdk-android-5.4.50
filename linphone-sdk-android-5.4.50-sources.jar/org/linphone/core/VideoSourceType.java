/*
VideoSourceType.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum representing the type of a video source. <br/>
* <br/>
*/
public enum VideoSourceType {
    /**
    * <br/>
    */
    Unknown(0),

    /**
    * The video source is another call. <br/>
    * <br/>
    */
    Call(1),

    /**
    * The video source is a camera. <br/>
    * <br/>
    */
    Camera(2),

    /**
    * The video source is an image. <br/>
    * <br/>
    */
    Image(3),

    /**
    * The video source is a screen sharing. <br/>
    * <br/>
    */
    ScreenSharing(4);

    protected final int mValue;

    private VideoSourceType (int value) {
        mValue = value;
    }

    static public VideoSourceType fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Unknown;
        case 1: return Call;
        case 2: return Camera;
        case 3: return Image;
        case 4: return ScreenSharing;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for VideoSourceType");
        }
    }
    
    static protected VideoSourceType[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        VideoSourceType[] enumArray = new VideoSourceType[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = VideoSourceType.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(VideoSourceType[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
