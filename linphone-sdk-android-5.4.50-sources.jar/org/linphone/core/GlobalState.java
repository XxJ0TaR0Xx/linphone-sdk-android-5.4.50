/*
GlobalState.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Describes the global state of the {@link Core} object. <br/>
* <br/>
* It is notified via the global_state_changed() callback in {@link CoreListener}. <br/>
*/
public enum GlobalState {
    /**
    * State in which we're in after {@link Core#stop}. <br/>
    * <br/>
    * Do not call any method while in this state except for {@link Core#start} <br/>
    */
    Off(0),

    /**
    * Transient state for when we call {@link Core#start} <br/>
    * <br/>
    */
    Startup(1),

    /**
    * Indicates {@link Core} has been started and is up and running. <br/>
    * <br/>
    */
    On(2),

    /**
    * Transient state for when we call {@link Core#stop} <br/>
    * <br/>
    */
    Shutdown(3),

    /**
    * Transient state between Startup and On if there is a remote provisionning URI<br/>
    * configured. <br/>
    * <br/>
    */
    Configuring(4),

    /**
    * {@link Core} state after being created by linphone_factory_create_core,<br/>
    * generally followed by a call to {@link Core#start} <br/>
    * <br/>
    */
    Ready(5);

    protected final int mValue;

    private GlobalState (int value) {
        mValue = value;
    }

    static public GlobalState fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Off;
        case 1: return Startup;
        case 2: return On;
        case 3: return Shutdown;
        case 4: return Configuring;
        case 5: return Ready;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for GlobalState");
        }
    }
    
    static protected GlobalState[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        GlobalState[] enumArray = new GlobalState[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = GlobalState.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(GlobalState[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
