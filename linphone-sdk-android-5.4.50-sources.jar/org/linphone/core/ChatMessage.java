/*
ChatMessage.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* A {@link ChatMessage} represents an instant message that can be send or<br/>
* received through a {@link ChatRoom}. <br/>
* <br/>
* To create a {@link ChatMessage}, use {@link ChatRoom#createEmptyMessage}, then<br/>
* either add text using {@link #addUtf8TextContent} or a {@link Content} with<br/>
* file informations using {@link #addFileContent}. A valid {@link Content} for<br/>
* file transfer must contain a type and subtype, the name of the file and it's<br/>
* size. Finally call {@link #send} to send it.<br/>
* To send files through a {@link ChatMessage}, you need to have configured a file<br/>
* transfer server URL with {@link Core#setFileTransferServer}. On the receiving<br/>
* side, either use {@link #downloadContent} to download received files or enable<br/>
* auto-download in the {@link Core} using {@link Core#setMaxSizeForAutoDownloadIncomingFiles}<br/>
* , -1 disabling the feature and 0 always downloading files no matter it's size.<br/>
* Keep in mind a {@link ChatMessage} created by a {@link ChatRoom#Backend#Basic}<br/>
* {@link ChatRoom} can only contain one {@link Content}, either text or file. <br/>
*/
public interface ChatMessage {
    public enum Direction {
        /**
        * Incoming message. <br/>
        * <br/>
        */
        Incoming(0),

        /**
        * Outgoing message. <br/>
        * <br/>
        */
        Outgoing(1);

        protected final int mValue;

        private Direction (int value) {
            mValue = value;
        }

        static public Direction fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Incoming;
            case 1: return Outgoing;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Direction");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum State {
        /**
        * Initial state. <br/>
        * <br/>
        */
        Idle(0),

        /**
        * Delivery in progress. <br/>
        * <br/>
        */
        InProgress(1),

        /**
        * Message successfully delivered and acknowledged by the server. <br/>
        * <br/>
        */
        Delivered(2),

        /**
        * Message was not delivered. <br/>
        * <br/>
        */
        NotDelivered(3),

        /**
        * Message was received and acknowledged but cannot get file from server. <br/>
        * <br/>
        */
        FileTransferError(4),

        /**
        * File transfer has been completed successfully. <br/>
        * <br/>
        */
        FileTransferDone(5),

        /**
        * Message successfully delivered an acknowledged by the remote user. <br/>
        * <br/>
        */
        DeliveredToUser(6),

        /**
        * Message successfully displayed to the remote user. <br/>
        * <br/>
        */
        Displayed(7),

        /**
        * File transfer is in progress. <br/>
        * <br/>
        * If message is incoming it's a download, otherwise it's an upload. <br/>
        */
        FileTransferInProgress(8),

        /**
        * Message is pending delivery. <br/>
        * <br/>
        */
        PendingDelivery(9),

        /**
        * The user cancelled the file transfer. <br/>
        * <br/>
        */
        FileTransferCancelling(10);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Idle;
            case 1: return InProgress;
            case 2: return Delivered;
            case 3: return NotDelivered;
            case 4: return FileTransferError;
            case 5: return FileTransferDone;
            case 6: return DeliveredToUser;
            case 7: return Displayed;
            case 8: return FileTransferInProgress;
            case 9: return PendingDelivery;
            case 10: return FileTransferCancelling;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Linphone message has an app-specific field that can store a text. <br/>
    * <br/>
    * The application might want to use it for keeping data over restarts, like<br/>
    * thumbnail image path. <br/>
    * @return the application-specific data or null if none has been stored.   <br/>
    */
    @Nullable
    public String getAppdata();

    /**
    * Linphone message has an app-specific field that can store a text. <br/>
    * <br/>
    * The application might want to use it for keeping data over restarts, like<br/>
    * thumbnail image path.<br/>
    * Invoking this function will attempt to update the message storage to reflect<br/>
    * the change if it is enabled.<br/>
    * @param data the data to store into the message.   <br/>
    */
    public void setAppdata(@Nullable String data);

    /**
    * Gets the SIP call-id accociated with the message. <br/>
    * <br/>
    * @return the call-id   <br/>
    */
    @NonNull
    public String getCallId();

    /**
    * Returns the chatroom this message belongs to. <br/>
    * <br/>
    * @return the {@link ChatRoom} in which this message has been sent or received.   <br/>
    */
    @NonNull
    public ChatRoom getChatRoom();

    /**
    * Gets the content type of a chat message. <br/>
    * <br/>
    * @return The content type of the chat message   <br/>
    */
    @NonNull
    public String getContentType();

    /**
    * Sets the content type of a chat message. <br/>
    * <br/>
    * This content type must match a content that is text representable, such as<br/>
    * text/plain, text/html or image/svg+xml. <br/>
    * @param contentType The new content type of the chat message   <br/>
    */
    public void setContentType(@NonNull String contentType);

    /**
    * Returns the list of contents in the message. <br/>
    * <br/>
    * @return The list of {@link Content}.    <br/>
    */
    @NonNull
    public Content[] getContents();

    /**
    * Returns back pointer to {@link Core} object. <br/>
    * <br/>
    * @return the {@link Core} object associated with this message.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Returns the real time at which an ephemeral message expires and will be<br/>
    * deleted. <br/>
    * <br/>
    * see: {@link #isEphemeral} <br/>
    * @return the time at which an ephemeral message expires. 0 means the message has<br/>
    * not been read. <br/>
    */
    public long getEphemeralExpireTime();

    /**
    * Returns lifetime of an ephemeral message. <br/>
    * <br/>
    * The lifetime is the duration after which the ephemeral message will disappear<br/>
    * once viewed. see: {@link #isEphemeral} <br/>
    * @return the lifetime of an ephemeral message, by default 0 (disabled). <br/>
    */
    public long getEphemeralLifetime();

    /**
    * Gets full details about delivery error of a chat message. <br/>
    * <br/>
    * @return a {@link ErrorInfo} describing the details.   <br/>
    */
    @NonNull
    public ErrorInfo getErrorInfo();

    /**
    * Messages can carry external body as defined by rfc2017. <br/>
    * <br/>
    * @return external body url or null if not present.   <br/>
    */
    @Nullable
    public String getExternalBodyUrl();

    /**
    * Messages can carry external body as defined by rfc2017. <br/>
    * <br/>
    * @param externalBodyUrl ex: access-type=URL; URL="http://www.foo.com/file"   <br/>
    */
    public void setExternalBodyUrl(@Nullable String externalBodyUrl);

    /**
    * Gets the file transfer information (used by callbacks to recover informations<br/>
    * during a rcs file transfer) <br/>
    * <br/>
    * @return a pointer to the {@link Content} structure or null if not present.   <br/>
    */
    @Nullable
    public Content getFileTransferInformation();

    /**
    * Gets the forward info if available as a string. <br/>
    * <br/>
    * @return the original sender of the message if it has been forwarded, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public String getForwardInfo();

    /**
    * Gets origin of the message. <br/>
    * <br/>
    * @return the {@link Address} of the sender.   <br/>
    */
    @NonNull
    public Address getFromAddress();

    /**
    * Returns wether the chat message is an ephemeral message or not. <br/>
    * <br/>
    * An ephemeral message will automatically disappear from the recipient's screen<br/>
    * after the message has been viewed. <br/>
    * @return true if it is an ephemeral message, false otherwise <br/>
    */
    public boolean isEphemeral();

    /**
    * Return whether or not a chat message is a file transfer. <br/>
    * <br/>
    * @return Whether or not the message is a file transfer <br/>
    * @deprecated 06/07/2020 check if {@link #getContents} contains a {@link Content}<br/>
    * for which {@link Content#isFileTransfer} returns true. <br/>
    */
    @Deprecated
    public boolean isFileTransfer();

    /**
    * Gets whether or not a file is currently being downloaded or uploaded. <br/>
    * <br/>
    * @return true if download or upload is in progress, false otherwise <br/>
    */
    public boolean isFileTransferInProgress();

    /**
    * Returns wether the chat message is a forward message or not. <br/>
    * <br/>
    * @return true if it is a forward message, false otherwise <br/>
    */
    public boolean isForward();

    /**
    * Returns wehther the message has been sent or received. <br/>
    * <br/>
    * @return true if message has been sent, false if it has been received. <br/>
    */
    public boolean isOutgoing();

    /**
    * Returns wether the message has been read or not. <br/>
    * <br/>
    * @return true if message has been marked as read, false otherwise. <br/>
    */
    public boolean isRead();

    /**
    * Returns wether the chat message is a reply message or not. <br/>
    * <br/>
    * @return true if it is a reply message, false otherwise <br/>
    */
    public boolean isReply();

    /**
    * Gets if the message was end-to-end encrypted when transferred. <br/>
    * <br/>
    * @return true if the message was end-to-end encrypted when transferred, false<br/>
    * otherwise. <br/>
    */
    public boolean isSecured();

    /**
    * Return whether or not a chat message is a text. <br/>
    * <br/>
    * @return Whether or not the message is a text <br/>
    * @deprecated 06/07/2020 check if {@link #getContents} contains a {@link Content}<br/>
    * with a PlainText content type. <br/>
    */
    @Deprecated
    public boolean isText();

    /**
    * Returns the local address the message was sent or received with. <br/>
    * <br/>
    * @return the {@link Address} of the local address used to send/receive this<br/>
    * message.   <br/>
    */
    @NonNull
    public Address getLocalAddress();

    /**
    * Get the message identifier. <br/>
    * <br/>
    * It is used to identify a message so that it can be notified as delivered and/or<br/>
    * displayed. <br/>
    * @return The message identifier.   <br/>
    */
    @NonNull
    public String getMessageId();

    /**
    * Returns our own reaction for a given chat message, if any. <br/>
    * <br/>
    * @return Our own {@link ChatMessageReaction} for that message if any, null<br/>
    * otherwise.   <br/>
    */
    @Nullable
    public ChatMessageReaction getOwnReaction();

    /**
    * Returns the peer (remote) address of the message. <br/>
    * <br/>
    * @return the {@link Address} of the peer address used to send/receive this<br/>
    * message.   <br/>
    */
    @NonNull
    public Address getPeerAddress();

    /**
    * Gets the list of reactions received for this chat message. <br/>
    * <br/>
    * Warning: list is ordered by content of reaction message, not by received<br/>
    * timestamp! <br/>
    * @return The sorted list of reaction if any.      <br/>
    */
    @NonNull
    public ChatMessageReaction[] getReactions();

    /**
    * Returns the {@link ChatMessage} this message is a reply to. <br/>
    * <br/>
    * @return the original message {@link ChatMessage}.   <br/>
    */
    @Nullable
    public ChatMessage getReplyMessage();

    /**
    * Returns the ID of the message this is a reply to. <br/>
    * <br/>
    * @return the original message id.   <br/>
    */
    @Nullable
    public String getReplyMessageId();

    /**
    * Returns the address of the sender of the message this is a reply to. <br/>
    * <br/>
    * @return the original message sender {@link Address}.   <br/>
    */
    @Nullable
    public Address getReplyMessageSenderAddress();

    /**
    * Gets the state of the message. <br/>
    * <br/>
    * @return the current {@link State} of the message. <br/>
    */
    public ChatMessage.State getState();

    /**
    * Gets the text content if available as a string. <br/>
    * <br/>
    * @return the {@link Content} buffer if available in System Locale, null<br/>
    * otherwise.   <br/>
    * @deprecated 01/07/2020. Use {@link #getUtf8Text} instead. <br/>
    */
    @Deprecated
    @Nullable
    public String getTextContent();

    /**
    * Gets the time the message was sent. <br/>
    * <br/>
    * @return the timestamp of when the message was sent. <br/>
    */
    public long getTime();

    /**
    * Gets destination of the message. <br/>
    * <br/>
    * @return the {@link Address} of the recipient.   <br/>
    */
    @NonNull
    public Address getToAddress();

    /**
    * Gets if a chat message is to be stored. <br/>
    * <br/>
    * @return Whether or not the message is to be stored <br/>
    */
    public boolean getToBeStored();

    /**
    * Sets if a chat message is to be stored. <br/>
    * <br/>
    * This content type must match a content that is text representable, such as<br/>
    * text/plain, text/html or image/svg+xml. <br/>
    * @param toBeStored Whether or not the chat message is to be stored <br/>
    */
    public void setToBeStored(boolean toBeStored);

    /**
    * Gets text part of this message. <br/>
    * <br/>
    * @return The text as UTF8 characters or null if no text.   <br/>
    */
    @Nullable
    public String getUtf8Text();

    /**
    * Sets a text to be sent, given as a string of UTF-8 characters. <br/>
    * <br/>
    * @param text The text in UTF8 to set.   <br/>
    * @return 0 if succeed. <br/>
    */
    public int setUtf8Text(@Nullable String text);

    /**
    * Adds a content to the ChatMessage. <br/>
    * <br/>
    * @param content the {@link Content} object to add.   <br/>
    */
    public void addContent(@NonNull Content content);

    /**
    * Adds custom headers to the message. <br/>
    * <br/>
    * @param headerName name of the header   <br/>
    * @param headerValue header value   <br/>
    */
    public void addCustomHeader(@NonNull String headerName, @Nullable String headerValue);

    /**
    * Adds a file content to the ChatMessage. <br/>
    * <br/>
    * @param content the {@link Content} object to add.   <br/>
    */
    public void addFileContent(@NonNull Content content);

    /**
    * Creates a {@link Content} of type PlainText with the given text as body. <br/>
    * <br/>
    * @param text The text in System Locale to add to the message.   <br/>
    * @deprecated 01/07/2020. Use {@link #addUtf8TextContent} instead. <br/>
    */
    @Deprecated
    public void addTextContent(@NonNull String text);

    /**
    * Creates a {@link Content} of type text/plain with the provided string, and<br/>
    * attach it to the message. <br/>
    * <br/>
    * @param text The text to add to the message.   <br/>
    */
    public void addUtf8TextContent(@NonNull String text);

    /**
    * Cancels an ongoing file transfer attached to this message (upload or download). <br/>
    * <br/>
    */
    public void cancelFileTransfer();

    /**
    * Creates a emoji reaction for the given chat mesage. <br/>
    * <br/>
    * To send it, use {@link ChatMessageReaction#send}. <br/>
    * @param utf8Reaction the emoji character(s) as UTF-8.   <br/>
    * @return a {@link ChatMessageReaction} object.   <br/>
    */
    @NonNull
    public ChatMessageReaction createReaction(@NonNull String utf8Reaction);

    /**
    * Starts the download of the {@link Content} referenced in the {@link ChatMessage}<br/>
    * from remote server. <br/>
    * <br/>
    * @param content the {@link Content} object to download (must have the {@link Content#isFileTransfer}<br/>
    * method return true).   <br/>
    * @return false if there is an error, true otherwise. <br/>
    */
    public boolean downloadContent(@NonNull Content content);

    /**
    * Starts the download of all the {@link Content} objects representing file<br/>
    * transfers included in the message ({@link Content#isFileTransfer} method<br/>
    * returns true). <br/>
    * <br/>
    * @return false if there is an error, true otherwise. <br/>
    */
    public boolean downloadContents();

    /**
    * Retrieves a custom header value given its name. <br/>
    * <br/>
    * @param headerName header name searched   <br/>
    * @return the custom header value or null if not found.   <br/>
    */
    @Nullable
    public String getCustomHeader(@NonNull String headerName);

    /**
    * Gets the list of participants for which the imdn state has reached the<br/>
    * specified state and the time at which they did. <br/>
    * <br/>
    * @param state The LinphoneChatMessageState the imdn have reached (only use<br/>
    * LinphoneChatMessageStateDelivered, LinphoneChatMessageStateDeliveredToUser,<br/>
    * LinphoneChatMessageStateDisplayed and LinphoneChatMessageStateNotDelivered) <br/>
    * @return The list of participants.      <br/>
    */
    @NonNull
    public ParticipantImdnState[] getParticipantsByImdnState(ChatMessage.State state);

    /**
    * Returns wether the chat message has a conference invitation content or not. <br/>
    * <br/>
    * @return true if it has one, false otherwise. <br/>
    */
    public boolean hasConferenceInvitationContent();

    /**
    * Returns wether the chat message has a text content or not. <br/>
    * <br/>
    * @return true if it has one, false otherwise. <br/>
    * @deprecated 27/10/2020. Check if {@link #getContents} contains a {@link Content}<br/>
    * for which it's content type is PlainText. <br/>
    */
    @Deprecated
    public boolean hasTextContent();

    /**
    * Marks the message as read. <br/>
    * <br/>
    * Only triggers LinphoneChatRoomCbsChatRoomReadCb if it was the last unread<br/>
    * message. <br/>
    */
    public void markAsRead();

    /**
    * Fulfills a chat message character by character and send the character<br/>
    * immediately as real-time text (RFC4103 / T.140) or as Baudot tones. <br/>
    * <br/>
    * The method used to send the character depends on if real-time text is enabled<br/>
    * or not. If it is, real-time text is of course used, otherwise Baudot will be<br/>
    * used if it is enabled in the {@link Core} (see {@link Core#enableBaudot}). If<br/>
    * real-time text is used, the {@link ChatRoom} the message was created from must<br/>
    * be a real-time text capable chat room: it must be obtained by placing or<br/>
    * receiving a call with real-time text capabilities (see {@link CallParams#enableRealtimeText}<br/>
    * ), and getting the {@link ChatRoom} interface from the call with {@link Call#getChatRoom}<br/>
    * . When the message is terminated (ie a new line needs to be started), use<br/>
    * {@link #send} in order to trigger the sending of the new line character and<br/>
    * have the full message (comprising all characters sent so far) stored in local<br/>
    * database. <br/>
    * @param character The character to send (T.140 char for real-time text). <br/>
    * @return 0 if succeed. <br/>
    */
    public int putChar(int character);

    /**
    * Removes a content from the ChatMessage. <br/>
    * <br/>
    * @param content the {@link Content} object to remove.   <br/>
    */
    public void removeContent(@NonNull Content content);

    /**
    * Removes a custom header from the message. <br/>
    * <br/>
    * @param headerName name of the header to remove   <br/>
    */
    public void removeCustomHeader(@NonNull String headerName);

    /**
    * Sends a chat message. <br/>
    * <br/>
    */
    public void send();

    /**
    */
    public void addListener(ChatMessageListener listener);

    /**
    */
    public void removeListener(ChatMessageListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class ChatMessageImpl implements ChatMessage {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected ChatMessageImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getAppdata(long nativePtr);
    @Override @Nullable
    synchronized public String getAppdata()  {
        synchronized(core) { 
        
        return getAppdata(nativePtr);
        }
    }

    private native void setAppdata(long nativePtr, String data);
    @Override
    synchronized public void setAppdata(@Nullable String data)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setAppdata() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setAppdata(nativePtr, data);
        }
    }

    private native String getCallId(long nativePtr);
    @Override @NonNull
    synchronized public String getCallId()  {
        synchronized(core) { 
        
        return getCallId(nativePtr);
        }
    }

    private native ChatRoom getChatRoom(long nativePtr);
    @Override @NonNull
    synchronized public ChatRoom getChatRoom()  {
        synchronized(core) { 
        
        return (ChatRoom)getChatRoom(nativePtr);
        }
    }

    private native String getContentType(long nativePtr);
    @Override @NonNull
    synchronized public String getContentType()  {
        synchronized(core) { 
        
        return getContentType(nativePtr);
        }
    }

    private native void setContentType(long nativePtr, String contentType);
    @Override
    synchronized public void setContentType(@NonNull String contentType)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setContentType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setContentType(nativePtr, contentType);
        }
    }

    private native Content[] getContents(long nativePtr);
    @Override @NonNull
    synchronized public Content[] getContents()  {
        synchronized(core) { 
        
        return getContents(nativePtr);
        }
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native long getEphemeralExpireTime(long nativePtr);
    @Override
    synchronized public long getEphemeralExpireTime()  {
        synchronized(core) { 
        
        return getEphemeralExpireTime(nativePtr);
        }
    }

    private native long getEphemeralLifetime(long nativePtr);
    @Override
    synchronized public long getEphemeralLifetime()  {
        synchronized(core) { 
        
        return getEphemeralLifetime(nativePtr);
        }
    }

    private native ErrorInfo getErrorInfo(long nativePtr);
    @Override @NonNull
    synchronized public ErrorInfo getErrorInfo()  {
        synchronized(core) { 
        
        return (ErrorInfo)getErrorInfo(nativePtr);
        }
    }

    private native String getExternalBodyUrl(long nativePtr);
    @Override @Nullable
    synchronized public String getExternalBodyUrl()  {
        synchronized(core) { 
        
        return getExternalBodyUrl(nativePtr);
        }
    }

    private native void setExternalBodyUrl(long nativePtr, String externalBodyUrl);
    @Override
    synchronized public void setExternalBodyUrl(@Nullable String externalBodyUrl)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setExternalBodyUrl() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setExternalBodyUrl(nativePtr, externalBodyUrl);
        }
    }

    private native Content getFileTransferInformation(long nativePtr);
    @Override @Nullable
    synchronized public Content getFileTransferInformation()  {
        synchronized(core) { 
        
        return (Content)getFileTransferInformation(nativePtr);
        }
    }

    private native String getForwardInfo(long nativePtr);
    @Override @Nullable
    synchronized public String getForwardInfo()  {
        synchronized(core) { 
        
        return getForwardInfo(nativePtr);
        }
    }

    private native Address getFromAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getFromAddress()  {
        synchronized(core) { 
        
        return (Address)getFromAddress(nativePtr);
        }
    }

    private native boolean isEphemeral(long nativePtr);
    @Override
    synchronized public boolean isEphemeral()  {
        synchronized(core) { 
        
        return isEphemeral(nativePtr);
        }
    }

    private native boolean isFileTransfer(long nativePtr);
    @Override
    synchronized public boolean isFileTransfer()  {
        synchronized(core) { 
        
        return isFileTransfer(nativePtr);
        }
    }

    private native boolean isFileTransferInProgress(long nativePtr);
    @Override
    synchronized public boolean isFileTransferInProgress()  {
        synchronized(core) { 
        
        return isFileTransferInProgress(nativePtr);
        }
    }

    private native boolean isForward(long nativePtr);
    @Override
    synchronized public boolean isForward()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isForward() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isForward(nativePtr);
        }
    }

    private native boolean isOutgoing(long nativePtr);
    @Override
    synchronized public boolean isOutgoing()  {
        synchronized(core) { 
        
        return isOutgoing(nativePtr);
        }
    }

    private native boolean isRead(long nativePtr);
    @Override
    synchronized public boolean isRead()  {
        synchronized(core) { 
        
        return isRead(nativePtr);
        }
    }

    private native boolean isReply(long nativePtr);
    @Override
    synchronized public boolean isReply()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isReply() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isReply(nativePtr);
        }
    }

    private native boolean isSecured(long nativePtr);
    @Override
    synchronized public boolean isSecured()  {
        synchronized(core) { 
        
        return isSecured(nativePtr);
        }
    }

    private native boolean isText(long nativePtr);
    @Override
    synchronized public boolean isText()  {
        synchronized(core) { 
        
        return isText(nativePtr);
        }
    }

    private native Address getLocalAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getLocalAddress()  {
        synchronized(core) { 
        
        return (Address)getLocalAddress(nativePtr);
        }
    }

    private native String getMessageId(long nativePtr);
    @Override @NonNull
    synchronized public String getMessageId()  {
        synchronized(core) { 
        
        return getMessageId(nativePtr);
        }
    }

    private native ChatMessageReaction getOwnReaction(long nativePtr);
    @Override @Nullable
    synchronized public ChatMessageReaction getOwnReaction()  {
        synchronized(core) { 
        
        return (ChatMessageReaction)getOwnReaction(nativePtr);
        }
    }

    private native Address getPeerAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getPeerAddress()  {
        synchronized(core) { 
        
        return (Address)getPeerAddress(nativePtr);
        }
    }

    private native ChatMessageReaction[] getReactions(long nativePtr);
    @Override @NonNull
    synchronized public ChatMessageReaction[] getReactions()  {
        synchronized(core) { 
        
        return getReactions(nativePtr);
        }
    }

    private native ChatMessage getReplyMessage(long nativePtr);
    @Override @Nullable
    synchronized public ChatMessage getReplyMessage()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getReplyMessage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessage)getReplyMessage(nativePtr);
        }
    }

    private native String getReplyMessageId(long nativePtr);
    @Override @Nullable
    synchronized public String getReplyMessageId()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getReplyMessageId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getReplyMessageId(nativePtr);
        }
    }

    private native Address getReplyMessageSenderAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getReplyMessageSenderAddress()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getReplyMessageSenderAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)getReplyMessageSenderAddress(nativePtr);
        }
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public ChatMessage.State getState()  {
        synchronized(core) { 
        
        return ChatMessage.State.fromInt(getState(nativePtr));
        }
    }

    private native String getTextContent(long nativePtr);
    @Override @Nullable
    synchronized public String getTextContent()  {
        synchronized(core) { 
        
        return getTextContent(nativePtr);
        }
    }

    private native long getTime(long nativePtr);
    @Override
    synchronized public long getTime()  {
        synchronized(core) { 
        
        return getTime(nativePtr);
        }
    }

    private native Address getToAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getToAddress()  {
        synchronized(core) { 
        
        return (Address)getToAddress(nativePtr);
        }
    }

    private native boolean getToBeStored(long nativePtr);
    @Override
    synchronized public boolean getToBeStored()  {
        synchronized(core) { 
        
        return getToBeStored(nativePtr);
        }
    }

    private native void setToBeStored(long nativePtr, boolean toBeStored);
    @Override
    synchronized public void setToBeStored(boolean toBeStored)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setToBeStored() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setToBeStored(nativePtr, toBeStored);
        }
    }

    private native String getUtf8Text(long nativePtr);
    @Override @Nullable
    synchronized public String getUtf8Text()  {
        synchronized(core) { 
        
        return getUtf8Text(nativePtr);
        }
    }

    private native int setUtf8Text(long nativePtr, String text);
    @Override
    synchronized public int setUtf8Text(@Nullable String text)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUtf8Text() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setUtf8Text(nativePtr, text);
        }
    }

    private native void addContent(long nativePtr, Content content);
    @Override
    synchronized public void addContent(@NonNull Content content)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addContent(nativePtr, content);
        }
    }

    private native void addCustomHeader(long nativePtr, String headerName, String headerValue);
    @Override
    synchronized public void addCustomHeader(@NonNull String headerName, @Nullable String headerValue)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomHeader(nativePtr, headerName, headerValue);
        }
    }

    private native void addFileContent(long nativePtr, Content content);
    @Override
    synchronized public void addFileContent(@NonNull Content content)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addFileContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addFileContent(nativePtr, content);
        }
    }

    private native void addTextContent(long nativePtr, String text);
    @Override
    synchronized public void addTextContent(@NonNull String text)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addTextContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addTextContent(nativePtr, text);
        }
    }

    private native void addUtf8TextContent(long nativePtr, String text);
    @Override
    synchronized public void addUtf8TextContent(@NonNull String text)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addUtf8TextContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addUtf8TextContent(nativePtr, text);
        }
    }

    private native void cancelFileTransfer(long nativePtr);
    @Override
    synchronized public void cancelFileTransfer()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call cancelFileTransfer() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        cancelFileTransfer(nativePtr);
        }
    }

    private native ChatMessageReaction createReaction(long nativePtr, String utf8Reaction);
    @Override @NonNull
    synchronized public ChatMessageReaction createReaction(@NonNull String utf8Reaction)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createReaction() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ChatMessageReaction)createReaction(nativePtr, utf8Reaction);
        }
    }

    private native boolean downloadContent(long nativePtr, Content content);
    @Override
    synchronized public boolean downloadContent(@NonNull Content content)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call downloadContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return downloadContent(nativePtr, content);
        }
    }

    private native boolean downloadContents(long nativePtr);
    @Override
    synchronized public boolean downloadContents()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call downloadContents() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return downloadContents(nativePtr);
        }
    }

    private native String getCustomHeader(long nativePtr, String headerName);
    @Override @Nullable
    synchronized public String getCustomHeader(@NonNull String headerName)  {
        synchronized(core) { 
        
        return getCustomHeader(nativePtr, headerName);
        }
    }

    private native ParticipantImdnState[] getParticipantsByImdnState(long nativePtr, int state);
    @Override @NonNull
    synchronized public ParticipantImdnState[] getParticipantsByImdnState(ChatMessage.State state)  {
        synchronized(core) { 
        
        return getParticipantsByImdnState(nativePtr, state.toInt());
        }
    }

    private native boolean hasConferenceInvitationContent(long nativePtr);
    @Override
    synchronized public boolean hasConferenceInvitationContent()  {
        synchronized(core) { 
        
        return hasConferenceInvitationContent(nativePtr);
        }
    }

    private native boolean hasTextContent(long nativePtr);
    @Override
    synchronized public boolean hasTextContent()  {
        synchronized(core) { 
        
        return hasTextContent(nativePtr);
        }
    }

    private native void markAsRead(long nativePtr);
    @Override
    synchronized public void markAsRead()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call markAsRead() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        markAsRead(nativePtr);
        }
    }

    private native int putChar(long nativePtr, int character);
    @Override
    synchronized public int putChar(int character)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call putChar() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return putChar(nativePtr, character);
        }
    }

    private native void removeContent(long nativePtr, Content content);
    @Override
    synchronized public void removeContent(@NonNull Content content)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeContent() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeContent(nativePtr, content);
        }
    }

    private native void removeCustomHeader(long nativePtr, String headerName);
    @Override
    synchronized public void removeCustomHeader(@NonNull String headerName)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeCustomHeader(nativePtr, headerName);
        }
    }

    private native void send(long nativePtr);
    @Override
    synchronized public void send()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call send() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        send(nativePtr);
        }
    }

    private native void addListener(long nativePtr, ChatMessageListener listener);
    @Override
    synchronized public void addListener(ChatMessageListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, ChatMessageListener listener);
    @Override
    synchronized public void removeListener(ChatMessageListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
