/*
ZrtpPeerStatus.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum describing the ZRTP SAS validation status of a peer URI. <br/>
* <br/>
*/
public enum ZrtpPeerStatus {
    /**
    * Peer URI unkown or never validated/invalidated the SAS. <br/>
    * <br/>
    */
    Unknown(0),

    /**
    * Peer URI SAS rejected in database. <br/>
    * <br/>
    */
    Invalid(1),

    /**
    * Peer URI SAS validated in database. <br/>
    * <br/>
    */
    Valid(2);

    protected final int mValue;

    private ZrtpPeerStatus (int value) {
        mValue = value;
    }

    static public ZrtpPeerStatus fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Unknown;
        case 1: return Invalid;
        case 2: return Valid;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for ZrtpPeerStatus");
        }
    }
    
    static protected ZrtpPeerStatus[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        ZrtpPeerStatus[] enumArray = new ZrtpPeerStatus[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = ZrtpPeerStatus.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(ZrtpPeerStatus[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
