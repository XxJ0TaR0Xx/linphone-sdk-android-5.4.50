/*
AccountManagerServices.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Creates and manage SIP user accounts remotely, using the REST API of the<br/>
* Flexisip Account Manager. <br/>
* <br/>
* see: https://gitlab.linphone.org/BC/public/flexisip-account-manager <br/>
*/
public interface AccountManagerServices {
    /**
    * Gets the configurer preferred language, if set. <br/>
    * <br/>
    * @return the language previously set, if any (otherwise null).   <br/>
    */
    @Nullable
    public String getLanguage();

    /**
    * Sets the preferred language to get error messages from account manager (if<br/>
    * supported, otherwise will be english). <br/>
    * <br/>
    * @param language The language (en, fr, etc...) you'd like to have error messages<br/>
    * in (if possible).   <br/>
    */
    public void setLanguage(@Nullable String language);

    /**
    * Requests to delete a device from the list of currently known devices. <br/>
    * <br/>
    * @param sipIdentity the SIP identity URI that identifies your account for which<br/>
    * you want the devices list.   <br/>
    * @param device the {@link AccountDevice} to delete.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createDeleteDeviceRequest(@NonNull Address sipIdentity, @NonNull AccountDevice device);

    /**
    * Requests a an account creation request token that once validated using the URL<br/>
    * returned by this method upon success, will allow you to call {@link #createGetAccountCreationTokenFromRequestTokenRequest}<br/>
    * to obtain a valid account creation token. <br/>
    * <br/>
    * Once the account creation token is obtained, you can call {@link #createNewAccountUsingTokenRequest}<br/>
    * . <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createGetAccountCreationRequestTokenRequest();

    /**
    * Converts an account creation request token obtained by<br/>
    * linphone_account_manager_services_request_account_creation_request_token to an<br/>
    * account creation token. <br/>
    * <br/>
    * The obtained token can be used to call {@link #createNewAccountUsingTokenRequest}<br/>
    * . <br/>
    * @param requestToken the token obtained previously and validated using your web<br/>
    * browser.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createGetAccountCreationTokenFromRequestTokenRequest(@NonNull String requestToken);

    /**
    * Requests the list of devices currently known. <br/>
    * <br/>
    * @param sipIdentity the SIP identity URI that identifies your account for which<br/>
    * you want the devices list.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createGetDevicesListRequest(@NonNull Address sipIdentity);

    /**
    * Validates the link between an email address and an account using a code<br/>
    * received by email after calling {@link #createSendEmailLinkingCodeByEmailRequest}<br/>
    * <br/>
    * @param sipIdentity the SIP identity URI that identifies the account to which<br/>
    * you want to link the email address to.    <br/>
    * @param code the code received by email.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createLinkEmailToAccountUsingCodeRequest(@NonNull Address sipIdentity, @NonNull String code);

    /**
    * Validates the link between a phone number and an account using a code received<br/>
    * by SMS after calling {@link #createSendPhoneNumberLinkingCodeBySmsRequest} <br/>
    * <br/>
    * @param sipIdentity the SIP identity URI that identifies the account to which<br/>
    * you want to link the phone number to.    <br/>
    * @param code the code received by SMS.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createLinkPhoneNumberToAccountUsingCodeRequest(@NonNull Address sipIdentity, @NonNull String code);

    /**
    * Creates an account using an account creation token, for example obtained using<br/>
    * {@link #createSendAccountCreationTokenByPushRequest}. <br/>
    * <br/>
    * @param username the username of the newly created account.   <br/>
    * @param password the password to use for the newly created account.   <br/>
    * @param algorithm the algorithm to use to hash the password (must be either MD5<br/>
    * or SHA-256).   <br/>
    * @param token the account creation token obtained previously.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createNewAccountUsingTokenRequest(@NonNull String username, @NonNull String password, @NonNull String algorithm, @NonNull String token);

    /**
    * Requests a push notification to be sent to device, containing a valid account<br/>
    * creation token. <br/>
    * <br/>
    * Provider, param & prid can be obtained from {@link Core#getPushNotificationConfig}<br/>
    * , but on iOS may need some modifications (depending on debug mode for example).<br/>
    * Once the token is obtained, you can call {@link #createNewAccountUsingTokenRequest}<br/>
    * . <br/>
    * @param pnProvider The provider, for example "apns.dev".   <br/>
    * @param pnParam The parameters, for example<br/>
    * "ABCD1234.org.linphone.phone.remote".   <br/>
    * @param pnPrid The prid, also known as push token.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createSendAccountCreationTokenByPushRequest(@NonNull String pnProvider, @NonNull String pnParam, @NonNull String pnPrid);

    /**
    * Requests a code to be sent to a given email address, that can be used later to<br/>
    * associate said email to an account using {@link #createLinkEmailToAccountUsingCodeRequest}<br/>
    * . <br/>
    * <br/>
    * @param sipIdentity the SIP identity URI that identifies the account to which<br/>
    * you want to link the email address to.    <br/>
    * @param emailAddress the email address to which to send the code to.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createSendEmailLinkingCodeByEmailRequest(@NonNull Address sipIdentity, @NonNull String emailAddress);

    /**
    * Requests a code to be sent to a given phone number, that can be used later to<br/>
    * associate said phone number to an account using {@link #createLinkPhoneNumberToAccountUsingCodeRequest}<br/>
    * . <br/>
    * <br/>
    * @param sipIdentity the SIP identity URI that identifies the account to which<br/>
    * you want to link the phone number to.    <br/>
    * @param phoneNumber the phone number to which to send the code by SMS.   <br/>
    * @return the {@link AccountManagerServicesRequest} request object.   <br/>
    */
    @NonNull
    public AccountManagerServicesRequest createSendPhoneNumberLinkingCodeBySmsRequest(@NonNull Address sipIdentity, @NonNull String phoneNumber);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AccountManagerServicesImpl implements AccountManagerServices {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AccountManagerServicesImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getLanguage(long nativePtr);
    @Override @Nullable
    synchronized public String getLanguage()  {
        
        
        return getLanguage(nativePtr);
    }

    private native void setLanguage(long nativePtr, String language);
    @Override
    synchronized public void setLanguage(@Nullable String language)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setLanguage() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setLanguage(nativePtr, language);
    }

    private native AccountManagerServicesRequest createDeleteDeviceRequest(long nativePtr, Address sipIdentity, AccountDevice device);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createDeleteDeviceRequest(@NonNull Address sipIdentity, @NonNull AccountDevice device)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createDeleteDeviceRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createDeleteDeviceRequest(nativePtr, sipIdentity, device);
    }

    private native AccountManagerServicesRequest createGetAccountCreationRequestTokenRequest(long nativePtr);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createGetAccountCreationRequestTokenRequest()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createGetAccountCreationRequestTokenRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createGetAccountCreationRequestTokenRequest(nativePtr);
    }

    private native AccountManagerServicesRequest createGetAccountCreationTokenFromRequestTokenRequest(long nativePtr, String requestToken);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createGetAccountCreationTokenFromRequestTokenRequest(@NonNull String requestToken)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createGetAccountCreationTokenFromRequestTokenRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createGetAccountCreationTokenFromRequestTokenRequest(nativePtr, requestToken);
    }

    private native AccountManagerServicesRequest createGetDevicesListRequest(long nativePtr, Address sipIdentity);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createGetDevicesListRequest(@NonNull Address sipIdentity)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createGetDevicesListRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createGetDevicesListRequest(nativePtr, sipIdentity);
    }

    private native AccountManagerServicesRequest createLinkEmailToAccountUsingCodeRequest(long nativePtr, Address sipIdentity, String code);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createLinkEmailToAccountUsingCodeRequest(@NonNull Address sipIdentity, @NonNull String code)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createLinkEmailToAccountUsingCodeRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createLinkEmailToAccountUsingCodeRequest(nativePtr, sipIdentity, code);
    }

    private native AccountManagerServicesRequest createLinkPhoneNumberToAccountUsingCodeRequest(long nativePtr, Address sipIdentity, String code);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createLinkPhoneNumberToAccountUsingCodeRequest(@NonNull Address sipIdentity, @NonNull String code)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createLinkPhoneNumberToAccountUsingCodeRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createLinkPhoneNumberToAccountUsingCodeRequest(nativePtr, sipIdentity, code);
    }

    private native AccountManagerServicesRequest createNewAccountUsingTokenRequest(long nativePtr, String username, String password, String algorithm, String token);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createNewAccountUsingTokenRequest(@NonNull String username, @NonNull String password, @NonNull String algorithm, @NonNull String token)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createNewAccountUsingTokenRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createNewAccountUsingTokenRequest(nativePtr, username, password, algorithm, token);
    }

    private native AccountManagerServicesRequest createSendAccountCreationTokenByPushRequest(long nativePtr, String pnProvider, String pnParam, String pnPrid);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createSendAccountCreationTokenByPushRequest(@NonNull String pnProvider, @NonNull String pnParam, @NonNull String pnPrid)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createSendAccountCreationTokenByPushRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createSendAccountCreationTokenByPushRequest(nativePtr, pnProvider, pnParam, pnPrid);
    }

    private native AccountManagerServicesRequest createSendEmailLinkingCodeByEmailRequest(long nativePtr, Address sipIdentity, String emailAddress);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createSendEmailLinkingCodeByEmailRequest(@NonNull Address sipIdentity, @NonNull String emailAddress)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createSendEmailLinkingCodeByEmailRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createSendEmailLinkingCodeByEmailRequest(nativePtr, sipIdentity, emailAddress);
    }

    private native AccountManagerServicesRequest createSendPhoneNumberLinkingCodeBySmsRequest(long nativePtr, Address sipIdentity, String phoneNumber);
    @Override @NonNull
    synchronized public AccountManagerServicesRequest createSendPhoneNumberLinkingCodeBySmsRequest(@NonNull Address sipIdentity, @NonNull String phoneNumber)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createSendPhoneNumberLinkingCodeBySmsRequest() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AccountManagerServicesRequest)createSendPhoneNumberLinkingCodeBySmsRequest(nativePtr, sipIdentity, phoneNumber);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
