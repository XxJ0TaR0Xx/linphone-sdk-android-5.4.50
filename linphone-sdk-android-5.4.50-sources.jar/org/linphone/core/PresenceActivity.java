/*
PresenceActivity.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Presence activity type holding information about a presence activity. <br/>
* <br/>
*/
public interface PresenceActivity {
    public enum Type {
        /**
        * The person has a calendar appointment, without specifying exactly of what type. <br/>
        * <br/>
        * This activity is indicated if more detailed information is not available or the<br/>
        * person chooses not to reveal more information. <br/>
        */
        Appointment(0),

        /**
        * The person is physically away from all interactive communication devices. <br/>
        * <br/>
        */
        Away(1),

        /**
        * The person is eating the first meal of the day, usually eaten in the morning. <br/>
        * <br/>
        */
        Breakfast(2),

        /**
        * The person is busy, without further details. <br/>
        * <br/>
        */
        Busy(3),

        /**
        * The person is having his or her main meal of the day, eaten in the evening or<br/>
        * at midday. <br/>
        * <br/>
        */
        Dinner(4),

        /**
        * This is a scheduled national or local holiday. <br/>
        * <br/>
        */
        Holiday(5),

        /**
        * The person is riding in a vehicle, such as a car, but not steering. <br/>
        * <br/>
        */
        InTransit(6),

        /**
        * The person is looking for (paid) work. <br/>
        * <br/>
        */
        LookingForWork(7),

        /**
        * The person is eating his or her midday meal. <br/>
        * <br/>
        */
        Lunch(8),

        /**
        * The person is scheduled for a meal, without specifying whether it is breakfast,<br/>
        * lunch, or dinner, or some other meal. <br/>
        * <br/>
        */
        Meal(9),

        /**
        * The person is in an assembly or gathering of people, as for a business, social,<br/>
        * or religious purpose. <br/>
        * <br/>
        * A meeting is a sub-class of an appointment. <br/>
        */
        Meeting(10),

        /**
        * The person is talking on the telephone. <br/>
        * <br/>
        */
        OnThePhone(11),

        /**
        * The person is engaged in an activity with no defined representation. <br/>
        * <br/>
        * A string describing the activity in plain text SHOULD be provided. <br/>
        */
        Other(12),

        /**
        * A performance is a sub-class of an appointment and includes musical,<br/>
        * theatrical, and cinematic performances as well as lectures. <br/>
        * <br/>
        * It is distinguished from a meeting by the fact that the person may either be<br/>
        * lecturing or be in the audience, with a potentially large number of other<br/>
        * people, making interruptions particularly noticeable. <br/>
        */
        Performance(13),

        /**
        * The person will not return for the foreseeable future, e.g., because it is no<br/>
        * longer working for the company. <br/>
        * <br/>
        */
        PermanentAbsence(14),

        /**
        * The person is occupying himself or herself in amusement, sport, or other<br/>
        * recreation. <br/>
        * <br/>
        */
        Playing(15),

        /**
        * The person is giving a presentation, lecture, or participating in a formal<br/>
        * round-table discussion. <br/>
        * <br/>
        */
        Presentation(16),

        /**
        * The person is visiting stores in search of goods or services. <br/>
        * <br/>
        */
        Shopping(17),

        /**
        * The person is sleeping. <br/>
        * <br/>
        */
        Sleeping(18),

        /**
        * The person is observing an event, such as a sports event. <br/>
        * <br/>
        */
        Spectator(19),

        /**
        * The person is controlling a vehicle, watercraft, or plane. <br/>
        * <br/>
        */
        Steering(20),

        /**
        * The person is on a business or personal trip, but not necessarily in-transit. <br/>
        * <br/>
        */
        Travel(21),

        /**
        * The person is watching television. <br/>
        * <br/>
        */
        TV(22),

        /**
        * The activity of the person is unknown. <br/>
        * <br/>
        */
        Unknown(23),

        /**
        * A period of time devoted to pleasure, rest, or relaxation. <br/>
        * <br/>
        */
        Vacation(24),

        /**
        * The person is engaged in, typically paid, labor, as part of a profession or<br/>
        * job. <br/>
        * <br/>
        */
        Working(25),

        /**
        * The person is participating in religious rites. <br/>
        * <br/>
        */
        Worship(26);

        protected final int mValue;

        private Type (int value) {
            mValue = value;
        }

        static public Type fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Appointment;
            case 1: return Away;
            case 2: return Breakfast;
            case 3: return Busy;
            case 4: return Dinner;
            case 5: return Holiday;
            case 6: return InTransit;
            case 7: return LookingForWork;
            case 8: return Lunch;
            case 9: return Meal;
            case 10: return Meeting;
            case 11: return OnThePhone;
            case 12: return Other;
            case 13: return Performance;
            case 14: return PermanentAbsence;
            case 15: return Playing;
            case 16: return Presentation;
            case 17: return Shopping;
            case 18: return Sleeping;
            case 19: return Spectator;
            case 20: return Steering;
            case 21: return Travel;
            case 22: return TV;
            case 23: return Unknown;
            case 24: return Vacation;
            case 25: return Working;
            case 26: return Worship;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Type");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Gets the description of a presence activity. <br/>
    * <br/>
    * @return A pointer to the description string of the presence activity, or null<br/>
    * if no description is specified.    <br/>
    */
    @Nullable
    public String getDescription();

    /**
    * Sets the description of a presence activity. <br/>
    * <br/>
    * @param description An additional description of the activity. Can be null if no<br/>
    * additional description is to be added.   <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int setDescription(@Nullable String description);

    /**
    * Gets the activity type of a presence activity. <br/>
    * <br/>
    * @return The {@link Type} of the activity. <br/>
    */
    public PresenceActivity.Type getType();

    /**
    * Sets the type of activity of a presence activity. <br/>
    * <br/>
    * @param acttype The {@link Type} to set for the activity. <br/>
    * @return 0 if successful, a value < 0 in case of error. <br/>
    */
    public int setType(PresenceActivity.Type acttype);

    /**
    * Gets the string representation of a presence activity. <br/>
    * <br/>
    * @return A pointer a dynamically allocated string representing the given<br/>
    * activity.    <br/>
    * The returned string is to be freed by calling ms_free(). <br/>
    */
    @NonNull
    public String toString();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    
}

class PresenceActivityImpl implements PresenceActivity {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected PresenceActivityImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getDescription(long nativePtr);
    @Override @Nullable
    synchronized public String getDescription()  {
        
        
        return getDescription(nativePtr);
    }

    private native int setDescription(long nativePtr, String description);
    @Override
    synchronized public int setDescription(@Nullable String description)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDescription() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setDescription(nativePtr, description);
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public PresenceActivity.Type getType()  {
        
        
        return PresenceActivity.Type.fromInt(getType(nativePtr));
    }

    private native int setType(long nativePtr, int acttype);
    @Override
    synchronized public int setType(PresenceActivity.Type acttype)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setType() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setType(nativePtr, acttype.toInt());
    }

    private native String toString(long nativePtr);
    @Override @NonNull
    synchronized public String toString()  {
        
        
        return toString(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    
}
