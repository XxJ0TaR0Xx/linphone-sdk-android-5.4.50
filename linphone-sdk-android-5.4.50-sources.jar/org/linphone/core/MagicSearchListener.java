/*
MagicSearchListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* {@link MagicSearchListener} is an interface to be notified of results of<br/>
* contact searches initiated from the {@link MagicSearch}. <br/>
* <br/>
* see: {@link MagicSearch#addListener} <br/>
*/
public interface MagicSearchListener {
    /**
    * Callback used to notify when results are received. <br/>
    * <br/>
    * @param magicSearch {@link MagicSearch} object   <br/>
    */
    public void onSearchResultsReceived(@NonNull MagicSearch magicSearch);

    /**
    * Callback used to notify when LDAP have more results available. <br/>
    * <br/>
    * @param magicSearch {@link MagicSearch} object   <br/>
    * @param ldap {@link Ldap} object   <br/>
    * @deprecated 18/11/2024 use LinphoneMagicSearchCbsMoreResultsAvailableCb<br/>
    * instead. <br/>
    */
    public void onLdapHaveMoreResults(@NonNull MagicSearch magicSearch, @NonNull Ldap ldap);

    /**
    * Callback used to notify when more results are available for a given {@link MagicSearch#Source}<br/>
    * flag. <br/>
    * <br/>
    * @param magicSearch {@link MagicSearch} object   <br/>
    * @param source The source flag indicating for which type of result there is more<br/>
    * results available. <br/>
    */
    public void onMoreResultsAvailable(@NonNull MagicSearch magicSearch, MagicSearch.Source source);

}