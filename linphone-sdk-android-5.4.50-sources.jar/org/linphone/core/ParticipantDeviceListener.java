/*
ParticipantDeviceListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for the handling a {@link ParticipantDevice}<br/>
* objects. <br/>
* <br/>
* Use {@link Factory#createParticipantDeviceCbs} to create an instance. Then pass<br/>
* the object to a {@link ParticipantDevice} instance through {@link ParticipantDevice#addListener}<br/>
* . <br/>
*/
public interface ParticipantDeviceListener {
    /**
    * Callback used to notify that is this participant device speaking has changed. <br/>
    * <br/>
    * @param participantDevice {@link ParticipantDevice} object   <br/>
    * @param isSpeaking is this participant device speaking <br/>
    */
    public void onIsSpeakingChanged(@NonNull ParticipantDevice participantDevice, boolean isSpeaking);

    /**
    * Callback used to notify that this participant device is muted or is no longer<br/>
    * muted. <br/>
    * <br/>
    * @param participantDevice {@link ParticipantDevice} object   <br/>
    * @param isMuted is this participant device muted <br/>
    */
    public void onIsMuted(@NonNull ParticipantDevice participantDevice, boolean isMuted);

    /**
    * Callback used to notify that this participant device is screen sharing or is no<br/>
    * longer screen sharing. <br/>
    * <br/>
    * @param participantDevice {@link ParticipantDevice} object   <br/>
    * @param isScreenSharing is this participant device screen sharing <br/>
    */
    public void onScreenSharingChanged(@NonNull ParticipantDevice participantDevice, boolean isScreenSharing);

    /**
    * Callback used to notify that participant device changed state. <br/>
    * <br/>
    * @param participantDevice LinphoneParticipantDevice object   <br/>
    * @param state new participant device state <br/>
    */
    public void onStateChanged(@NonNull ParticipantDevice participantDevice, ParticipantDevice.State state);

    /**
    * Callback used to notify that participant device stream capability has changed. <br/>
    * <br/>
    * @param participantDevice {@link ParticipantDevice} object   <br/>
    * @param direction participant device's stream direction <br/>
    * @param streamType type of stream: audio, video or text <br/>
    */
    public void onStreamCapabilityChanged(@NonNull ParticipantDevice participantDevice, MediaDirection direction, StreamType streamType);

    /**
    * Callback used to notify that participant device thumbnail stream capability has<br/>
    * changed. <br/>
    * <br/>
    * @param participantDevice {@link ParticipantDevice} object   <br/>
    * @param direction participant device's thumbnail direction <br/>
    */
    public void onThumbnailStreamCapabilityChanged(@NonNull ParticipantDevice participantDevice, MediaDirection direction);

    /**
    * Callback used to notify that participant device stream availability has<br/>
    * changed. <br/>
    * <br/>
    * @param participantDevice {@link ParticipantDevice} object   <br/>
    * @param available true if the stream is available on our side <br/>
    * @param streamType type of stream: audio, video or text <br/>
    */
    public void onStreamAvailabilityChanged(@NonNull ParticipantDevice participantDevice, boolean available, StreamType streamType);

    /**
    * Callback used to notify that participant device thumbnail stream availability<br/>
    * has changed. <br/>
    * <br/>
    * @param participantDevice {@link ParticipantDevice} object   <br/>
    * @param available participant device's thumbnail stream availability <br/>
    */
    public void onThumbnailStreamAvailabilityChanged(@NonNull ParticipantDevice participantDevice, boolean available);

    /**
    * Callback to notify that there are errors from the video rendering of the<br/>
    * participant device. <br/>
    * <br/>
    * Check LinphoneCallCbsVideoDisplayErrorOccurredCb for more details.<br/>
    * @param participantDevice LinphoneParticipantDevice object   <br/>
    * @param errorCode the error code coming from the display render. <br/>
    */
    public void onVideoDisplayErrorOccurred(@NonNull ParticipantDevice participantDevice, int errorCode);

}