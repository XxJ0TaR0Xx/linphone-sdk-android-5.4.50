/*
Event.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object representing an event state, which is subcribed or published. <br/>
* <br/>
* see: {@link Core#publish} <br/>
* see: {@link Core#subscribe} <br/>
*/
public interface Event {
    /**
    * Get the call ID of the subscription. <br/>
    * <br/>
    * @return The call ID used by the call as a string.   <br/>
    */
    @Nullable
    public String getCallId();

    /**
    * Returns back pointer to the {@link Core} that created this {@link Event}. <br/>
    * <br/>
    * @return the {@link Core} object associated.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Get full details about an error occured. <br/>
    * <br/>
    * @return a {@link ErrorInfo} object.   <br/>
    */
    @NonNull
    public ErrorInfo getErrorInfo();

    /**
    * Get the "from" address of the subscription. <br/>
    * <br/>
    * @return the from {@link Address}.   <br/>
    * @deprecated 19/07/2020 use {@link #getFromAddress} instead <br/>
    */
    @Deprecated
    @NonNull
    public Address getFrom();

    /**
    * Get the "from" address of the subscription. <br/>
    * <br/>
    * @return the from {@link Address}.   <br/>
    */
    @NonNull
    public Address getFromAddress();

    /**
    * Get the name of the event as specified in the event package RFC. <br/>
    * <br/>
    * @return the event name.   <br/>
    */
    @NonNull
    public String getName();

    /**
    * Get publish state. <br/>
    * <br/>
    * If the event object was not created by a publish mechanism, {@link PublishState#None}<br/>
    * is returned. <br/>
    * @return the current {@link PublishState} <br/>
    */
    public PublishState getPublishState();

    /**
    * Return reason code (in case of error state reached). <br/>
    * <br/>
    * @return a {@link Reason} enum <br/>
    */
    public Reason getReason();

    /**
    * Get the "contact" address of the subscription. <br/>
    * <br/>
    * @return The "contact" address of the subscription   <br/>
    */
    @NonNull
    public Address getRemoteContact();

    /**
    * Get the "request uri" address of the subscription. <br/>
    * <br/>
    * @return the request uri {@link Address}.   <br/>
    */
    @Nullable
    public Address getRequestAddress();

    /**
    * Sets the "request uri" address of the subscription. <br/>
    * <br/>
    * @param requestAddress {@link Address} to use in the request uri   <br/>
    */
    public void setRequestAddress(@Nullable Address requestAddress);

    /**
    * Get the resource address of the subscription or publish. <br/>
    * <br/>
    * @return the resource {@link Address}.   <br/>
    */
    @NonNull
    public Address getResource();

    /**
    * Get subscription direction. <br/>
    * <br/>
    * If the object wasn't created by a subscription mechanism, {@link SubscriptionDir#InvalidDir}<br/>
    * is returned. <br/>
    * @return the {@link SubscriptionDir} <br/>
    */
    public SubscriptionDir getSubscriptionDir();

    /**
    * Get subscription state. <br/>
    * <br/>
    * If the event object was not created by a subscription mechanism, {@link SubscriptionState#None}<br/>
    * is returned. <br/>
    * @return the current {@link SubscriptionState} <br/>
    */
    public SubscriptionState getSubscriptionState();

    /**
    * Get the "to" address of the subscription. <br/>
    * <br/>
    * @return the to {@link Address}.   <br/>
    * @deprecated 19/07/2020 use {@link #getToAddress} instead <br/>
    */
    @Deprecated
    @NonNull
    public Address getTo();

    /**
    * Get the "to" address of the subscription. <br/>
    * <br/>
    * @return the to {@link Address}.   <br/>
    */
    @NonNull
    public Address getToAddress();

    /**
    * Accept an incoming publish. <br/>
    * <br/>
    * @return 0 if successful, error code otherwise <br/>
    */
    public int acceptPublish();

    /**
    * Accept an incoming subcription. <br/>
    * <br/>
    * @return 0 if successful, error code otherwise <br/>
    */
    public int acceptSubscription();

    /**
    * Add a custom header to an outgoing susbscription or publish. <br/>
    * <br/>
    * @param name header's name   <br/>
    * @param value the header's value.   <br/>
    */
    public void addCustomHeader(@NonNull String name, @Nullable String value);

    /**
    * Deny an incoming publish with given reason. <br/>
    * <br/>
    * @param reason The {@link Reason} of denial.   <br/>
    * @return 0 if successful, error code otherwise <br/>
    */
    public int denyPublish(@NonNull Reason reason);

    /**
    * Deny an incoming subscription with given reason. <br/>
    * <br/>
    * @param reason The {@link Reason} of denial.   <br/>
    * @return 0 if successful, error code otherwise <br/>
    */
    public int denySubscription(@NonNull Reason reason);

    /**
    * Obtain the value of a given header for an incoming subscription. <br/>
    * <br/>
    * @param name header's name   <br/>
    * @return the header's value or null if such header doesn't exist.   <br/>
    */
    @Nullable
    public String getCustomHeader(@NonNull String name);

    /**
    * Send a notification. <br/>
    * <br/>
    * @param body an optional body containing the actual notification data.   <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    */
    public int notify(@Nullable Content body);

    /**
    * Prevent an event from refreshing its publish. <br/>
    * <br/>
    * This is useful to let registrations to expire naturally (or) when the<br/>
    * application wants to keep control on when refreshes are sent. The refreshing<br/>
    * operations can be resumed with {@link ProxyConfig#refreshRegister}. <br/>
    */
    public void pausePublish();

    /**
    * Refresh an outgoing publish keeping the same body. <br/>
    * <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    */
    public int refreshPublish();

    /**
    * Refresh an outgoing subscription keeping the same body. <br/>
    * <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    */
    public int refreshSubscribe();

    /**
    * Remove custom header to an outgoing susbscription or publish. <br/>
    * <br/>
    * @param name header's name   <br/>
    */
    public void removeCustomHeader(@NonNull String name);

    /**
    * Send a publish created by {@link Core#createPublish}. <br/>
    * <br/>
    * @param body the new data to be published   <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    */
    public int sendPublish(@NonNull Content body);

    /**
    * Send a subscription previously created by {@link Core#createSubscribe}. <br/>
    * <br/>
    * @param body optional content to attach with the subscription.   <br/>
    * @return 0 if successful, -1 otherwise. <br/>
    */
    public int sendSubscribe(@Nullable Content body);

    /**
    * Terminate an incoming or outgoing subscription that was previously acccepted,<br/>
    * or a previous publication. <br/>
    * <br/>
    * The {@link Event} shall not be used anymore after this operation. <br/>
    */
    public void terminate();

    /**
    * Update (refresh) a publish. <br/>
    * <br/>
    * @param body the new data to be published   <br/>
    * @return 0 if successful, error code otherwise <br/>
    */
    public int updatePublish(@NonNull Content body);

    /**
    * Update (refresh) an outgoing subscription, changing the body. <br/>
    * <br/>
    * @param body an optional body to include in the subscription update, may be<br/>
    * null.   <br/>
    * @return 0 if successful, error code otherwise    <br/>
    */
    @Nullable
    public int updateSubscribe(@Nullable Content body);

    /**
    */
    public void addListener(EventListener listener);

    /**
    */
    public void removeListener(EventListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class EventImpl implements Event {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected EventImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native String getCallId(long nativePtr);
    @Override @Nullable
    synchronized public String getCallId()  {
        synchronized(core) { 
        
        return getCallId(nativePtr);
        }
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native ErrorInfo getErrorInfo(long nativePtr);
    @Override @NonNull
    synchronized public ErrorInfo getErrorInfo()  {
        synchronized(core) { 
        
        return (ErrorInfo)getErrorInfo(nativePtr);
        }
    }

    private native Address getFrom(long nativePtr);
    @Override @NonNull
    synchronized public Address getFrom()  {
        synchronized(core) { 
        
        return (Address)getFrom(nativePtr);
        }
    }

    private native Address getFromAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getFromAddress()  {
        synchronized(core) { 
        
        return (Address)getFromAddress(nativePtr);
        }
    }

    private native String getName(long nativePtr);
    @Override @NonNull
    synchronized public String getName()  {
        synchronized(core) { 
        
        return getName(nativePtr);
        }
    }

    private native int getPublishState(long nativePtr);
    @Override
    synchronized public PublishState getPublishState()  {
        synchronized(core) { 
        
        return PublishState.fromInt(getPublishState(nativePtr));
        }
    }

    private native int getReason(long nativePtr);
    @Override
    synchronized public Reason getReason()  {
        synchronized(core) { 
        
        return Reason.fromInt(getReason(nativePtr));
        }
    }

    private native Address getRemoteContact(long nativePtr);
    @Override @NonNull
    synchronized public Address getRemoteContact()  {
        synchronized(core) { 
        
        return (Address)getRemoteContact(nativePtr);
        }
    }

    private native Address getRequestAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getRequestAddress()  {
        synchronized(core) { 
        
        return (Address)getRequestAddress(nativePtr);
        }
    }

    private native void setRequestAddress(long nativePtr, Address requestAddress);
    @Override
    synchronized public void setRequestAddress(@Nullable Address requestAddress)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setRequestAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setRequestAddress(nativePtr, requestAddress);
        }
    }

    private native Address getResource(long nativePtr);
    @Override @NonNull
    synchronized public Address getResource()  {
        synchronized(core) { 
        
        return (Address)getResource(nativePtr);
        }
    }

    private native int getSubscriptionDir(long nativePtr);
    @Override
    synchronized public SubscriptionDir getSubscriptionDir()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getSubscriptionDir() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return SubscriptionDir.fromInt(getSubscriptionDir(nativePtr));
        }
    }

    private native int getSubscriptionState(long nativePtr);
    @Override
    synchronized public SubscriptionState getSubscriptionState()  {
        synchronized(core) { 
        
        return SubscriptionState.fromInt(getSubscriptionState(nativePtr));
        }
    }

    private native Address getTo(long nativePtr);
    @Override @NonNull
    synchronized public Address getTo()  {
        synchronized(core) { 
        
        return (Address)getTo(nativePtr);
        }
    }

    private native Address getToAddress(long nativePtr);
    @Override @NonNull
    synchronized public Address getToAddress()  {
        synchronized(core) { 
        
        return (Address)getToAddress(nativePtr);
        }
    }

    private native int acceptPublish(long nativePtr);
    @Override
    synchronized public int acceptPublish()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call acceptPublish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return acceptPublish(nativePtr);
        }
    }

    private native int acceptSubscription(long nativePtr);
    @Override
    synchronized public int acceptSubscription()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call acceptSubscription() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return acceptSubscription(nativePtr);
        }
    }

    private native void addCustomHeader(long nativePtr, String name, String value);
    @Override
    synchronized public void addCustomHeader(@NonNull String name, @Nullable String value)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomHeader(nativePtr, name, value);
        }
    }

    private native int denyPublish(long nativePtr, int reason);
    @Override
    synchronized public int denyPublish(@NonNull Reason reason)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call denyPublish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return denyPublish(nativePtr, reason.toInt());
        }
    }

    private native int denySubscription(long nativePtr, int reason);
    @Override
    synchronized public int denySubscription(@NonNull Reason reason)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call denySubscription() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return denySubscription(nativePtr, reason.toInt());
        }
    }

    private native String getCustomHeader(long nativePtr, String name);
    @Override @Nullable
    synchronized public String getCustomHeader(@NonNull String name)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCustomHeader(nativePtr, name);
        }
    }

    private native int notify(long nativePtr, Content body);
    @Override
    synchronized public int notify(@Nullable Content body)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call notify() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return notify(nativePtr, body);
        }
    }

    private native void pausePublish(long nativePtr);
    @Override
    synchronized public void pausePublish()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call pausePublish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        pausePublish(nativePtr);
        }
    }

    private native int refreshPublish(long nativePtr);
    @Override
    synchronized public int refreshPublish()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call refreshPublish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return refreshPublish(nativePtr);
        }
    }

    private native int refreshSubscribe(long nativePtr);
    @Override
    synchronized public int refreshSubscribe()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call refreshSubscribe() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return refreshSubscribe(nativePtr);
        }
    }

    private native void removeCustomHeader(long nativePtr, String name);
    @Override
    synchronized public void removeCustomHeader(@NonNull String name)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call removeCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        removeCustomHeader(nativePtr, name);
        }
    }

    private native int sendPublish(long nativePtr, Content body);
    @Override
    synchronized public int sendPublish(@NonNull Content body)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sendPublish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return sendPublish(nativePtr, body);
        }
    }

    private native int sendSubscribe(long nativePtr, Content body);
    @Override
    synchronized public int sendSubscribe(@Nullable Content body)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call sendSubscribe() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return sendSubscribe(nativePtr, body);
        }
    }

    private native void terminate(long nativePtr);
    @Override
    synchronized public void terminate()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call terminate() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        terminate(nativePtr);
        }
    }

    private native int updatePublish(long nativePtr, Content body);
    @Override
    synchronized public int updatePublish(@NonNull Content body)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call updatePublish() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return updatePublish(nativePtr, body);
        }
    }

    private native int updateSubscribe(long nativePtr, Content body);
    @Override @Nullable
    synchronized public int updateSubscribe(@Nullable Content body)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call updateSubscribe() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return updateSubscribe(nativePtr, body);
        }
    }

    private native void addListener(long nativePtr, EventListener listener);
    @Override
    synchronized public void addListener(EventListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, EventListener listener);
    @Override
    synchronized public void removeListener(EventListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
