/*
VideoDefinition.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* This object represents a video definition, eg. <br/>
* <br/>
* it's width, it's height and possibly it's name.<br/>
* It is mostly used to configure the default video size sent by your camera<br/>
* during a video call with {@link Core#setPreferredVideoDefinition} method. <br/>
*/
public interface VideoDefinition {
    /**
    * Get the height of the video definition. <br/>
    * <br/>
    * @return The height of the video definition <br/>
    */
    public int getHeight();

    /**
    * Set the height of the video definition. <br/>
    * <br/>
    * @param height The height of the video definition <br/>
    */
    public void setHeight(int height);

    /**
    * Tells whether a {@link VideoDefinition} is undefined. <br/>
    * <br/>
    * @return A boolean value telling whether the {@link VideoDefinition} is<br/>
    * undefined. <br/>
    */
    public boolean isUndefined();

    /**
    * Get the name of the video definition. <br/>
    * <br/>
    * @return The name of the video definition   <br/>
    */
    @Nullable
    public String getName();

    /**
    * Set the name of the video definition. <br/>
    * <br/>
    * @param name The name of the video definition   <br/>
    */
    public void setName(@Nullable String name);

    /**
    * Get the width of the video definition. <br/>
    * <br/>
    * @return The width of the video definition <br/>
    */
    public int getWidth();

    /**
    * Set the width of the video definition. <br/>
    * <br/>
    * @param width The width of the video definition <br/>
    */
    public void setWidth(int width);

    /**
    * Clone a video definition. <br/>
    * <br/>
    * @return The new clone of the video definition   <br/>
    */
    @NonNull
    public VideoDefinition clone();

    /**
    * Tells whether two {@link VideoDefinition} objects are equal (the widths and the<br/>
    * heights are the same but can be switched). <br/>
    * <br/>
    * @param videoDefinition2 {@link VideoDefinition} object   <br/>
    * @return A boolean value telling whether the two {@link VideoDefinition} objects<br/>
    * are equal. <br/>
    */
    public boolean equals(@NonNull VideoDefinition videoDefinition2);

    /**
    * Set the width and the height of the video definition. <br/>
    * <br/>
    * @param width The width of the video definition <br/>
    * @param height The height of the video definition <br/>
    */
    public void setDefinition(int width, int height);

    /**
    * Tells whether two {@link VideoDefinition} objects are strictly equal (the<br/>
    * widths are the same and the heights are the same). <br/>
    * <br/>
    * @param videoDefinition2 {@link VideoDefinition} object   <br/>
    * @return A boolean value telling whether the two {@link VideoDefinition} objects<br/>
    * are strictly equal. <br/>
    */
    public boolean strictEquals(@NonNull VideoDefinition videoDefinition2);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class VideoDefinitionImpl implements VideoDefinition {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected VideoDefinitionImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getHeight(long nativePtr);
    @Override
    synchronized public int getHeight()  {
        
        
        return getHeight(nativePtr);
    }

    private native void setHeight(long nativePtr, int height);
    @Override
    synchronized public void setHeight(int height)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setHeight() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setHeight(nativePtr, height);
    }

    private native boolean isUndefined(long nativePtr);
    @Override
    synchronized public boolean isUndefined()  {
        
        
        return isUndefined(nativePtr);
    }

    private native String getName(long nativePtr);
    @Override @Nullable
    synchronized public String getName()  {
        
        
        return getName(nativePtr);
    }

    private native void setName(long nativePtr, String name);
    @Override
    synchronized public void setName(@Nullable String name)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setName() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setName(nativePtr, name);
    }

    private native int getWidth(long nativePtr);
    @Override
    synchronized public int getWidth()  {
        
        
        return getWidth(nativePtr);
    }

    private native void setWidth(long nativePtr, int width);
    @Override
    synchronized public void setWidth(int width)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setWidth() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setWidth(nativePtr, width);
    }

    private native VideoDefinition clone(long nativePtr);
    @Override @NonNull
    synchronized public VideoDefinition clone()  {
        
        
        return (VideoDefinition)clone(nativePtr);
    }

    private native boolean equals(long nativePtr, VideoDefinition videoDefinition2);
    @Override
    synchronized public boolean equals(@NonNull VideoDefinition videoDefinition2)  {
        
        
        return equals(nativePtr, videoDefinition2);
    }

    private native void setDefinition(long nativePtr, int width, int height);
    @Override
    synchronized public void setDefinition(int width, int height)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDefinition() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDefinition(nativePtr, width, height);
    }

    private native boolean strictEquals(long nativePtr, VideoDefinition videoDefinition2);
    @Override
    synchronized public boolean strictEquals(@NonNull VideoDefinition videoDefinition2)  {
        
        
        return strictEquals(nativePtr, videoDefinition2);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
