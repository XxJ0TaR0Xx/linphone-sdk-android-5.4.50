/*
CallStats.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* This object carry various statistic informations regarding the quality of an<br/>
* audio or video stream for a given {@link Call}. <br/>
* <br/>
* To receive these informations periodically and as soon as they are computed,<br/>
* implement the call_stats_updated() callback inside a {@link CoreListener}.<br/>
* At any time, the application can access latest computed statistics using {@link Call#getAudioStats}<br/>
* and {@link Call#getVideoStats}. <br/>
*/
public interface CallStats {
    /**
    * Get the bandwidth measurement of the received stream, expressed in kbit/s,<br/>
    * including IP/UDP/RTP headers. <br/>
    * <br/>
    * @return The bandwidth measurement of the received stream in kbit/s. <br/>
    */
    public float getDownloadBandwidth();

    /**
    * Get the estimated bandwidth measurement of the received stream, expressed in<br/>
    * kbit/s, including IP/UDP/RTP headers. <br/>
    * <br/>
    * @return The estimated bandwidth measurement of the received stream in kbit/s. <br/>
    */
    public float getEstimatedDownloadBandwidth();

    /**
    * If the FEC is enabled, gets the cumulative number of lost source packets of the<br/>
    * RTP session that have not been repaired by the current FEC stream. <br/>
    * <br/>
    * @return The cumulative number of lost packets <br/>
    */
    public int getFecCumulativeLostPacketsNumber();

    /**
    * Get the bandwidth measurement of the part of the received stream dedicated to<br/>
    * FEC, expressed in kbit/s, including IP/UDP/RTP headers. <br/>
    * <br/>
    * @return The bandwidth measurement of the received FEC stream in kbit/s. <br/>
    */
    public float getFecDownloadBandwidth();

    /**
    * If the FEC is enabled, gets the cumulative number of source packets of the RTP<br/>
    * session that have been repaired by the current FEC stream. <br/>
    * <br/>
    * @return The cumulative number of repaired packets <br/>
    */
    public int getFecRepairedPacketsNumber();

    /**
    * Get the bandwidth measurement of the part of the sent stream dedicated to FEC,<br/>
    * expressed in kbit/s, including IP/UDP/RTP headers. <br/>
    * <br/>
    * @return The bandwidth measurement of the sent stream in kbit/s. <br/>
    */
    public float getFecUploadBandwidth();

    /**
    * Get the state of ICE processing. <br/>
    * <br/>
    * @return The {@link IceState} of ICE processing <br/>
    */
    public IceState getIceState();

    /**
    * Get the IP address family of the remote peer. <br/>
    * <br/>
    * @return The IP address family {@link Address#Family} of the remote peer. <br/>
    */
    public Address.Family getIpFamilyOfRemote();

    /**
    * Did ZRTP used a Post Quantum algorithm to perform a key exchange. <br/>
    * <br/>
    * @return true if the ZRTP key exchange was performed using a PQ algo false<br/>
    * otherwise: ZRTP exchange not completed or not using a PQ algo <br/>
    */
    public boolean isZrtpKeyAgreementAlgoPostQuantum();

    /**
    * Get the jitter buffer size in ms. <br/>
    * <br/>
    * @return The jitter buffer size in ms. <br/>
    */
    public float getJitterBufferSizeMs();

    /**
    * Gets the cumulative number of late packets. <br/>
    * <br/>
    * @return The cumulative number of late packets <br/>
    */
    public int getLatePacketsCumulativeNumber();

    /**
    * Gets the local late rate since last report, expressed as a percentage. <br/>
    * <br/>
    * @return The local late rate <br/>
    */
    public float getLocalLateRate();

    /**
    * Get the local loss rate since last report, expressed as a percentage. <br/>
    * <br/>
    * @return The local loss rate <br/>
    */
    public float getLocalLossRate();

    /**
    * Gets the remote reported interarrival jitter, expressed in seconds. <br/>
    * <br/>
    * @return The interarrival jitter at last received receiver report <br/>
    */
    public float getReceiverInterarrivalJitter();

    /**
    * Gets the remote reported loss rate since last report, expressed as a<br/>
    * percentage. <br/>
    * <br/>
    * @return The receiver loss rate <br/>
    */
    public float getReceiverLossRate();

    /**
    * Get the round trip delay in s. <br/>
    * <br/>
    * @return The round trip delay in s. <br/>
    */
    public float getRoundTripDelay();

    /**
    * Get the bandwidth measurement of the received RTCP, expressed in kbit/s,<br/>
    * including IP/UDP/RTP headers. <br/>
    * <br/>
    * @return The bandwidth measurement of the received RTCP in kbit/s. <br/>
    */
    public float getRtcpDownloadBandwidth();

    /**
    * Get the bandwidth measurement of the sent RTCP, expressed in kbit/s, including<br/>
    * IP/UDP/RTP headers. <br/>
    * <br/>
    * @return The bandwidth measurement of the sent RTCP in kbit/s. <br/>
    */
    public float getRtcpUploadBandwidth();

    /**
    * Get the RTP cumulative number of incoming packet lost. <br/>
    * <br/>
    * @return The number of RTP cumulative number of incoming packet lost <br/>
    */
    public int getRtpCumPacketLoss();

    /**
    * Get the RTP incoming packets discarded because the queue exceeds its max size. <br/>
    * <br/>
    * @return The RTP incoming packets discarded because the queue exceeds its max<br/>
    * size <br/>
    */
    public int getRtpDiscarded();

    /**
    * Get the number of received bytes excluding IPv4/IPv6/UDP headers and including<br/>
    * late and duplicate packets. <br/>
    * <br/>
    * @return the number of received bytes excluding IPv4/IPv6/UDP headers and<br/>
    * including late and duplicate packets <br/>
    */
    public int getRtpHwRecv();

    /**
    * Get the number of RTP received packets. <br/>
    * <br/>
    * @return The number of RTP received packets <br/>
    */
    public int getRtpPacketRecv();

    /**
    * Get the number of RTP outgoing packets. <br/>
    * <br/>
    * @return The number of RTP outgoing packets <br/>
    */
    public int getRtpPacketSent();

    /**
    * Get the RTP incoming recv_bytes of payload and delivered in time to the<br/>
    * application. <br/>
    * <br/>
    * @return The number of recv_bytes of payload and delivered in time to the<br/>
    * application <br/>
    */
    public int getRtpRecv();

    /**
    * Get the RTP outgoing sent_bytes (excluding IP header) <br/>
    * <br/>
    * @return The number of outgoing sent_bytes (excluding IP header) <br/>
    */
    public int getRtpSent();

    /**
    * Gets the local interarrival jitter, expressed in seconds. <br/>
    * <br/>
    * @return The interarrival jitter at last emitted sender report <br/>
    */
    public float getSenderInterarrivalJitter();

    /**
    * Get the local loss rate since last report, expressed as a percentage. <br/>
    * <br/>
    * @return The sender loss rate <br/>
    */
    public float getSenderLossRate();

    /**
    * Get the method used for SRTP key exchange. <br/>
    * <br/>
    * @return The {@link MediaEncryption} method used to exchange the SRTP keys   <br/>
    */
    @NonNull
    public MediaEncryption getSrtpSource();

    /**
    * Get the SRTP Cryto suite in use. <br/>
    * <br/>
    * @return The SRTP crypto suite currently in use {@link SrtpSuite}   <br/>
    */
    @NonNull
    public SrtpSuite getSrtpSuite();

    /**
    * Get the type of the stream the stats refer to. <br/>
    * <br/>
    * @return The {@link StreamType} the stats refer to <br/>
    */
    public StreamType getType();

    /**
    * Get the bandwidth measurement of the sent stream, expressed in kbit/s,<br/>
    * including IP/UDP/RTP headers. <br/>
    * <br/>
    * @return The bandwidth measurement of the sent stream in kbit/s. <br/>
    */
    public float getUploadBandwidth();

    /**
    * Get the state of uPnP processing. <br/>
    * <br/>
    * @return The {@link UpnpState} of uPnP processing. <br/>
    */
    public UpnpState getUpnpState();

    /**
    * Get the ZRTP algorithm statistics details (authentication method) <br/>
    * <br/>
    * @return The auth tag algo <br/>
    */
    public String getZrtpAuthTagAlgo();

    /**
    * Get the ZRTP algorithm statistics details (cipher) <br/>
    * <br/>
    * @return The cipher algo <br/>
    */
    public String getZrtpCipherAlgo();

    /**
    * Get the ZRTP algorithm statistics details (hash function) <br/>
    * <br/>
    * @return The hash algo <br/>
    */
    public String getZrtpHashAlgo();

    /**
    * Get the ZRTP algorithm statistics details (key agreeement) <br/>
    * <br/>
    * @return The key agreement algo <br/>
    */
    public String getZrtpKeyAgreementAlgo();

    /**
    * Get the ZRTP algorithm statistics details (SAS display) <br/>
    * <br/>
    * @return The sas algo <br/>
    */
    public String getZrtpSasAlgo();

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class CallStatsImpl implements CallStats {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected CallStatsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native float getDownloadBandwidth(long nativePtr);
    @Override
    synchronized public float getDownloadBandwidth()  {
        
        
        return getDownloadBandwidth(nativePtr);
    }

    private native float getEstimatedDownloadBandwidth(long nativePtr);
    @Override
    synchronized public float getEstimatedDownloadBandwidth()  {
        
        
        return getEstimatedDownloadBandwidth(nativePtr);
    }

    private native int getFecCumulativeLostPacketsNumber(long nativePtr);
    @Override
    synchronized public int getFecCumulativeLostPacketsNumber()  {
        
        
        return getFecCumulativeLostPacketsNumber(nativePtr);
    }

    private native float getFecDownloadBandwidth(long nativePtr);
    @Override
    synchronized public float getFecDownloadBandwidth()  {
        
        
        return getFecDownloadBandwidth(nativePtr);
    }

    private native int getFecRepairedPacketsNumber(long nativePtr);
    @Override
    synchronized public int getFecRepairedPacketsNumber()  {
        
        
        return getFecRepairedPacketsNumber(nativePtr);
    }

    private native float getFecUploadBandwidth(long nativePtr);
    @Override
    synchronized public float getFecUploadBandwidth()  {
        
        
        return getFecUploadBandwidth(nativePtr);
    }

    private native int getIceState(long nativePtr);
    @Override
    synchronized public IceState getIceState()  {
        
        
        return IceState.fromInt(getIceState(nativePtr));
    }

    private native int getIpFamilyOfRemote(long nativePtr);
    @Override
    synchronized public Address.Family getIpFamilyOfRemote()  {
        
        
        return Address.Family.fromInt(getIpFamilyOfRemote(nativePtr));
    }

    private native boolean isZrtpKeyAgreementAlgoPostQuantum(long nativePtr);
    @Override
    synchronized public boolean isZrtpKeyAgreementAlgoPostQuantum()  {
        
        
        return isZrtpKeyAgreementAlgoPostQuantum(nativePtr);
    }

    private native float getJitterBufferSizeMs(long nativePtr);
    @Override
    synchronized public float getJitterBufferSizeMs()  {
        
        
        return getJitterBufferSizeMs(nativePtr);
    }

    private native int getLatePacketsCumulativeNumber(long nativePtr);
    @Override
    synchronized public int getLatePacketsCumulativeNumber()  {
        
        
        return getLatePacketsCumulativeNumber(nativePtr);
    }

    private native float getLocalLateRate(long nativePtr);
    @Override
    synchronized public float getLocalLateRate()  {
        
        
        return getLocalLateRate(nativePtr);
    }

    private native float getLocalLossRate(long nativePtr);
    @Override
    synchronized public float getLocalLossRate()  {
        
        
        return getLocalLossRate(nativePtr);
    }

    private native float getReceiverInterarrivalJitter(long nativePtr);
    @Override
    synchronized public float getReceiverInterarrivalJitter()  {
        
        
        return getReceiverInterarrivalJitter(nativePtr);
    }

    private native float getReceiverLossRate(long nativePtr);
    @Override
    synchronized public float getReceiverLossRate()  {
        
        
        return getReceiverLossRate(nativePtr);
    }

    private native float getRoundTripDelay(long nativePtr);
    @Override
    synchronized public float getRoundTripDelay()  {
        
        
        return getRoundTripDelay(nativePtr);
    }

    private native float getRtcpDownloadBandwidth(long nativePtr);
    @Override
    synchronized public float getRtcpDownloadBandwidth()  {
        
        
        return getRtcpDownloadBandwidth(nativePtr);
    }

    private native float getRtcpUploadBandwidth(long nativePtr);
    @Override
    synchronized public float getRtcpUploadBandwidth()  {
        
        
        return getRtcpUploadBandwidth(nativePtr);
    }

    private native int getRtpCumPacketLoss(long nativePtr);
    @Override
    synchronized public int getRtpCumPacketLoss()  {
        
        
        return getRtpCumPacketLoss(nativePtr);
    }

    private native int getRtpDiscarded(long nativePtr);
    @Override
    synchronized public int getRtpDiscarded()  {
        
        
        return getRtpDiscarded(nativePtr);
    }

    private native int getRtpHwRecv(long nativePtr);
    @Override
    synchronized public int getRtpHwRecv()  {
        
        
        return getRtpHwRecv(nativePtr);
    }

    private native int getRtpPacketRecv(long nativePtr);
    @Override
    synchronized public int getRtpPacketRecv()  {
        
        
        return getRtpPacketRecv(nativePtr);
    }

    private native int getRtpPacketSent(long nativePtr);
    @Override
    synchronized public int getRtpPacketSent()  {
        
        
        return getRtpPacketSent(nativePtr);
    }

    private native int getRtpRecv(long nativePtr);
    @Override
    synchronized public int getRtpRecv()  {
        
        
        return getRtpRecv(nativePtr);
    }

    private native int getRtpSent(long nativePtr);
    @Override
    synchronized public int getRtpSent()  {
        
        
        return getRtpSent(nativePtr);
    }

    private native float getSenderInterarrivalJitter(long nativePtr);
    @Override
    synchronized public float getSenderInterarrivalJitter()  {
        
        
        return getSenderInterarrivalJitter(nativePtr);
    }

    private native float getSenderLossRate(long nativePtr);
    @Override
    synchronized public float getSenderLossRate()  {
        
        
        return getSenderLossRate(nativePtr);
    }

    private native int getSrtpSource(long nativePtr);
    @Override @NonNull
    synchronized public MediaEncryption getSrtpSource()  {
        
        
        return MediaEncryption.fromInt(getSrtpSource(nativePtr));
    }

    private native int getSrtpSuite(long nativePtr);
    @Override @NonNull
    synchronized public SrtpSuite getSrtpSuite()  {
        
        
        return SrtpSuite.fromInt(getSrtpSuite(nativePtr));
    }

    private native int getType(long nativePtr);
    @Override
    synchronized public StreamType getType()  {
        
        
        return StreamType.fromInt(getType(nativePtr));
    }

    private native float getUploadBandwidth(long nativePtr);
    @Override
    synchronized public float getUploadBandwidth()  {
        
        
        return getUploadBandwidth(nativePtr);
    }

    private native int getUpnpState(long nativePtr);
    @Override
    synchronized public UpnpState getUpnpState()  {
        
        
        return UpnpState.fromInt(getUpnpState(nativePtr));
    }

    private native String getZrtpAuthTagAlgo(long nativePtr);
    @Override
    synchronized public String getZrtpAuthTagAlgo()  {
        
        
        return getZrtpAuthTagAlgo(nativePtr);
    }

    private native String getZrtpCipherAlgo(long nativePtr);
    @Override
    synchronized public String getZrtpCipherAlgo()  {
        
        
        return getZrtpCipherAlgo(nativePtr);
    }

    private native String getZrtpHashAlgo(long nativePtr);
    @Override
    synchronized public String getZrtpHashAlgo()  {
        
        
        return getZrtpHashAlgo(nativePtr);
    }

    private native String getZrtpKeyAgreementAlgo(long nativePtr);
    @Override
    synchronized public String getZrtpKeyAgreementAlgo()  {
        
        
        return getZrtpKeyAgreementAlgo(nativePtr);
    }

    private native String getZrtpSasAlgo(long nativePtr);
    @Override
    synchronized public String getZrtpSasAlgo()  {
        
        
        return getZrtpSasAlgo(nativePtr);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
