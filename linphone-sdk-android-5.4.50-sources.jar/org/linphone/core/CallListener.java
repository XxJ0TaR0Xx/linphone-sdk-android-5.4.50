/*
CallListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* That class holds all the callbacks which are called by {@link Call} objects. <br/>
* <br/>
* Use {@link Factory#createCallCbs} to create an instance. Then, call the<br/>
* callback setters on the events you need to monitor and pass the object to a<br/>
* {@link Call} instance through {@link Call#addListener}. <br/>
*/
public interface CallListener {
    /**
    * Callback for being notified of received DTMFs. <br/>
    * <br/>
    * @param call {@link Call} object that received the dtmf   <br/>
    * @param dtmf The ascii code of the dtmf <br/>
    */
    public void onDtmfReceived(@NonNull Call call, int dtmf);

    /**
    * GoClear ACK sent callback. <br/>
    * <br/>
    * @param call the {@link Call} on which the GoClear ACK was sent.   <br/>
    */
    public void onGoclearAckSent(@NonNull Call call);

    /**
    * Call security level downgraded callback. <br/>
    * <br/>
    * @param call {@link Call} object whose security level is downgraded.   <br/>
    */
    public void onSecurityLevelDowngraded(@NonNull Call call);

    /**
    * Call encryption changed callback. <br/>
    * <br/>
    * @param call {@link Call} object whose encryption is changed.   <br/>
    * @param on Whether encryption is activated. <br/>
    * @param authenticationToken An authentication_token, currently set for ZRTP kind<br/>
    * of encryption only.   <br/>
    */
    public void onEncryptionChanged(@NonNull Call call, boolean on, @Nullable String authenticationToken);

    /**
    * Call authentication token verified callback. <br/>
    * <br/>
    * @param call {@link Call} object whose authentication is verified.   <br/>
    * @param verified Whether encryption is verified. <br/>
    */
    public void onAuthenticationTokenVerified(@NonNull Call call, boolean verified);

    /**
    * Call send master key changed callback. <br/>
    * <br/>
    * @param call {@link Call} object whose encryption is changed.   <br/>
    * @param sendMasterKey The send master key of the SRTP session.   <br/>
    */
    public void onSendMasterKeyChanged(@NonNull Call call, @Nullable String sendMasterKey);

    /**
    * Call receive master key changed callback. <br/>
    * <br/>
    * @param call {@link Call} object whose encryption is changed.   <br/>
    * @param receiveMasterKey The receive master key of the SRTP session.   <br/>
    */
    public void onReceiveMasterKeyChanged(@NonNull Call call, @Nullable String receiveMasterKey);

    /**
    * Callback for receiving info messages. <br/>
    * <br/>
    * @param call {@link Call} whose info message belongs to.   <br/>
    * @param message {@link InfoMessage} object.   <br/>
    */
    public void onInfoMessageReceived(@NonNull Call call, @NonNull InfoMessage message);

    /**
    * Call state notification callback. <br/>
    * <br/>
    * @param call {@link Call} whose state is changed.   <br/>
    * @param state The new {@link Call#State} of the call <br/>
    * @param message An informational message about the state.   <br/>
    */
    public void onStateChanged(@NonNull Call call, Call.State state, @NonNull String message);

    /**
    * Callback for receiving quality statistics for calls. <br/>
    * <br/>
    * @param call {@link Call} object whose statistics are notified   <br/>
    * @param stats {@link CallStats} object   <br/>
    */
    public void onStatsUpdated(@NonNull Call call, @NonNull CallStats stats);

    /**
    * Callback for notifying progresses of transfers. <br/>
    * <br/>
    * @param call {@link Call} that was transferred   <br/>
    * @param state The {@link Call#State} of the call to transfer target at the far<br/>
    * end. <br/>
    */
    public void onTransferStateChanged(@NonNull Call call, Call.State state);

    /**
    * Callback for notifying when a call transfer (refer) is requested. <br/>
    * <br/>
    * @param call {@link Call} associated with the transfer request.   <br/>
    * @param referTo The target {@link Address} to which the call is being<br/>
    * transferred.   <br/>
    */
    public void onReferRequested(@NonNull Call call, @NonNull Address referTo);

    /**
    * Callback for notifying the processing SIP ACK messages. <br/>
    * <br/>
    * @param call {@link Call} for which an ACK is being received or sent   <br/>
    * @param ack the ACK {@link Headers}   <br/>
    * @param isReceived if true this ACK is an incoming one, otherwise it is an ACK<br/>
    * about to be sent. <br/>
    */
    public void onAckProcessing(@NonNull Call call, @NonNull Headers ack, boolean isReceived);

    /**
    * Callback for notifying a received TMMBR. <br/>
    * <br/>
    * @param call LinphoneCall for which the TMMBR has changed   <br/>
    * @param streamIndex the index of the current stream <br/>
    * @param tmmbr the value of the received TMMBR <br/>
    */
    public void onTmmbrReceived(@NonNull Call call, int streamIndex, int tmmbr);

    /**
    * Callback for notifying a snapshot taken. <br/>
    * <br/>
    * @param call LinphoneCall for which the snapshot was taken   <br/>
    * @param filePath the name of the saved file   <br/>
    */
    public void onSnapshotTaken(@NonNull Call call, @NonNull String filePath);

    /**
    * Callback to notify a next video frame has been decoded. <br/>
    * <br/>
    * @param call LinphoneCall for which the next video frame has been decoded   <br/>
    */
    public void onNextVideoFrameDecoded(@NonNull Call call);

    /**
    * Callback to notify that the camera is not working and has been changed to "No<br/>
    * Webcam". <br/>
    * <br/>
    * A camera is detected as mis-functionning as soon as it outputs no frames at all<br/>
    * during a period of 5 seconds. This check is only performed on desktop<br/>
    * platforms, in the purpose of notifying camera failures, for example if when a<br/>
    * usb cable gets disconnected.<br/>
    * @param call LinphoneCall for which the next video frame has been decoded   <br/>
    * @param cameraName the name of the non-working camera   <br/>
    */
    public void onCameraNotWorking(@NonNull Call call, @NonNull String cameraName);

    /**
    * Callback to notify that there are errors from the video rendering. <br/>
    * <br/>
    * The error code depends of the implementation.<br/>
    * @param call LinphoneCall   <br/>
    * @param errorCode error code from render. It depends of the renderer. <br/>
    */
    public void onVideoDisplayErrorOccurred(@NonNull Call call, int errorCode);

    /**
    * Callback to notify that the audio device has been changed. <br/>
    * <br/>
    * @param call LinphoneCall for which the audio device has changed   <br/>
    * @param audioDevice the new audio device used for this call   <br/>
    */
    public void onAudioDeviceChanged(@NonNull Call call, @NonNull AudioDevice audioDevice);

    /**
    * Callback to notify that the call is being recorded by the remote. <br/>
    * <br/>
    * @param call LinphoneCall for which the audio is recorded   <br/>
    * @param recording true if the call is being recorded by the remote, false<br/>
    * otherwise <br/>
    */
    public void onRemoteRecording(@NonNull Call call, boolean recording);

    /**
    * Callback to notify that Baudot tones have been detected in the audio received<br/>
    * from the remote. <br/>
    * <br/>
    * @param call LinphoneCall where Baudot tones have been detected   <br/>
    * @param standard The Baudot standard of the detected tones. <br/>
    */
    public void onBaudotDetected(@NonNull Call call, BaudotStandard standard);

}