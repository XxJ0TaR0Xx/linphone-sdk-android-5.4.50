/*
SupportLevel.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* <br/>
*/
public enum SupportLevel {
    /**
    * No support for the feature. <br/>
    * <br/>
    */
    NoSupport(0),

    /**
    * Optional support for the feature. <br/>
    * <br/>
    */
    Optional(1),

    /**
    * Mandatory support for the feature. <br/>
    * <br/>
    */
    Mandatory(2);

    protected final int mValue;

    private SupportLevel (int value) {
        mValue = value;
    }

    static public SupportLevel fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return NoSupport;
        case 1: return Optional;
        case 2: return Mandatory;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for SupportLevel");
        }
    }
    
    static protected SupportLevel[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        SupportLevel[] enumArray = new SupportLevel[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = SupportLevel.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(SupportLevel[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
