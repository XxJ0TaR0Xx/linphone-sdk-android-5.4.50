/*
AccountListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for the handling of {@link Account} objects. <br/>
* <br/>
*/
public interface AccountListener {
    /**
    * Callback for notifying when a registration state has changed for the account. <br/>
    * <br/>
    * @param account LinphoneAccount object whose registration state changed.   <br/>
    * @param state The current LinphoneRegistrationState. <br/>
    * @param message A non null informational message about the state.   <br/>
    */
    public void onRegistrationStateChanged(@NonNull Account account, RegistrationState state, @NonNull String message);

    /**
    * Callback for notifying a message waiting indication change for the account. <br/>
    * <br/>
    * @param account LinphoneAccount object whose message waiting indication changed.<br/>
    *   <br/>
    * @param mwi The current LinphoneMessageWaitingIndication.   <br/>
    */
    public void onMessageWaitingIndicationChanged(@NonNull Account account, @NonNull MessageWaitingIndication mwi);

    /**
    * Callback for notifying that the conference information list of an account has<br/>
    * been updated. <br/>
    * <br/>
    * This is generally the case when retrieving conference informations from a CCMP<br/>
    * server as the request might take a little bit of time to be responded. In order<br/>
    * to allow the core to perform its tasks while the conference information are<br/>
    * being sent, the core will send first the list of conference information that<br/>
    * are locally stored and then this callback is called once it is updated with the<br/>
    * information received by the CCMP server. <br/>
    * @param account {@link Account} object whose message waiting indication changed.<br/>
    *   <br/>
    * @param infos The updated list of conference informations    <br/>
    */
    public void onConferenceInformationUpdated(@NonNull Account account, @NonNull ConferenceInfo[] infos);

}