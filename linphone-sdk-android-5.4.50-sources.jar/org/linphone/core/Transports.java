/*
Transports.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* SIP transports & ports configuration object. <br/>
* <br/>
* Indicates which transport among UDP, TCP, TLS and DTLS should be enabled and if<br/>
* so on which port to listen. You can use special values like<br/>
* LC_SIP_TRANSPORT_DISABLED (0), LC_SIP_TRANSPORT_RANDOM (-1) and<br/>
* LC_SIP_TRANSPORT_DONTBIND (-2).<br/>
* Once configuration is complete, use {@link Core#setTransports} to apply it.<br/>
* This will be saved in configuration file so you don't have to do it each time<br/>
* the {@link Core} starts. <br/>
*/
public interface Transports {
    /**
    * Gets the DTLS port in the {@link Transports} object. <br/>
    * <br/>
    * @return the DTLS port <br/>
    */
    public int getDtlsPort();

    /**
    * Sets the DTLS port in the {@link Transports} object. <br/>
    * <br/>
    * @param port the DTLS port <br/>
    */
    public void setDtlsPort(int port);

    /**
    * Gets the TCP port in the {@link Transports} object. <br/>
    * <br/>
    * @return the TCP port <br/>
    */
    public int getTcpPort();

    /**
    * Sets the TCP port in the {@link Transports} object. <br/>
    * <br/>
    * @param port the TCP port <br/>
    */
    public void setTcpPort(int port);

    /**
    * Gets the TLS port in the {@link Transports} object. <br/>
    * <br/>
    * @return the TLS port <br/>
    */
    public int getTlsPort();

    /**
    * Sets the TLS port in the {@link Transports} object. <br/>
    * <br/>
    * @param port the TLS port <br/>
    */
    public void setTlsPort(int port);

    /**
    * Gets the UDP port in the {@link Transports} object. <br/>
    * <br/>
    * @return the UDP port <br/>
    */
    public int getUdpPort();

    /**
    * Sets the UDP port in the {@link Transports} object. <br/>
    * <br/>
    * @param port the UDP port <br/>
    */
    public void setUdpPort(int port);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class TransportsImpl implements Transports {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected TransportsImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native int getDtlsPort(long nativePtr);
    @Override
    synchronized public int getDtlsPort()  {
        
        
        return getDtlsPort(nativePtr);
    }

    private native void setDtlsPort(long nativePtr, int port);
    @Override
    synchronized public void setDtlsPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDtlsPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDtlsPort(nativePtr, port);
    }

    private native int getTcpPort(long nativePtr);
    @Override
    synchronized public int getTcpPort()  {
        
        
        return getTcpPort(nativePtr);
    }

    private native void setTcpPort(long nativePtr, int port);
    @Override
    synchronized public void setTcpPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTcpPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTcpPort(nativePtr, port);
    }

    private native int getTlsPort(long nativePtr);
    @Override
    synchronized public int getTlsPort()  {
        
        
        return getTlsPort(nativePtr);
    }

    private native void setTlsPort(long nativePtr, int port);
    @Override
    synchronized public void setTlsPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setTlsPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setTlsPort(nativePtr, port);
    }

    private native int getUdpPort(long nativePtr);
    @Override
    synchronized public int getUdpPort()  {
        
        
        return getUdpPort(nativePtr);
    }

    private native void setUdpPort(long nativePtr, int port);
    @Override
    synchronized public void setUdpPort(int port)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setUdpPort() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setUdpPort(nativePtr, port);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
