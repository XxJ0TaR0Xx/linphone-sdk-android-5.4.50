/*
Account.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that represents a Linphone Account. <br/>
* <br/>
* This object replaces the deprecated {@link ProxyConfig}. Use a {@link AccountParams}<br/>
* object to configure it. <br/>
*/
public interface Account {
    /**
    * Indicates whether AVPF/SAVPF is being used for calls using this account. <br/>
    * <br/>
    * @return true if AVPF/SAVPF is enabled, false otherwise. <br/>
    */
    public boolean isAvpfEnabled();

    /**
    * Returns the list of call logs for a given account. <br/>
    * <br/>
    * This list must be freed after use. <br/>
    * @return The list of call logs .     <br/>
    */
    @NonNull
    public CallLog[] getCallLogs();

    /**
    * Returns the list of chat rooms for a given account. <br/>
    * <br/>
    * @return The list of chat rooms .   <br/>
    */
    @NonNull
    public ChatRoom[] getChatRooms();

    /**
    * Returns the list of conference information stored locally for a given account. <br/>
    * <br/>
    * This list must be freed after use. <br/>
    * @return The list of call logs .   <br/>
    * warning: this method also start the synchronization with the CCMP server,<br/>
    * should it be defined in the #AccountParams. The application may want to wait<br/>
    * for the callback conference_information_updated to get a up-to-date list of<br/>
    * conferences <br/>
    */
    @NonNull
    public ConferenceInfo[] getConferenceInformationList();

    /**
    * Return the contact address of the account. <br/>
    * <br/>
    * @return a {@link Address} correspong to the contact address of the account.   <br/>
    */
    @Nullable
    public Address getContactAddress();

    /**
    * Set the contact address for the account. <br/>
    * <br/>
    * A client application should not use this function, as the Contact address is<br/>
    * provided by the registrar in the 200 Ok. This function is mainly intended for<br/>
    * server applications. <br/>
    * @param addr a {@link Address} to use as contact.   <br/>
    */
    public void setContactAddress(@Nullable Address addr);

    /**
    * Get the {@link Core} object to which is associated the {@link Account}. <br/>
    * <br/>
    * @return The {@link Core} object to which is associated the {@link Account}.   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Get the dependency of a {@link Account}. <br/>
    * <br/>
    * @return The account this one is dependent upon, or null if not marked<br/>
    * dependent.   <br/>
    */
    @Nullable
    public Account getDependency();

    /**
    * Mark this account as being dependent on the given one. <br/>
    * <br/>
    * The dependency must refer to an account previously added to the core and which<br/>
    * idkey property is defined.<br/>
    * see: {@link AccountParams#setIdkey}<br/>
    * The account marked as dependent will wait for successful registration on its<br/>
    * dependency before triggering its own.<br/>
    * Once registered, both accounts will share the same contact address (the<br/>
    * 'dependency' one).<br/>
    * This mecanism must be enabled before the account is added to the core<br/>
    * @param dependsOn The {@link Account} this one shall be depending on.   <br/>
    */
    public void setDependency(@Nullable Account dependsOn);

    /**
    * Get the reason why registration failed when the account state is<br/>
    * LinphoneRegistrationFailed. <br/>
    * <br/>
    * @return The {@link Reason} why registration failed for this account. <br/>
    */
    public Reason getError();

    /**
    * Get detailed information why registration failed when the account state is<br/>
    * LinphoneRegistrationFailed. <br/>
    * <br/>
    * @return The {@link ErrorInfo} explaining why registration failed for this<br/>
    * account.   <br/>
    */
    @NonNull
    public ErrorInfo getErrorInfo();

    /**
    * Returns the missed calls count for a given account. <br/>
    * <br/>
    * @return The missed calls count. <br/>
    */
    public int getMissedCallsCount();

    /**
    * Get the {@link AccountParams} as read-only object. <br/>
    * <br/>
    * To make changes, clone the returned object using {@link AccountParams#clone}<br/>
    * method, make your changes on it and apply them using with {@link #setParams}. <br/>
    * @return The {@link AccountParams} attached to this account.   <br/>
    */
    @NonNull
    public AccountParams getParams();

    /**
    * Set the {@link AccountParams} used by this {@link Account}. <br/>
    * <br/>
    * @param params The {@link AccountParams} object.   <br/>
    */
    public int setParams(@NonNull AccountParams params);

    /**
    * Get the registration state of the given account. <br/>
    * <br/>
    * @return The {@link RegistrationState} of the account. <br/>
    */
    public RegistrationState getState();

    /**
    * Get the transport from either service route, route or addr. <br/>
    * <br/>
    * @return The transport as a string (I.E udp, tcp, tls, dtls). <br/>
    * @deprecated 01/03/2021 Use Linphone_account_params_get_transport() instead. <br/>
    */
    @Deprecated
    public TransportType getTransport();

    /**
    * Returns the unread chat message count for a given account. <br/>
    * <br/>
    * @return The unread chat message count. <br/>
    */
    public int getUnreadChatMessageCount();

    /**
    * Set one custom parameter to this {@link Account}. <br/>
    * <br/>
    * @param key key of the searched parameter.   <br/>
    * @param value value of the searched parameter.   <br/>
    */
    public void addCustomParam(@NonNull String key, @NonNull String value);

    /**
    * Deletes all the call logs related to this account from the database. <br/>
    * <br/>
    */
    public void clearCallLogs();

    /**
    * Instantiate a new account with values from source. <br/>
    * <br/>
    * @return The newly created {@link Account} object.   <br/>
    */
    @NonNull
    public Account clone();

    /**
    * Returns a filtered list of chat rooms for a given account. <br/>
    * <br/>
    * @param filter the criteria a chat room must meet somehow (subject, participant<br/>
    * address, friend's name).   <br/>
    * @return The list of chat rooms .     <br/>
    */
    @NonNull
    public ChatRoom[] filterChatRooms(@NonNull String filter);

    /**
    * Find authentication info matching account, if any, similarly to<br/>
    * linphone_core_find_auth_info. <br/>
    * <br/>
    * @return a {@link AuthInfo} matching account criteria if possible, null if<br/>
    * nothing can be found.   <br/>
    */
    @Nullable
    public AuthInfo findAuthInfo();

    /**
    * Returns the list of call logs for a given account. <br/>
    * <br/>
    * This list must be freed after use. <br/>
    * @param remoteAddress the {@link Address} object to filter call logs.   <br/>
    * @return The list of filtered call logs .     <br/>
    */
    @NonNull
    public CallLog[] getCallLogsForAddress(@NonNull Address remoteAddress);

    /**
    * Obtain the value of a header sent by the server in last answer to REGISTER. <br/>
    * <br/>
    * @param headerName The header name for which to fetch corresponding value.   <br/>
    * @return The value of the queried header.   <br/>
    */
    @Nullable
    public String getCustomHeader(@NonNull String headerName);

    /**
    * Get the custom parameter with key to this {@link Account}. <br/>
    * <br/>
    * @param key key of the searched parameter.   <br/>
    * @return The value of the parameter with key if found or an empty string<br/>
    * otherwise.   <br/>
    */
    @NonNull
    public String getCustomParam(@NonNull String key);

    /**
    * Detect if the given input is a phone number or not. <br/>
    * <br/>
    * @param username The string to parse.   <br/>
    * @return true if input is a phone number, false otherwise. <br/>
    */
    public boolean isPhoneNumber(@NonNull String username);

    /**
    * Normalize a human readable phone number into a basic string. <br/>
    * <br/>
    * 888-444-222 becomes 888444222 or +33888444222 depending on the {@link Account}<br/>
    * object. This function will always generate a normalized username if input is a<br/>
    * phone number. <br/>
    * @param username The string to parse.   <br/>
    * @return null if input is an invalid phone number, normalized phone number from<br/>
    * username input otherwise.      <br/>
    */
    @Nullable
    public String normalizePhoneNumber(@NonNull String username);

    /**
    * Normalize a human readable sip uri into a fully qualified LinphoneAddress. <br/>
    * <br/>
    * A sip address should look like DisplayName <sip:username@domain:port> .<br/>
    * Basically this function performs the following tasks<br/>
    * The result is a syntactically correct SIP address. <br/>
    * @param username The string to parse.   <br/>
    * @return null if invalid input, normalized sip address otherwise.     <br/>
    */
    @Nullable
    public Address normalizeSipUri(@NonNull String username);

    /**
    * Prevent an account from refreshing its registration. <br/>
    * <br/>
    * This is useful to let registrations to expire naturally (or) when the<br/>
    * application wants to keep control on when refreshes are sent. However,<br/>
    * linphone_core_set_network_reachable(lc,true) will always request the accounts<br/>
    * to refresh their registrations. The refreshing operations can be resumed with<br/>
    * {@link #refreshRegister}. <br/>
    */
    public void pauseRegister();

    /**
    * Refresh a proxy registration. <br/>
    * <br/>
    * This is useful if for example you resuming from suspend, thus IP address may<br/>
    * have changed. <br/>
    */
    public void refreshRegister();

    /**
    * Re-sets the number of missed calls for this account to 0. <br/>
    * <br/>
    */
    public void resetMissedCallsCount();

    /**
    * Set the value of a custom header sent to the server in REGISTERs request. <br/>
    * <br/>
    * @param headerName The header name.   <br/>
    * @param headerValue The header value.   <br/>
    */
    public void setCustomHeader(@NonNull String headerName, @Nullable String headerValue);

    /**
    * Create a new {@link Account} with a Proxy config backpointer. <br/>
    * <br/>
    * This is only intended to be used while keeping a backward compatibility with<br/>
    * proxy config. <br/>
    * @param lc The {@link Core} object.   <br/>
    * @param params The {@link AccountParams} object.   <br/>
    * @param config The {@link ProxyConfig} object.   <br/>
    * @return The newly created {@link Account} object.   <br/>
    */
    @NonNull
    public Account newWithConfig(@Nullable Core lc, @NonNull AccountParams params, @Nullable ProxyConfig config);

    /**
    */
    public void addListener(AccountListener listener);

    /**
    */
    public void removeListener(AccountListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class AccountImpl implements Account {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected AccountImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native boolean isAvpfEnabled(long nativePtr);
    @Override
    synchronized public boolean isAvpfEnabled()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call isAvpfEnabled() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return isAvpfEnabled(nativePtr);
    }

    private native CallLog[] getCallLogs(long nativePtr);
    @Override @NonNull
    synchronized public CallLog[] getCallLogs()  {
        
        
        return getCallLogs(nativePtr);
    }

    private native ChatRoom[] getChatRooms(long nativePtr);
    @Override @NonNull
    synchronized public ChatRoom[] getChatRooms()  {
        
        
        return getChatRooms(nativePtr);
    }

    private native ConferenceInfo[] getConferenceInformationList(long nativePtr);
    @Override @NonNull
    synchronized public ConferenceInfo[] getConferenceInformationList()  {
        
        
        return getConferenceInformationList(nativePtr);
    }

    private native Address getContactAddress(long nativePtr);
    @Override @Nullable
    synchronized public Address getContactAddress()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getContactAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)getContactAddress(nativePtr);
    }

    private native void setContactAddress(long nativePtr, Address addr);
    @Override
    synchronized public void setContactAddress(@Nullable Address addr)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setContactAddress() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setContactAddress(nativePtr, addr);
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCore() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Core)getCore(nativePtr);
    }

    private native Account getDependency(long nativePtr);
    @Override @Nullable
    synchronized public Account getDependency()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDependency() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Account)getDependency(nativePtr);
    }

    private native void setDependency(long nativePtr, Account dependsOn);
    @Override
    synchronized public void setDependency(@Nullable Account dependsOn)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setDependency() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setDependency(nativePtr, dependsOn);
    }

    private native int getError(long nativePtr);
    @Override
    synchronized public Reason getError()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getError() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return Reason.fromInt(getError(nativePtr));
    }

    private native ErrorInfo getErrorInfo(long nativePtr);
    @Override @NonNull
    synchronized public ErrorInfo getErrorInfo()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getErrorInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (ErrorInfo)getErrorInfo(nativePtr);
    }

    private native int getMissedCallsCount(long nativePtr);
    @Override
    synchronized public int getMissedCallsCount()  {
        
        
        return getMissedCallsCount(nativePtr);
    }

    private native AccountParams getParams(long nativePtr);
    @Override @NonNull
    synchronized public AccountParams getParams()  {
        
        
        return (AccountParams)getParams(nativePtr);
    }

    private native int setParams(long nativePtr, AccountParams params);
    @Override
    synchronized public int setParams(@NonNull AccountParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return setParams(nativePtr, params);
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public RegistrationState getState()  {
        
        
        return RegistrationState.fromInt(getState(nativePtr));
    }

    private native int getTransport(long nativePtr);
    @Override
    synchronized public TransportType getTransport()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getTransport() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return TransportType.fromInt(getTransport(nativePtr));
    }

    private native int getUnreadChatMessageCount(long nativePtr);
    @Override
    synchronized public int getUnreadChatMessageCount()  {
        
        
        return getUnreadChatMessageCount(nativePtr);
    }

    private native void addCustomParam(long nativePtr, String key, String value);
    @Override
    synchronized public void addCustomParam(@NonNull String key, @NonNull String value)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call addCustomParam() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        addCustomParam(nativePtr, key, value);
    }

    private native void clearCallLogs(long nativePtr);
    @Override
    synchronized public void clearCallLogs()  {
        
        
        clearCallLogs(nativePtr);
    }

    private native Account clone(long nativePtr);
    @Override @NonNull
    synchronized public Account clone()  {
        
        
        return (Account)clone(nativePtr);
    }

    private native ChatRoom[] filterChatRooms(long nativePtr, String filter);
    @Override @NonNull
    synchronized public ChatRoom[] filterChatRooms(@NonNull String filter)  {
        
        
        return filterChatRooms(nativePtr, filter);
    }

    private native AuthInfo findAuthInfo(long nativePtr);
    @Override @Nullable
    synchronized public AuthInfo findAuthInfo()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call findAuthInfo() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (AuthInfo)findAuthInfo(nativePtr);
    }

    private native CallLog[] getCallLogsForAddress(long nativePtr, Address remoteAddress);
    @Override @NonNull
    synchronized public CallLog[] getCallLogsForAddress(@NonNull Address remoteAddress)  {
        
        
        return getCallLogsForAddress(nativePtr, remoteAddress);
    }

    private native String getCustomHeader(long nativePtr, String headerName);
    @Override @Nullable
    synchronized public String getCustomHeader(@NonNull String headerName)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCustomHeader(nativePtr, headerName);
    }

    private native String getCustomParam(long nativePtr, String key);
    @Override @NonNull
    synchronized public String getCustomParam(@NonNull String key)  {
        
        
        return getCustomParam(nativePtr, key);
    }

    private native boolean isPhoneNumber(long nativePtr, String username);
    @Override
    synchronized public boolean isPhoneNumber(@NonNull String username)  {
        
        
        return isPhoneNumber(nativePtr, username);
    }

    private native String normalizePhoneNumber(long nativePtr, String username);
    @Override @Nullable
    synchronized public String normalizePhoneNumber(@NonNull String username)  {
        
        
        return normalizePhoneNumber(nativePtr, username);
    }

    private native Address normalizeSipUri(long nativePtr, String username);
    @Override @Nullable
    synchronized public Address normalizeSipUri(@NonNull String username)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call normalizeSipUri() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Address)normalizeSipUri(nativePtr, username);
    }

    private native void pauseRegister(long nativePtr);
    @Override
    synchronized public void pauseRegister()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call pauseRegister() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        pauseRegister(nativePtr);
    }

    private native void refreshRegister(long nativePtr);
    @Override
    synchronized public void refreshRegister()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call refreshRegister() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        refreshRegister(nativePtr);
    }

    private native void resetMissedCallsCount(long nativePtr);
    @Override
    synchronized public void resetMissedCallsCount()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call resetMissedCallsCount() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        resetMissedCallsCount(nativePtr);
    }

    private native void setCustomHeader(long nativePtr, String headerName, String headerValue);
    @Override
    synchronized public void setCustomHeader(@NonNull String headerName, @Nullable String headerValue)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setCustomHeader() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setCustomHeader(nativePtr, headerName, headerValue);
    }

    private native Account newWithConfig(long nativePtr, Core lc, AccountParams params, ProxyConfig config);
    @Override @NonNull
    synchronized public Account newWithConfig(@Nullable Core lc, @NonNull AccountParams params, @Nullable ProxyConfig config)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newWithConfig() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Account)newWithConfig(nativePtr, lc, params, config);
    }

    private native void addListener(long nativePtr, AccountListener listener);
    @Override
    synchronized public void addListener(AccountListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, AccountListener listener);
    @Override
    synchronized public void removeListener(AccountListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
