/*
ZrtpKeyAgreement.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* Enum describing the ZRTP key exchange algorithns. <br/>
* <br/>
*/
public enum ZrtpKeyAgreement {
    /**
    * <br/>
    */
    Invalid(0),

    /**
    * <br/>
    */
    Dh2K(1),

    /**
    * <br/>
    */
    Dh3K(2),

    /**
    * <br/>
    */
    Ec25(3),

    /**
    * <br/>
    */
    Ec38(4),

    /**
    * <br/>
    */
    Ec52(5),

    /**
    * <br/>
    */
    X255(6),

    /**
    * <br/>
    */
    X448(7),

    /**
    * <br/>
    */
    K255(8),

    /**
    * <br/>
    */
    K448(9),

    /**
    * <br/>
    */
    Kyb1(10),

    /**
    * <br/>
    */
    Kyb2(11),

    /**
    * <br/>
    */
    Kyb3(12),

    /**
    * <br/>
    */
    Hqc1(13),

    /**
    * <br/>
    */
    Hqc2(14),

    /**
    * <br/>
    */
    Hqc3(15),

    /**
    * <br/>
    */
    K255Kyb512(16),

    /**
    * <br/>
    */
    K255Hqc128(17),

    /**
    * <br/>
    */
    K448Kyb1024(18),

    /**
    * <br/>
    */
    K448Hqc256(19),

    /**
    * <br/>
    */
    K255Kyb512Hqc128(20),

    /**
    * <br/>
    */
    K448Kyb1024Hqc256(21),

    /**
    * <br/>
    */
    Mlk1(22),

    /**
    * <br/>
    */
    Mlk2(23),

    /**
    * <br/>
    */
    Mlk3(24),

    /**
    * <br/>
    */
    K255Mlk512(25),

    /**
    * <br/>
    */
    K448Mlk1024(26);

    protected final int mValue;

    private ZrtpKeyAgreement (int value) {
        mValue = value;
    }

    static public ZrtpKeyAgreement fromInt(int value) throws RuntimeException {
        switch(value) {
        case 0: return Invalid;
        case 1: return Dh2K;
        case 2: return Dh3K;
        case 3: return Ec25;
        case 4: return Ec38;
        case 5: return Ec52;
        case 6: return X255;
        case 7: return X448;
        case 8: return K255;
        case 9: return K448;
        case 10: return Kyb1;
        case 11: return Kyb2;
        case 12: return Kyb3;
        case 13: return Hqc1;
        case 14: return Hqc2;
        case 15: return Hqc3;
        case 16: return K255Kyb512;
        case 17: return K255Hqc128;
        case 18: return K448Kyb1024;
        case 19: return K448Hqc256;
        case 20: return K255Kyb512Hqc128;
        case 21: return K448Kyb1024Hqc256;
        case 22: return Mlk1;
        case 23: return Mlk2;
        case 24: return Mlk3;
        case 25: return K255Mlk512;
        case 26: return K448Mlk1024;
        default:
            throw new RuntimeException("Unhandled enum value " + value + " for ZrtpKeyAgreement");
        }
    }
    
    static protected ZrtpKeyAgreement[] fromIntArray(int[] values) throws RuntimeException {
        int arraySize = values.length;
        ZrtpKeyAgreement[] enumArray = new ZrtpKeyAgreement[arraySize];
        for (int i = 0; i < arraySize; i++) {
            enumArray[i] = ZrtpKeyAgreement.fromInt(values[i]);
        }
        return enumArray;
    }
    
    static protected int[] toIntArray(ZrtpKeyAgreement[] values) throws RuntimeException {
        int arraySize = values.length;
        int[] intArray = new int[arraySize];
        for (int i = 0; i < arraySize; i++) {
            intArray[i] = values[i].toInt();
        }
        return intArray;
    }

    public int toInt() {
        return mValue;
    }
}
