/*
Player.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Player interface. <br/>
* <br/>
*/
public interface Player {
    public enum State {
        /**
        * No file is opened for playing. <br/>
        * <br/>
        */
        Closed(0),

        /**
        * The player is paused. <br/>
        * <br/>
        */
        Paused(1),

        /**
        * The player is playing. <br/>
        * <br/>
        */
        Playing(2);

        protected final int mValue;

        private State (int value) {
            mValue = value;
        }

        static public State fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Closed;
            case 1: return Paused;
            case 2: return Playing;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for State");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Returns the {@link Core} object managing this player's call, if any. <br/>
    * <br/>
    * @return the {@link Core} object associated   <br/>
    */
    @NonNull
    public Core getCore();

    /**
    * Get the current position in the opened file. <br/>
    * <br/>
    * @return The current position in the opened file <br/>
    */
    public int getCurrentPosition();

    /**
    * Get the duration of the opened file. <br/>
    * <br/>
    * @return The duration of the opened file <br/>
    */
    public int getDuration();

    /**
    * Returns whether the file has video and if it can be displayed. <br/>
    * <br/>
    * @return true if file has video and it can be displayed, false otherwise <br/>
    */
    public boolean getIsVideoAvailable();

    /**
    * Get the current state of a player. <br/>
    * <br/>
    * @return The current {@link State} of the player. <br/>
    */
    public Player.State getState();

    /**
    * Get the volume gain of the player. <br/>
    * <br/>
    * @return Percentage of the gain. Valid values are in [ 0.0 : 1.0 ]. <br/>
    */
    public float getVolumeGain();

    /**
    * Set the volume gain of the player. <br/>
    * <br/>
    * @param gain Percentage of the gain. Valid values are in [ 0.0 : 1.0 ]. <br/>
    */
    public void setVolumeGain(float gain);

    /**
    * Sets a window id to be used to display video if any. <br/>
    * <br/>
    * @param windowId The window id pointer to use.   <br/>
    */
    public void setWindowId(@Nullable Object windowId);

    /**
    * Close the opened file. <br/>
    * <br/>
    */
    public void close();

    /**
    * Create a window id to be used to display video if any. <br/>
    * <br/>
    * A context can be used to prevent Linphone from allocating the container<br/>
    * (#MSOglContextInfo for MSOGL). null if not used.<br/>
    * @param context preallocated Window ID (Used only for MSOGL)   <br/>
    * @return window_id The window id pointer to use.   <br/>
    */
    @Nullable
    public Object createWindowId(@Nullable Object context);

    /**
    * Create a window id to be used to display video if any. <br/>
    * <br/>
    * @return window_id The window id pointer to use.   <br/>
    */
    @Nullable
    public Object createWindowId();

    /**
    * Open a file for playing. <br/>
    * <br/>
    * Actually, only WAVE and MKV/MKA file formats are supported and a limited set of<br/>
    * codecs depending of the selected format. Here are the list of working<br/>
    * combinations:<br/>
    * @param filename The path to the file to open   <br/>
    */
    public int open(@NonNull String filename);

    /**
    * Pause the playing of a file. <br/>
    * <br/>
    * @return 0 on success, a negative value otherwise <br/>
    */
    public int pause();

    /**
    * Seek in an opened file. <br/>
    * <br/>
    * @param timeMs The time we want to go to in the file (in milliseconds). <br/>
    * @return 0 on success, a negative value otherwise. <br/>
    */
    public int seek(int timeMs);

    /**
    * Start playing a file that has been opened with {@link #open}. <br/>
    * <br/>
    * @return 0 on success, a negative value otherwise <br/>
    */
    public int start();

    /**
    */
    public void addListener(PlayerListener listener);

    /**
    */
    public void removeListener(PlayerListener listener);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class PlayerImpl implements Player {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected Core core = null;
    protected boolean _isConst = false;

    protected PlayerImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        core = getCore();
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        
        return (Core)getCore(nativePtr);
    }

    private native int getCurrentPosition(long nativePtr);
    @Override
    synchronized public int getCurrentPosition()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCurrentPosition() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getCurrentPosition(nativePtr);
        }
    }

    private native int getDuration(long nativePtr);
    @Override
    synchronized public int getDuration()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getDuration() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getDuration(nativePtr);
        }
    }

    private native boolean getIsVideoAvailable(long nativePtr);
    @Override
    synchronized public boolean getIsVideoAvailable()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getIsVideoAvailable() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getIsVideoAvailable(nativePtr);
        }
    }

    private native int getState(long nativePtr);
    @Override
    synchronized public Player.State getState()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getState() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return Player.State.fromInt(getState(nativePtr));
        }
    }

    private native float getVolumeGain(long nativePtr);
    @Override
    synchronized public float getVolumeGain()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getVolumeGain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return getVolumeGain(nativePtr);
        }
    }

    private native void setVolumeGain(long nativePtr, float gain);
    @Override
    synchronized public void setVolumeGain(float gain)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setVolumeGain() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setVolumeGain(nativePtr, gain);
        }
    }

    private native void setWindowId(long nativePtr, Object windowId);
    @Override
    synchronized public void setWindowId(@Nullable Object windowId)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setWindowId(nativePtr, windowId);
        }
    }

    private native void close(long nativePtr);
    @Override
    synchronized public void close()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call close() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        close(nativePtr);
        }
    }

    private native Object createWindowId2(long nativePtr, Object context);
    @Override @Nullable
    synchronized public Object createWindowId(@Nullable Object context)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return createWindowId2(nativePtr, context);
        }
    }

    private native Object createWindowId(long nativePtr);
    @Override @Nullable
    synchronized public Object createWindowId()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call createWindowId() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return createWindowId(nativePtr);
        }
    }

    private native int open(long nativePtr, String filename);
    @Override
    synchronized public int open(@NonNull String filename)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call open() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return open(nativePtr, filename);
        }
    }

    private native int pause(long nativePtr);
    @Override
    synchronized public int pause()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call pause() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return pause(nativePtr);
        }
    }

    private native int seek(long nativePtr, int timeMs);
    @Override
    synchronized public int seek(int timeMs)  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call seek() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return seek(nativePtr, timeMs);
        }
    }

    private native int start(long nativePtr);
    @Override
    synchronized public int start()  {
        synchronized(core) { 
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call start() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return start(nativePtr);
        }
    }

    private native void addListener(long nativePtr, PlayerListener listener);
    @Override
    synchronized public void addListener(PlayerListener listener)  {
        
        
        addListener(nativePtr, listener);
    }

    private native void removeListener(long nativePtr, PlayerListener listener);
    @Override
    synchronized public void removeListener(PlayerListener listener)  {
        
        
        removeListener(nativePtr, listener);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
