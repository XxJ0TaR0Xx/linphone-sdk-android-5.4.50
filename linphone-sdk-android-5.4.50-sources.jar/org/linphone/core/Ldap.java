/*
Ldap.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import java.lang.StackTraceElement;
import org.linphone.mediastream.Log;

/**
* Object that represents a LDAP connection. <br/>
* <br/>
* Use a {@link LdapParams} object to configure it.<br/>
* @deprecated 18/11/2024 {@link Ldap} object is no longer used, use {@link RemoteContactDirectory}<br/>
* instead. <br/>
*/
public interface Ldap {
    public enum DebugLevel {
        /**
        * Set OpenLdap verbosity to none. <br/>
        * <br/>
        */
        Off(0),

        /**
        * Set OpenLdap verbosity to debug level. <br/>
        * <br/>
        */
        Verbose(1);

        protected final int mValue;

        private DebugLevel (int value) {
            mValue = value;
        }

        static public DebugLevel fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Off;
            case 1: return Verbose;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for DebugLevel");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum AuthMethod {
        /**
        * Connection without passwords. <br/>
        * <br/>
        */
        Anonymous(0),

        /**
        * Connection with username/password. <br/>
        * <br/>
        */
        Simple(1);

        protected final int mValue;

        private AuthMethod (int value) {
            mValue = value;
        }

        static public AuthMethod fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Anonymous;
            case 1: return Simple;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for AuthMethod");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum CertVerificationMode {
        /**
        * Use default value defined on core. <br/>
        * <br/>
        */
        Default(-1),

        /**
        * Verification is disabled. <br/>
        * <br/>
        */
        Disabled(0),

        /**
        * Verification is enabled. <br/>
        * <br/>
        */
        Enabled(1);

        protected final int mValue;

        private CertVerificationMode (int value) {
            mValue = value;
        }

        static public CertVerificationMode fromInt(int value) throws RuntimeException {
            switch(value) {
            case -1: return Default;
            case 0: return Disabled;
            case 1: return Enabled;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for CertVerificationMode");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    public enum Check {
        /**
        * No error. <br/>
        * <br/>
        */
        Ok(0),

        /**
        * Server field is empty. <br/>
        * <br/>
        */
        ServerEmpty(1),

        /**
        * The server is not an url. <br/>
        * <br/>
        */
        ServerNotUrl(2),

        /**
        * The server doesn't contain a scheme. <br/>
        * <br/>
        */
        ServerNoScheme(4),

        /**
        * The server is not a LDAP scheme. <br/>
        * <br/>
        */
        ServerNotLdap(8),

        /**
        * LDAP over SSL is non-standardized and deprecated: ldaps has been specified. <br/>
        * <br/>
        */
        ServerLdaps(16),

        /**
        * Base Object has been specified. <br/>
        * <br/>
        */
        BaseObjectEmpty(32),

        /**
        * Some required fields are missing. <br/>
        * <br/>
        */
        MissingFields(64);

        protected final int mValue;

        private Check (int value) {
            mValue = value;
        }

        static public Check fromInt(int value) throws RuntimeException {
            switch(value) {
            case 0: return Ok;
            case 1: return ServerEmpty;
            case 2: return ServerNotUrl;
            case 4: return ServerNoScheme;
            case 8: return ServerNotLdap;
            case 16: return ServerLdaps;
            case 32: return BaseObjectEmpty;
            case 64: return MissingFields;
            default:
                throw new RuntimeException("Unhandled enum value " + value + " for Check");
            }
        }

        public int toInt() {
            return mValue;
        }
    };

    /**
    * Get the {@link Core} object to which is associated the {@link Ldap}. <br/>
    * <br/>
    * @return The {@link Core} object to which is associated the {@link Ldap}.   <br/>
    * @deprecated 18/11/2024 {@link Ldap} object is no longer used, use {@link RemoteContactDirectory}<br/>
    * instead. <br/>
    */
    @Deprecated
    @NonNull
    public Core getCore();

    /**
    * Get the index of the {@link Ldap}. <br/>
    * <br/>
    * @return The index of the Ldap <br/>
    * @deprecated 18/11/2024 {@link Ldap} object is no longer used, use {@link RemoteContactDirectory}<br/>
    * instead. <br/>
    */
    @Deprecated
    public int getIndex();

    /**
    * Set the index associated to the {@link Ldap}. <br/>
    * <br/>
    * @param index The index of the Ldap. Can be -1 : it will be determined on save. <br/>
    * @deprecated 18/11/2024 {@link Ldap} object is no longer used, use {@link RemoteContactDirectory}<br/>
    * instead. <br/>
    */
    @Deprecated
    public void setIndex(int index);

    /**
    * Get the {@link LdapParams} as read-only object. <br/>
    * <br/>
    * To make changes, clone the returned object using {@link LdapParams#clone}<br/>
    * method, make your changes on it and apply them using with {@link #setParams}. <br/>
    * @return The {@link LdapParams} attached to this ldap.   <br/>
    * @deprecated 18/11/2024 {@link Ldap} object is no longer used, use {@link RemoteContactDirectory}<br/>
    * instead. <br/>
    */
    @Deprecated
    @NonNull
    public LdapParams getParams();

    /**
    * Set the {@link LdapParams} used by this {@link Ldap}. <br/>
    * <br/>
    * The parameters will be saved in the configuration file.<br/>
    * @param params The {@link LdapParams} object.   <br/>
    * @deprecated 18/11/2024 {@link Ldap} object is no longer used, use {@link RemoteContactDirectory}<br/>
    * instead. <br/>
    */
    @Deprecated
    public void setParams(@NonNull LdapParams params);

    /**
    * Create a new {@link Ldap}, associate it with the {@link LdapParams} and store<br/>
    * it into the configuration file. <br/>
    * <br/>
    * @param lc The {@link Core} object.   <br/>
    * @param params The {@link LdapParams} object.   <br/>
    * @return The newly created {@link Ldap} object.     <br/>
    * @deprecated 18/11/2024 {@link Ldap} object is no longer used, use {@link RemoteContactDirectory}<br/>
    * instead. <br/>
    */
    @Deprecated
    @NonNull
    public Ldap newWithParams(@NonNull Core lc, @NonNull LdapParams params);

    /**
      * Sets the object to store in this object user's data
      * @param data the object to store
      */
    public void setUserData(Object data);

    /**
      * Gets the object stored in this object user's data
      * @return the object store if any, null otherwise
      */
    public Object getUserData();

    /**
      * Gets the native pointer used by this class to make native method calls.
      * @return the nativer pointer, as long
      */
    public long getNativePointer();

    public String toString();
}

class LdapImpl implements Ldap {

    protected long nativePtr = 0;
    protected transient Object userData = null;
    protected boolean _isConst = false;

    protected LdapImpl(long ptr, boolean isConst) {
        nativePtr = ptr;
        _isConst = isConst;
    }

    public long getNativePointer() {
        return nativePtr;
    }


    public boolean isConst() {
        return _isConst;
    }

    private native Core getCore(long nativePtr);
    @Override @NonNull
    synchronized public Core getCore()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getCore() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Core)getCore(nativePtr);
    }

    private native int getIndex(long nativePtr);
    @Override
    synchronized public int getIndex()  {
        
        
        return getIndex(nativePtr);
    }

    private native void setIndex(long nativePtr, int index);
    @Override
    synchronized public void setIndex(int index)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setIndex() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setIndex(nativePtr, index);
    }

    private native LdapParams getParams(long nativePtr);
    @Override @NonNull
    synchronized public LdapParams getParams()  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call getParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (LdapParams)getParams(nativePtr);
    }

    private native void setParams(long nativePtr, LdapParams params);
    @Override
    synchronized public void setParams(@NonNull LdapParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call setParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        setParams(nativePtr, params);
    }

    private native Ldap newWithParams(long nativePtr, Core lc, LdapParams params);
    @Override @NonNull
    synchronized public Ldap newWithParams(@NonNull Core lc, @NonNull LdapParams params)  {
        
        if (_isConst) {
			try {
				throw new CoreException(this.toString() + " is const! If you want to call newWithParams() on it, clone it first.");
			} catch (CoreException e) {
				Log.e(e);
				for (StackTraceElement st : e.getStackTrace()) {
					Log.e(st);
				}
			}
		}
        return (Ldap)newWithParams(nativePtr, lc, params);
    }

    private native boolean unref(long ptr, boolean isConst);
    protected void finalize() throws Throwable {
        /* Considering the following scenario:
        User scrolls fast in a chat message list that contains a lot of images, 
        so the VM will garbage collect often due to the images taking much space.
        The view itself only has a reference on the EventLogs, not the ChatMessages directly,
        so each call of onBindView will call eventLog.getChatMessage() and the reference will only be temporary.
        It has been observed a race condition in which the JNI level can obtain a LocalRef from a WeakGlobalRef
        of an object that has been scheduled for destruction and for which the finalize() method will be called shortly after.
        The result is a Java object that has been finalized can have it's methods called after the finalize() has terminated.*/
        
        /*The workaround we made here is to keep the nativePtr value even after the unref() only if the object is still reffed by the SDK,
        so the few methods calls following the finalize() will still work because we know the native pointer still exists.*/

        /*This solution will work as long as the objects still have a ref at C level, which is the case with ChatMessages because they are hold by the Events.
        Should we have this problem again in a situation where the C no longer holds a reference (resulting in the C object being destroyed by finalize()), 
        another solution is possible (but more complex to implement).
        This solution would consist in implementing at C level, a queue of belle_sip_object_t that are loosing their last ref. 
        Instead of being deleted immediately by belle_sip_object_unref() calling belle_sip_object_delete(), 
        unref() would place the object onto this "C finalizer queue", the delete() call would then be performed later, 
        by a hook added into the main android looper.
        This solution should work because the actual destruction will be performed from the looper context, 
        so in a place where the local java object causing our troubles no longer exists for sure.
        This solution has however the inconvenience that it can work only within an application that uses a single thread to call liblinphone API.*/
        
        if (nativePtr != 0) {
            boolean destroyed = unref(nativePtr, _isConst);
            if (destroyed) {
                nativePtr = 0;
            }
        }
        super.finalize();
    }

    @Override
    public void setUserData(Object data) {
        userData = data;
    }

    @Override
    public Object getUserData() {
        return userData;
    }

    @Override
    public String toString() {
        return "Java object [" + super.toString() + "], native pointer [" + String.format("0x%08x", nativePtr) + "]";
    }
}
