/*
EventListener.java
Copyright (C) 2010  Belledonne Communications, Grenoble, France

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

package org.linphone.core;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;

/**
* An object to handle the callbacks for handling the LinphoneEvent operations. <br/>
* <br/>
*/
public interface EventListener {
    /**
    * Callback used to notify the response to a sent NOTIFY. <br/>
    * <br/>
    * @param event The {@link Event} object that has sent the NOTIFY and for which we<br/>
    * received a response   <br/>
    */
    public void onNotifyResponse(@NonNull Event event);

    /**
    * Callback used to notify the received to a NOTIFY. <br/>
    * <br/>
    * @param event The LinphoneEvent object that receive the NOTIFY   <br/>
    * @param content The LinphoneContent object that containe the body of the event   <br/>
    */
    public void onNotifyReceived(@NonNull Event event, @Nullable Content content);

    /**
    * Callback used to notify the received to a SUBSCRIBE. <br/>
    * <br/>
    * @param event The LinphoneEvent object that receive the SUBSCRIBE   <br/>
    */
    public void onSubscribeReceived(@NonNull Event event);

    /**
    * SUBSCRIBE state changed callback. <br/>
    * <br/>
    * @param event The {@link Event} object that state changed   <br/>
    * @param state The {@link SubscriptionState} <br/>
    */
    public void onSubscribeStateChanged(@NonNull Event event, SubscriptionState state);

    /**
    * Callback used to notify the received to a PUBLISH. <br/>
    * <br/>
    * @param event The LinphoneEvent object that receive the PUBLISH   <br/>
    * @param content The LinphoneContent object that containe the body of the event   <br/>
    */
    public void onPublishReceived(@NonNull Event event, @Nullable Content content);

    /**
    * PUBLISH state changed callback. <br/>
    * <br/>
    * @param event The LinphoneEvent object that state changed   <br/>
    * @param state The LinphonePublishState <br/>
    */
    public void onPublishStateChanged(@NonNull Event event, PublishState state);

}